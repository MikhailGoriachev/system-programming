﻿namespace CarRentalWF.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniExit = new System.Windows.Forms.ToolStripMenuItem();
            this.TspMain = new System.Windows.Forms.ToolStrip();
            this.TsiInfo = new System.Windows.Forms.ToolStripButton();
            this.TsiAdd = new System.Windows.Forms.ToolStripButton();
            this.TsiEdit = new System.Windows.Forms.ToolStripButton();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.CmsMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiMainInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiMainExit = new System.Windows.Forms.ToolStripMenuItem();
            this.TbpQuery6 = new System.Windows.Forms.TabPage();
            this.GrbQuery6 = new System.Windows.Forms.GroupBox();
            this.TbxQuery6 = new System.Windows.Forms.TextBox();
            this.GbxResult6 = new System.Windows.Forms.GroupBox();
            this.DgvQuery6 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn68 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plateDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rentalDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.countRentalsDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sumRentalsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sumDurationDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.query6ViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TbpQuery5 = new System.Windows.Forms.TabPage();
            this.GrbQuery5 = new System.Windows.Forms.GroupBox();
            this.TbxQuery5 = new System.Windows.Forms.TextBox();
            this.GbxResult5 = new System.Windows.Forms.GroupBox();
            this.DgvQuery5 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn64 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn65 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn66 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn67 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.countRentalsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sumDurationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.query5ViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TbpQuery4 = new System.Windows.Forms.TabPage();
            this.GrbQuery4 = new System.Windows.Forms.GroupBox();
            this.TbxQuery4 = new System.Windows.Forms.TextBox();
            this.GbxResult4 = new System.Windows.Forms.GroupBox();
            this.DgvQuery4 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn63 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateStartDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plateDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rentalDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.durationDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sumPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.query4ViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TbpQuery3 = new System.Windows.Forms.TabPage();
            this.GrbQuery3 = new System.Windows.Forms.GroupBox();
            this.TbxQuery3 = new System.Windows.Forms.TextBox();
            this.GbxResult3 = new System.Windows.Forms.GroupBox();
            this.DgvQuery3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn58 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn59 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn60 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn61 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn62 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TbpQuery2 = new System.Windows.Forms.TabPage();
            this.GrbQuery2 = new System.Windows.Forms.GroupBox();
            this.TbxQuery2 = new System.Windows.Forms.TextBox();
            this.GbxResult2 = new System.Windows.Forms.GroupBox();
            this.DgvQuery2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn52 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn53 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn54 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn55 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn56 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn57 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rentalViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TbpQuery1 = new System.Windows.Forms.TabPage();
            this.GrbQuery1 = new System.Windows.Forms.GroupBox();
            this.TbxQuery1 = new System.Windows.Forms.TextBox();
            this.GbxResult1 = new System.Windows.Forms.GroupBox();
            this.DgvQuery1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TbpRentals = new System.Windows.Forms.TabPage();
            this.GbxRentals = new System.Windows.Forms.GroupBox();
            this.DgvSales = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colorDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rentalDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateStartDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.durationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TbpCars = new System.Windows.Forms.TabPage();
            this.GbxCars = new System.Windows.Forms.GroupBox();
            this.DgvCars = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearManufDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inshurancePayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rentalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carsViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TbpClients = new System.Windows.Forms.TabPage();
            this.GbxClients = new System.Windows.Forms.GroupBox();
            this.DgvClients = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passportDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TbpColors = new System.Windows.Forms.TabPage();
            this.GbxGoods = new System.Windows.Forms.GroupBox();
            this.DgvColors = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.color1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TbpBrands = new System.Windows.Forms.TabPage();
            this.GbxBrands = new System.Windows.Forms.GroupBox();
            this.DgvBrands = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brand1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.unitBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.goodBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sellerBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.purchaseViewModelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.saleViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sellerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.BdsData = new System.Windows.Forms.BindingSource(this.components);
            this.purchaseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sellerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.purchaseViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.saleViewModelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.brandBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.MnsMain.SuspendLayout();
            this.TspMain.SuspendLayout();
            this.CmsMain.SuspendLayout();
            this.TbpQuery6.SuspendLayout();
            this.GrbQuery6.SuspendLayout();
            this.GbxResult6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.query6ViewModelBindingSource)).BeginInit();
            this.TbpQuery5.SuspendLayout();
            this.GrbQuery5.SuspendLayout();
            this.GbxResult5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.query5ViewModelBindingSource)).BeginInit();
            this.TbpQuery4.SuspendLayout();
            this.GrbQuery4.SuspendLayout();
            this.GbxResult4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.query4ViewModelBindingSource)).BeginInit();
            this.TbpQuery3.SuspendLayout();
            this.GrbQuery3.SuspendLayout();
            this.GbxResult3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            this.TbpQuery2.SuspendLayout();
            this.GrbQuery2.SuspendLayout();
            this.GbxResult2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalViewModelBindingSource)).BeginInit();
            this.TbpQuery1.SuspendLayout();
            this.GrbQuery1.SuspendLayout();
            this.GbxResult1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery1)).BeginInit();
            this.TbpRentals.SuspendLayout();
            this.GbxRentals.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSales)).BeginInit();
            this.TbpCars.SuspendLayout();
            this.GbxCars.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvCars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsViewModelBindingSource)).BeginInit();
            this.TbpClients.SuspendLayout();
            this.GbxClients.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvClients)).BeginInit();
            this.TbpColors.SuspendLayout();
            this.GbxGoods.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvColors)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorBindingSource)).BeginInit();
            this.TbpBrands.SuspendLayout();
            this.GbxBrands.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvBrands)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brandBindingSource1)).BeginInit();
            this.TbcMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.unitBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseViewModelBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BdsData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brandBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // MnsMain
            // 
            this.MnsMain.BackColor = System.Drawing.Color.DarkGray;
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.MnsMain.Size = new System.Drawing.Size(1146, 29);
            this.MnsMain.TabIndex = 0;
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniExit});
            this.MniFile.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(59, 25);
            this.MniFile.Text = "&Файл";
            // 
            // MniExit
            // 
            this.MniExit.Name = "MniExit";
            this.MniExit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.MniExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.MniExit.Size = new System.Drawing.Size(182, 26);
            this.MniExit.Text = "&Выход";
            this.MniExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TspMain
            // 
            this.TspMain.BackColor = System.Drawing.Color.Gray;
            this.TspMain.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.TspMain.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.TspMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsiInfo,
            this.TsiAdd,
            this.TsiEdit});
            this.TspMain.Location = new System.Drawing.Point(0, 29);
            this.TspMain.Name = "TspMain";
            this.TspMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.TspMain.Size = new System.Drawing.Size(1146, 39);
            this.TspMain.TabIndex = 2;
            this.TspMain.Text = "toolStrip1";
            // 
            // TsiInfo
            // 
            this.TsiInfo.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsiInfo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsiInfo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsiInfo.Margin = new System.Windows.Forms.Padding(0, 1, 5, 2);
            this.TsiInfo.Name = "TsiInfo";
            this.TsiInfo.Size = new System.Drawing.Size(23, 36);
            this.TsiInfo.Text = "О программе...";
            this.TsiInfo.Click += new System.EventHandler(this.Info_Command);
            // 
            // TsiAdd
            // 
            this.TsiAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsiAdd.Image = global::CarRentalWF.Properties.Resources.table_add;
            this.TsiAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsiAdd.Margin = new System.Windows.Forms.Padding(10, 1, 0, 2);
            this.TsiAdd.Name = "TsiAdd";
            this.TsiAdd.Size = new System.Drawing.Size(36, 36);
            this.TsiAdd.Text = "Добавить запись...";
            this.TsiAdd.Click += new System.EventHandler(this.Add_Command);
            // 
            // TsiEdit
            // 
            this.TsiEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsiEdit.Image = global::CarRentalWF.Properties.Resources.table_edit;
            this.TsiEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsiEdit.Name = "TsiEdit";
            this.TsiEdit.Size = new System.Drawing.Size(36, 36);
            this.TsiEdit.Text = "Редактировать выбранную запись...";
            this.TsiEdit.Click += new System.EventHandler(this.Edit_Command);
            // 
            // StsMain
            // 
            this.StsMain.BackColor = System.Drawing.Color.DarkGray;
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Location = new System.Drawing.Point(0, 499);
            this.StsMain.Name = "StsMain";
            this.StsMain.Padding = new System.Windows.Forms.Padding(1, 0, 16, 0);
            this.StsMain.Size = new System.Drawing.Size(1146, 22);
            this.StsMain.TabIndex = 3;
            // 
            // CmsMain
            // 
            this.CmsMain.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.CmsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiMainInfo,
            this.toolStripMenuItem3,
            this.CmiMainExit});
            this.CmsMain.Name = "CmsMain";
            this.CmsMain.Size = new System.Drawing.Size(202, 54);
            // 
            // CmiMainInfo
            // 
            this.CmiMainInfo.Name = "CmiMainInfo";
            this.CmiMainInfo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.CmiMainInfo.Size = new System.Drawing.Size(201, 22);
            this.CmiMainInfo.Text = "&О программе...";
            this.CmiMainInfo.Click += new System.EventHandler(this.Info_Command);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(198, 6);
            // 
            // CmiMainExit
            // 
            this.CmiMainExit.Name = "CmiMainExit";
            this.CmiMainExit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CmiMainExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.CmiMainExit.Size = new System.Drawing.Size(201, 22);
            this.CmiMainExit.Text = "&Выход";
            this.CmiMainExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TbpQuery6
            // 
            this.TbpQuery6.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery6.Controls.Add(this.GrbQuery6);
            this.TbpQuery6.Controls.Add(this.GbxResult6);
            this.TbpQuery6.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery6.Name = "TbpQuery6";
            this.TbpQuery6.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery6.Size = new System.Drawing.Size(1138, 402);
            this.TbpQuery6.TabIndex = 6;
            this.TbpQuery6.Text = "Запрос №6";
            // 
            // GrbQuery6
            // 
            this.GrbQuery6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery6.Controls.Add(this.TbxQuery6);
            this.GrbQuery6.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery6.ForeColor = System.Drawing.Color.White;
            this.GrbQuery6.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery6.Name = "GrbQuery6";
            this.GrbQuery6.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery6.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery6.TabIndex = 0;
            this.GrbQuery6.TabStop = false;
            this.GrbQuery6.Text = " Информация о запросе ";
            // 
            // TbxQuery6
            // 
            this.TbxQuery6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery6.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery6.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery6.Multiline = true;
            this.TbxQuery6.Name = "TbxQuery6";
            this.TbxQuery6.ReadOnly = true;
            this.TbxQuery6.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery6.TabIndex = 0;
            this.TbxQuery6.TabStop = false;
            this.TbxQuery6.Text = "6. Для всех автомобилей прокатной фирмы определите количество фактов проката, сум" +
    "ма за прокаты, суммарная длительность прокатов";
            // 
            // GbxResult6
            // 
            this.GbxResult6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult6.Controls.Add(this.DgvQuery6);
            this.GbxResult6.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult6.ForeColor = System.Drawing.Color.White;
            this.GbxResult6.Location = new System.Drawing.Point(8, 152);
            this.GbxResult6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult6.Name = "GbxResult6";
            this.GbxResult6.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult6.Size = new System.Drawing.Size(1119, 243);
            this.GbxResult6.TabIndex = 1;
            this.GbxResult6.TabStop = false;
            this.GbxResult6.Text = " Результат ";
            // 
            // DgvQuery6
            // 
            this.DgvQuery6.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery6.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DgvQuery6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery6.AutoGenerateColumns = false;
            this.DgvQuery6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery6.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn68,
            this.brandDataGridViewTextBoxColumn3,
            this.plateDataGridViewTextBoxColumn3,
            this.rentalDataGridViewTextBoxColumn3,
            this.countRentalsDataGridViewTextBoxColumn1,
            this.sumRentalsDataGridViewTextBoxColumn,
            this.sumDurationDataGridViewTextBoxColumn1});
            this.DgvQuery6.DataSource = this.query6ViewModelBindingSource;
            this.DgvQuery6.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery6.Name = "DgvQuery6";
            this.DgvQuery6.ReadOnly = true;
            this.DgvQuery6.RowHeadersVisible = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery6.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.DgvQuery6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery6.Size = new System.Drawing.Size(1102, 211);
            this.DgvQuery6.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn68
            // 
            this.dataGridViewTextBoxColumn68.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn68.HeaderText = "Id";
            this.dataGridViewTextBoxColumn68.Name = "dataGridViewTextBoxColumn68";
            this.dataGridViewTextBoxColumn68.ReadOnly = true;
            // 
            // brandDataGridViewTextBoxColumn3
            // 
            this.brandDataGridViewTextBoxColumn3.DataPropertyName = "Brand";
            this.brandDataGridViewTextBoxColumn3.HeaderText = "Модель";
            this.brandDataGridViewTextBoxColumn3.Name = "brandDataGridViewTextBoxColumn3";
            this.brandDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // plateDataGridViewTextBoxColumn3
            // 
            this.plateDataGridViewTextBoxColumn3.DataPropertyName = "Plate";
            this.plateDataGridViewTextBoxColumn3.HeaderText = "Госномер";
            this.plateDataGridViewTextBoxColumn3.Name = "plateDataGridViewTextBoxColumn3";
            this.plateDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // rentalDataGridViewTextBoxColumn3
            // 
            this.rentalDataGridViewTextBoxColumn3.DataPropertyName = "Rental";
            this.rentalDataGridViewTextBoxColumn3.HeaderText = "Стоимость / день";
            this.rentalDataGridViewTextBoxColumn3.Name = "rentalDataGridViewTextBoxColumn3";
            this.rentalDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // countRentalsDataGridViewTextBoxColumn1
            // 
            this.countRentalsDataGridViewTextBoxColumn1.DataPropertyName = "CountRentals";
            this.countRentalsDataGridViewTextBoxColumn1.HeaderText = "Количество прокатов";
            this.countRentalsDataGridViewTextBoxColumn1.Name = "countRentalsDataGridViewTextBoxColumn1";
            this.countRentalsDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // sumRentalsDataGridViewTextBoxColumn
            // 
            this.sumRentalsDataGridViewTextBoxColumn.DataPropertyName = "SumRentals";
            this.sumRentalsDataGridViewTextBoxColumn.HeaderText = "Сумма";
            this.sumRentalsDataGridViewTextBoxColumn.Name = "sumRentalsDataGridViewTextBoxColumn";
            this.sumRentalsDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sumDurationDataGridViewTextBoxColumn1
            // 
            this.sumDurationDataGridViewTextBoxColumn1.DataPropertyName = "SumDuration";
            this.sumDurationDataGridViewTextBoxColumn1.HeaderText = "Длительность";
            this.sumDurationDataGridViewTextBoxColumn1.Name = "sumDurationDataGridViewTextBoxColumn1";
            this.sumDurationDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // query6ViewModelBindingSource
            // 
            this.query6ViewModelBindingSource.DataSource = typeof(CarRentalLibrary.Models.ViewModels.Query6ViewModel);
            // 
            // TbpQuery5
            // 
            this.TbpQuery5.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery5.Controls.Add(this.GrbQuery5);
            this.TbpQuery5.Controls.Add(this.GbxResult5);
            this.TbpQuery5.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery5.Name = "TbpQuery5";
            this.TbpQuery5.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery5.Size = new System.Drawing.Size(1138, 402);
            this.TbpQuery5.TabIndex = 5;
            this.TbpQuery5.Text = "Запрос №5";
            // 
            // GrbQuery5
            // 
            this.GrbQuery5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery5.Controls.Add(this.TbxQuery5);
            this.GrbQuery5.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery5.ForeColor = System.Drawing.Color.White;
            this.GrbQuery5.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery5.Name = "GrbQuery5";
            this.GrbQuery5.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery5.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery5.TabIndex = 0;
            this.GrbQuery5.TabStop = false;
            this.GrbQuery5.Text = " Информация о запросе ";
            // 
            // TbxQuery5
            // 
            this.TbxQuery5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery5.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery5.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery5.Multiline = true;
            this.TbxQuery5.Name = "TbxQuery5";
            this.TbxQuery5.ReadOnly = true;
            this.TbxQuery5.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery5.TabIndex = 0;
            this.TbxQuery5.TabStop = false;
            this.TbxQuery5.Text = "5. Для всех клиентов прокатной фирмы вычисляет количество фактов проката, суммарн" +
    "ое количество дней проката, упорядочивание по убыванию суммарного количества дне" +
    "й проката";
            // 
            // GbxResult5
            // 
            this.GbxResult5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult5.Controls.Add(this.DgvQuery5);
            this.GbxResult5.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult5.ForeColor = System.Drawing.Color.White;
            this.GbxResult5.Location = new System.Drawing.Point(8, 152);
            this.GbxResult5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult5.Name = "GbxResult5";
            this.GbxResult5.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult5.Size = new System.Drawing.Size(1119, 243);
            this.GbxResult5.TabIndex = 1;
            this.GbxResult5.TabStop = false;
            this.GbxResult5.Text = " Результат ";
            // 
            // DgvQuery5
            // 
            this.DgvQuery5.AllowUserToResizeRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery5.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.DgvQuery5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery5.AutoGenerateColumns = false;
            this.DgvQuery5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn64,
            this.dataGridViewTextBoxColumn65,
            this.dataGridViewTextBoxColumn66,
            this.dataGridViewTextBoxColumn67,
            this.countRentalsDataGridViewTextBoxColumn,
            this.sumDurationDataGridViewTextBoxColumn});
            this.DgvQuery5.DataSource = this.query5ViewModelBindingSource;
            this.DgvQuery5.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery5.Name = "DgvQuery5";
            this.DgvQuery5.ReadOnly = true;
            this.DgvQuery5.RowHeadersVisible = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery5.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.DgvQuery5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery5.Size = new System.Drawing.Size(1102, 211);
            this.DgvQuery5.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn64
            // 
            this.dataGridViewTextBoxColumn64.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn64.HeaderText = "Id";
            this.dataGridViewTextBoxColumn64.Name = "dataGridViewTextBoxColumn64";
            this.dataGridViewTextBoxColumn64.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn65
            // 
            this.dataGridViewTextBoxColumn65.DataPropertyName = "Surname";
            this.dataGridViewTextBoxColumn65.HeaderText = "Фамилия";
            this.dataGridViewTextBoxColumn65.Name = "dataGridViewTextBoxColumn65";
            this.dataGridViewTextBoxColumn65.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn66
            // 
            this.dataGridViewTextBoxColumn66.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn66.HeaderText = "Имя";
            this.dataGridViewTextBoxColumn66.Name = "dataGridViewTextBoxColumn66";
            this.dataGridViewTextBoxColumn66.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn67
            // 
            this.dataGridViewTextBoxColumn67.DataPropertyName = "Patronymic";
            this.dataGridViewTextBoxColumn67.HeaderText = "Отчество";
            this.dataGridViewTextBoxColumn67.Name = "dataGridViewTextBoxColumn67";
            this.dataGridViewTextBoxColumn67.ReadOnly = true;
            // 
            // countRentalsDataGridViewTextBoxColumn
            // 
            this.countRentalsDataGridViewTextBoxColumn.DataPropertyName = "CountRentals";
            this.countRentalsDataGridViewTextBoxColumn.HeaderText = "Количество прокатов";
            this.countRentalsDataGridViewTextBoxColumn.Name = "countRentalsDataGridViewTextBoxColumn";
            this.countRentalsDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sumDurationDataGridViewTextBoxColumn
            // 
            this.sumDurationDataGridViewTextBoxColumn.DataPropertyName = "SumDuration";
            this.sumDurationDataGridViewTextBoxColumn.HeaderText = "Длительность";
            this.sumDurationDataGridViewTextBoxColumn.Name = "sumDurationDataGridViewTextBoxColumn";
            this.sumDurationDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // query5ViewModelBindingSource
            // 
            this.query5ViewModelBindingSource.DataSource = typeof(CarRentalLibrary.Models.ViewModels.Query5ViewModel);
            // 
            // TbpQuery4
            // 
            this.TbpQuery4.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery4.Controls.Add(this.GrbQuery4);
            this.TbpQuery4.Controls.Add(this.GbxResult4);
            this.TbpQuery4.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery4.Name = "TbpQuery4";
            this.TbpQuery4.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery4.Size = new System.Drawing.Size(1138, 402);
            this.TbpQuery4.TabIndex = 4;
            this.TbpQuery4.Text = "Запрос №4";
            // 
            // GrbQuery4
            // 
            this.GrbQuery4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery4.Controls.Add(this.TbxQuery4);
            this.GrbQuery4.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery4.ForeColor = System.Drawing.Color.White;
            this.GrbQuery4.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery4.Name = "GrbQuery4";
            this.GrbQuery4.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery4.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery4.TabIndex = 0;
            this.GrbQuery4.TabStop = false;
            this.GrbQuery4.Text = " Информация о запросе ";
            // 
            // TbxQuery4
            // 
            this.TbxQuery4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery4.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery4.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery4.Multiline = true;
            this.TbxQuery4.Name = "TbxQuery4";
            this.TbxQuery4.ReadOnly = true;
            this.TbxQuery4.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery4.TabIndex = 0;
            this.TbxQuery4.TabStop = false;
            this.TbxQuery4.Text = "4. Вычисляет для каждого факта проката стоимость проката. Включает поля Дата прок" +
    "ата, Госномер автомобиля, Модель автомобиля, Стоимость проката. Сортировка по по" +
    "лю Дата проката";
            // 
            // GbxResult4
            // 
            this.GbxResult4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult4.Controls.Add(this.DgvQuery4);
            this.GbxResult4.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult4.ForeColor = System.Drawing.Color.White;
            this.GbxResult4.Location = new System.Drawing.Point(8, 152);
            this.GbxResult4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult4.Name = "GbxResult4";
            this.GbxResult4.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult4.Size = new System.Drawing.Size(1119, 243);
            this.GbxResult4.TabIndex = 1;
            this.GbxResult4.TabStop = false;
            this.GbxResult4.Text = " Результат ";
            // 
            // DgvQuery4
            // 
            this.DgvQuery4.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery4.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.DgvQuery4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery4.AutoGenerateColumns = false;
            this.DgvQuery4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn63,
            this.dateStartDataGridViewTextBoxColumn1,
            this.plateDataGridViewTextBoxColumn2,
            this.brandDataGridViewTextBoxColumn2,
            this.rentalDataGridViewTextBoxColumn2,
            this.durationDataGridViewTextBoxColumn1,
            this.sumPriceDataGridViewTextBoxColumn});
            this.DgvQuery4.DataSource = this.query4ViewModelBindingSource;
            this.DgvQuery4.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery4.Name = "DgvQuery4";
            this.DgvQuery4.ReadOnly = true;
            this.DgvQuery4.RowHeadersVisible = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery4.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.DgvQuery4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery4.Size = new System.Drawing.Size(1102, 211);
            this.DgvQuery4.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn63
            // 
            this.dataGridViewTextBoxColumn63.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn63.HeaderText = "Id";
            this.dataGridViewTextBoxColumn63.Name = "dataGridViewTextBoxColumn63";
            this.dataGridViewTextBoxColumn63.ReadOnly = true;
            // 
            // dateStartDataGridViewTextBoxColumn1
            // 
            this.dateStartDataGridViewTextBoxColumn1.DataPropertyName = "DateStart";
            this.dateStartDataGridViewTextBoxColumn1.HeaderText = "Дата";
            this.dateStartDataGridViewTextBoxColumn1.Name = "dateStartDataGridViewTextBoxColumn1";
            this.dateStartDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // plateDataGridViewTextBoxColumn2
            // 
            this.plateDataGridViewTextBoxColumn2.DataPropertyName = "Plate";
            this.plateDataGridViewTextBoxColumn2.HeaderText = "Госномер";
            this.plateDataGridViewTextBoxColumn2.Name = "plateDataGridViewTextBoxColumn2";
            this.plateDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // brandDataGridViewTextBoxColumn2
            // 
            this.brandDataGridViewTextBoxColumn2.DataPropertyName = "Brand";
            this.brandDataGridViewTextBoxColumn2.HeaderText = "Модель";
            this.brandDataGridViewTextBoxColumn2.Name = "brandDataGridViewTextBoxColumn2";
            this.brandDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // rentalDataGridViewTextBoxColumn2
            // 
            this.rentalDataGridViewTextBoxColumn2.DataPropertyName = "Rental";
            this.rentalDataGridViewTextBoxColumn2.HeaderText = "Стоимость / день";
            this.rentalDataGridViewTextBoxColumn2.Name = "rentalDataGridViewTextBoxColumn2";
            this.rentalDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // durationDataGridViewTextBoxColumn1
            // 
            this.durationDataGridViewTextBoxColumn1.DataPropertyName = "Duration";
            this.durationDataGridViewTextBoxColumn1.HeaderText = "Длительность";
            this.durationDataGridViewTextBoxColumn1.Name = "durationDataGridViewTextBoxColumn1";
            this.durationDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // sumPriceDataGridViewTextBoxColumn
            // 
            this.sumPriceDataGridViewTextBoxColumn.DataPropertyName = "SumPrice";
            this.sumPriceDataGridViewTextBoxColumn.HeaderText = "Сумма";
            this.sumPriceDataGridViewTextBoxColumn.Name = "sumPriceDataGridViewTextBoxColumn";
            this.sumPriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // query4ViewModelBindingSource
            // 
            this.query4ViewModelBindingSource.DataSource = typeof(CarRentalLibrary.Models.ViewModels.Query4ViewModel);
            // 
            // TbpQuery3
            // 
            this.TbpQuery3.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery3.Controls.Add(this.GrbQuery3);
            this.TbpQuery3.Controls.Add(this.GbxResult3);
            this.TbpQuery3.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery3.Name = "TbpQuery3";
            this.TbpQuery3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery3.Size = new System.Drawing.Size(1138, 402);
            this.TbpQuery3.TabIndex = 3;
            this.TbpQuery3.Text = "Запрос №3";
            // 
            // GrbQuery3
            // 
            this.GrbQuery3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery3.Controls.Add(this.TbxQuery3);
            this.GrbQuery3.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery3.ForeColor = System.Drawing.Color.White;
            this.GrbQuery3.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery3.Name = "GrbQuery3";
            this.GrbQuery3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery3.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery3.TabIndex = 0;
            this.GrbQuery3.TabStop = false;
            this.GrbQuery3.Text = " Информация о запросе ";
            // 
            // TbxQuery3
            // 
            this.TbxQuery3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery3.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery3.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery3.Multiline = true;
            this.TbxQuery3.Name = "TbxQuery3";
            this.TbxQuery3.ReadOnly = true;
            this.TbxQuery3.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery3.TabIndex = 0;
            this.TbxQuery3.TabStop = false;
            this.TbxQuery3.Text = "3. Выбирает информацию о клиентах по серии и номеру паспорта\r\n\r\nЗаданный номер и " +
    "серия паспорта: значение ";
            // 
            // GbxResult3
            // 
            this.GbxResult3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult3.Controls.Add(this.DgvQuery3);
            this.GbxResult3.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult3.ForeColor = System.Drawing.Color.White;
            this.GbxResult3.Location = new System.Drawing.Point(8, 152);
            this.GbxResult3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult3.Name = "GbxResult3";
            this.GbxResult3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult3.Size = new System.Drawing.Size(1119, 243);
            this.GbxResult3.TabIndex = 1;
            this.GbxResult3.TabStop = false;
            this.GbxResult3.Text = " Результат ";
            // 
            // DgvQuery3
            // 
            this.DgvQuery3.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.DgvQuery3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery3.AutoGenerateColumns = false;
            this.DgvQuery3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn58,
            this.dataGridViewTextBoxColumn59,
            this.dataGridViewTextBoxColumn60,
            this.dataGridViewTextBoxColumn61,
            this.dataGridViewTextBoxColumn62});
            this.DgvQuery3.DataSource = this.clientBindingSource;
            this.DgvQuery3.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery3.Name = "DgvQuery3";
            this.DgvQuery3.ReadOnly = true;
            this.DgvQuery3.RowHeadersVisible = false;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery3.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.DgvQuery3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery3.Size = new System.Drawing.Size(1101, 210);
            this.DgvQuery3.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn58
            // 
            this.dataGridViewTextBoxColumn58.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn58.HeaderText = "Id";
            this.dataGridViewTextBoxColumn58.Name = "dataGridViewTextBoxColumn58";
            this.dataGridViewTextBoxColumn58.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn59
            // 
            this.dataGridViewTextBoxColumn59.DataPropertyName = "Surname";
            this.dataGridViewTextBoxColumn59.HeaderText = "Фамилия";
            this.dataGridViewTextBoxColumn59.Name = "dataGridViewTextBoxColumn59";
            this.dataGridViewTextBoxColumn59.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn60
            // 
            this.dataGridViewTextBoxColumn60.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn60.HeaderText = "Имя";
            this.dataGridViewTextBoxColumn60.Name = "dataGridViewTextBoxColumn60";
            this.dataGridViewTextBoxColumn60.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn61
            // 
            this.dataGridViewTextBoxColumn61.DataPropertyName = "Patronymic";
            this.dataGridViewTextBoxColumn61.HeaderText = "Отчество";
            this.dataGridViewTextBoxColumn61.Name = "dataGridViewTextBoxColumn61";
            this.dataGridViewTextBoxColumn61.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn62
            // 
            this.dataGridViewTextBoxColumn62.DataPropertyName = "Passport";
            this.dataGridViewTextBoxColumn62.HeaderText = "Паспорт";
            this.dataGridViewTextBoxColumn62.Name = "dataGridViewTextBoxColumn62";
            this.dataGridViewTextBoxColumn62.ReadOnly = true;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataSource = typeof(CarRentalLibrary.Models.Client);
            // 
            // TbpQuery2
            // 
            this.TbpQuery2.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery2.Controls.Add(this.GrbQuery2);
            this.TbpQuery2.Controls.Add(this.GbxResult2);
            this.TbpQuery2.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery2.Name = "TbpQuery2";
            this.TbpQuery2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery2.Size = new System.Drawing.Size(1138, 402);
            this.TbpQuery2.TabIndex = 2;
            this.TbpQuery2.Text = "Запрос №2";
            // 
            // GrbQuery2
            // 
            this.GrbQuery2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery2.Controls.Add(this.TbxQuery2);
            this.GrbQuery2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery2.ForeColor = System.Drawing.Color.White;
            this.GrbQuery2.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery2.Name = "GrbQuery2";
            this.GrbQuery2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery2.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery2.TabIndex = 0;
            this.GrbQuery2.TabStop = false;
            this.GrbQuery2.Text = " Информация о запросе ";
            // 
            // TbxQuery2
            // 
            this.TbxQuery2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery2.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery2.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery2.Multiline = true;
            this.TbxQuery2.Name = "TbxQuery2";
            this.TbxQuery2.ReadOnly = true;
            this.TbxQuery2.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery2.TabIndex = 0;
            this.TbxQuery2.Text = "2. Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брен" +
    "дом\r\n\r\nЗаданная модель/бренд: значение\r\n\r\n";
            // 
            // GbxResult2
            // 
            this.GbxResult2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult2.Controls.Add(this.DgvQuery2);
            this.GbxResult2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult2.ForeColor = System.Drawing.Color.White;
            this.GbxResult2.Location = new System.Drawing.Point(8, 152);
            this.GbxResult2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult2.Name = "GbxResult2";
            this.GbxResult2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult2.Size = new System.Drawing.Size(1119, 243);
            this.GbxResult2.TabIndex = 1;
            this.GbxResult2.TabStop = false;
            this.GbxResult2.Text = " Результат ";
            // 
            // DgvQuery2
            // 
            this.DgvQuery2.AllowUserToResizeRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.DgvQuery2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery2.AutoGenerateColumns = false;
            this.DgvQuery2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn50,
            this.dataGridViewTextBoxColumn51,
            this.dataGridViewTextBoxColumn52,
            this.dataGridViewTextBoxColumn53,
            this.dataGridViewTextBoxColumn54,
            this.dataGridViewTextBoxColumn55,
            this.dataGridViewTextBoxColumn56,
            this.dataGridViewTextBoxColumn57});
            this.DgvQuery2.DataSource = this.rentalViewModelBindingSource;
            this.DgvQuery2.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery2.Name = "DgvQuery2";
            this.DgvQuery2.ReadOnly = true;
            this.DgvQuery2.RowHeadersVisible = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery2.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.DgvQuery2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery2.Size = new System.Drawing.Size(1102, 210);
            this.DgvQuery2.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn50
            // 
            this.dataGridViewTextBoxColumn50.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn50.HeaderText = "Id";
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            this.dataGridViewTextBoxColumn50.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn51
            // 
            this.dataGridViewTextBoxColumn51.DataPropertyName = "Client";
            this.dataGridViewTextBoxColumn51.HeaderText = "Клиент";
            this.dataGridViewTextBoxColumn51.Name = "dataGridViewTextBoxColumn51";
            this.dataGridViewTextBoxColumn51.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn52
            // 
            this.dataGridViewTextBoxColumn52.DataPropertyName = "Brand";
            this.dataGridViewTextBoxColumn52.HeaderText = "Модель";
            this.dataGridViewTextBoxColumn52.Name = "dataGridViewTextBoxColumn52";
            this.dataGridViewTextBoxColumn52.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn53
            // 
            this.dataGridViewTextBoxColumn53.DataPropertyName = "Color";
            this.dataGridViewTextBoxColumn53.HeaderText = "Цвет";
            this.dataGridViewTextBoxColumn53.Name = "dataGridViewTextBoxColumn53";
            this.dataGridViewTextBoxColumn53.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn54
            // 
            this.dataGridViewTextBoxColumn54.DataPropertyName = "Plate";
            this.dataGridViewTextBoxColumn54.HeaderText = "Госномер";
            this.dataGridViewTextBoxColumn54.Name = "dataGridViewTextBoxColumn54";
            this.dataGridViewTextBoxColumn54.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn55
            // 
            this.dataGridViewTextBoxColumn55.DataPropertyName = "Rental";
            this.dataGridViewTextBoxColumn55.HeaderText = "Стоимость / день";
            this.dataGridViewTextBoxColumn55.Name = "dataGridViewTextBoxColumn55";
            this.dataGridViewTextBoxColumn55.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn56
            // 
            this.dataGridViewTextBoxColumn56.DataPropertyName = "DateStart";
            this.dataGridViewTextBoxColumn56.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn56.Name = "dataGridViewTextBoxColumn56";
            this.dataGridViewTextBoxColumn56.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn57
            // 
            this.dataGridViewTextBoxColumn57.DataPropertyName = "Duration";
            this.dataGridViewTextBoxColumn57.HeaderText = "Длительность (день)";
            this.dataGridViewTextBoxColumn57.Name = "dataGridViewTextBoxColumn57";
            this.dataGridViewTextBoxColumn57.ReadOnly = true;
            // 
            // rentalViewModelBindingSource
            // 
            this.rentalViewModelBindingSource.DataSource = typeof(CarRentalLibrary.Models.ViewModels.RentalViewModel);
            // 
            // TbpQuery1
            // 
            this.TbpQuery1.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery1.Controls.Add(this.GrbQuery1);
            this.TbpQuery1.Controls.Add(this.GbxResult1);
            this.TbpQuery1.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery1.Name = "TbpQuery1";
            this.TbpQuery1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery1.Size = new System.Drawing.Size(1138, 402);
            this.TbpQuery1.TabIndex = 1;
            this.TbpQuery1.Text = "Запрос №1";
            // 
            // GrbQuery1
            // 
            this.GrbQuery1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery1.Controls.Add(this.TbxQuery1);
            this.GrbQuery1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery1.ForeColor = System.Drawing.Color.White;
            this.GrbQuery1.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery1.Name = "GrbQuery1";
            this.GrbQuery1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery1.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery1.TabIndex = 0;
            this.GrbQuery1.TabStop = false;
            this.GrbQuery1.Text = " Информация о запросе ";
            // 
            // TbxQuery1
            // 
            this.TbxQuery1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery1.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery1.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery1.Multiline = true;
            this.TbxQuery1.Name = "TbxQuery1";
            this.TbxQuery1.ReadOnly = true;
            this.TbxQuery1.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery1.TabIndex = 0;
            this.TbxQuery1.TabStop = false;
            this.TbxQuery1.Text = "1. Выбирает информацию обо всех фактах проката автомобиля с заданным госномером\r\n" +
    "\r\nЗаданный госномер: значение";
            // 
            // GbxResult1
            // 
            this.GbxResult1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult1.Controls.Add(this.DgvQuery1);
            this.GbxResult1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult1.ForeColor = System.Drawing.Color.White;
            this.GbxResult1.Location = new System.Drawing.Point(8, 152);
            this.GbxResult1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult1.Name = "GbxResult1";
            this.GbxResult1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult1.Size = new System.Drawing.Size(1119, 243);
            this.GbxResult1.TabIndex = 1;
            this.GbxResult1.TabStop = false;
            this.GbxResult1.Text = " Результат ";
            // 
            // DgvQuery1
            // 
            this.DgvQuery1.AllowUserToResizeRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.DgvQuery1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery1.AutoGenerateColumns = false;
            this.DgvQuery1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn42,
            this.dataGridViewTextBoxColumn43,
            this.dataGridViewTextBoxColumn44,
            this.dataGridViewTextBoxColumn45,
            this.dataGridViewTextBoxColumn46,
            this.dataGridViewTextBoxColumn47,
            this.dataGridViewTextBoxColumn48,
            this.dataGridViewTextBoxColumn49});
            this.DgvQuery1.DataSource = this.rentalViewModelBindingSource;
            this.DgvQuery1.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery1.Name = "DgvQuery1";
            this.DgvQuery1.ReadOnly = true;
            this.DgvQuery1.RowHeadersVisible = false;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery1.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.DgvQuery1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery1.Size = new System.Drawing.Size(1102, 210);
            this.DgvQuery1.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn42.HeaderText = "Id";
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            this.dataGridViewTextBoxColumn42.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.DataPropertyName = "Client";
            this.dataGridViewTextBoxColumn43.HeaderText = "Клиент";
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            this.dataGridViewTextBoxColumn43.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.DataPropertyName = "Brand";
            this.dataGridViewTextBoxColumn44.HeaderText = "Модель";
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            this.dataGridViewTextBoxColumn44.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.DataPropertyName = "Color";
            this.dataGridViewTextBoxColumn45.HeaderText = "Цвет";
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            this.dataGridViewTextBoxColumn45.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn46
            // 
            this.dataGridViewTextBoxColumn46.DataPropertyName = "Plate";
            this.dataGridViewTextBoxColumn46.HeaderText = "Госномер";
            this.dataGridViewTextBoxColumn46.Name = "dataGridViewTextBoxColumn46";
            this.dataGridViewTextBoxColumn46.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.DataPropertyName = "Rental";
            this.dataGridViewTextBoxColumn47.HeaderText = "Стоимость / день";
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            this.dataGridViewTextBoxColumn47.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.DataPropertyName = "DateStart";
            this.dataGridViewTextBoxColumn48.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            this.dataGridViewTextBoxColumn48.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn49
            // 
            this.dataGridViewTextBoxColumn49.DataPropertyName = "Duration";
            this.dataGridViewTextBoxColumn49.HeaderText = "Длительность (день)";
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            this.dataGridViewTextBoxColumn49.ReadOnly = true;
            // 
            // TbpRentals
            // 
            this.TbpRentals.BackColor = System.Drawing.Color.Gray;
            this.TbpRentals.Controls.Add(this.GbxRentals);
            this.TbpRentals.Location = new System.Drawing.Point(4, 25);
            this.TbpRentals.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpRentals.Name = "TbpRentals";
            this.TbpRentals.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpRentals.Size = new System.Drawing.Size(1138, 402);
            this.TbpRentals.TabIndex = 13;
            this.TbpRentals.Text = "Факты проката";
            // 
            // GbxRentals
            // 
            this.GbxRentals.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxRentals.Controls.Add(this.DgvSales);
            this.GbxRentals.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxRentals.ForeColor = System.Drawing.Color.White;
            this.GbxRentals.Location = new System.Drawing.Point(8, 8);
            this.GbxRentals.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxRentals.Name = "GbxRentals";
            this.GbxRentals.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxRentals.Size = new System.Drawing.Size(1119, 391);
            this.GbxRentals.TabIndex = 1;
            this.GbxRentals.TabStop = false;
            this.GbxRentals.Text = " Содержание таблицы \"Факты проката\" ";
            // 
            // DgvSales
            // 
            this.DgvSales.AllowUserToResizeRows = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvSales.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.DgvSales.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvSales.AutoGenerateColumns = false;
            this.DgvSales.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvSales.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvSales.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvSales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvSales.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn41,
            this.clientDataGridViewTextBoxColumn,
            this.brandDataGridViewTextBoxColumn1,
            this.colorDataGridViewTextBoxColumn1,
            this.plateDataGridViewTextBoxColumn1,
            this.rentalDataGridViewTextBoxColumn1,
            this.dateStartDataGridViewTextBoxColumn,
            this.durationDataGridViewTextBoxColumn});
            this.DgvSales.DataSource = this.rentalViewModelBindingSource;
            this.DgvSales.Location = new System.Drawing.Point(8, 24);
            this.DgvSales.Name = "DgvSales";
            this.DgvSales.ReadOnly = true;
            this.DgvSales.RowHeadersVisible = false;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
            this.DgvSales.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.DgvSales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvSales.Size = new System.Drawing.Size(1102, 359);
            this.DgvSales.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn41.HeaderText = "Id";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            this.dataGridViewTextBoxColumn41.ReadOnly = true;
            // 
            // clientDataGridViewTextBoxColumn
            // 
            this.clientDataGridViewTextBoxColumn.DataPropertyName = "Client";
            this.clientDataGridViewTextBoxColumn.HeaderText = "Клиент";
            this.clientDataGridViewTextBoxColumn.Name = "clientDataGridViewTextBoxColumn";
            this.clientDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // brandDataGridViewTextBoxColumn1
            // 
            this.brandDataGridViewTextBoxColumn1.DataPropertyName = "Brand";
            this.brandDataGridViewTextBoxColumn1.HeaderText = "Модель";
            this.brandDataGridViewTextBoxColumn1.Name = "brandDataGridViewTextBoxColumn1";
            this.brandDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // colorDataGridViewTextBoxColumn1
            // 
            this.colorDataGridViewTextBoxColumn1.DataPropertyName = "Color";
            this.colorDataGridViewTextBoxColumn1.HeaderText = "Цвет";
            this.colorDataGridViewTextBoxColumn1.Name = "colorDataGridViewTextBoxColumn1";
            this.colorDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // plateDataGridViewTextBoxColumn1
            // 
            this.plateDataGridViewTextBoxColumn1.DataPropertyName = "Plate";
            this.plateDataGridViewTextBoxColumn1.HeaderText = "Госномер";
            this.plateDataGridViewTextBoxColumn1.Name = "plateDataGridViewTextBoxColumn1";
            this.plateDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // rentalDataGridViewTextBoxColumn1
            // 
            this.rentalDataGridViewTextBoxColumn1.DataPropertyName = "Rental";
            this.rentalDataGridViewTextBoxColumn1.HeaderText = "Стоимость / день";
            this.rentalDataGridViewTextBoxColumn1.Name = "rentalDataGridViewTextBoxColumn1";
            this.rentalDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dateStartDataGridViewTextBoxColumn
            // 
            this.dateStartDataGridViewTextBoxColumn.DataPropertyName = "DateStart";
            this.dateStartDataGridViewTextBoxColumn.HeaderText = "Дата";
            this.dateStartDataGridViewTextBoxColumn.Name = "dateStartDataGridViewTextBoxColumn";
            this.dateStartDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // durationDataGridViewTextBoxColumn
            // 
            this.durationDataGridViewTextBoxColumn.DataPropertyName = "Duration";
            this.durationDataGridViewTextBoxColumn.HeaderText = "Длительность (день)";
            this.durationDataGridViewTextBoxColumn.Name = "durationDataGridViewTextBoxColumn";
            this.durationDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // TbpCars
            // 
            this.TbpCars.BackColor = System.Drawing.Color.Gray;
            this.TbpCars.Controls.Add(this.GbxCars);
            this.TbpCars.Location = new System.Drawing.Point(4, 25);
            this.TbpCars.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpCars.Name = "TbpCars";
            this.TbpCars.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpCars.Size = new System.Drawing.Size(1138, 402);
            this.TbpCars.TabIndex = 12;
            this.TbpCars.Text = "Машины";
            // 
            // GbxCars
            // 
            this.GbxCars.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxCars.Controls.Add(this.DgvCars);
            this.GbxCars.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxCars.ForeColor = System.Drawing.Color.White;
            this.GbxCars.Location = new System.Drawing.Point(8, 8);
            this.GbxCars.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxCars.Name = "GbxCars";
            this.GbxCars.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxCars.Size = new System.Drawing.Size(1119, 387);
            this.GbxCars.TabIndex = 1;
            this.GbxCars.TabStop = false;
            this.GbxCars.Text = " Содержание таблицы \"Машины\" ";
            // 
            // DgvCars
            // 
            this.DgvCars.AllowUserToResizeRows = false;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvCars.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle15;
            this.DgvCars.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvCars.AutoGenerateColumns = false;
            this.DgvCars.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvCars.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvCars.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvCars.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvCars.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn40,
            this.brandDataGridViewTextBoxColumn,
            this.colorDataGridViewTextBoxColumn,
            this.plateDataGridViewTextBoxColumn,
            this.yearManufDataGridViewTextBoxColumn,
            this.inshurancePayDataGridViewTextBoxColumn,
            this.rentalDataGridViewTextBoxColumn});
            this.DgvCars.DataSource = this.carsViewModelBindingSource;
            this.DgvCars.Location = new System.Drawing.Point(8, 24);
            this.DgvCars.Name = "DgvCars";
            this.DgvCars.ReadOnly = true;
            this.DgvCars.RowHeadersVisible = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black;
            this.DgvCars.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.DgvCars.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvCars.Size = new System.Drawing.Size(1102, 352);
            this.DgvCars.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn40.HeaderText = "Id";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.ReadOnly = true;
            // 
            // brandDataGridViewTextBoxColumn
            // 
            this.brandDataGridViewTextBoxColumn.DataPropertyName = "Brand";
            this.brandDataGridViewTextBoxColumn.HeaderText = "Модель";
            this.brandDataGridViewTextBoxColumn.Name = "brandDataGridViewTextBoxColumn";
            this.brandDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // colorDataGridViewTextBoxColumn
            // 
            this.colorDataGridViewTextBoxColumn.DataPropertyName = "Color";
            this.colorDataGridViewTextBoxColumn.HeaderText = "Цвет";
            this.colorDataGridViewTextBoxColumn.Name = "colorDataGridViewTextBoxColumn";
            this.colorDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // plateDataGridViewTextBoxColumn
            // 
            this.plateDataGridViewTextBoxColumn.DataPropertyName = "Plate";
            this.plateDataGridViewTextBoxColumn.HeaderText = "Госномер";
            this.plateDataGridViewTextBoxColumn.Name = "plateDataGridViewTextBoxColumn";
            this.plateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // yearManufDataGridViewTextBoxColumn
            // 
            this.yearManufDataGridViewTextBoxColumn.DataPropertyName = "YearManuf";
            this.yearManufDataGridViewTextBoxColumn.HeaderText = "Год выпуска";
            this.yearManufDataGridViewTextBoxColumn.Name = "yearManufDataGridViewTextBoxColumn";
            this.yearManufDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // inshurancePayDataGridViewTextBoxColumn
            // 
            this.inshurancePayDataGridViewTextBoxColumn.DataPropertyName = "InshurancePay";
            this.inshurancePayDataGridViewTextBoxColumn.HeaderText = "Страховая стоимость";
            this.inshurancePayDataGridViewTextBoxColumn.Name = "inshurancePayDataGridViewTextBoxColumn";
            this.inshurancePayDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rentalDataGridViewTextBoxColumn
            // 
            this.rentalDataGridViewTextBoxColumn.DataPropertyName = "Rental";
            this.rentalDataGridViewTextBoxColumn.HeaderText = "Стоимость за день";
            this.rentalDataGridViewTextBoxColumn.Name = "rentalDataGridViewTextBoxColumn";
            this.rentalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // carsViewModelBindingSource
            // 
            this.carsViewModelBindingSource.DataSource = typeof(CarRentalLibrary.Models.ViewModels.CarsViewModel);
            // 
            // TbpClients
            // 
            this.TbpClients.BackColor = System.Drawing.Color.Gray;
            this.TbpClients.Controls.Add(this.GbxClients);
            this.TbpClients.Location = new System.Drawing.Point(4, 25);
            this.TbpClients.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpClients.Name = "TbpClients";
            this.TbpClients.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpClients.Size = new System.Drawing.Size(1138, 402);
            this.TbpClients.TabIndex = 11;
            this.TbpClients.Text = "Клиенты";
            // 
            // GbxClients
            // 
            this.GbxClients.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxClients.Controls.Add(this.DgvClients);
            this.GbxClients.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxClients.ForeColor = System.Drawing.Color.White;
            this.GbxClients.Location = new System.Drawing.Point(8, 8);
            this.GbxClients.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxClients.Name = "GbxClients";
            this.GbxClients.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxClients.Size = new System.Drawing.Size(1118, 387);
            this.GbxClients.TabIndex = 1;
            this.GbxClients.TabStop = false;
            this.GbxClients.Text = " Содержание таблицы \"Клиенты\" ";
            // 
            // DgvClients
            // 
            this.DgvClients.AllowUserToResizeRows = false;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvClients.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.DgvClients.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvClients.AutoGenerateColumns = false;
            this.DgvClients.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvClients.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvClients.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvClients.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn34,
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn38,
            this.dataGridViewTextBoxColumn39,
            this.passportDataGridViewTextBoxColumn});
            this.DgvClients.DataSource = this.clientBindingSource;
            this.DgvClients.Location = new System.Drawing.Point(8, 24);
            this.DgvClients.Name = "DgvClients";
            this.DgvClients.ReadOnly = true;
            this.DgvClients.RowHeadersVisible = false;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            this.DgvClients.RowsDefaultCellStyle = dataGridViewCellStyle18;
            this.DgvClients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvClients.Size = new System.Drawing.Size(1101, 355);
            this.DgvClients.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn34.HeaderText = "Id";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "Surname";
            this.dataGridViewTextBoxColumn35.HeaderText = "Фамилия";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn38.HeaderText = "Имя";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            this.dataGridViewTextBoxColumn38.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.DataPropertyName = "Patronymic";
            this.dataGridViewTextBoxColumn39.HeaderText = "Отчество";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            this.dataGridViewTextBoxColumn39.ReadOnly = true;
            // 
            // passportDataGridViewTextBoxColumn
            // 
            this.passportDataGridViewTextBoxColumn.DataPropertyName = "Passport";
            this.passportDataGridViewTextBoxColumn.HeaderText = "Паспорт";
            this.passportDataGridViewTextBoxColumn.Name = "passportDataGridViewTextBoxColumn";
            this.passportDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // TbpColors
            // 
            this.TbpColors.BackColor = System.Drawing.Color.Gray;
            this.TbpColors.Controls.Add(this.GbxGoods);
            this.TbpColors.Location = new System.Drawing.Point(4, 25);
            this.TbpColors.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpColors.Name = "TbpColors";
            this.TbpColors.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpColors.Size = new System.Drawing.Size(1138, 402);
            this.TbpColors.TabIndex = 10;
            this.TbpColors.Text = "Цвета";
            // 
            // GbxGoods
            // 
            this.GbxGoods.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxGoods.Controls.Add(this.DgvColors);
            this.GbxGoods.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxGoods.ForeColor = System.Drawing.Color.White;
            this.GbxGoods.Location = new System.Drawing.Point(8, 8);
            this.GbxGoods.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxGoods.Name = "GbxGoods";
            this.GbxGoods.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxGoods.Size = new System.Drawing.Size(1119, 387);
            this.GbxGoods.TabIndex = 1;
            this.GbxGoods.TabStop = false;
            this.GbxGoods.Text = " Содержание таблицы \"Цвета\" ";
            // 
            // DgvColors
            // 
            this.DgvColors.AllowUserToResizeRows = false;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvColors.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
            this.DgvColors.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvColors.AutoGenerateColumns = false;
            this.DgvColors.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvColors.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvColors.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvColors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvColors.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn29,
            this.color1DataGridViewTextBoxColumn});
            this.DgvColors.DataSource = this.colorBindingSource;
            this.DgvColors.Location = new System.Drawing.Point(8, 24);
            this.DgvColors.Name = "DgvColors";
            this.DgvColors.ReadOnly = true;
            this.DgvColors.RowHeadersVisible = false;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.Black;
            this.DgvColors.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.DgvColors.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvColors.Size = new System.Drawing.Size(1102, 355);
            this.DgvColors.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn29.FillWeight = 10F;
            this.dataGridViewTextBoxColumn29.HeaderText = "Id";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            // 
            // color1DataGridViewTextBoxColumn
            // 
            this.color1DataGridViewTextBoxColumn.DataPropertyName = "Color1";
            this.color1DataGridViewTextBoxColumn.FillWeight = 90F;
            this.color1DataGridViewTextBoxColumn.HeaderText = "Название цвета";
            this.color1DataGridViewTextBoxColumn.Name = "color1DataGridViewTextBoxColumn";
            this.color1DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // colorBindingSource
            // 
            this.colorBindingSource.DataSource = typeof(CarRentalLibrary.Models.Color);
            // 
            // TbpBrands
            // 
            this.TbpBrands.BackColor = System.Drawing.Color.Gray;
            this.TbpBrands.Controls.Add(this.GbxBrands);
            this.TbpBrands.Location = new System.Drawing.Point(4, 25);
            this.TbpBrands.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpBrands.Name = "TbpBrands";
            this.TbpBrands.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpBrands.Size = new System.Drawing.Size(1138, 402);
            this.TbpBrands.TabIndex = 9;
            this.TbpBrands.Text = "Модели автомобилей";
            // 
            // GbxBrands
            // 
            this.GbxBrands.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxBrands.Controls.Add(this.DgvBrands);
            this.GbxBrands.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxBrands.ForeColor = System.Drawing.Color.White;
            this.GbxBrands.Location = new System.Drawing.Point(8, 8);
            this.GbxBrands.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxBrands.Name = "GbxBrands";
            this.GbxBrands.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxBrands.Size = new System.Drawing.Size(1119, 387);
            this.GbxBrands.TabIndex = 1;
            this.GbxBrands.TabStop = false;
            this.GbxBrands.Text = " Содержание таблицы \"Модели автомобилей\"";
            // 
            // DgvBrands
            // 
            this.DgvBrands.AllowUserToResizeRows = false;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvBrands.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.DgvBrands.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvBrands.AutoGenerateColumns = false;
            this.DgvBrands.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvBrands.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvBrands.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvBrands.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvBrands.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn28,
            this.brand1DataGridViewTextBoxColumn});
            this.DgvBrands.DataSource = this.brandBindingSource1;
            this.DgvBrands.Location = new System.Drawing.Point(8, 24);
            this.DgvBrands.Name = "DgvBrands";
            this.DgvBrands.ReadOnly = true;
            this.DgvBrands.RowHeadersVisible = false;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.Black;
            this.DgvBrands.RowsDefaultCellStyle = dataGridViewCellStyle22;
            this.DgvBrands.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvBrands.Size = new System.Drawing.Size(1102, 355);
            this.DgvBrands.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn28.FillWeight = 10F;
            this.dataGridViewTextBoxColumn28.HeaderText = "Id";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            // 
            // brand1DataGridViewTextBoxColumn
            // 
            this.brand1DataGridViewTextBoxColumn.DataPropertyName = "Brand1";
            this.brand1DataGridViewTextBoxColumn.FillWeight = 90F;
            this.brand1DataGridViewTextBoxColumn.HeaderText = "Модель";
            this.brand1DataGridViewTextBoxColumn.Name = "brand1DataGridViewTextBoxColumn";
            this.brand1DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // brandBindingSource1
            // 
            this.brandBindingSource1.DataSource = typeof(CarRentalLibrary.Models.Brand);
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpBrands);
            this.TbcMain.Controls.Add(this.TbpColors);
            this.TbcMain.Controls.Add(this.TbpClients);
            this.TbcMain.Controls.Add(this.TbpCars);
            this.TbcMain.Controls.Add(this.TbpRentals);
            this.TbcMain.Controls.Add(this.TbpQuery1);
            this.TbcMain.Controls.Add(this.TbpQuery2);
            this.TbcMain.Controls.Add(this.TbpQuery3);
            this.TbcMain.Controls.Add(this.TbpQuery4);
            this.TbcMain.Controls.Add(this.TbpQuery5);
            this.TbcMain.Controls.Add(this.TbpQuery6);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.Location = new System.Drawing.Point(0, 68);
            this.TbcMain.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(1146, 431);
            this.TbcMain.TabIndex = 1;
            this.TbcMain.SelectedIndexChanged += new System.EventHandler(this.TbcMain_SelectedIndexChanged);
            // 
            // brandBindingSource
            // 
            this.brandBindingSource.DataSource = typeof(CarRentalLibrary.Models.Brand);
            // 
            // carBindingSource
            // 
            this.carBindingSource.DataSource = typeof(CarRentalLibrary.Models.Car);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1146, 521);
            this.ContextMenuStrip = this.CmsMain;
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.TspMain);
            this.Controls.Add(this.MnsMain);
            this.Controls.Add(this.StsMain);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.MnsMain;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание на 24.01.2022";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.TspMain.ResumeLayout(false);
            this.TspMain.PerformLayout();
            this.CmsMain.ResumeLayout(false);
            this.TbpQuery6.ResumeLayout(false);
            this.GrbQuery6.ResumeLayout(false);
            this.GrbQuery6.PerformLayout();
            this.GbxResult6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.query6ViewModelBindingSource)).EndInit();
            this.TbpQuery5.ResumeLayout(false);
            this.GrbQuery5.ResumeLayout(false);
            this.GrbQuery5.PerformLayout();
            this.GbxResult5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.query5ViewModelBindingSource)).EndInit();
            this.TbpQuery4.ResumeLayout(false);
            this.GrbQuery4.ResumeLayout(false);
            this.GrbQuery4.PerformLayout();
            this.GbxResult4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.query4ViewModelBindingSource)).EndInit();
            this.TbpQuery3.ResumeLayout(false);
            this.GrbQuery3.ResumeLayout(false);
            this.GrbQuery3.PerformLayout();
            this.GbxResult3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            this.TbpQuery2.ResumeLayout(false);
            this.GrbQuery2.ResumeLayout(false);
            this.GrbQuery2.PerformLayout();
            this.GbxResult2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalViewModelBindingSource)).EndInit();
            this.TbpQuery1.ResumeLayout(false);
            this.GrbQuery1.ResumeLayout(false);
            this.GrbQuery1.PerformLayout();
            this.GbxResult1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery1)).EndInit();
            this.TbpRentals.ResumeLayout(false);
            this.GbxRentals.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvSales)).EndInit();
            this.TbpCars.ResumeLayout(false);
            this.GbxCars.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvCars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsViewModelBindingSource)).EndInit();
            this.TbpClients.ResumeLayout(false);
            this.GbxClients.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvClients)).EndInit();
            this.TbpColors.ResumeLayout(false);
            this.GbxGoods.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvColors)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorBindingSource)).EndInit();
            this.TbpBrands.ResumeLayout(false);
            this.GbxBrands.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvBrands)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brandBindingSource1)).EndInit();
            this.TbcMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.unitBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseViewModelBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BdsData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brandBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniExit;
        private System.Windows.Forms.ToolStrip TspMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.BindingSource purchaseBindingSource;
        private System.Windows.Forms.BindingSource purchaseViewModelBindingSource;
        private System.Windows.Forms.BindingSource purchaseViewModelBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datePurchaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronymicDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource sellerBindingSource1;
        private System.Windows.Forms.BindingSource sellerBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateSellDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource saleViewModelBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnId;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnDateSell;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnGoods;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnUnit;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnSumPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnIdSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnSurnameSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnNameSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnPatronymicSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnCountGoodsSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnAvgPrice;
        private System.Windows.Forms.BindingSource unitBindingSource;
        private System.Windows.Forms.BindingSource goodBindingSource;
        private System.Windows.Forms.BindingSource sellerBindingSource2;
        private System.Windows.Forms.BindingSource saleViewModelBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn longDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shortDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronymicDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnIdGoods;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnGoodsKey;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnCountGoods;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnAvgPriceGoods;
        private System.Windows.Forms.BindingSource BdsData;
        private System.Windows.Forms.ToolStripButton TsiInfo;
        private System.Windows.Forms.ContextMenuStrip CmsMain;
        private System.Windows.Forms.ToolStripMenuItem CmiMainInfo;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem CmiMainExit;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.ToolStripButton TsiAdd;
        private System.Windows.Forms.ToolStripButton TsiEdit;
        private System.Windows.Forms.BindingSource brandBindingSource;
        private System.Windows.Forms.BindingSource brandBindingSource1;
        private System.Windows.Forms.BindingSource colorBindingSource;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private System.Windows.Forms.BindingSource carBindingSource;
        private System.Windows.Forms.BindingSource carsViewModelBindingSource;
        private System.Windows.Forms.BindingSource rentalViewModelBindingSource;
        private System.Windows.Forms.BindingSource query4ViewModelBindingSource;
        private System.Windows.Forms.BindingSource query5ViewModelBindingSource;
        private System.Windows.Forms.BindingSource query6ViewModelBindingSource;
        private System.Windows.Forms.TabPage TbpQuery6;
        private System.Windows.Forms.GroupBox GrbQuery6;
        private System.Windows.Forms.TextBox TbxQuery6;
        private System.Windows.Forms.GroupBox GbxResult6;
        private System.Windows.Forms.DataGridView DgvQuery6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn68;
        private System.Windows.Forms.DataGridViewTextBoxColumn brandDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn plateDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentalDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn countRentalsDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sumRentalsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sumDurationDataGridViewTextBoxColumn1;
        private System.Windows.Forms.TabPage TbpQuery5;
        private System.Windows.Forms.GroupBox GrbQuery5;
        private System.Windows.Forms.TextBox TbxQuery5;
        private System.Windows.Forms.GroupBox GbxResult5;
        private System.Windows.Forms.DataGridView DgvQuery5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn64;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn65;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn66;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn67;
        private System.Windows.Forms.DataGridViewTextBoxColumn countRentalsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sumDurationDataGridViewTextBoxColumn;
        private System.Windows.Forms.TabPage TbpQuery4;
        private System.Windows.Forms.GroupBox GrbQuery4;
        private System.Windows.Forms.TextBox TbxQuery4;
        private System.Windows.Forms.GroupBox GbxResult4;
        private System.Windows.Forms.DataGridView DgvQuery4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn63;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateStartDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn plateDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn brandDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentalDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn durationDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sumPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.TabPage TbpQuery3;
        private System.Windows.Forms.GroupBox GrbQuery3;
        private System.Windows.Forms.TextBox TbxQuery3;
        private System.Windows.Forms.GroupBox GbxResult3;
        private System.Windows.Forms.DataGridView DgvQuery3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn58;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn59;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn60;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn61;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn62;
        private System.Windows.Forms.TabPage TbpQuery2;
        private System.Windows.Forms.GroupBox GrbQuery2;
        private System.Windows.Forms.TextBox TbxQuery2;
        private System.Windows.Forms.GroupBox GbxResult2;
        private System.Windows.Forms.DataGridView DgvQuery2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn51;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn52;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn53;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn54;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn55;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn56;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn57;
        private System.Windows.Forms.TabPage TbpQuery1;
        private System.Windows.Forms.GroupBox GrbQuery1;
        private System.Windows.Forms.TextBox TbxQuery1;
        private System.Windows.Forms.GroupBox GbxResult1;
        private System.Windows.Forms.DataGridView DgvQuery1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private System.Windows.Forms.TabPage TbpRentals;
        private System.Windows.Forms.GroupBox GbxRentals;
        private System.Windows.Forms.DataGridView DgvSales;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn brandDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colorDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn plateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentalDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateStartDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn durationDataGridViewTextBoxColumn;
        private System.Windows.Forms.TabPage TbpCars;
        private System.Windows.Forms.GroupBox GbxCars;
        private System.Windows.Forms.DataGridView DgvCars;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn brandDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn plateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearManufDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn inshurancePayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentalDataGridViewTextBoxColumn;
        private System.Windows.Forms.TabPage TbpClients;
        private System.Windows.Forms.GroupBox GbxClients;
        private System.Windows.Forms.DataGridView DgvClients;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn passportDataGridViewTextBoxColumn;
        private System.Windows.Forms.TabPage TbpColors;
        private System.Windows.Forms.GroupBox GbxGoods;
        private System.Windows.Forms.DataGridView DgvColors;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn color1DataGridViewTextBoxColumn;
        private System.Windows.Forms.TabPage TbpBrands;
        private System.Windows.Forms.GroupBox GbxBrands;
        private System.Windows.Forms.DataGridView DgvBrands;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn brand1DataGridViewTextBoxColumn;
        private System.Windows.Forms.TabControl TbcMain;
    }
}

