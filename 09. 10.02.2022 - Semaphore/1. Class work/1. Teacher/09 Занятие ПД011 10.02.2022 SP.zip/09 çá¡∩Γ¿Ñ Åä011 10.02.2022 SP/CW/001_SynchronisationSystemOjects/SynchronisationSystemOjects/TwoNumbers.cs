﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SynchronisationSystemOjects
{
    // общий ресурс, как и в предыдущем примере
    class TwoNumbers
    {
        public static int Number1; // инкремент на каждом цикле
        public static int Number2; // инкремент через цикл
    } // class TwoNumbers
}
