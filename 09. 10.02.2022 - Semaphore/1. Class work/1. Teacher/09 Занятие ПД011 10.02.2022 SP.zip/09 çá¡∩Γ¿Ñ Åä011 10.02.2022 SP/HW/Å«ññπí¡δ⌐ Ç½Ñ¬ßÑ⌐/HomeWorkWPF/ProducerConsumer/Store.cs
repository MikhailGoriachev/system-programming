﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace HomeWorkWPF.ProducerConsumer
{
    // Общий ресурс
    public class Store
    {
        private int _counter = 0;                            // счетчик элементов в контейнере
        private double _value;                              // контейнер для хранения

       

        // чтение данных
        public double Get()
        {
            // ожидание данных от производителя
            while (_counter == 0) { }

            // обработка
            lock (this)
            {
                --_counter;
                return _value;
            }
        } 

        // запись данных
        public void Put(double value)
        {
            // ожидание завершения чтения данных потребителем
            while (_counter > 0) { }

            lock (this)
            {
                ++_counter;
                _value = value;
                
            }
        } // Put

    }
}
