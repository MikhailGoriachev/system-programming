﻿using HomeWorkWPF.ProducerConsumer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace HomeWorkWPF
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const int MaxLimit = 50;        // максимальное значение количества генерируемых чисел
        private const int MinLimit = 10;        // минимальное значение количества генерируемых чисел

        // первая пара
        Store store1;
        Producer producer1;
        Consumer consumer1;

        // вторая пара
        Store store2;
        Producer producer2;
        Consumer consumer2;

        // третья пара
        Store store3;
        Producer producer3;
        Consumer consumer3;

        public MainWindow()
        {
            InitializeComponent();

            // первая пара
            store1 = new Store();
            producer1 = new Producer(store1, this);
            consumer1 = new Consumer(store1, this);

            // вторая пара
            store2 = new Store();
            producer2 = new Producer(store2, this);
            consumer2 = new Consumer(store2, this);
            

            // третья пара
            store3 = new Store();
            producer3 = new Producer(store3, this);
            consumer3 = new Consumer(store3, this);
           

        }


        // запуск процесса 1
        private void Start_Thread1(object sender, RoutedEventArgs e)
        {
            // первая пара
            store1 = new Store();
            producer1 = new Producer(store1, this);
            consumer1 = new Consumer(store1, this);

            // генерация числа выполнения операций
            int limit = Utils.GetRandom(MinLimit, MaxLimit);

            // очистка
            Txb_thread1.Text = "";

            Thread threadProducer = new Thread(()=>producer1.Run(Txb_thread1, limit));
            Thread threadConsumer = new Thread(()=>consumer1.Run(Txb_thread1, limit));

            threadConsumer.Start();
            threadProducer.Start();

            threadConsumer.Join();
            threadProducer.Join();
        }


        // запуск процесса 2
        private void Start_Thread2(object sender, RoutedEventArgs e)
        {
            // вторая пара
            store2 = new Store();
            producer2 = new Producer(store2, this);
            consumer2 = new Consumer(store2, this);

            // генерация числа выполнения операций
            int limit = Utils.GetRandom(MinLimit, MaxLimit);

            // очистка
            Txb_thread2.Text = "";

            Thread threadProducer = new Thread(() => producer2.Run(Txb_thread2, limit));
            Thread threadConsumer = new Thread(() => consumer2.Run(Txb_thread2, limit));

            threadConsumer.Start();
            threadProducer.Start();

            threadConsumer.Join();
            threadProducer.Join();
        }


        // запуск процесса 3
        private void Start_Thread3(object sender, RoutedEventArgs e)
        {
            // третья пара
            store3 = new Store();
            producer3 = new Producer(store3, this);
            consumer3 = new Consumer(store3, this);

            // генерация числа выполнения операций
            int limit = Utils.GetRandom(MinLimit, MaxLimit);

            // очистка
            Txb_thread3.Text = "";

            Thread threadProducer = new Thread(() => producer3.Run(Txb_thread3, limit));
            Thread threadConsumer = new Thread(() => consumer3.Run(Txb_thread3, limit));

            threadConsumer.Start();
            threadProducer.Start();

            threadConsumer.Join();
            threadProducer.Join();
        }



        // запуск всех процессов
        private void Start_All_Thread(object sender, RoutedEventArgs e)
        {

            Start_Thread1(null, null);
            Start_Thread2(null, null);
            Start_Thread3(null, null);
        }

        private void Exit_Command(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
