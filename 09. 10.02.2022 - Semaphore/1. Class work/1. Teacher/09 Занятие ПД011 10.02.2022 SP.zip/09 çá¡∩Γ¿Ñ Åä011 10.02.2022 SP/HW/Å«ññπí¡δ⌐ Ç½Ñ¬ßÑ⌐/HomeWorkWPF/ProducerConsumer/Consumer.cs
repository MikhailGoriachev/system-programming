﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace HomeWorkWPF.ProducerConsumer
{
    // потребитель
    class Consumer
    {
        const int LimitConsumer = 15;    // лимит потребления       
        private int _product = 0;       // счетчик потребленных товаров

        // ссылка на общий ресурс
        private Store _store;

        // ссылка на форму
        private Window _form;

        // !!! Внедрение зависимости !!! Получаем ссылку на общий ресурс в конструкторе 
        public Consumer(Store store, Window form)
        {
            _store = store;
            _form = form;
        }


        // поток для чтения из общего ресурса
        public void Run(TextBox textBox, int LimitConsumer)
        {
            
            _form.Dispatcher.BeginInvoke(
                    DispatcherPriority.Normal,
                    (ThreadStart)(() => textBox.Text += $"Потребителем будет обработано {LimitConsumer} чисел;\n"));

            while (_product < LimitConsumer)
            {
                double z1, z2, a;
                // забрать данные из другого потока(читать из общего ресурса)
                a = _store.Get();
                double sqrt = Math.Sqrt(2 * a);
                z1 = ((a + 2) / (sqrt) - (a) / (sqrt + 2) + (2) / (a - sqrt) * ((Math.Sqrt(a) - Math.Sqrt(2)) / (a + 2)));
                z2 = 1 / ((Math.Sqrt(a) + Math.Sqrt(2)));
                Thread.Sleep(1_500);

                // объект Mutex - для захвата ресурса (проб.)
                Mutex mutex = new Mutex(false, "mutexConsumer");
                try
                {
                    mutex.WaitOne(); // поставить блокировку - захватить ресурс textBox
                    _form.Dispatcher.BeginInvoke(
                      DispatcherPriority.Normal,
                      (ThreadStart)(() => textBox.Text += $"Полученное значение a = {a,6:f2};\nВычисленные результат = {z1,6:f2}, z2 = {z2,6:f2};\n"));
                }
                finally
                {
                    mutex.ReleaseMutex();  // снять блокировку - освободить ресурс textBox 
                }

                // увеличить счетчик потребленных товаров
                ++_product;
                             
                
            } // while

           
        } // Run
    }
}
