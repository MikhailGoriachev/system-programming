﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace HomeWorkWPF.ProducerConsumer
{
    // производоитель
    // генерирует n вещественных случайных чисел (от 10 до 50) с диапазоном значений от -10 до 20. 
    public class Producer
    {
       
        private const double MaxValue = 20d;    // максимальное значение числа
        private const double MinValue = -10d;   // минимальное значение числа
        private int _produced = 0;              // счетчик произведенных товаров

        // ссылка на общий ресурс
        private Store _store;

        // ссылка на форму
        private Window _form;

        // конструктор(внедрение зависимостей)
        public Producer(Store store, Window form)
        {
            _store = store;
            _form = form;
        }

        // поток для записи в общий ресурс
        public void Run(TextBox textBox, int LimitProducer)
        {
            _form.Dispatcher.BeginInvoke(
                    DispatcherPriority.Normal,
                    (ThreadStart)(() => textBox.Text += $"Производителем будет сгенерировано {LimitProducer} чисел;\n"));            

            // запись данных в общий ресурс   
            while (_produced < LimitProducer)
            {                        
                ++_produced;
                double value = Utils.GetRandom(MinValue, MaxValue +1);
                Thread.Sleep(1_200);

                // передать данные другому потоку(записать в общий ресурс)
               
                _store.Put(value);
              
            } // while

        }  // Run


    }
}
