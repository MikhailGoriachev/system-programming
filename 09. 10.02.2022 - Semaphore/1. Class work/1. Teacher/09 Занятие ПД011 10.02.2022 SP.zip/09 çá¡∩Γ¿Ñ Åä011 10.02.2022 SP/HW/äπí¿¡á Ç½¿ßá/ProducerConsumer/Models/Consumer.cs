﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace ProducerConsumer.Models
{
    public class Consumer {
        private int _limitConcumer;
        private int _consumed = 0;   // счетчик

        public void Restart() => _consumed = 0;

        // ссылка на общий ресурс
        private SharedResource _sharedResource;

        private Window _window;
        public Window Window { get => _window; set => _window = value; } // Window

        private TextBox _textBox;
        public TextBox TextBox { get => _textBox; set => _textBox = value; } // TextBox

        public Consumer(SharedResource sharedResource, int limitConcumer) {
            _sharedResource = sharedResource;
            _limitConcumer = limitConcumer;
        } // Consumer

        // поток для чтения из общего ресурса
        public void Run() {
            OutputToTextBox($"\tЗапуск потребителя, требуется вычислить {_limitConcumer} пар чисел\r\n");

            while (_consumed < _limitConcumer) {
                // чтение данных
                (double z1, double z2) = _sharedResource.Get();
                ++_consumed;

                if (Double.IsNaN(z1) || Double.IsNaN(z2))
                    OutputToTextBox($"\t{_consumed}. Ошибка вычислений!\r\n");
                else
                    OutputToTextBox($"\t{_consumed}. Вычислены значения: z1 = {z1:f3}, z2 ={z2:f3}\r\n");

            } // while

            OutputToTextBox($"\tФиниш потребителя, вычислено {_consumed} пар чисел\r\n\r\n");
        } // Run

        // вывод текста в TextBox
        private void OutputToTextBox(string text) {
                _window.Dispatcher.BeginInvoke(
                DispatcherPriority.Normal,
                (ThreadStart)(() => _textBox.Text += text));
        } // OutputToTextBox+
    } // Consumer
}
