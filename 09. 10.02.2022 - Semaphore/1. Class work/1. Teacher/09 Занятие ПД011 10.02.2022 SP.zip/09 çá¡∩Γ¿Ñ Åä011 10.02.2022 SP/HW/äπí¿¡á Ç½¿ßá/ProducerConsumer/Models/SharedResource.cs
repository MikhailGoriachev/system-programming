﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProducerConsumer.Models
{
    public class SharedResource {
        // !!! общий ресурс !!!
        private int _counter = 0; // счетчик чисел
        private double _value;


        // чтение данных
        public (double z1, double z2) Get() {
            // ожидаем появления данных
            while (_counter == 0) { }

            double z1, z2;
            lock (this) {
                z1 = (((_value + 2) / Math.Sqrt(2 * _value)) - (_value / (Math.Sqrt(2 * _value) + 2)) + (2 / (_value - Math.Sqrt(2 * _value))))
                            * (Math.Sqrt(_value) - Math.Sqrt(2)) / (_value + 2);

                z2 = 1 / (Math.Sqrt(_value) + Math.Sqrt(2d));
                --_counter;
            } // lock

            return (z2, z1); 
        } // GetT

        // запись данных
        public void Put(double value) {
            // ожидание завершения чтения данных потребителем
            while (_counter > 0) { }

            lock (this) {
                _value = value;
                ++_counter;
            } // lock
        } // Put
    } // SharedResource
}
