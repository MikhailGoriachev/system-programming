﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProducerConsumer.Models;
using ProducerConsumer.Helpers;
using System.Threading;

namespace ProducerConsumer
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // общие ресурсы
        private SharedResource _sharedResource1;
        private SharedResource _sharedResource2;
        private SharedResource _sharedResource3;

        private Producer _producer1;
        private Producer _producer2;
        private Producer _producer3;

        private Consumer _consumer1;
        private Consumer _consumer2;
        private Consumer _consumer3;
        public MainWindow() {
            InitializeComponent();
            // настройка первой пары
            _sharedResource1 = new SharedResource();
            int n = Utils.GetRandom(10, 50);
            _producer1 = new Producer(_sharedResource1, n) { TextBox = TbxThread1, Window = this};
            _consumer1 = new Consumer(_sharedResource1, n) { TextBox = TbxThread1, Window = this };

            // настройка второй пары
            _sharedResource2 = new SharedResource();
            n = Utils.GetRandom(10, 50);
            _producer2 = new Producer(_sharedResource2, n) { TextBox = TbxThread2, Window = this };
            _consumer2 = new Consumer(_sharedResource2, n) { TextBox = TbxThread2, Window = this };

            // настройка третьей пары
            _sharedResource3 = new SharedResource();
            n = Utils.GetRandom(10, 50);
            _producer3 = new Producer(_sharedResource3, n) { TextBox = TbxThread3, Window = this };
            _consumer3 = new Consumer(_sharedResource3, n) { TextBox = TbxThread3, Window = this };
        }

        private void Exit_Command(object sender, RoutedEventArgs e) => Close();

        // Запуск первой пары
        private void Start1_Command(object sender, RoutedEventArgs e) {
            _producer1.Restart();
            _consumer1.Restart();
            TbxThread1.Text = "";
            Thread threadConsumer = new Thread(_consumer1.Run);
            Thread threadProducer = new Thread(_producer1.Run);

            threadConsumer.Start();  // старт потребителя
            threadProducer.Start();  // старт производителя
        } // Start1_Command

        // Запуск второй пары
        private void Start2_Command(object sender, RoutedEventArgs e) {
            _producer2.Restart();
            _consumer2.Restart();
            TbxThread2.Text = "";
            Thread threadConsumer = new Thread(_consumer2.Run);
            Thread threadProducer = new Thread(_producer2.Run);

            threadConsumer.Start();  // старт потребителя
            threadProducer.Start();  // старт производителя
        } // Start2_Command

        // Запуск третьей пары
        private void Start3_Command(object sender, RoutedEventArgs e) {
            _producer3.Restart();
            _consumer3.Restart();
            TbxThread3.Text = "";
            Thread threadConsumer = new Thread(_consumer3.Run);
            Thread threadProducer = new Thread(_producer3.Run);

            threadConsumer.Start();  // старт потребителя
            threadProducer.Start();  // старт производителя
        } // Start2_Command

        // Запуск пар одновременно
        private void StartAll_Command(object sender, RoutedEventArgs e) {
            List<Producer> producers = new List<Producer> { _producer1, _producer2, _producer3};
            List<Consumer> consumers = new List<Consumer> { _consumer1, _consumer2, _consumer3 };

            producers.ForEach(p => p.Restart());
            consumers.ForEach(c => c.Restart());

            TbxThread1.Text = TbxThread2.Text = TbxThread3.Text = "";
            List<Thread> threads = new List<Thread> {
                new Thread(_consumer1.Run),
                new Thread(_consumer2.Run),
                new Thread(_consumer3.Run),
                new Thread(_producer1.Run),
                new Thread(_producer2.Run),
                new Thread(_producer3.Run)
            };

            threads.ForEach(t => t.Start());
        } // StartAll_Command
    }
}
