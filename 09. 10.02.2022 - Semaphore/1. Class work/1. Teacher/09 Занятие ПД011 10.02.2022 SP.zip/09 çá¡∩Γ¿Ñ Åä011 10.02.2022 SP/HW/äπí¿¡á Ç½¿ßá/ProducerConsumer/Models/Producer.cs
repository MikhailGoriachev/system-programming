﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using ProducerConsumer.Helpers;

namespace ProducerConsumer.Models
{
    public class Producer {
        private int _limitProducer;
        private int _produced = 0;   // счетчик

        public void Restart() => _produced = 0;

        // ссылка на общий ресурс
        private SharedResource _sharedResource;

        private Window _window;
        public Window Window { get => _window; set => _window = value; } // Window

        private TextBox _textBox;
        public TextBox TextBox { get => _textBox; set => _textBox = value; } // TextBox

        public Producer(SharedResource sharedResource, int limitProducer) {
            _sharedResource = sharedResource;
            _limitProducer = limitProducer;
        } // Producer

        // поток для записи в общий ресурс
        public void Run() {
            OutputToTextBox($"Запуск производителя, требуется записать {_limitProducer} чисел\r\n");

            while (_produced < _limitProducer) {
                // запись данных
                ++_produced;
                double value = Utils.GetRandom(-10d, 20d);
                OutputToTextBox($"{_produced}. Число записано: {value:f3}\r\n");

                //передать данные другому потоку
                _sharedResource.Put(value);
            } // while

            OutputToTextBox($"Финиш производителя, записано {_produced} чисел\r\n");
        }  // Run

        // вывод текста в TextBox
        private void OutputToTextBox(string text) {
            _window.Dispatcher.BeginInvoke(
                DispatcherPriority.Normal,
                (ThreadStart)(() => _textBox.Text += text));
        } // OutputToTextBox
    } // Producer
}
