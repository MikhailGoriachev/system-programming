﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProducerConsumer.Models
{
    public class Store
    {
        // !!! общий ресурс !!!
        private int _counter = 0; // индикатор загрузки общего ресурса
        private double _value;


        // чтение данных - отправить данные потребителю
        public double Get() {
            double temp = 0;

            // ожидаем появления данных
            while (_counter == 0) {}

            // выполнение чтения данных
            // temp - локальная переменная, в каждом экземпляре метода
            // это будет собственный экземпляр переменной
            lock (this) {
                -- _counter;
                temp = _value;
            }

            return temp;
        } // Get

        // запись данных
        public void Put(double value) {
            // ожидание момента получения товара потребителем / ожидание завершения чтения данных потребителем
            while(_counter > 0) {}

            lock (this) {
                ++_counter;
                _value = value;
            } // lock
        } // Put
    } // class Store
}
