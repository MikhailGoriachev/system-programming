﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ProducerConsumer.Infrastructure;

namespace ProducerConsumer.Models
{
    // Потребитель вычисляет z1 и z2 по выражению 
    public class Consumer
    {
        private int _limitConcumer;  // предел потребления
        private int _consumed = 0;   // счетчик потребленных данных

        // ссылка на общий ресурс - только получение ссылки, нельзя создавать!!!
        // !! только внедрение зависимости !!
        private Store _store;

        // поля класса для вывода в элементы интерфейса WPF
        private Window _window;
        private TextBox _textBox;

        public Consumer(int limitConsumer, Store store, Window window, TextBox textBox) {
            _limitConcumer = limitConsumer;
            _store = store;

            // для связи с интерфейсом пользователя
            _window = window;
            _textBox = textBox;
        }

        // поток для чтения из общего ресурса
        public void Run() {
            Utils.OutputToTextBox($"Потребитель  : старт, требуется чисел: {_limitConcumer}\r\n", _window, _textBox);

            while (_consumed < _limitConcumer) {
                // чтение данных
                double value = _store.Get();

                // обработка по заданию
                double z1 = (((value + 2)/Math.Sqrt(2*value)) - (value/(Math.Sqrt(2*value) + 2)) + (2/(value - Math.Sqrt(2*value)))) * ((Math.Sqrt(value) - Math.Sqrt(2)) / (value + 2));
                double z2 = 1/(Math.Sqrt(value) + Math.Sqrt(2));

                Thread.Sleep(1_200); // для имитации длительной обработки

                ++_consumed;
                Utils.OutputToTextBox(
                    $"Потребитель  : осталось: {_limitConcumer - _consumed, 3}, число: {value, 7:f4}, " +
                        $"{(double.IsNaN(z1)?"ошибка вычислений":$"z1 = {z1:f4}, z2 = {z2:f4}")} " +
                        $"\r\n", _window, _textBox);
            } // while

            Utils.OutputToTextBox($"Потребитель  : финиш, использовано чисел: {_consumed}\r\n", _window, _textBox);
            // !! по окончании работы потока можно выполнить метод окна, извещающий о завершении потока !! 
        }  // Run
    } // class Consumer
}