﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ProducerConsumer.Infrastructure;
using ProducerConsumer.Models;

namespace ProducerConsumer.Controllers
{
    // решение задачи 
    public class TaskController
    {
        private Producer _producer;
        private Consumer _consumer;

        // n - количество циклов работы
        public TaskController(int n, Window window, TextBox textBox) {
            Store store = new Store();

            _producer = new Producer(n, store, window, textBox);
            _consumer = new Consumer(n, store, window, textBox);
        } // Task1Controller


        // метод для запуска в отдельном потоке!!!
        public void Run() {
            Thread threadProducer = new Thread(_producer.Run);
            Thread threadConsimer = new Thread(_consumer.Run);

            threadProducer.Start();
            threadConsimer.Start();

            threadProducer.Join();
            threadConsimer.Join();
        } // Run
    } // class TaskController

}
