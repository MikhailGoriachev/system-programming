﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ProducerConsumer.Infrastructure;

namespace ProducerConsumer.Models
{
    // Производитель генерирует n вещественных случайных чисел (от 10 до 50)
    // с диапазоном значений от -10 до 20. 
    // производитель данных - запись данных в общий ресурс
    public class Producer
    {
        private int _limitProducer;
        private int _produced = 0;   // счетчик произведенных товаров

        private double _lo, _hi;    // диапазон значений генерации

        // ссылка на общий ресурс
        private Store _store;

        // поля класса для вывода в элементы интерфейса WPF
        private Window _window;
        private TextBox _textBox;

        public Producer(int limitProducer, Store store, Window window, TextBox textBox) {
            _limitProducer = limitProducer;
            _store = store;

            // для связи с интерфейсом пользователя
            _window = window;
            _textBox = textBox;

            // диапазон формирования случайных чисел
            _lo = -10d;
            _hi = 20d;
        } // Producer

        // поток для записи в общий ресурс - записать сформированное случайное число
        public void Run() {
            Utils.OutputToTextBox($"Производитель: старт, требуется чисел: {_limitProducer}\r\n", _window, _textBox);

            while (_produced < _limitProducer) {
                // запись данных
                Thread.Sleep(1_200);  // !! имитация длительной работы !!
                ++_produced;
                double value = Utils.GetRandom(_lo, _hi);
                Utils.OutputToTextBox(
                    $"Производитель: осталось: {_limitProducer - _produced, 3}, число: {value, 7:f4}\r\n", _window, _textBox);

                // положить данные на склад, передать данные другому потоку
                _store.Put(value);
            } // while

            Utils.OutputToTextBox($"Производитель: финиш, сформировано чисел: {_produced}\r\n", _window, _textBox);
            // !! по окончании работы потока можно выполнить метод окна, извещающий о завершении потока !! 
        }  // Run
    } // class Producer
}
