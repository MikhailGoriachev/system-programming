﻿using System.Threading;
using System.Windows;
using ProducerConsumer.Controllers;
using ProducerConsumer.Infrastructure;

namespace ProducerConsumer.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // для конструктора пока работы нет :)
        public MainWindow() {
            InitializeComponent();
        }
        

        // запуск первой пары "Производитель" - "Потребитель" на исполнение в отдельном потоке
        private void First_Exec(object sender, RoutedEventArgs e) {
            // чистим поле вывода
            TxbFirst.Text = "";

            int n = Utils.GetRandom(10, 50);
            TaskController task = new TaskController(n, this, TxbFirst);

            new Thread(task.Run).Start();
        } // First_Exec

        // запуск второй пары "Производитель" - "Потребитель" на исполнение в отдельном потоке
        private void Secnd_Exec(object sender, RoutedEventArgs e) {
            // чистим поле вывода
            TxbScnd.Text = "";

            int n = Utils.GetRandom(10, 50);
            TaskController task = new TaskController(n, this, TxbScnd);

            new Thread(task.Run).Start();
        }

        // запуск третьей пары "Производитель" - "Потребитель" на исполнение в отдельном потоке
        private void Third_Exec(object sender, RoutedEventArgs e) {
            // чистим поле вывода
            TxbThrd.Text = "";

            int n = Utils.GetRandom(10, 50);
            TaskController task = new TaskController(n, this, TxbThrd);

            new Thread(task.Run).Start();
        }

        // запуск всех пар "Производитель" - "Потребитель" на исполнение, параллельно, в отдельных потоках
        private void All_Exec(object sender, RoutedEventArgs e) {
            // чистим поля вывода
            TxbFirst.Text = TxbScnd.Text = TxbThrd.Text = "";

            TaskController task1 = new TaskController(Utils.GetRandom(10, 50), this, TxbFirst);
            TaskController task2 = new TaskController(Utils.GetRandom(10, 50), this, TxbScnd);
            TaskController task3 = new TaskController(Utils.GetRandom(10, 50), this, TxbThrd);

            new Thread(task1.Run).Start();
            new Thread(task2.Run).Start();
            new Thread(task3.Run).Start();
        }

        // выход из приложения
        private void Quit_Exec(object sender, RoutedEventArgs e) =>
            Application.Current.Shutdown(0);
    }
}
