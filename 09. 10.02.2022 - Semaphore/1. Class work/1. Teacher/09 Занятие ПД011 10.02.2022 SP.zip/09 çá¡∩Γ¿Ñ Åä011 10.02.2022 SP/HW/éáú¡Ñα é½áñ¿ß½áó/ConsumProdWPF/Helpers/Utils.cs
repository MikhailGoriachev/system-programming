﻿using System;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace ConsumProdWPF.Helpers
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {
        
        // объект для получения случайных чисел
        public static Random Random = new Random();
        
        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo)*Random.NextDouble();
        
        // формирование случайных целых чисел в диапазоне от lo до hi
        public static int  GetRandom(int lo, int hi)
            => Random.Next(lo,hi);

        #region Прикладные методы

        //Безопасный вывод данных в Tbx
        public static void OutPutToTbx(Window form, TextBox textBox, string OutPut)
        {
            form.Dispatcher.BeginInvoke(DispatcherPriority.Normal,
                  (ThreadStart)(() => textBox.Text += OutPut));
        }

        #endregion


    } // class Utils
}