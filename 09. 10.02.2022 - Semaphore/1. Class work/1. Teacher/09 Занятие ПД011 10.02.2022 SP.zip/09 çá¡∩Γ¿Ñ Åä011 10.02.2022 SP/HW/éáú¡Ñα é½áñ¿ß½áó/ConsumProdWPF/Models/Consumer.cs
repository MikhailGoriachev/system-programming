﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ConsumProdWPF.Helpers;

namespace ConsumProdWPF.Models
{
    public class Consumer
    {
        //Значение максимального кол-ва элементов, которые нужно обработать 
        int MaxAmount;

        //Кол-во обработанных значений 
        int _counter;

        //Ссылка на общий ресурс
        MutualRes _mutualRes;

        //Окно 
        private Window _window;

        //Tbx для вывода
        private TextBox _textBox;

        //Данные для обработки
        private double Value;

        //CTOR
        public Consumer(int amount,MutualRes mutualRes ,Window window, TextBox textBox)
        {
            MaxAmount = amount;
            _mutualRes = mutualRes;
            _window = window;
            _textBox = textBox;
        }

        //Реализация 
        public void Run()
        {
            for (; _counter < MaxAmount; _counter++)
            {
                //Получаем данные для обработки 
                Value = _mutualRes.Get();

                //Производим вычисления
                /*double z1 = Value * Value + Math.Sqrt(Value) * 200; //Временная запись */
                double z1 = (((Value + 2) / Math.Sqrt(2 * Value)) - (Value / (Math.Sqrt(2 * Value) + 2)) + 2 / (Value - Math.Sqrt(2 * Value))) * (Math.Sqrt(Value) - Math.Sqrt(2)) / (Value + 2);
                double z2 = 1 / (Math.Sqrt(Value) + Math.Sqrt(2));

                    //Выводим данные в граф. элементы 

                    Utils.OutPutToTbx(_window, _textBox, $"\r\n\n│Потребитель вычислил: " +
                        $"{(double.IsNaN(z1) ? "Ошибка в вычислениях" : $"\r\n│ Входящее значение = {Value:f2}\r\n│ Z1 = {z1:f2};\r\n│ Z2 = {z2:f2}")}" +
                        $"\r\n│осталось вычислить ещё {MaxAmount - _counter} из {MaxAmount}");
            }
            //Сообщение о завершении процесса
            Utils.OutPutToTbx(_window, _textBox, $"\r\n\nПотребитель завершил свою работу! Обработано {_counter} значений");

        }
    }
}
