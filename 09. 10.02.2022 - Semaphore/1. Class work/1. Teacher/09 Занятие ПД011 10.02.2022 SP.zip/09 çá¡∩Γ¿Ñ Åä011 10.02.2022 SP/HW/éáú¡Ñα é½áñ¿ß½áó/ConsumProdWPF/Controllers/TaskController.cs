﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ConsumProdWPF.Models;

namespace ConsumProdWPF.Controllers
{
    public class TaskController
    {
        //Потребитель/Производитель 
        private Producer _producer;
        private Consumer _consumer;

        //Ctor
        /// <summary>
        /// Конструктор контроллера
        /// </summary>
        /// <param name="NumAmount"> Кол-во значений, которые необходимо обработать</param>
        /// <param name="window"> Ссылка на окно WPF</param>
        /// <param name="textBox"> Ссылка на элемент интерфейса</param>
        public TaskController(int NumAmount, Window window, TextBox textBox)
        {
            MutualRes mutualRes = new MutualRes();

            //Создаём части паттерна 
            _producer = new Producer(NumAmount,mutualRes,window,textBox);
            _consumer = new Consumer(NumAmount, mutualRes, window, textBox);
        }

        //Запуск потоков производителя и потребителя. 
        public void Run()
        {
            Thread thread_1 = new Thread(_producer.Run);
            Thread thread_2 = new Thread(_consumer.Run);

            //Запускаем потоки 
            thread_1.Start();
            thread_2.Start();

            //Поскольку run запускается в отдельном потке - данные потоки будут вложены в него, следственно
            //родительский поток должен ожидать завершения каждого из дочерних
            thread_1.Join();
            thread_2.Join();
        }

    }
}
