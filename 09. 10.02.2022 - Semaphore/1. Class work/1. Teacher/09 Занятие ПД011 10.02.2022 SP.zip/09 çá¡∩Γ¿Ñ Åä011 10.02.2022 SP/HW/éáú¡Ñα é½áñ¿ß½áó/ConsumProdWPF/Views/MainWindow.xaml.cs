﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ConsumProdWPF.Controllers;
using ConsumProdWPF.Helpers;

namespace ConsumProdWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void FirstThread_Start(object sender, RoutedEventArgs e)
        {
            TaskController task = new TaskController(Utils.GetRandom(10,50),this,Tbx_Thread_1);
            if (task == null)
                return;
            Tbx_Thread_1.Text = "";
            Thread thread = new Thread(task.Run);
            thread.Start();
        }

        private void SecondThread_Start(object sender, RoutedEventArgs e)
        {
            TaskController task = new TaskController(Utils.GetRandom(10, 50), this, Tbx_Thread_2);

            if (task == null)
                return;

            Tbx_Thread_2.Text = "";

            Thread thread = new Thread(task.Run);
            thread.Start();
        }

        private void ThridThread_Start(object sender, RoutedEventArgs e)
        {

            TaskController task = new TaskController(Utils.GetRandom(10, 50), this, Tbx_Thread_3);

            if (task == null)
                return;

            Tbx_Thread_3.Text = "";

            Thread thread = new Thread(task.Run);
            thread.Start();
        }

        private void AllThreads_Start(object sender, RoutedEventArgs e)
        {
            //Создаём обекты
            TaskController task1 = new TaskController(Utils.GetRandom(10, 50), this, Tbx_Thread_1);
            TaskController task2 = new TaskController(Utils.GetRandom(10, 50), this, Tbx_Thread_2);
            TaskController task3 = new TaskController(Utils.GetRandom(10, 50), this, Tbx_Thread_3);

            //Убираем временный текст с Tbx

            Tbx_Thread_1.Text = "";
            Tbx_Thread_2.Text = "";
            Tbx_Thread_3.Text = "";

            //Создаём потоки 
            List<Thread> threads = new List<Thread>()
            {
                new Thread(task1.Run),
                new Thread(task2.Run),
                new Thread(task3.Run)
            };

            //Запускаем потоки 
            threads.ForEach(t => t.Start());


        }
    }
}
