﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ConsumProdWPF.Helpers;

namespace ConsumProdWPF.Models
{
    public class Producer
    {
        //Лимит кол-ва генерируемых значений 
        private int _maxAmount;

        //Счётчик уже созданных значений 
        private int _counter;
        //Диапазон значений генерации 
        (double lo, double hi) _range = (-10d, 30d);

        //Ссылка на общий ресурс 
        private MutualRes _mutualRes;

        //Окно 
        private Window _window;

        //Tbx для вывода
        private TextBox _textBox;

        //Генерируемое значение 
        private double Value;

        //Ctor
        public Producer(int amount, MutualRes mutualRes, Window window, TextBox textBox)
        {

            _maxAmount = amount;
            _mutualRes = mutualRes;
            _window = window;
            _textBox = textBox;
        }

        //Реализация поведения 
        public void Run()
        {
            //Пока кол-во созданных значений не достигло максимума - генерим их 
            while (_counter < _maxAmount)
            {
                //Создаём значение 
                Value = Utils.GetRandom(_range.lo,_range.hi);

                //Заносим значение на ресурс 
                _mutualRes.Put(Value);
                _counter++;
                //Выводим информацию об совершенном действии
                Utils.OutPutToTbx(_window,_textBox,$"\r\n\n│Производитель создал значение {Value:f2},\r\n│ это {_maxAmount - _counter} из {_maxAmount}");

            }

            //Сообщение о завершении потока
            Utils.OutPutToTbx(_window, _textBox, $"\r\n\nПроизводитель завершил свою работу! Создано {_counter} значений");

        }


    }
}
