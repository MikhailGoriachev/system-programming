﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsumProdWPF.Helpers;

namespace ConsumProdWPF.Models
{
    //Общий ресурс 
    public class MutualRes
    {
        //Флаг загрузки ресурса 
        private int _count;

        //Загружаемое и читаемое значение 
        private double _value;

        //Прочитать данные с ресурса
        public double Get()
        {
            //Ожидаем отработку потока записи данных в общий ресурс
            while (_count == 0)
            {}

            lock (this)
            {
                //Данные загружены
                _count = 0;
                return _value;
            }

        }

        //Запись данных в общий ресурс 
        public void Put(double value)
        {
            //Пока данные не прочитаны - поток находиися в ожидании
            while(_count > 0)
            { }

            lock (this)
            {
                _value = value;
                //Сигнализирование о присутствии данных на ресурсе
                _count = 1;
            }
        }

    }
}
