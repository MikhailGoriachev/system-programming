﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using ProducerConsumer.Helpers;

namespace ProducerConsumer.Models
{
    public class Producer {
        private int _limitProducer;
        private int _produced = 0;   // счетчик

        public void Restart() {
            _produced = 0;
            _sharedResource.Restart();
        } // Restart

        // ссылка на общий ресурс
        private SharedResource _sharedResource;

        // поля класса для вывода в элементы интерфейса WPF
        private Window _window;
        public Window Window { get => _window; set => _window = value; } // Window

        private TextBox _textBox;
        public TextBox TextBox { get => _textBox; set => _textBox = value; } // TextBox
        
        private Ellipse _ellipse;
        public Ellipse Ellipse { get => _ellipse; set => _ellipse = value; } // Ellipse

        public Producer(SharedResource sharedResource, int limitProducer) {
            _sharedResource = sharedResource;
            _limitProducer = limitProducer;
        } // Producer

        // поток для записи в общий ресурс
        public void Run() {
            Utils.OutputToTextBox(_window, _textBox, $"Запуск производителя, требуется записать {_limitProducer} чисел\r\n");
            // изменить цвет индикатора
            Utils.ChangeColorEllipse(_window, _ellipse, Brushes.DarkSeaGreen);

            while (_produced < _limitProducer) {
                // запись данных
                ++_produced;
                double value = Utils.GetRandom(-10d, 20d);

                // Thread.Sleep(100); // для имитации длительной обработки

                Utils.OutputToTextBox(_window, _textBox, $"{_produced}. Число записано: {value, 6:f2}\r\n");

                //передать данные другому потоку
                _sharedResource.Put(value);
            } // while

            Utils.OutputToTextBox(_window, _textBox, $"Финиш производителя, записано {_produced} чисел\r\n");
            Utils.ChangeColorEllipse(_window, _ellipse, Brushes.DarkRed);
        }  // Run

    } // Producer
}
