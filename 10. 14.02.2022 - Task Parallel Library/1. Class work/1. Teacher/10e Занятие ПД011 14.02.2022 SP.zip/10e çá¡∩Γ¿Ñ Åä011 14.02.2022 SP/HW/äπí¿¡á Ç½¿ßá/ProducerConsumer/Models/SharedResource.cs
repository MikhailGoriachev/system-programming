﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProducerConsumer.Models
{
    public class SharedResource {
        // !!! общий ресурс !!!
        private bool _wrote;      // true: запись, false: чтение 
        private int _counter = 0; // счетчик чисел
        private string _fileName; // имя файла
        private Mutex _mutex;

        public SharedResource(Mutex mutex, string fileName, int limit) {
            _mutex = mutex;
            _wrote = false;
            _fileName = fileName;
            if (!File.Exists(fileName)) File.Create(fileName);
            File.WriteAllText(_fileName, "");
        } // SharedResource

        // очистка файла, сброс счетчика
        public void Restart() {
            _counter = 0;
            File.WriteAllText(_fileName, "");
        } // Restart

        // чтение данных
        public List<double> Get() {
            List<double> result = new List<double>();

            // ожидаем появления данных
            while (_wrote) { }

            // чтение данных
            try {
                _mutex.WaitOne(); // поставить блокировку
                File.ReadAllLines(_fileName)
                    .ToList()
                    .ForEach(x => result.Add(double.Parse(x)));
            }
            finally {
                _mutex.ReleaseMutex();  // снять блокировку
            } // try-finally

            _wrote = true;
            return result; 
        } // GetT

        // запись данных
        public void Put(double value) {

            // ожидание завершения чтения данных потребителем
            while (!_wrote) { }

            try {
                _mutex.WaitOne(); // поставить блокировку
                File.AppendAllText(_fileName, $"{value}\n", Encoding.Default);
                ++_counter;
            }
            finally {
                _mutex.ReleaseMutex(); // снять блокировку
            } // try-finally

            _wrote = false;
        } // Put
    } // SharedResource
}
