﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using ProducerConsumer.Helpers;
using System.Windows.Media;
using System.Windows.Shapes;


namespace ProducerConsumer.Models
{
    public class Consumer {
        // ссылка на общий ресурс
        private SharedResource _sharedResource;

        // поля класса для вывода в элементы интерфейса WPF
        private Window _window;
        public Window Window { get => _window; set => _window = value; } // Window

        private TextBox _textBox;
        public TextBox TextBox { get => _textBox; set => _textBox = value; } // TextBox

        private Ellipse _ellipse;
        public Ellipse Ellipse { get => _ellipse; set => _ellipse = value; } // Ellipse

        public Consumer(SharedResource sharedResource) {
            _sharedResource = sharedResource;
        } // Consumer

        // поток для чтения из общего ресурса
        public void Run() {
            Utils.OutputToTextBox(_window, _textBox, $"Запуск потребителя\r\n");
            // изменить цвет индикатора
            Utils.ChangeColorEllipse(_window, _ellipse, Brushes.DarkSeaGreen);

            while(true) {
                // чтение данных из другого потока
                List<double> res = _sharedResource.Get();


                // вывод чисел в исходном порядке 
                Utils.OutputToTextBox(_window, _textBox, $"\nПрочитаны числа:\n");
                int i = 0;
                res.ForEach(x => { Utils.OutputToTextBox(_window, _textBox, $"{x,9:f2}{(++i % 6 == 0 ? "\n" : "")}"); Thread.Sleep(10); });

                // вывод нечетных чисел
                Utils.OutputToTextBox(_window, _textBox, $"\n\nНечетные числа:\n");
                i = 0;
                res.ForEach(x => { if ((int)x % 2 != 0) { Utils.OutputToTextBox(_window, _textBox, $"{x,9:f2}{(++i % 6 == 0 ? "\n" : "")}"); Thread.Sleep(10); } });
                if (res.Count > 64)
                    break;
            }

            Utils.OutputToTextBox(_window, _textBox, $"\n\nФиниш потребителя\r\n\r\n");
            // изменить цвет индикатора
            Utils.ChangeColorEllipse(_window, _ellipse, Brushes.DarkRed);
        } // Run
    } // Consumer
}
