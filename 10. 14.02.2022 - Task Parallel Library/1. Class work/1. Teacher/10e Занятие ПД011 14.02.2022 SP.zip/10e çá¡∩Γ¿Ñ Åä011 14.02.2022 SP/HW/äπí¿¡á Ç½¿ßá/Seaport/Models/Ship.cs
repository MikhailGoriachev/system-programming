﻿using Seaport.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Seaport.Models
{
    // класс, описывающий корабль
    public class Ship {
        // максимальная емкость корабля
        public const int MaxContainersCount = 4;

        // бортовой номер
        private string _number;
        public string Number {
            get => _number;
            set {
                if (string.IsNullOrWhiteSpace(value)) throw new Exception("Ship: Некорректное значение бортового номера!");
                _number = value; } // set
        } // Number

        // кол-во контейнеров на борту
        private int _containers;
        public int Containers {
            get => _containers;
            set {
                if (value < 0 || value > MaxContainersCount) throw new Exception("Ship: Некорректное значение кол-ва контейнеров на борту!");
                _containers = value; 
            } // set
        } // Containers

        // состояние корабля
        private string _state;
        public string State {
            get => _state;
            set {
                if (string.IsNullOrWhiteSpace(value)) throw new Exception("Ship: Некорректное значение состояния корабля!");
                _state = value;
            } // set
        } // Number


        public static Ship Generate(int containers) {
            int number = Utils.GetRandom(1, 999);
            return new Ship {
                Containers = containers,
                State = $"Ожидает {(containers == 0?"по": "раз")}грузку",
                Number = $"{(number > 99?"": number > 9 ?"0": "00")}{number}"
            };
        } // Generate

    } // Ship
}
