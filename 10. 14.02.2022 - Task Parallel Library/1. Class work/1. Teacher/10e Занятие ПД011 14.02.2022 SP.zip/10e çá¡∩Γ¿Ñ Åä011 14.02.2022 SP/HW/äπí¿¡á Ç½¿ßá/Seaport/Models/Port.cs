﻿using Seaport.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Seaport.Models
{
    internal class Port {
        // максимальное кол-во контейнеров в порту
        public const int MaxContainersCount = 40;
        // очередь для погрузки
        private List<Ship> _loadingTurn;

        // очередь для разгрузки
        private List<Ship> _unloadingTurn;

        // кол-во контейнеров в порту
        private int _containers;

        private Semaphore _semaphore;   // ссылка на семафор - причалы в порту

        // поля класса для вывода в элементы интерфейса WPF
        private Window _window;
        public Window Window { get => _window; set => _window = value; } // Window

        public DataGrid DgLoadingTurn { get; set; }
        public DataGrid DgUnloadingTurn { get; set; }

        public Port(Semaphore semaphore) {
            _semaphore = semaphore;
            _loadingTurn = new List<Ship>();
            _unloadingTurn = new List<Ship>();
            for (int i = 0; i < 8; i++) _loadingTurn.Add(Ship.Generate(Utils.GetRandom(0, 2)));
            for (int i = 0; i < 8; i++) _unloadingTurn.Add(Ship.Generate(Utils.GetRandom(1, 4)));
        } // Port

        // метод для запуска в отдельном потоке
        public void Run() {
            loadDataGrid(_loadingTurn, _unloadingTurn);
            List<Thread> loadingThreads = new List<Thread>();
            List<Thread> unloadingThreads = new List<Thread>();

            _loadingTurn.ForEach(s => loadingThreads.Add(new Thread(() => { Loading(s); })));
            _unloadingTurn.ForEach(s => unloadingThreads.Add(new Thread(() => { Unloading(s); })));

            loadingThreads.ForEach(t => t.Start());
            unloadingThreads.ForEach(t => t.Start());

            loadingThreads.ForEach(t => t.Join());
            unloadingThreads.ForEach(t => t.Join());
        } // Run

        // погрузка
        public void Loading(Ship ship) {
            while (ship.Containers < 4 && _containers < 1) {
                try {
                    // занимаем ресурс, декремент счетчика свободных ресурсов 
                    // если свободных ресурсов нет - ожидание освобождения ресурса
                    _semaphore.WaitOne();
                    ship.State = "Погрузка";

                    ship.Containers++;
                    _containers--;
                    Thread.Sleep(1000);
                }
                finally  { // гарантированнное освобождение ресурса
                    _semaphore.Release(); // освобождаем ресурс, инкремент счетчика свободных ресурсов
                } // try-finally

                ship.State = $"Ожидает {(ship.Containers != Ship.MaxContainersCount ? "по" : "раз")}грузку";
                Thread.Sleep(1_200);
                loadDataGrid(new List<Ship>(), new List<Ship>());
                // _loading.Remove(ship);
                if (ship.Containers >= Ship.MaxContainersCount)
                {
                    _unloadingTurn.Add(ship);
                    _loadingTurn.Remove(ship);
                }
                loadDataGrid(_loadingTurn, _unloadingTurn);
            } // while
        }// Loading

        // разгрузка
        public void Unloading(Ship ship) {
            while (ship.Containers > 0 && _containers < MaxContainersCount) {
                try {
                    // занимаем ресурс, декремент счетчика свободных ресурсов 
                    // если свободных ресурсов нет - ожидание освобождения ресурса
                    _semaphore.WaitOne();
                    ship.State = "Разгрузка";

                    ship.Containers--;
                    _containers++;
                    Thread.Sleep(1000);
                }
                finally  { // гарантированнное освобождение ресурса
                    _semaphore.Release(); // освобождаем ресурс, инкремент счетчика свободных ресурсов
                } // try-finally

                ship.State = $"Ожидает {(ship.Containers != Ship.MaxContainersCount ? "по" : "раз")}грузку";
                Thread.Sleep(1_200);
                loadDataGrid(new List<Ship>(), new List<Ship>());
                if (ship.Containers == 0) {
                    _unloadingTurn.Remove(ship);
                    _loadingTurn.Add(ship);
                }
                loadDataGrid(_loadingTurn, _unloadingTurn);
            } // while
        }// Loading

        // вывод коллекций в DataGrid
        private void loadDataGrid(List<Ship> loadingTurn, List<Ship> unloadingTurn) {
            Utils.OutputToDataGrid(_window, DgLoadingTurn, loadingTurn);
            Utils.OutputToDataGrid(_window, DgUnloadingTurn, unloadingTurn);
        } // loadDataGrid

    } // Port
}
