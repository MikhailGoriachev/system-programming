﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExhibitionModel
{
    // жанры живописи
    public enum Genres
    {
        Portrait,     // портрет 
        Landscape,    // пейзаж
        StillLive     // натюрморт
        // ...
    } // enum Genres
}
