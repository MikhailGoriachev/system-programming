﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ThreadsH_W7SP.Tasks;

namespace TaskConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            // Настройка консоли 
            Console.Title = "Домашняя работа №7.";
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.Clear();
            Console.CursorVisible = false;

            TaskA task1 = new TaskA { BinFileName = "Thread1Data.bin" };
            TaskB task2 = new TaskB { JsonFileName = "Thread2Data.json" };
            TaskC task3 = new TaskC { TextFileName = "Thread3Data.txt" };


            List<Thread> threads = new List<Thread>(new [] {
                new Thread(task1.Process1_Console),
                new Thread(task2.Process2_Console),
                new Thread(task3.Process3_Console)});

            threads.ForEach(t => t.Start());
            threads.ForEach(t => t.Join());
        }
    }
}
