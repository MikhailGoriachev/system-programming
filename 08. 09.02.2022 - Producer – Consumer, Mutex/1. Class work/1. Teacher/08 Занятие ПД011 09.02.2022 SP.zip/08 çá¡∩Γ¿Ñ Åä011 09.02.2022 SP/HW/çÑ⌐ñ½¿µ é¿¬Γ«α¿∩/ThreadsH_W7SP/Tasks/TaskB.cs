﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using ThreadsH_W7SP.Models;

namespace ThreadsH_W7SP.Tasks
{
    // б)	создание коллекции заявок на ремонт ноутбуков
    // (наименование устройства, модель, тип процессора, объем оперативной памяти,
    // емкость накопителя, диагональ экрана, описание неисправности,
    // фамилия и инициалы владельца), сериализация этой коллекции при первом запуске;
    // десериализация, перемешивание и сериализация при последующих запусках.
    // Формат файла данных – JSON

    public class TaskB
    {
        // данные для потока 2
        private CollectionRepairLaptop _collectionRepair;
        public CollectionRepairLaptop CollectionRepairLaptop => _collectionRepair;


        // имя Json файла для потока2
        private string _jsonFileName;
        public string JsonFileName
        {
            get => _jsonFileName;

            // при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
            set
            {
                _jsonFileName = value;
                _collectionRepair.Initialize();
                if (!File.Exists(_jsonFileName))
                {
                    SerializationJson(_jsonFileName, _collectionRepair);
                } // if               
            } // set 
        }// JsonFileName


        // конструкторы
        public TaskB() : this(new CollectionRepairLaptop()) { }
        public TaskB(CollectionRepairLaptop collectionRepair)
        {
            _collectionRepair = collectionRepair;
        }


        // метод для потока 2 - используется в консольном приложении
        // Cоздание коллекции заявок на ремонт ноутбуков
        // перемешивание и сериализация при последующих запусках
        public void Process2_Console()
        {
            // критическая секция
            lock (typeof(Console)) {
                Console.WriteLine($"\n\n Поток 2: {_collectionRepair.Show(" Данные сформированы:")}");
            }

            DeserializeJson(_jsonFileName, _collectionRepair);

            Shuffle(_collectionRepair);

            _collectionRepair.OrderByAmountOfRAMDesc();

            // критическая секция
            lock (typeof(Console)) {
                    Console.WriteLine($"\n Поток 2: {_collectionRepair.Show(" Вывод данных, коллекция упорядочена по убыванию объема оперативной памяти:")}");
            }// lock

            SerializationJson(_jsonFileName, _collectionRepair);
        }// Process2_Console


        // перемешивание массива, метод для потока 3
        public void Shuffle(CollectionRepairLaptop collectionRepair)
        {
            for (int i = collectionRepair.Count - 1; i >= 1; i--)
            {
                int temp = Utils.Random.Next(i + 1);
                (collectionRepair[i], collectionRepair[temp]) = (collectionRepair[temp], collectionRepair[i]);
            } // for i
        } // Shuffle


        // сериализация в JSON формате
        public void SerializationJson(string fileName, CollectionRepairLaptop collectionRepair)
        {     // форматтеру передаём тип
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(CollectionRepairLaptop));

            using (FileStream fs = new FileStream(fileName, FileMode.Create))
            {
                jsonFormatter.WriteObject(fs, collectionRepair);
            } // using

        }// SerializationJson


        // десериализация в JSON формате
        public void DeserializeJson(string fileName, CollectionRepairLaptop collectionRepair)
        {    // форматтеру передаём тип

            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(CollectionRepairLaptop));
            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate))
            {
                collectionRepair = (CollectionRepairLaptop)jsonFormatter.ReadObject(fs);
            } // using

        }// DeserializeJson

    }// class TaskB
}
