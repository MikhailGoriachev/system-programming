﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace ThreadsH_W7SP.Models
{
    [DataContract]
    public class CollectionRepairLaptop
    {

        // контейнер данных
        [DataMember]
        private List<RepairLaptop> _laptops;
        [DataMember]
        public List<RepairLaptop> RepairLaptops         
        {
            get => _laptops;
            private set => _laptops = value;
        } // Appliances

        public int Count => _laptops.Count;

        public CollectionRepairLaptop() : this(new List<RepairLaptop>())
        {
            Initialize();
        } // CollectionRepairLaptop

        public CollectionRepairLaptop(List<RepairLaptop> laptops)
        {
            _laptops = laptops;
        } // CollectionRepairLaptop


        public void Initialize()
        {
            _laptops = new List<RepairLaptop>(
                new RepairLaptop[] {
                    new RepairLaptop("ПК 'ASUS'", "TUF Gaming F15", "11-e Tiger Lake", 16, 512, 15.6, "поломка камеры",           "Дулин С.И."),
                    new RepairLaptop("ПК 'HP'",   "Pavilion x30",   "11-e Tiger Lake", 8,  512, 14d,  "поломка матрицы",          "Сумёнов К.С."),
                    new RepairLaptop("ПК 'Aser'", "Aspire 3",       "11-e Tiger Lake", 8,  512, 15.6, "проблемы видеокарты",      "Кутузов Ю.Л."),
                    new RepairLaptop("ПК 'ASUS'", "VivoBook 15",    "11-e Tiger Lake", 16, 512, 15.6, "неисправность батареи",    "Помещин С.Р."),
                    new RepairLaptop("ПК 'Aser'", "Extensa 15",     "10-e Ice Lake",   8,  256, 15.6, "неисправность клавиатуры", "Тюрин Д.И."),
                });
        }// Initialize


        public RepairLaptop this[int index]
        {
            get => _laptops[index];
            set => _laptops[index] = value;
        } // indexer


        // Упорядочивание коллекции по убыванию объем оперативной памяти
        public void OrderByAmountOfRAMDesc() => _laptops.OrderByDescending(l => l.AmountOfRAM);

        public string Show(string caption) =>
            Show(caption, _laptops);

        // Вывести данные коллекции в консоль - для вывода 
        public static string Show(string caption, List<RepairLaptop> laptops)
        {
            // вывод заголовка таблицы данных 
            StringBuilder sb = new StringBuilder($"\r\n\n{caption}\r\n{RepairLaptop.Header()}");

            // вывод всех элементов массива объектов данных
            foreach (var el in laptops)
                sb.Append($"{el.ToTableRow()}\r\n");

            // вывод подвала таблицы
            return sb.Append($"{RepairLaptop.Footer}\r\n").ToString();
        } // Show

    }// class CollectionRepairLaptop
}
