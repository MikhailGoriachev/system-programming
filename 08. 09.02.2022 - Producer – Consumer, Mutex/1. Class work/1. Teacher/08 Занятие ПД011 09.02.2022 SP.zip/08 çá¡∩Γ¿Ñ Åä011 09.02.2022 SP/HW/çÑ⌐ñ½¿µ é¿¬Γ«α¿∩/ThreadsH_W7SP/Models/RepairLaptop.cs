﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ThreadsH_W7SP.Models
{
    // Класс по ремонту ноутбуков (
    // *наименование устройства,
    // *модель,
    // *тип процессора,
    // *объем оперативной памяти,
    // *емкость накопителя,
    // *диагональ экрана,
    // *описание неисправности,
    // *фамилия и инициалы владельца
    [DataContract]
    public class RepairLaptop
    {

        // наименование устройства
        [DataMember]
        private string _nameLaptop;
        public string NameLaptop
        {
            get => _nameLaptop;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RepairLaptop: Не верно задано наименование устройства или задано пустой строкой");
                _nameLaptop = value;
            }
        }// NameLaptop

        // модель
        [DataMember]
        private string _model;
        public string Model
        {
            get => _model;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RepairLaptop: Не верно задана модель устройства или задано пустой строкой");
                _model = value;
            }
        }// Model

        // тип процессора
        [DataMember]
        private string _processorType;
        public string ProcessorType
        {
            get => _processorType;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RepairLaptop: Не верно задан тип процессора устройства или задано пустой строкой");
                _processorType = value;
            }
        }// ProcessorType


        // объем оперативной памяти
        [DataMember]
        private int _amountRam;
        public int AmountOfRAM
        {
            get => _amountRam;
            set
            {
                if (value <= 0)
                    throw new ArgumentException($"RepairLaptop: Недопустимое значение объемa оперативной памяти: {value}");
                _amountRam = value;
            }
        }// AmountOfRAM

        // емкость накопителя
        [DataMember]
        private int _storage;
        public int Storage
        {
            get => _storage;
            set
            {
                if (value <= 0)
                    throw new ArgumentException($"RepairLaptop: Недопустимое значение емкости накопителя: {value}");
                _storage = value;
            }
        }// Storage


        // диагональ экрана
        [DataMember]
        private double _diagonal;
        public double Diagonal
        {
            get => _diagonal;
            set
            {
                if (value <= 0)
                    throw new ArgumentException($"RepairLaptop: Недопустимое значение диагонали экрана: {value}");
                _diagonal = value;
            }
        }// Diagonal


        // описание неисправности
        [DataMember]
        private string _defect;
        public string Defect
        {
            get => _defect;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RepairLaptop: Не верно задан описание неисправности или задано пустой строкой");
                _defect = value;
            }
        }// Defect


        // фамилия и инициалы владельца
        [DataMember]
        private string _fullName;
        public string FullName
        {
            get => _fullName;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RepairLaptop: Не верно задан ФИО владельца или задано пустой строкой");
                _fullName = value;
            }
        }// FullName

        // конструкторы
        public RepairLaptop() { }

        public RepairLaptop(string name, string model, string processor, int ram, int storage, double diagonal, string defect, string owner)
        {
            _nameLaptop = name;
            _model = model;
            _processorType = processor;
            _amountRam = ram;
            _storage = storage;
            _diagonal = diagonal;
            _defect = defect;
            _fullName = owner;
        }// RequestAirTicket

        

        // вывод данных ремонте ноутбуков в формате строки таблицы
        public string ToTableRow() =>
            $"│ {_nameLaptop,-9} │ {_model,-14} │ {_processorType,-16} │ {_amountRam, 3} │ {_storage, 6} │ {_diagonal , 9:f1} │ {_defect,-24} │ {_fullName,-13} │";


        // статическое свойство для вывода шапки таблицы
        public static string Header()
        {
            string str =
                $"┌───────────┬────────────────┬──────────────────┬─────┬────────┬───────────┬──────────────────────────┬───────────────┐\r\n" +
                $"│ Название  │     Модель     │  Тип процессора  │ RAM │ SSD,ГБ │ Диагональ │  Описание неисправности  │ ФИО владельца │\r\n" +
                $"├───────────┼────────────────┼──────────────────┼─────┼────────┼───────────┼──────────────────────────┼───────────────┤\r\n";
            return str;
        } // Header
        public static string Footer =>
                 "└───────────┴────────────────┴──────────────────┴─────┴────────┴───────────┴──────────────────────────┴───────────────┘";


    }// class RepairLaptop
}
