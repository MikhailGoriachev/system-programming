﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Windows.Threading;

namespace ThreadsH_W7SP.Tasks
{
    // а)	создание файла случайных вещественных чисел(не более 20 чисел),
    // создается при первом запуске, при последующих запусках –
    // перемешивание данных в файле.Сортировка файла по убыванию и сохранение файла
    public class TaskA
    {
        // имя бинарного файла для потока 1
        private string _binFileName;
        public string BinFileName
        {
            get => _binFileName;

            // при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
            set
            {
                _binFileName = value;

                if (!File.Exists(_binFileName))
                {
                    var data = Enumerable
                        .Repeat(0, Utils.GetRandom(10, 20))
                        .Select(x => Utils.GetRandom(-10d, 20d))
                        .ToList();

                    WrightToBinary(_binFileName, data);
                } // if
            } // set 
        }// BinFileName

        // ссылка на форму, в которой размещены элементы управления,
        // в которые будем выводить результаты работы
        private Window _form;
        public Window Form
        {
            get => _form;
            set => _form = value;
        }

        // контролы для вывода из потоков в форму
        public TextBox Executive1 { get; set; }

        // метод для потока 1 - используется в консольном приложении
        // Cоздание файла случайных вещественных чисел, перемешивание данных в файле.
        // Сортировка файла по убыванию и сохранение файла
        public void Process1_Console()
        {
            // чтение из файла в коллекцию
            List<double> data = new List<double>();

            ReadToBinary(_binFileName, data);

            // критическая секция
            lock (typeof(Console)) {
                Console.WriteLine(OutputToStrigBuilder(data, $"\n\n Поток 1: массив вещественных чисел \"{_binFileName}\":\n\t"));
            }

            Shuffle(data);
            data.OrderByDescending(a => a);

            // критическая секция
            lock (typeof(Console)) {
                Console.WriteLine(
                    $"{OutputToStrigBuilder(data, $"\n\n Поток 1: массив вещественных чисел перемешан \"{_binFileName}\":\n\t")}\n\n");
            } // lock

            WrightToBinary(_binFileName, data);
        } // Process1_Console


        // метод для потока 1 - используется в Windows Forms
        // Cоздание файла случайных вещественных чисел, перемешивание данных в файле.
        // Сортировка файла по убыванию и сохранение файла
        public void Process1_WPF()
        {
            // чтение из файла в коллекцию
            List<double> data = new List<double>();

            ReadToBinary(_binFileName, data);

            // Имитация длительной обработки
            Thread.Sleep(1_500);

            StringBuilder sb = OutputToStrigBuilder(data, $"\n\n Поток 1: массив вещественных чисел \"{_binFileName}\":\r\n");
            sb = OutputToStrigBuilder(data, $"\r\n\n Поток 1: массив вещественных чисел перемешан \"{_binFileName}\":\r\n");
            OutputToTextBox(sb);

            Shuffle(data);
            sb = OutputToStrigBuilder(data, $"\r\n\n Поток 1: массив вещественных чисел перемешан \"{_binFileName}\":\r\n");
            OutputToTextBox(sb);

            // Имитация длительной обработки
            Thread.Sleep(1_500);

            data.OrderByDescending(a => a);

            // запись в файл
            WrightToBinary(_binFileName, data);

            // Имитация длительной обработки
            Thread.Sleep(1_500);

            sb = OutputToStrigBuilder(data, 
                $"\r\n\n Поток 1: массив вещественных чисел отсортирован и записан \"{_binFileName}\":\r\n");
            sb.Append("\r\n\r\nОбработка завершена");
            OutputToTextBox(sb);
        } // Process1_WPF

        private void OutputToTextBox(StringBuilder sb) =>
            _form.Dispatcher.BeginInvoke(
                DispatcherPriority.Normal,
                (ThreadStart)(() => Executive1.Text += sb.ToString()));
        
        

        #region Вспомогательные методы

        // перемешивание массива, метод для потока 1
        public void Shuffle(List<double> data)
        {
            for (int i = data.Count - 1; i >= 1; i--)
            {
                int temp = Utils.Random.Next(i + 1);
                (data[i], data[temp]) = (data[temp], data[i]);
            } // for i
        } // Shuffle


        // запись в бинарный файл
        public void WrightToBinary(string fileName, List<double> data)
        {
            // запись в файл
            using (BinaryWriter bwr = new BinaryWriter(File.Create(_binFileName)))
                data.ForEach(datum => bwr.Write(datum));
        }// WrightToBinary


        // чтение бинарного файл
        public void ReadToBinary(string fileName, List<double> data)
        {
            using (BinaryReader brd = new BinaryReader(File.OpenRead(fileName)))
            {
                while (brd.BaseStream.Position < brd.BaseStream.Length)
                    data.Add(brd.ReadDouble());

            } // using
        }// ReadToBinary



        // вывод коллекции в StringBuilder
        private StringBuilder OutputToStrigBuilder(List<double> data, string title)
        {
            StringBuilder sb = new StringBuilder(title);

            foreach (var d in data)
            {
                sb.Append($"{d,7:f2}");
            }
            sb.AppendLine();
            return sb;
        }// OutputToStrigBuilder




        #endregion

    }// class TaskA
}
