﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreadsH_W7SP.Tasks
{
    // в)	обработка текстового файла – подсчет (без учета регистра)
    // частоты слов, результаты выводите в словарь (пары «слово – количество»)
    public class TaskC
    {
        // имя текстового файла для потока 3
        public string TextFileName { get; set; }


        // метод для потока 3 - используется в консольном приложении
        // Обработка текстового файла – подсчет частоты слов,
        // результаты выводите в словарь (пары «слово – количество»)
        public void Process3_Console()
        {
            // критическая секция
            lock (typeof(Console))
            {                
                List<string> strings = File.ReadLines(TextFileName).ToList();
                ShowWords(strings, $"\n\n Поток 3: файл \"{Path.GetFileName(TextFileName)}\":\n");

                Dictionary<string, int> words = CreateDictionary(strings);

                ShowWords(words.Select(w => $"{w.Key,-17}  - {w.Value}").ToList(), $"\n Поток 3: подсчет (без учета регистра) частоты слов:\n");
            }// lock
        } // Process3_Console


        // создание частотного словаря из коллекции строк
        private Dictionary<string, int> CreateDictionary(List<string> strings)
        {
            Dictionary<string, int> words = new Dictionary<string, int>();

            var del = "' ', '-', ':', '.', ',', '!', '?', '\\', '\n'".ToCharArray();

            strings.ForEach(
                s => s
                     .ToLower()
                     .Split(del, StringSplitOptions.RemoveEmptyEntries)
                     .ToList()
                     .ForEach(word => {
                        if (!words.ContainsKey(word))
                            words[word] = 0;
                            words[word]++;
                     }));

            return words;
        }// CreateDictionary


        // вывод списка строк 
        private void ShowWords(List<string> list, string title)
        {
            Console.WriteLine(title);
            foreach (var item in list)
            {
                Console.Write($" {item}\r\n");
            }
        } // ShowWords

    }// class TaskC
}
