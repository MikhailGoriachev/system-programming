﻿using HomeWorkLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace HomeWorkWPF
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    /// 

    public partial class MainWindow : Window
    {
        public RandomDouble rd;
        public RepairShop rs;
        public TextHandling th;


        public MainWindow()
        {
            InitializeComponent();

            // задача 1
            rd = new RandomDouble("test1taskWPF.txt");       // путь для файла
           

            // задача 2
            rs = new RepairShop();
         

            // задача 3
            th = new TextHandling();
            
        }

        #region ПОТОКИ
        // запуск процесса 1
        private void Start_Thread1(object sender, RoutedEventArgs e)
        {

            // создание потока в стиле "быстро, но грязно" - при помощи лямбда-выражения
            Thread thread = new Thread(() => {

                // создаем или открываем файл
                rd.CreateFile();





                // привязываем к DataGridView
                Dispatcher.BeginInvoke(
                    DispatcherPriority.Normal,
                    (ThreadStart)(() => BingTask1()));

            });
            thread.Start();
            MSI_task1.IsEnabled = true;



        }   


        // запуск процесса 2
        private void Start_Thread2(object sender, RoutedEventArgs e)
        {

            // создание потока в стиле "быстро, но грязно" - при помощи лямбда-выражения
            Thread thread = new Thread(() => {

                // создаем или открываем файл
                rs.CreateFile("test2taskWPF.json");

                // привязываем к DataGridView
                Dispatcher.BeginInvoke(
                    DispatcherPriority.Normal,
                    (ThreadStart)(() => BingTask2()));

            });
            thread.Start();
            MSI_task2.IsEnabled = true;



        }

       
        // запуск процесса 3
        private void Start_Thread3(object sender, RoutedEventArgs e)
        {

            // создание потока в стиле "быстро, но грязно" - при помощи лямбда-выражения
            Thread thread = new Thread(() => {

                // открываем файл
                th.CreateDictionary("test3taskWPF.txt");
                //rs.CreateFile("test2taskWF.txt");

                // привязываем к DataGridView
                Dispatcher.BeginInvoke(
                    DispatcherPriority.Normal,
                    (ThreadStart)(() => BingTask3()));

            });
            thread.Start();
            MSI_task3.IsEnabled = true;



        }

        // запуск всех процессов
        private void Start_All_Thread(object sender, RoutedEventArgs e)
        {

            Start_Thread1(null, null);
            Start_Thread2(null, null);
            Start_Thread3(null, null);
        }

        #endregion

        #region ПРИВЯЗКИ
        // привязка для потока 1
        public void BingTask1()
        {

            Txb_thread1.Text = "";
            rd.DoubleList.ForEach((item) => Txb_thread1.Text += item.ToString() + "\n");

        }

        // привязка для потока 2
        public void BingTask2()
        {
            Dgv_thread2.ItemsSource = null;
            Dgv_thread2.ItemsSource = rs.List;
        }

        // привязка для потока 3
        public void BingTask3()
        {

            Dgv_thread3.ItemsSource = null;
            Dgv_thread3.ItemsSource = th.dictionary.ToList();

        }
        #endregion


        #region ЗАДАЧА 1

        // открыть 
        private void OpenFileTask1(object sender, RoutedEventArgs e) {

            try
            {
                rd.FileName = OpenDW_TXT();    // назначить папку и имя для сохранения
                if (rd.FileName != null)
                {
                    rd.OpenFile();
                    BingTask1();
                }
                   

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }



        }

        // сохранить
        private void SaveFileTask1(object sender, RoutedEventArgs e)
        {
            try
            {
                rd.FileName = SaveDW_TXT();    // назначить папку и имя для сохранения
                if (rd.FileName != null)
                {
                    rd.SaveFile();
                   
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }


        }

        // Собрать новую коллекцию
        private void CreateNewTask1(object sender, RoutedEventArgs e)
        {
            rd.CreateCollecyion();
            BingTask1();
        }


        // Перемешать коллекцию
        private void ShuffuleTask1(object sender, RoutedEventArgs e)
        {            
            rd.ShuffleCollection();
            BingTask1();
        }



        // Сортировать по убыванию
        private void SortTask1(object sender, RoutedEventArgs e)
        {
            rd.SortByDesc();
            BingTask1();
        }






        #endregion

        #region ЗАДАЧА 2

        // открыть 
        private void OpenFileTask2(object sender, RoutedEventArgs e)
        {

            try
            {
                string filename = OpenDW_JSON();

                // назначить папку и имя для сохранения
                if (filename != null)
                {
                    rs = RepairShop.Deserialize(filename);
                    BingTask2();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }



        }

        // сохранить
        private void SaveFileTask2(object sender, RoutedEventArgs e)
        {
            try
            {
                string filename = SaveDW_JSON();

                    // назначить папку и имя для сохранения
                if (filename != null)
                {
                    rs.Serialize(filename);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }


        }

        // Собрать новую коллекцию
        private void CreateNewTask2(object sender, RoutedEventArgs e)
        {
            rs.CreateList();
            BingTask2();
        }

        // Перемешать коллекцию
        private void ShuffuleTask2(object sender, RoutedEventArgs e)
        {
            rs.ShuffleCollection();
            BingTask2();
        }

        #endregion

        #region ЗАДАЧА 3

        // открыть 
        private void OpenFileTask3(object sender, RoutedEventArgs e)
        {

            try
            {
                string filename = OpenDW_TXT();

                // назначить папку и имя для сохранения
                if (filename != null)
                {
                    th.CreateDictionary(filename);
                    BingTask3();

                }                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }


        }


        #endregion

        #region ДИАЛОГОВЫЕ ОКНА

        // диалоговое окно для открытия файла
        public string OpenDW_TXT() {

           
                Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
                string resultPath = null;
          
                dlg.DefaultExt = ".txt";
                dlg.Filter = "Текстовый документ (.txt)|*.txt";

                // Открыть диалоговое окно
                Nullable<bool> result = dlg.ShowDialog();


                if (result == true)
                {

                    resultPath = dlg.FileName;
                }
            
                return resultPath;
            
        }

        // диалоговое окно для открытия файла
        public string OpenDW_JSON()
        {


            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            string resultPath = null;

            dlg.DefaultExt = ".json";
            dlg.Filter = "Файл JSON (.json)|*.json";

            // Открыть диалоговое окно
            Nullable<bool> result = dlg.ShowDialog();


            if (result == true)
            {

                resultPath = dlg.FileName;
            }

            return resultPath;
        }


        // диалоговое окно для сохранения файла
        public string SaveDW_TXT() {

            
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            string resultPath = null;


            dlg.DefaultExt = ".txt"; 
            dlg.Filter = "Текстовый документ (.txt)|*.txt"; 

            // Открыть диалоговое окно

            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                
                resultPath = dlg.FileName;
            }

            return resultPath;



        }
        // диалоговое окно для сохранения файла
        public string SaveDW_JSON()
        {


            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            string resultPath = null;


            dlg.DefaultExt = ".json";
            dlg.Filter = "Файл JSON (.json)|*.json";

            // Открыть диалоговое окно

            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {

                resultPath = dlg.FileName;
            }

            return resultPath;
        }

        #endregion

        // выход
        private void Exit_Command(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}
