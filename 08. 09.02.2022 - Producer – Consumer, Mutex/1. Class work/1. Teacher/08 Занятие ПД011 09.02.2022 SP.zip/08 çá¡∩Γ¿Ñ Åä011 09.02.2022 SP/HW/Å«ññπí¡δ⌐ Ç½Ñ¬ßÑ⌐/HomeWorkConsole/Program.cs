﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using HomeWorkConsole;
using HomeWorkLibrary;
using Microsoft.VisualBasic;

namespace HomeWorkConsole
{
    class Program
    {
        static void Main(string[] args)
        {

            System.Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.Title = "Домашние задание на 09.02.22";

            
            // Создание экземпляра класса приложения
            App app = new App();


            // создание потока
            List<Thread> threads = new List<Thread>(new[] {
                new Thread(app.DemoTask3),
                new Thread(app.DemoTask2),
                new Thread(app.DemoTask1)
            });

            // запуск потоков на параллельное исполнение
            threads.ForEach(t => t.Start());

            // ожидание завершения потоков
            threads.ForEach(t => t.Join());


           
           

        }
    }
}
