﻿using HomeWorkLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkConsole
{

    class Task2Control
    {

        //Создание файла случайных вещественных чисел(не более 20 чисел), создается при первом запуске, 
        //при последующих запусках – перемешивание данных в файле.
        //Сортировка файла по убыванию и сохранение файла);


        // имя файла
        public string FileName { get; set; }


        // класс для обработки по заданию
        public RepairShop RP { get; set; }

        public Task2Control()
        {

            FileName = "test2task.json";                         // хардкодом задаем имя файла для обработки(файл лежит в папке с exe файлом)
            RP = new RepairShop();                              // создаем объект

        }


        // демонстрация обработок
        public void Demo()
        {
            // запрещаем переколючать поток
            // к сожалению, будем блокировать не только вывод в консоль, но и некоторые вычисления
            lock (typeof(Console))
            {
                Console.WriteLine($"\n\tИмя файла: {FileName}");
                Console.WriteLine($"\n\tФайл до обработки: ");
                RP.CreateFile(FileName);
                RP.Show();
                Console.WriteLine($"\n\tФайл перемешан: ");
                RP.ShuffleCollection();
                RP.Show();
            }
        }
    }
}
