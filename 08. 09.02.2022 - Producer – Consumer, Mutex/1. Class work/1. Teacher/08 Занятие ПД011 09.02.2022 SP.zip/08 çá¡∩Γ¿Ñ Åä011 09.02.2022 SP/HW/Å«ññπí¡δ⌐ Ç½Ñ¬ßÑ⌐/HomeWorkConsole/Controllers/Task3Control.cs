﻿using HomeWorkLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkConsole
{
    class Task3Control
    {

        //Создание файла случайных вещественных чисел(не более 20 чисел), создается при первом запуске, 
        //при последующих запусках – перемешивание данных в файле.
        //Сортировка файла по убыванию и сохранение файла);


        // имя файла
        public string FileName { get; set; }


        // класс для обработки по заданию
        public TextHandling TH { get; set; }

        public Task3Control()
        {

            FileName = "test3task.txt";                         // хардкодом задаем имя файла для обработки(файл лежит в папке с exe файлом)
            TH = new TextHandling();                              // создаем объект

        }



        // демонстрация обработок
        public void Demo()
        {
            // запрещаем переколючать поток
            // к сожалению, будем блокировать не только вывод в консоль, но и некоторые вычисления
            lock (typeof(Console))
            {
                Console.WriteLine($"\n\tИмя файла: {FileName}");
                TH.CreateDictionary(FileName);
                TH.ShowDictionary();
            }
        }

    }
}
