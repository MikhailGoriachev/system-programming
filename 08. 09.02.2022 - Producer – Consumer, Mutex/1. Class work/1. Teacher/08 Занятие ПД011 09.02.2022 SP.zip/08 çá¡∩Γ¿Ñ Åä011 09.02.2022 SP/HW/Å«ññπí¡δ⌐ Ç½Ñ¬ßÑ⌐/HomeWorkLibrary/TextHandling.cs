﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkLibrary
{
    // класс, для обработки текста
    public class TextHandling
    {
        public Dictionary<string, int> dictionary { get; set; }


        public TextHandling()
        {
            dictionary = new Dictionary<string, int>();
        }


        // метод для создания файла и записи в него чисел
        public void CreateDictionary(string FileName)
        {
            dictionary.Clear();
            // строка со знаками припинания
            char[] delimiterChars = "  , . ! : ; / ? - = + … — ".ToArray();

            string s;
            StreamReader f = new StreamReader(FileName);
            while ((s = f.ReadLine()) != null)
            {
                // что-нибудь делаем с прочитанной строкой s
                s = s.ToLower();                                // переводим строку в нижний регистр
                string[] words = s.Split(delimiterChars, StringSplitOptions.RemoveEmptyEntries);       // нарезаем строку на слова
                foreach (var item in words)
                {
                    if (dictionary.ContainsKey(item))           // если есть такой ключ, увеличить значение +1
                        dictionary[item] += 1;
                    else
                        dictionary[item] = 1;                // если нет такого ключа, добавить ключ и установить новое значение 1

                }

            }

            f.Close();

        }
        public static string Header() =>
                 $" ┌───────────────────────────┬─────────────────┐\n" +
                 $" │ Слово                     │ Кол. повторений │\n" +
                 $" ├───────────────────────────┼─────────────────┤";





        // статический метод для вывода подвала таблицы
        public static string Footer() =>
                 $" └───────────────────────────┴─────────────────┘";



        // вывод для словаря
        public void ShowDictionary() {


            Console.WriteLine(TextHandling.Header());
            foreach (var item in dictionary.OrderBy(pair => pair.Key))
            {
                Console.WriteLine($" │ {item.Key,-25} │ {item.Value,15} │ ");

            }
            Console.WriteLine(TextHandling.Footer());

        }




    }
}
