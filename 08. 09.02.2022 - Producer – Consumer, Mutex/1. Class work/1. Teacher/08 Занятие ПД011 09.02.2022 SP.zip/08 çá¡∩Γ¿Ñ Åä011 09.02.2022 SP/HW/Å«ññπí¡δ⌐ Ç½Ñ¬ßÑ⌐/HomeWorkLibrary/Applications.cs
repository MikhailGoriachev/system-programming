﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace HomeWorkLibrary
{
    // класс, описывающий заяявку на ремонт ноутбука
    [Serializable]
    [DataContract]
    public class Applications
    {
        //наименование устройства,   
        [DataMember]
        private string _devicename;
        public string DeviceName
        {
            get { return _devicename; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Applications: ошибка наименования устройства");
                _devicename = value;
            }
        }

        // модель
        [DataMember]
        private string _devicemodel;
        public string DeviceModel
        {
            get { return _devicemodel; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Applications: ошибка модели устройства");
                _devicemodel = value;
            }
        }

        // тип процессора
        [DataMember]
        private string _typeprocessor;
        public string TypeProcessor
        {
            get { return _typeprocessor; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Applications: ошибка типа процессора");
                _typeprocessor = value;
            }
        }

        // емкость накопителя
        [DataMember]
        private double _storagecapacity;
        public double StorageCapacity
        {
            get { return _storagecapacity; }
            set
            {
                if (value <= 0)
                    throw new Exception("Applications: ошибка емкости накопителя");
                _storagecapacity = value;
            }
        }

        // диагональ экрана
        [DataMember]
        private double _screendiagonal;
        public double ScreenDiagonal
        {
            get { return _screendiagonal; }
            set
            {
                if (value <= 0)
                    throw new Exception("Applications: ошибка диагонали экрана");
                _screendiagonal = value;
            }
        }

        // описание неисправности
        [DataMember]
        private string _defect;
        public string Defect
        {
            get { return _defect; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Applications: ошибка описания неисправности");
                _defect = value;
            }
        }

        // фамилия и инициалы владельца
        [DataMember]
        private string _ownername;
        public string OwnerName
        {
            get { return _ownername; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Applications: ошибка фамилии и инициалов владельца");
                _ownername = value;
            }
        }




        // конструктор с параметрами
        public Applications(string devicename, string devicemodel, string typeprocessor,  double storagecapacity, double screendiagonal, string defect, string ownername)
        {
            DeviceName = devicename;
            DeviceModel = devicemodel;
            TypeProcessor = typeprocessor;
            StorageCapacity = storagecapacity;
            ScreenDiagonal = screendiagonal;
            Defect = defect;
            OwnerName = ownername;
        }



        public static string Header()=>
                    $" ┌────────────┬─────────────────┬─────────────────┬──────────┬───────┬──────────────────────────────────────────────────┬───────────────────────────┐\n" +
                    $" │ Название   │ Модель          │ Процессор       │ ОЗУ      │ Д/Э   │ Описание дефекта                                 │ Фамилия И.О. владельца    │\n" +
                    $" ├────────────┼─────────────────┼─────────────────┼──────────┼───────┼──────────────────────────────────────────────────┼───────────────────────────┤";

       

      

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
                    $" └────────────┴─────────────────┴─────────────────┴──────────┴───────┴──────────────────────────────────────────────────┴───────────────────────────┘";



        public string ToTableRow => $" │ {_devicename,-10} │ {_devicemodel,-15} │ {_typeprocessor,-15} │ {_storagecapacity,8:f2} │ {_screendiagonal,5:f1} │ {_defect,-48} │ {_ownername,-25} │";




        #region ФОРМИРОВАНИЕ Электорприбора


        // модели телевизоров
        static string[] DeviseNames =  {
                "Samsung"  ,
                "HP"       ,
                "Dell"     ,
                "Acer"     ,
                "Asus"                
         };


        static string[] DeviseModels =  {
                ("A321"        ),
                ("Pavilion 3"        ),
                ("Inspirion G3"           ),
                ("SD1550"         ),
                ("Raptor 2"         ),
                ("Aspire 3"         ),
                ("Qualcom 12"  ),
                ("NB1030"          )

         };


        static string[] TypeProcessors =  {
                ("Intel Core I7"        ),
                ("Intel Core I5"        ),
                ("Intel Core I3"           ),
                ("AMD Razen 3"         ),
                ("AMD Razen 5"         ),
                ("AMD Razen 7"         ),
                ("Intel Xeon"  )
         };


        static double[] StorageCapacities =  {
                (  4096      ),
                (  8192      ),
                (  16384     ),
                (  32768     )
               
         };

        static double[] ScreenDiagonals =  {
                (  14      ),
                (  15.6      ),
                (  17.3     )
         };

        static string[] defects =  {
                "поломка матрицы, вследствие удара",
                "попадание влаги в шлейф матрицы",
                "отсутствие подсветки матрицы",
                "отсутствие звука",
                "зависание основного экрана",
                "поломка платы",
                "отсутствие реакции на включение",
                "сбои программного обеспечения",
                "полное или частичное отсутствие изображения",
                "некорректное цветовоспроизведение",                
                "перегрев оборудования, вследствие попадания пыли"
        };

        // ФИО для владельцев
        public static List<string> ownerNames = new List<string>{
                "Анисимова Д. Б.",
                "Мальцев С. К.",
                "Колесникова Е. Р.",
                "Кузьмин Т. А.",
                "Белова В. С.",
                "Волков В. Е.",
                "Павлова К. Т.",
                "Дегтярев С. А.",
                "Орлов Р. И.",
                "Алексеева Э. С.",
                "Афанасьева А. М.",
                "Фомина М. С.",
                "Захаров А. Я.",
                "Булгаков А. А.",
                "Рыбаков Р. Э."
        };


        // фабрика создания электроприборов
        public static Applications CreateApplications()
        {

            Applications result = new Applications(

                    DeviseNames[ Utils.GetRandom(0, DeviseNames.Length)],
                    DeviseModels[ Utils.GetRandom(0, DeviseModels.Length)],
                    TypeProcessors[ Utils.GetRandom(0, TypeProcessors.Length)],
                    StorageCapacities[ Utils.GetRandom(0, StorageCapacities.Length)],
                    ScreenDiagonals[ Utils.GetRandom(0, ScreenDiagonals.Length)],
                    defects[ Utils.GetRandom(0, defects.Length)],
                    ownerNames[ Utils.GetRandom(0, ownerNames.Count-1)]
                );

            return result;
        }



        #endregion


    }
}
