﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkLibrary
{
    // коллекции заявок на ремонт ноутбуков 
    [Serializable]
    [DataContract]
    public class RepairShop
    {
        // коллекция заявок
        [DataMember]
        public List<Applications> List { get; set; }


        public RepairShop() {

            List = new List<Applications>();


        }

        // Начальное формирование данных
        public void CreateList()
        {
            List.Clear();
            for (int i = 0; i < Utils.GetRandom(12, 16); i++)
                List.Add(Applications.CreateApplications());
        }

        // перемешать коллекцию
        public void ShuffleCollection()
        {
            List = List.OrderBy(x => Utils.Random.Next()).ToList();
        }

        // вывод в консоль
        public void Show() {

            Console.WriteLine(Applications.Header());
            List.ForEach(item => Console.WriteLine(item.ToTableRow));
            Console.WriteLine(Applications.Footer());
        }

        public void CreateFile(string FileName)
        {

            // проверяем существует ли файл файл
            if (!File.Exists(FileName))// если файл не существует
            {
                CreateList();   // начальное формирование коллекции
                Serialize(FileName);// запись файла в формат JSON
            }

            else // если файл существует
            {

                List = Deserialize(FileName).List;  // считываем файл
                ShuffleCollection();    // перемешиваем коллекцию
                Serialize(FileName);    // сохраняем коллекцию

            }

        }


        // сериализация
        public void Serialize(string fileName)
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(RepairShop));

            using (FileStream fs = new FileStream(fileName, FileMode.Create))
            {
                jsonFormatter.WriteObject(fs, this);
            }
        }

        // десериализация - удобно выполнять статическим методом
        public static RepairShop Deserialize(string fileName)
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(RepairShop));
            RepairShop newRepairShop = new RepairShop();
            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate))
            {
                newRepairShop = (RepairShop)jsonFormatter.ReadObject(fs);
            }

            return newRepairShop;

        }


    }
}
