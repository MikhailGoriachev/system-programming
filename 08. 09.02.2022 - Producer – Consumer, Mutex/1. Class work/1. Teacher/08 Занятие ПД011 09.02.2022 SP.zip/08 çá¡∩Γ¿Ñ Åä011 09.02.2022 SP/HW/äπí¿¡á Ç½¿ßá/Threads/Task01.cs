﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Threads
{
    /* Обработка 1.
     * Cоздание файла случайных вещественных чисел (не более 20 чисел), создается при первом запуске, 
     * при последующих запусках – перемешивание данных в файле. 
     * Сортировка файла по убыванию и сохранение файла.
     */
    public class Task01 {

        // имя бинарного файла
        private string _fileName;
        public string FileName {
            get => _fileName;

            // при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
            set {
                _fileName = value;

                if (!File.Exists(_fileName)) {
                    var data = Enumerable
                        .Repeat(0, Utils.GetRandom(8, 15))
                        .Select(x => Utils.GetRandom(-10d, 20d))
                        .ToList();

                    using (BinaryWriter bwr = new BinaryWriter(File.Create(_fileName)))
                        data.ForEach(datum => bwr.Write(datum));
                }
                // при последующих запусках – перемешивание данных в файле
                else {
                    // чтение из файла в коллекцию
                    List<double> data = new List<double>();
                    using (BinaryReader brd = new BinaryReader(File.OpenRead(_fileName))) {
                        while (brd.BaseStream.Position < brd.BaseStream.Length)
                            data.Add(brd.ReadDouble());
                    } // using

                    // Utils.Shuffle(data);
                     data = data
                        .OrderBy(item => Utils.Random.Next())
                        .ToList();

                    using (BinaryWriter bwr = new BinaryWriter(File.Create(_fileName)))
                        data.ForEach(datum => bwr.Write(datum));
                }// if
            } // set
        } // FileName

        // чтение коллекции из файла
        private List<double> GetAll() {
            List<double> data = new List<double>();
            using (BinaryReader brd = new BinaryReader(File.OpenRead(_fileName))) {
                while (brd.BaseStream.Position < brd.BaseStream.Length)
                    data.Add(brd.ReadDouble());
            } // using

            return data;
        } // GetAll

        // запись коллекции в файл
        private void PutAll(List<double> data) {
            using (BinaryWriter bwr = new BinaryWriter(File.Create(_fileName)))
                data.ForEach(datum => bwr.Write(datum));
        } // PutAll

        // обработка по заданию для WPF
        public StringBuilder Process_WPF() {
            // чтение из файла в коллекцию
            List<double> data = GetAll();

            StringBuilder sb = OutputToStrigBuilder(data, $"Поток 1: файл \"{Path.GetFileName(_fileName)}\":\r\n");

            // Сортировка по убыванию в другую коллекцию, для вывод исходных данных
            List<double> temp = data.OrderByDescending(x => x).ToList();

            // сохранение файла
            PutAll(temp);

            sb.AppendLine(OutputToStrigBuilder(temp, $"\r\n\r\nПоток 1: файл \"{Path.GetFileName(_fileName)}\" упорядочен по убыванию:\r\n").ToString());

            return sb;
        } // Process_WPF

        // обработка по заданию для консольного приложения
        public void Process_Console() {
            // чтение из файла в коллекцию
            List<double> data = GetAll();

            // Сортировка по убыванию в другую коллекцию, для вывод исходных данных
            List<double> temp = data.OrderByDescending(x => x).ToList();

            // сохранение файла
            PutAll(temp);

            lock (typeof(Console)){
                OutputToСonsole(data, $"Поток 1: файл \"{Path.GetFileName(_fileName)}\":");
                OutputToСonsole(temp, $"\r\n\r\nПоток 1: файл \"{Path.GetFileName(_fileName)}\" упорядочен по убыванию:");
            } // lock
            
        } // Process_Console

        // вывод коллекции в StringBuilder
        private StringBuilder OutputToStrigBuilder(List<double> data, string title)  {
            StringBuilder sb = new StringBuilder(title);

            int i = 1;
            data.ForEach(d => { sb.Append($"{d,8:f2}"); if (i++ % 8 == 0) sb.AppendLine(); });

            sb.AppendLine();
            return sb;
        } // OutputToStrigBuilder

        // вывод коллекции в консоль
        private static void OutputToСonsole(List<double> data, string title)  {
            Console.WriteLine(title);
            data.ForEach(d => Console.Write($"{d,8:f2}"));
        } // OutputToСonsole

    } // Task01
}
