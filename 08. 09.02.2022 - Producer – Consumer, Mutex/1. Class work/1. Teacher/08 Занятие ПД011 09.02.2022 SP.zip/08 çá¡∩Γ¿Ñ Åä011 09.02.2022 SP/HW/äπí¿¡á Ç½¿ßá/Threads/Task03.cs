﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Threads
{
    /* Обработка 3.
     * Обработка текстового файла – подсчет (без учета регистра) частоты слов, 
     * результаты выводите в словарь (пары «слово – количество»)
     */
    public class Task03 {
        // имя файла
        public string FileName { get; set; }

        // создание частотного словаря
        private Dictionary<string, int> CreateDictionary() {
            Dictionary<string, int> words = new Dictionary<string, int>();

            var delimiters = " ,.:!?'\"\t\n-+\r".ToCharArray();
            File.ReadAllText(FileName)
                .ToLower()
                .Split(delimiters, StringSplitOptions.RemoveEmptyEntries)
                .ToList()
                .ForEach(word => {
                    if (!words.ContainsKey(word))
                        words[word] = 0;
                    words[word]++;
                });
            return words;
        } // CreateDictionary

        // обработка по заданию для консольного приложения
        public void Process_Console() {
            // обработка по заданию
            List<string> strings = File.ReadLines(FileName).ToList();

            Dictionary<string, int> words = CreateDictionary();

            // вывод
            lock (typeof(Console)) {
                OutputToConsole(strings, $"\n\nПоток 3: файл \"{Path.GetFileName(FileName)}\":");
                OutputToConsole(words.Select(w => $"{w.Key,-15} - {w.Value,2}").ToList(), $"\nПоток 3: подсчет (без учета регистра) частоты слов:");
            }
        } // Process_Console

        // обработка по заданию для приложения WPF
        public Dictionary<string, int> Process_WPF(out string fileText) {
            fileText = $"Поток 3: файл \"{Path.GetFileName(FileName)}\":\r\n{File.ReadAllText(FileName)}";
            
            // пары «слово – количество»
            return CreateDictionary();
        } // Process_WPF


        // вывод в консоль
        private void OutputToConsole(List<string> list, string title) {
            Console.WriteLine(title);
            list.ForEach(item => Console.WriteLine($"\t{item}"));
            Console.WriteLine();
        } // OutputToConsole
    } // Task03
}
