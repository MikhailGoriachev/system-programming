﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using Processes.Models;

namespace Processes
{
    public partial class Form1 : Form
    {
        //коллекция для хранения истории вызова приложений
        private List<File> fileHistory = new List<File>();
        public Form1()
        {
            InitializeComponent();

            //блокнот
            prcMain.StartInfo = new ProcessStartInfo("notepad.exe"){WindowStyle = ProcessWindowStyle.Normal};

            //калькулятор
            PrcCalc.StartInfo = new ProcessStartInfo("calc.exe") {WindowStyle = ProcessWindowStyle.Normal};

            //коммандная строка
            PrcCommand.StartInfo = new ProcessStartInfo("cmd.exe") {WindowStyle = ProcessWindowStyle.Normal};

            //madia player
            PrcPlayer.StartInfo = new ProcessStartInfo("dvdplay.exe") {WindowStyle = ProcessWindowStyle.Normal};


            
        }

        private void Notepad_Click(object sender, EventArgs e)
        {
            // запускаем приложение
            prcMain.Start();

            // создаем объект класса File
            File file = new File(prcMain.ProcessName, prcMain.StartTime);

            //добавляем в коллекцию истории
            fileHistory.Add(file);

            //обновляем ListView
            ListViewUpdate();

        }

        private void Calc_Click(object sender, EventArgs e)
        {
            //запускаем приложение
            PrcCalc.Start();

            // создаем объект класса File
            File file = new File(PrcCalc.ProcessName, PrcCalc.StartTime);

            //добавляем в коллекцию истоиии
            fileHistory.Add(file);

            //обновим ListView
            ListViewUpdate();
        }

        public void ListViewUpdate()
        {
            LsvProcess.Items.Clear();

            foreach (var item in fileHistory)
            {
                var newListViewItem = new ListViewItem(new[]
                {
                    $"{item.FileName}", $"{item.DateAndTime}"
                });

                LsvProcess.Items.Add(newListViewItem);
            }
        }

        private void Command_Click(object sender, EventArgs e)
        {
            //запускаем приложение
            PrcCommand.Start();

            // создаем объект класса File
            File file = new File(PrcCommand.ProcessName, PrcCommand.StartTime);

            //добавляем в коллекцию истоиии
            fileHistory.Add(file);

            //обновим ListView
            ListViewUpdate();
        }

        private void Player_Click(object sender, EventArgs e)
        {
            PrcPlayer.Start();

            File file = new File(PrcPlayer.ProcessName, PrcPlayer.StartTime);

            fileHistory.Add(file);

            ListViewUpdate();
        }

        
    }
}
