﻿
namespace Processes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.блокнотToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.TsbNotepad = new System.Windows.Forms.ToolStripButton();
            this.TsbCalc = new System.Windows.Forms.ToolStripButton();
            this.TsbCommand = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.LsvProcess = new System.Windows.Forms.ListView();
            this.FileName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DateTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.prcMain = new System.Diagnostics.Process();
            this.PrcCalc = new System.Diagnostics.Process();
            this.PrcCommand = new System.Diagnostics.Process();
            this.PrcPlayer = new System.Diagnostics.Process();
            this.PrcSolit = new System.Diagnostics.Process();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1116, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.блокнотToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(69, 29);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // блокнотToolStripMenuItem
            // 
            this.блокнотToolStripMenuItem.Name = "блокнотToolStripMenuItem";
            this.блокнотToolStripMenuItem.Size = new System.Drawing.Size(181, 34);
            this.блокнотToolStripMenuItem.Text = "Блокнот";
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbNotepad,
            this.TsbCalc,
            this.TsbCommand,
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 33);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1116, 57);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // TsbNotepad
            // 
            this.TsbNotepad.AutoSize = false;
            this.TsbNotepad.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNotepad.Image = global::Processes.Properties.Resources.showContract;
            this.TsbNotepad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNotepad.Name = "TsbNotepad";
            this.TsbNotepad.Size = new System.Drawing.Size(50, 50);
            this.TsbNotepad.Text = "toolStripButton1";
            this.TsbNotepad.Click += new System.EventHandler(this.Notepad_Click);
            // 
            // TsbCalc
            // 
            this.TsbCalc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbCalc.Image = global::Processes.Properties.Resources.calc;
            this.TsbCalc.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbCalc.Name = "TsbCalc";
            this.TsbCalc.Size = new System.Drawing.Size(34, 52);
            this.TsbCalc.Text = "toolStripButton1";
            this.TsbCalc.Click += new System.EventHandler(this.Calc_Click);
            // 
            // TsbCommand
            // 
            this.TsbCommand.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbCommand.Image = global::Processes.Properties.Resources.free_icon_command_line_2535492;
            this.TsbCommand.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbCommand.Name = "TsbCommand";
            this.TsbCommand.Size = new System.Drawing.Size(34, 52);
            this.TsbCommand.Text = "toolStripButton1";
            this.TsbCommand.Click += new System.EventHandler(this.Command_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::Processes.Properties.Resources.pngegg;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(34, 52);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.Player_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipTitle = "Блокнот";
            // 
            // LsvProcess
            // 
            this.LsvProcess.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.FileName,
            this.DateTime});
            this.LsvProcess.HideSelection = false;
            this.LsvProcess.Location = new System.Drawing.Point(12, 93);
            this.LsvProcess.Name = "LsvProcess";
            this.LsvProcess.Size = new System.Drawing.Size(1092, 434);
            this.LsvProcess.TabIndex = 2;
            this.LsvProcess.UseCompatibleStateImageBehavior = false;
            this.LsvProcess.View = System.Windows.Forms.View.Details;
            // 
            // FileName
            // 
            this.FileName.Text = "Имя файла";
            this.FileName.Width = 292;
            // 
            // DateTime
            // 
            this.DateTime.Text = "Время и дата запуска";
            this.DateTime.Width = 333;
            // 
            // prcMain
            // 
            this.prcMain.StartInfo.Domain = "";
            this.prcMain.StartInfo.LoadUserProfile = false;
            this.prcMain.StartInfo.Password = null;
            this.prcMain.StartInfo.StandardErrorEncoding = null;
            this.prcMain.StartInfo.StandardOutputEncoding = null;
            this.prcMain.StartInfo.UserName = "";
            this.prcMain.SynchronizingObject = this;
            // 
            // PrcCalc
            // 
            this.PrcCalc.StartInfo.Domain = "";
            this.PrcCalc.StartInfo.LoadUserProfile = false;
            this.PrcCalc.StartInfo.Password = null;
            this.PrcCalc.StartInfo.StandardErrorEncoding = null;
            this.PrcCalc.StartInfo.StandardOutputEncoding = null;
            this.PrcCalc.StartInfo.UserName = "";
            this.PrcCalc.SynchronizingObject = this;
            // 
            // PrcCommand
            // 
            this.PrcCommand.StartInfo.Domain = "";
            this.PrcCommand.StartInfo.LoadUserProfile = false;
            this.PrcCommand.StartInfo.Password = null;
            this.PrcCommand.StartInfo.StandardErrorEncoding = null;
            this.PrcCommand.StartInfo.StandardOutputEncoding = null;
            this.PrcCommand.StartInfo.UserName = "";
            this.PrcCommand.SynchronizingObject = this;
            // 
            // PrcPlayer
            // 
            this.PrcPlayer.StartInfo.Domain = "";
            this.PrcPlayer.StartInfo.LoadUserProfile = false;
            this.PrcPlayer.StartInfo.Password = null;
            this.PrcPlayer.StartInfo.StandardErrorEncoding = null;
            this.PrcPlayer.StartInfo.StandardOutputEncoding = null;
            this.PrcPlayer.StartInfo.UserName = "";
            this.PrcPlayer.SynchronizingObject = this;
            // 
            // PrcSolit
            // 
            this.PrcSolit.StartInfo.Domain = "";
            this.PrcSolit.StartInfo.LoadUserProfile = false;
            this.PrcSolit.StartInfo.Password = null;
            this.PrcSolit.StartInfo.StandardErrorEncoding = null;
            this.PrcSolit.StartInfo.StandardOutputEncoding = null;
            this.PrcSolit.StartInfo.UserName = "";
            this.PrcSolit.SynchronizingObject = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1116, 539);
            this.Controls.Add(this.LsvProcess);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Список проложений Windows";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem блокнотToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton TsbNotepad;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ListView LsvProcess;
        public System.Windows.Forms.ColumnHeader FileName;
        public System.Windows.Forms.ColumnHeader DateTime;
        private System.Diagnostics.Process prcMain;
        private System.Windows.Forms.ToolStripButton TsbCalc;
        private System.Diagnostics.Process PrcCalc;
        private System.Windows.Forms.ToolStripButton TsbCommand;
        private System.Diagnostics.Process PrcCommand;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Diagnostics.Process PrcPlayer;
        private System.Diagnostics.Process PrcSolit;
    }
}

