﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Processes.Models
{
    public class File
    {
        //полное имя файла
        public string FileName { get; set; }
        // дата и время запуска
        public DateTime DateAndTime { get; set; }

        public File(string filename, DateTime date)
        {
            FileName = filename;
            DateAndTime = date;
        }
    }
}
