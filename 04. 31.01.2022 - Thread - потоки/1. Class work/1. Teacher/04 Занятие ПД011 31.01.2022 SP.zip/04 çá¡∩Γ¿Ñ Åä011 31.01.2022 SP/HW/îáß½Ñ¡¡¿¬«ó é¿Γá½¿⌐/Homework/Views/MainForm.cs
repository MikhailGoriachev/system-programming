﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Homework.Controllers;

namespace Homework.Views
{
	public partial class MainForm : Form
	{
		private ExecutionController _controller;

		public MainForm() : this(new ExecutionController())
		{
		}

		public MainForm(ExecutionController controller)
		{
			InitializeComponent();
			_controller = controller;
		}

		private void MainForm_Load(object sender, EventArgs e)
		{

		}

		private void BtnExecute_Click(object sender, EventArgs e)
		{
			if (!_controller.Validate(TxbPath.Text))
			{
				MessageBox.Show("Неверный путь файла или его тип", "Ошибка", MessageBoxButtons.OK,
					MessageBoxIcon.Error);
				return;
			}

			_controller.Execute(TxbPath.Text);
			UpdateListView();
		}

		private void BtnOpen_Click(object sender, EventArgs e)
		{
			// установка директории для выбора файла 
			OfdMain.InitialDirectory = Environment.CurrentDirectory;
			OfdMain.Filter = "Исполняемые файлы exe(*.exe)|*.exe";

			// запуск диалогового окна открытия и проверка на результат
			if (OfdMain.ShowDialog() == DialogResult.OK)
				TxbPath.Text = OfdMain.FileName;
		}


		// Метод обновления данных ListView
		private void UpdateListView()
		{
			LsvHistory.Items.Clear();

			_controller.History.ForEach(r => LsvHistory.Items.Add(new ListViewItem(new[]
			{
				$"{r.ProcessName}", $"{r.FullFileName}", $"{r.ExecuteDateTime}" //:dd/MM/YYYY HH:mm:ss
			})));
		}
	}
}
