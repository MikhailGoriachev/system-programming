﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models;

namespace Homework.Controllers
{
	// контроллер для работы запуска исполняемых файлов
	public class ExecutionController
	{
		// ассоциативный массив запущенных исполняемых файлов
		// (в текущей реализации роли не играет, 
		private Dictionary<int, Process> _processes;

		// коллекция записей истории
		private List<HistoryRecord> _history;
		public List<HistoryRecord> History => _history;


		public ExecutionController() : this(new Dictionary<int, Process>(), new List<HistoryRecord>())
		{
		}


		public ExecutionController(Dictionary<int, Process> processes, List<HistoryRecord> history)
		{
			_processes = processes;
			_history = history;
		}

		
		// запуск файла
		public bool Execute(string path)
		{
			Process proc = new Process();
			proc.StartInfo = new ProcessStartInfo(path) {WindowStyle = ProcessWindowStyle.Normal};

			if (!proc.Start()) return true;
			
			_processes.Add(_processes.Count == 0? 0 : _processes.Keys.Max() + 1, proc);
			
			AddHistoryRecord(proc.ProcessName, proc.MainModule?.FileName, proc.StartTime);

			return true;
		}

		// валидация пути и имени файла
		public bool Validate(string path) =>
			(File.Exists(path) || Path.GetExtension(path).Equals("exe"));


		// добавление записи в историю
		public void AddHistoryRecord(string procName, string fileName, DateTime dateTime) => _history.Add(
			new HistoryRecord
			{
				ExecuteDateTime = dateTime,
				FullFileName = fileName,
				ProcessName = fileName
			});

	}
}
