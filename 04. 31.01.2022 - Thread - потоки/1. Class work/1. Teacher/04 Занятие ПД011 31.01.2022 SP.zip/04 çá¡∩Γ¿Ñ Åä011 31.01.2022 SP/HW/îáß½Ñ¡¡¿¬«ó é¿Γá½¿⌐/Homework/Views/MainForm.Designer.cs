﻿
namespace Homework.Views
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.MniMain = new System.Windows.Forms.MenuStrip();
			this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
			this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.TstrMain = new System.Windows.Forms.ToolStrip();
			this.GrbSelecting = new System.Windows.Forms.GroupBox();
			this.GrbHistory = new System.Windows.Forms.GroupBox();
			this.LblPromptPath = new System.Windows.Forms.Label();
			this.TxbPath = new System.Windows.Forms.TextBox();
			this.BtnOpen = new System.Windows.Forms.Button();
			this.BtnExecute = new System.Windows.Forms.Button();
			this.LsvHistory = new System.Windows.Forms.ListView();
			this.OfdMain = new System.Windows.Forms.OpenFileDialog();
			this.ClnProcName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.ClnFileName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.ClnDateTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.MniMain.SuspendLayout();
			this.GrbSelecting.SuspendLayout();
			this.GrbHistory.SuspendLayout();
			this.SuspendLayout();
			// 
			// MniMain
			// 
			this.MniMain.Font = new System.Drawing.Font("Segoe UI", 11F);
			this.MniMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniHelp});
			this.MniMain.Location = new System.Drawing.Point(0, 0);
			this.MniMain.Name = "MniMain";
			this.MniMain.Size = new System.Drawing.Size(835, 28);
			this.MniMain.TabIndex = 0;
			this.MniMain.Text = "menuStrip1";
			// 
			// MniFile
			// 
			this.MniFile.Name = "MniFile";
			this.MniFile.Size = new System.Drawing.Size(57, 24);
			this.MniFile.Text = "Файл";
			// 
			// MniHelp
			// 
			this.MniHelp.Name = "MniHelp";
			this.MniHelp.Size = new System.Drawing.Size(79, 24);
			this.MniHelp.Text = "Справка";
			// 
			// TstrMain
			// 
			this.TstrMain.Font = new System.Drawing.Font("Segoe UI", 11F);
			this.TstrMain.Location = new System.Drawing.Point(0, 28);
			this.TstrMain.Name = "TstrMain";
			this.TstrMain.Size = new System.Drawing.Size(835, 25);
			this.TstrMain.TabIndex = 1;
			this.TstrMain.Text = "toolStrip1";
			// 
			// GrbSelecting
			// 
			this.GrbSelecting.Controls.Add(this.BtnExecute);
			this.GrbSelecting.Controls.Add(this.BtnOpen);
			this.GrbSelecting.Controls.Add(this.TxbPath);
			this.GrbSelecting.Controls.Add(this.LblPromptPath);
			this.GrbSelecting.Location = new System.Drawing.Point(8, 64);
			this.GrbSelecting.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
			this.GrbSelecting.Name = "GrbSelecting";
			this.GrbSelecting.Size = new System.Drawing.Size(816, 112);
			this.GrbSelecting.TabIndex = 2;
			this.GrbSelecting.TabStop = false;
			this.GrbSelecting.Text = "Файл для запуска";
			// 
			// GrbHistory
			// 
			this.GrbHistory.Controls.Add(this.LsvHistory);
			this.GrbHistory.Location = new System.Drawing.Point(8, 184);
			this.GrbHistory.Name = "GrbHistory";
			this.GrbHistory.Size = new System.Drawing.Size(824, 288);
			this.GrbHistory.TabIndex = 3;
			this.GrbHistory.TabStop = false;
			this.GrbHistory.Text = "История";
			// 
			// LblPromptPath
			// 
			this.LblPromptPath.AutoSize = true;
			this.LblPromptPath.Location = new System.Drawing.Point(16, 40);
			this.LblPromptPath.Name = "LblPromptPath";
			this.LblPromptPath.Size = new System.Drawing.Size(52, 18);
			this.LblPromptPath.TabIndex = 0;
			this.LblPromptPath.Text = "Путь:";
			// 
			// TxbPath
			// 
			this.TxbPath.Location = new System.Drawing.Point(70, 37);
			this.TxbPath.Name = "TxbPath";
			this.TxbPath.Size = new System.Drawing.Size(696, 27);
			this.TxbPath.TabIndex = 1;
			// 
			// BtnOpen
			// 
			this.BtnOpen.Location = new System.Drawing.Point(768, 37);
			this.BtnOpen.Name = "BtnOpen";
			this.BtnOpen.Size = new System.Drawing.Size(32, 27);
			this.BtnOpen.TabIndex = 2;
			this.BtnOpen.Text = "button1";
			this.BtnOpen.UseVisualStyleBackColor = true;
			this.BtnOpen.Click += new System.EventHandler(this.BtnOpen_Click);
			// 
			// BtnExecute
			// 
			this.BtnExecute.Location = new System.Drawing.Point(680, 72);
			this.BtnExecute.Name = "BtnExecute";
			this.BtnExecute.Size = new System.Drawing.Size(120, 32);
			this.BtnExecute.TabIndex = 3;
			this.BtnExecute.Text = "Запуск";
			this.BtnExecute.UseVisualStyleBackColor = true;
			this.BtnExecute.Click += new System.EventHandler(this.BtnExecute_Click);
			// 
			// LsvHistory
			// 
			this.LsvHistory.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ClnProcName,
            this.ClnFileName,
            this.ClnDateTime});
			this.LsvHistory.HideSelection = false;
			this.LsvHistory.Location = new System.Drawing.Point(16, 32);
			this.LsvHistory.Name = "LsvHistory";
			this.LsvHistory.Size = new System.Drawing.Size(792, 248);
			this.LsvHistory.TabIndex = 0;
			this.LsvHistory.UseCompatibleStateImageBehavior = false;
			this.LsvHistory.View = System.Windows.Forms.View.Details;
			// 
			// ClnProcName
			// 
			this.ClnProcName.Text = "Имя процесса";
			// 
			// ClnFileName
			// 
			this.ClnFileName.Text = "Полное имя файла";
			// 
			// ClnDateTime
			// 
			this.ClnDateTime.Text = "Дата и время запуска";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(835, 479);
			this.Controls.Add(this.GrbHistory);
			this.Controls.Add(this.GrbSelecting);
			this.Controls.Add(this.TstrMain);
			this.Controls.Add(this.MniMain);
			this.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MainMenuStrip = this.MniMain;
			this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Домашняя работа";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.MniMain.ResumeLayout(false);
			this.MniMain.PerformLayout();
			this.GrbSelecting.ResumeLayout(false);
			this.GrbSelecting.PerformLayout();
			this.GrbHistory.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip MniMain;
		private System.Windows.Forms.ToolStripMenuItem MniFile;
		private System.Windows.Forms.ToolStripMenuItem MniHelp;
		private System.Windows.Forms.ToolStrip TstrMain;
		private System.Windows.Forms.GroupBox GrbSelecting;
		private System.Windows.Forms.GroupBox GrbHistory;
		private System.Windows.Forms.Button BtnExecute;
		private System.Windows.Forms.Button BtnOpen;
		private System.Windows.Forms.TextBox TxbPath;
		private System.Windows.Forms.Label LblPromptPath;
		private System.Windows.Forms.ListView LsvHistory;
		private System.Windows.Forms.OpenFileDialog OfdMain;
		private System.Windows.Forms.ColumnHeader ClnProcName;
		private System.Windows.Forms.ColumnHeader ClnFileName;
		private System.Windows.Forms.ColumnHeader ClnDateTime;
	}
}

