﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	// Запись данных в истории запусков исполняемых файлов
	public class HistoryRecord
	{
		// имя процесса
		public string ProcessName { get; set; }
		
		// полное имя файла
		public string FullFileName { get; set; }
		
		// дата и время запуска
		public DateTime ExecuteDateTime { get; set; }
	}
}
