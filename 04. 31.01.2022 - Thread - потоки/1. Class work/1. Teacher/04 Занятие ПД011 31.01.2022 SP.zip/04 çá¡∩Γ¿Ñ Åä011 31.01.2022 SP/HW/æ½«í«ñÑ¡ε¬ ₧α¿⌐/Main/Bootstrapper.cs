﻿using FluentValidation;
using Main.Infrastructure;
using Main.Pages.ProcessesTab;
using Main.Pages.Shell;
using Stylet;
using StyletIoC;


namespace Main
{
	public sealed class Bootstrapper : Bootstrapper<ShellViewModel>
	{
		protected override void ConfigureIoC(IStyletIoCBuilder builder)
		{
			builder.Bind<IViewManager>().To<ViewManagerSupportGenericViewModels>();

			builder.Bind(typeof(IModelValidator<>)).To(typeof(FluentValidationAdapter<>));
			builder.Bind(typeof(IValidator<>)).ToAllImplementations();
		}
	}
}