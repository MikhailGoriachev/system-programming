﻿using Main.Infrastructure;
using Main.Pages.ProcessesTab;
using Stylet;


namespace Main.Pages.Shell
{
	public sealed class ShellViewModel : Conductor<Screen>.Collection.OneActive, IShell
	{
		public ShellViewModel(ProcessesTabViewModel processesTab) =>
			ActivateItem(processesTab);
	}
}