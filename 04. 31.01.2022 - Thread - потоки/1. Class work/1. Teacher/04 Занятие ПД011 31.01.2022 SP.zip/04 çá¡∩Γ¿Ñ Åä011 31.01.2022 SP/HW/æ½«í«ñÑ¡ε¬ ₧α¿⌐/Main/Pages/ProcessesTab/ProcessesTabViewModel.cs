﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using FluentValidation;
using Main.Infrastructure;
using Stylet;


namespace Main.Pages.ProcessesTab
{
	public sealed record ProcessInfo(Process Process, DateTime StartTime);


	public sealed class ProcessesTabViewModelValidator : AbstractValidator<ProcessesTabViewModel>
	{
		public ProcessesTabViewModelValidator()
		{
			RuleFor(model => model.ProcessName)
				.NotEmpty()
				.WithMessage("Процесс должен быть указан");

			When(model => IsExecutable(model.ProcessName), () =>
				{
					RuleFor(model => model.ProcessName)
						.Must(IsProcessExists)
						.WithMessage("Процесс с таким именем не существует");
				})
				.Otherwise(() =>
				{
					RuleFor(model => model.ProcessName)
						.Must(s => IsProcessExists(AddDotExe(s)))
						.WithMessage("Процесс с таким именем не существует");
				});
		}


		private static bool IsProcessExists(string processName) =>
			File.Exists($@"{Environment.SystemDirectory}\{processName}");


		private static bool IsExecutable(string fileName) => fileName.EndsWith(".exe", StringComparison.Ordinal);


		private static string AddDotExe(string fileName) =>
			$"{fileName}.exe";
	}


	public class ProcessesTabViewModel : TabScreen
	{
		public BindableCollection<ProcessInfo> RunningProcesses { get; } = new();
		public string ProcessName { get; set; } = string.Empty;

		public bool CanStart => HasErrors == false;


		public ProcessesTabViewModel(IModelValidator<ProcessesTabViewModel> validator) :
			base("Процессы", validator) { }


		public void Start()
		{
			var process = new Process
			{
				StartInfo           = new(ProcessName),
				EnableRaisingEvents = true
			};

			var now = DateTime.UtcNow;
			var startupInfo = new ProcessInfo(process, now);

			process.Exited += (_, _) => Close(startupInfo);
			RunningProcesses.Add(startupInfo);

			process.Start();
		}


		public void Close(ProcessInfo process)
		{
			process.Process.Kill();

			RunningProcesses.Remove(process);
		}


		protected override void OnValidationStateChanged(IEnumerable<string> changedProperties)
		{
			base.OnValidationStateChanged(changedProperties);

			NotifyOfPropertyChange(() => CanStart);
		}
	}
}