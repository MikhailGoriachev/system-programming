﻿using System;
using System.Collections.Generic;
using System.Linq;
using FluentValidation;


namespace Main.Infrastructure
{
	public static class Extensions
	{
		public static Random Rand { get; } = new();

		public static T Random<T>(this IList<T> collection) => collection[Rand.Next(collection.Count)];


		public static (bool IsValid, CollectionValidationResult<T>? ErrorDetails) TryValidate<T>
			(this IValidator<T> validator, IEnumerable<T> items)
		{
			var hasErrors = items
							.Select((arg, i) => new CollectionValidationResult<T>
								(arg, i, validator.Validate(arg)))
							.FirstOrDefault(arg => arg.ValidationResult.IsValid == false);

			return hasErrors is null ? (true, null) : (false, hasErrors);
		}
	}
}