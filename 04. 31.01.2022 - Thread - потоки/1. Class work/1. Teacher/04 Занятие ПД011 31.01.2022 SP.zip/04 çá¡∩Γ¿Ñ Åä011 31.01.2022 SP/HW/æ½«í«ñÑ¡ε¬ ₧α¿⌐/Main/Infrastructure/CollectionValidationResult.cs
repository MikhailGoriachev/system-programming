﻿using FluentValidation.Results;


namespace Main.Infrastructure
{
	public sealed record CollectionValidationResult<T>(T Item, int Index, ValidationResult ValidationResult);
}