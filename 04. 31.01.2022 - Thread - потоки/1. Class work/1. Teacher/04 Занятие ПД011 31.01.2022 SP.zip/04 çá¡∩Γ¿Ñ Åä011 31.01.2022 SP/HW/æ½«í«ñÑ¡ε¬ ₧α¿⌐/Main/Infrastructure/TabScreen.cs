﻿using Stylet;
using System.Windows.Input;


namespace Main.Infrastructure
{
	public class TabScreen : Screen
	{
		public TabScreen(string displayName)
		{
			DisplayName = displayName;
		}


		public TabScreen(string displayName, IModelValidator validator) : base(validator)
		{
			DisplayName  = displayName;

			AutoValidate = true;
			Validate();
		}


		protected override void OnViewLoaded()
		{
			View.Focusable = true;
			Keyboard.Focus(View);
		}


		public void ActivateOtherTab(Screen tabScreen)
		{
			var parent = (IShell)Parent;

			parent.ActivateItem(tabScreen);
		}
	}
}