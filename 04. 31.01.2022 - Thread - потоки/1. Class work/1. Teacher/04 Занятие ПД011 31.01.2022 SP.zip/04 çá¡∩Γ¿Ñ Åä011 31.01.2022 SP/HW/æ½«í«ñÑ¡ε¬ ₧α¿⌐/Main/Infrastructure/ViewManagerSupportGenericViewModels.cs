﻿using System.Text.RegularExpressions;
using Stylet;


namespace Main.Infrastructure
{
	public sealed class ViewManagerSupportGenericViewModels : ViewManager
	{
		private readonly Regex _viewNameForGenericVieModel;


		public ViewManagerSupportGenericViewModels(ViewManagerConfig config) : base(config)
		{
			_viewNameForGenericVieModel = new(
				@$"(<=.)?{Regex.Escape(ViewModelNameSuffix)}(\`.*)?$",
				RegexOptions.Compiled
			);
		}


		protected override string ViewTypeNameForModelTypeName(string modelTypeName) =>
			modelTypeName.Contains('`') == false
				? base.ViewTypeNameForModelTypeName(modelTypeName)
				: _viewNameForGenericVieModel.Replace(modelTypeName, Regex.Escape(ViewNameSuffix));
	}
}