﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using Stylet;


namespace Main.Infrastructure
{
	public sealed class FluentValidationAdapter<T> : IModelValidator<T> where T : class
	{
		private readonly IValidator<T> _validator;
		private T _subject = null!;


		public FluentValidationAdapter(IValidator<T> validator) =>
			_validator = validator;


		public void Initialize(object subject) =>
			_subject = (T)subject;


		public async Task<IEnumerable<string>> ValidatePropertyAsync(string propertyName) =>
			(await _validator.ValidateAsync(_subject, x => x.IncludeProperties(propertyName))
							 .ConfigureAwait(false))
			.Errors
			.Select(x => x.ErrorMessage);


		public async Task<Dictionary<string, IEnumerable<string>>> ValidateAllPropertiesAsync()
		{
			var t = await _validator.ValidateAsync(_subject).ConfigureAwait(false);

			return t.Errors
					.GroupBy(x => x.PropertyName)
					.ToDictionary(x => x.Key,
						x => x.Select(failure => failure.ErrorMessage));
		}
	}
}