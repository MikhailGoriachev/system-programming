﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HomeWorkConsole
{
    internal partial class App
    {
        private Task1Control task1Control;
        private Task2Control task2Control;
        private Task3Control task3Control;

        //  конструктор
        public App() 
        {
            task1Control = new Task1Control();
            task2Control = new Task2Control();
            task3Control = new Task3Control();
           
        } // App        

    }
}
