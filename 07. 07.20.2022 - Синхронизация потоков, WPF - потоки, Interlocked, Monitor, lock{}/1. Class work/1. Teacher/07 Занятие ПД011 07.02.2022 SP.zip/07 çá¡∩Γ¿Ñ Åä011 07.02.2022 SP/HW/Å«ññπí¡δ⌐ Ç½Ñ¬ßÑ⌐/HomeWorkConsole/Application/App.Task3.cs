﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkConsole
{
    internal partial class App
    {

        public void DemoTask3()
        {
            task3Control.Demo();


        }



    }
}
