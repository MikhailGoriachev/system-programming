﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace HomeWorkConsole
{
    internal partial class App
    {
        
        public void DemoTask1()
        {
            task1Control.Demo();


        }

      

    }
}
