﻿using HomeWorkLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace HomeWorkConsole
{
    class Task1Control
    {

        //Создание файла случайных вещественных чисел(не более 20 чисел), создается при первом запуске, 
        //при последующих запусках – перемешивание данных в файле.
        //Сортировка файла по убыванию и сохранение файла);


        // имя файла
        public string FileName { get; set; }


        // класс для обработки по заданию
        public RandomDouble RD { get; set; }

        public Task1Control() {

            FileName = "test1task.txt";             // хардкодом задаем имя файла для обработки(файл лежит в папке с exe файлом)
            RD = new RandomDouble(FileName);        // создаем объект

        }


        // демонстрация обработок
        public void Demo() {

            Console.WriteLine($"\n\tИмя файла: {FileName}");
            Console.WriteLine($"\n\tФайл до обработки: ");
            RD.CreateFile();
            RD.Show();
            Console.WriteLine($"\n\tФайл перемешан: ");
            RD.ShuffleCollection();
            RD.Show();
            Console.WriteLine($"\n\tФайл отсортирован по убыванию: ");
            RD.SortByDesc();
            RD.Show();

        }
    }
}
