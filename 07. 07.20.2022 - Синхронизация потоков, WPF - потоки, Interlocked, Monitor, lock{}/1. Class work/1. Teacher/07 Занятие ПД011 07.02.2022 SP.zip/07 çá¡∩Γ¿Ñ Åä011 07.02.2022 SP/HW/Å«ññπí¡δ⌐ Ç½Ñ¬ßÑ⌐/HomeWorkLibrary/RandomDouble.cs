﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkLibrary
{
    public class RandomDouble
    {
        // Имя Файла для случайных вещественных чисел 
        public string FileName { get; set; }

        // коллекция случайных чисел
        private List<double> _doubleList;

        public List<double> DoubleList
        {
            get { return _doubleList; }
            set { _doubleList = value; }
        }

        public RandomDouble() {

            _doubleList = new List<double>();


        }

        public RandomDouble(string filename)
        {

            _doubleList = new List<double>();
            FileName = filename;


        }

        // вывести коллекцию
        public void Show() {

            _doubleList.ForEach(item => Console.WriteLine($"{ item,12:f4}"));         

        }

        // создание коллекции
        public void CreateCollecyion() {

            _doubleList.Clear();
            for (int i = 0; i < Utils.GetRandom(10, 21); i++)
            {
                _doubleList.Add(Utils.GetRandom(-20.0, 20.0));
            }
        }

        // перемешать коллекцию
        public void ShuffleCollection() {

            _doubleList = _doubleList.OrderBy(x => Utils.Random.Next()).ToList();

        }

        // Сортировка файла по убыванию
        public void SortByDesc() {

            _doubleList = _doubleList.OrderByDescending(x => x).ToList();

            FileStream fileStream = null;
            fileStream = File.Create(FileName); // создаем файл
                                                // получаем поток
            StreamWriter output = new StreamWriter(fileStream);

            // записываем текст в поток
            WriteCollection(output);

            // закрываем поток
            output.Close();

        }

        // записать коллекцию
        public void WriteCollection(StreamWriter output) {

            _doubleList.ForEach(item => output.WriteLine(item));           
        }


        // прочитать коллекцию в _doubleList
        public void ReadCollection(StreamReader input) {

            _doubleList.Clear();

            string line = input.ReadLine(); // строка для чтения
            while (line != null)            {

                Double.TryParse(line, out double a); // парсим из строки число
                _doubleList.Add(a);                 // записываем его коллекцию
                line = input.ReadLine();
            }


        }

        // открыть файл
        public void OpenFile() {

            FileStream fileStream = null;
            fileStream = File.Open(FileName, FileMode.Open); // открываем файл 
            StreamReader input = new StreamReader(fileStream); // поток для чтения
            ReadCollection(input);
            // закрываем поток
            input.Close();
        }


        // сохранить файл
        public void SaveFile() {

            FileStream fileStream = null;
            fileStream = File.Create(FileName); // создаем файл
                                                // получаем поток
            StreamWriter output = new StreamWriter(fileStream);           

            // записываем текст в поток
            WriteCollection(output);

            // закрываем поток
            output.Close();


        }

        // метод для создания файла и записи в него чисел
        public void CreateFile() {

            // проверяем существует ли файл файл
            if (!File.Exists(FileName))
            {
                CreateCollecyion();
                SaveFile();
            }

            else
            {
                OpenFile();
            }

        }



    }
}
