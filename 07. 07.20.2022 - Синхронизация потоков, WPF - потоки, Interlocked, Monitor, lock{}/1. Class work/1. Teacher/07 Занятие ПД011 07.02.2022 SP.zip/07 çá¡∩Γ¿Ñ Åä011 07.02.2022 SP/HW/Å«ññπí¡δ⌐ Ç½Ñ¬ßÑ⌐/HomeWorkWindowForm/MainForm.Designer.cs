﻿
namespace HomeWorkWindowForm
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задача1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задача2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задача3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.Tss_lbl_info = new System.Windows.Forms.ToolStripStatusLabel();
            this.Tss_lbl_count = new System.Windows.Forms.ToolStripStatusLabel();
            this.tcb_main = new System.Windows.Forms.TabControl();
            this.tbp_task1 = new System.Windows.Forms.TabPage();
            this.tbp_task2 = new System.Windows.Forms.TabPage();
            this.tbp_task3 = new System.Windows.Forms.TabPage();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.собратьНовуюКоллекциюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.перемешатьКоллекциюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.сортироватьПоУбываниюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.собратьНовуюКоллекциюToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.перемешатьКоллекциюToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_task1 = new System.Windows.Forms.DataGridView();
            this.RandomDouble = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bns_task1 = new System.Windows.Forms.BindingSource(this.components);
            this.Sfd_main = new System.Windows.Forms.SaveFileDialog();
            this.Ofd_main = new System.Windows.Forms.OpenFileDialog();
            this.dgv_task2 = new System.Windows.Forms.DataGridView();
            this.deviceNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deviceModelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeProcessorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.storageCapacityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.screenDiagonalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.defectDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ownerNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_task3 = new System.Windows.Forms.DataGridView();
            this.WordColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CountColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tcb_main.SuspendLayout();
            this.tbp_task1.SuspendLayout();
            this.tbp_task2.SuspendLayout();
            this.tbp_task3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_task1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bns_task1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_task2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_task3)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.задача1ToolStripMenuItem,
            this.задача2ToolStripMenuItem,
            this.задача3ToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(933, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(110, 6);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_click);
            // 
            // задача1ToolStripMenuItem
            // 
            this.задача1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.сохранитьToolStripMenuItem,
            this.toolStripMenuItem2,
            this.собратьНовуюКоллекциюToolStripMenuItem,
            this.перемешатьКоллекциюToolStripMenuItem,
            this.сортироватьПоУбываниюToolStripMenuItem});
            this.задача1ToolStripMenuItem.Name = "задача1ToolStripMenuItem";
            this.задача1ToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.задача1ToolStripMenuItem.Text = "Задача 1";
            // 
            // задача2ToolStripMenuItem
            // 
            this.задача2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem1,
            this.сохранитьToolStripMenuItem1,
            this.toolStripMenuItem3,
            this.собратьНовуюКоллекциюToolStripMenuItem1,
            this.перемешатьКоллекциюToolStripMenuItem1});
            this.задача2ToolStripMenuItem.Name = "задача2ToolStripMenuItem";
            this.задача2ToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.задача2ToolStripMenuItem.Text = "Задача 2";
            // 
            // задача3ToolStripMenuItem
            // 
            this.задача3ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem2});
            this.задача3ToolStripMenuItem.Name = "задача3ToolStripMenuItem";
            this.задача3ToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.задача3ToolStripMenuItem.Text = "Задача 3";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(95, 20);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.AboutProgramm_command);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tss_lbl_info,
            this.Tss_lbl_count});
            this.statusStrip1.Location = new System.Drawing.Point(0, 428);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(933, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // Tss_lbl_info
            // 
            this.Tss_lbl_info.Name = "Tss_lbl_info";
            this.Tss_lbl_info.Size = new System.Drawing.Size(147, 17);
            this.Tss_lbl_info.Text = "Количество элементов: ";
            // 
            // Tss_lbl_count
            // 
            this.Tss_lbl_count.Name = "Tss_lbl_count";
            this.Tss_lbl_count.Size = new System.Drawing.Size(22, 17);
            this.Tss_lbl_count.Text = "-/-";
            // 
            // tcb_main
            // 
            this.tcb_main.Controls.Add(this.tbp_task1);
            this.tcb_main.Controls.Add(this.tbp_task2);
            this.tcb_main.Controls.Add(this.tbp_task3);
            this.tcb_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcb_main.Location = new System.Drawing.Point(0, 24);
            this.tcb_main.Name = "tcb_main";
            this.tcb_main.SelectedIndex = 0;
            this.tcb_main.Size = new System.Drawing.Size(933, 404);
            this.tcb_main.TabIndex = 2;
            // 
            // tbp_task1
            // 
            this.tbp_task1.Controls.Add(this.dgv_task1);
            this.tbp_task1.Location = new System.Drawing.Point(4, 22);
            this.tbp_task1.Name = "tbp_task1";
            this.tbp_task1.Padding = new System.Windows.Forms.Padding(3);
            this.tbp_task1.Size = new System.Drawing.Size(925, 378);
            this.tbp_task1.TabIndex = 0;
            this.tbp_task1.Text = "Задача 1";
            this.tbp_task1.UseVisualStyleBackColor = true;
            // 
            // tbp_task2
            // 
            this.tbp_task2.Controls.Add(this.dgv_task2);
            this.tbp_task2.Location = new System.Drawing.Point(4, 22);
            this.tbp_task2.Name = "tbp_task2";
            this.tbp_task2.Padding = new System.Windows.Forms.Padding(3);
            this.tbp_task2.Size = new System.Drawing.Size(925, 378);
            this.tbp_task2.TabIndex = 1;
            this.tbp_task2.Text = "Задача 2";
            this.tbp_task2.UseVisualStyleBackColor = true;
            // 
            // tbp_task3
            // 
            this.tbp_task3.Controls.Add(this.dgv_task3);
            this.tbp_task3.Location = new System.Drawing.Point(4, 22);
            this.tbp_task3.Name = "tbp_task3";
            this.tbp_task3.Size = new System.Drawing.Size(925, 378);
            this.tbp_task3.TabIndex = 2;
            this.tbp_task3.Text = "Задача 3";
            this.tbp_task3.UseVisualStyleBackColor = true;
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(233, 22);
            this.открытьToolStripMenuItem.Text = "Открыть...";
            this.открытьToolStripMenuItem.Click += new System.EventHandler(this.Open_task1);
            // 
            // сохранитьToolStripMenuItem
            // 
            this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
            this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(233, 22);
            this.сохранитьToolStripMenuItem.Text = "Сохранить...";
            this.сохранитьToolStripMenuItem.Click += new System.EventHandler(this.Save_task1);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(230, 6);
            // 
            // собратьНовуюКоллекциюToolStripMenuItem
            // 
            this.собратьНовуюКоллекциюToolStripMenuItem.Name = "собратьНовуюКоллекциюToolStripMenuItem";
            this.собратьНовуюКоллекциюToolStripMenuItem.Size = new System.Drawing.Size(233, 22);
            this.собратьНовуюКоллекциюToolStripMenuItem.Text = "Собрать новую коллекцию";
            this.собратьНовуюКоллекциюToolStripMenuItem.Click += new System.EventHandler(this.CreateCollection);
            // 
            // перемешатьКоллекциюToolStripMenuItem
            // 
            this.перемешатьКоллекциюToolStripMenuItem.Name = "перемешатьКоллекциюToolStripMenuItem";
            this.перемешатьКоллекциюToolStripMenuItem.Size = new System.Drawing.Size(233, 22);
            this.перемешатьКоллекциюToolStripMenuItem.Text = "Перемешать коллекцию";
            this.перемешатьКоллекциюToolStripMenuItem.Click += new System.EventHandler(this.Shuffle_task1);
            // 
            // открытьToolStripMenuItem1
            // 
            this.открытьToolStripMenuItem1.Name = "открытьToolStripMenuItem1";
            this.открытьToolStripMenuItem1.Size = new System.Drawing.Size(233, 22);
            this.открытьToolStripMenuItem1.Text = "Открыть...";
            this.открытьToolStripMenuItem1.Click += new System.EventHandler(this.Open_task2);
            // 
            // сохранитьToolStripMenuItem1
            // 
            this.сохранитьToolStripMenuItem1.Name = "сохранитьToolStripMenuItem1";
            this.сохранитьToolStripMenuItem1.Size = new System.Drawing.Size(233, 22);
            this.сохранитьToolStripMenuItem1.Text = "Сохранить...";
            this.сохранитьToolStripMenuItem1.Click += new System.EventHandler(this.Save_task2);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(230, 6);
            // 
            // сортироватьПоУбываниюToolStripMenuItem
            // 
            this.сортироватьПоУбываниюToolStripMenuItem.Name = "сортироватьПоУбываниюToolStripMenuItem";
            this.сортироватьПоУбываниюToolStripMenuItem.Size = new System.Drawing.Size(233, 22);
            this.сортироватьПоУбываниюToolStripMenuItem.Text = "Сортировать по убыванию";
            this.сортироватьПоУбываниюToolStripMenuItem.Click += new System.EventHandler(this.Sort_desk);
            // 
            // собратьНовуюКоллекциюToolStripMenuItem1
            // 
            this.собратьНовуюКоллекциюToolStripMenuItem1.Name = "собратьНовуюКоллекциюToolStripMenuItem1";
            this.собратьНовуюКоллекциюToolStripMenuItem1.Size = new System.Drawing.Size(233, 22);
            this.собратьНовуюКоллекциюToolStripMenuItem1.Text = "Собрать новую коллекцию";
            this.собратьНовуюКоллекциюToolStripMenuItem1.Click += new System.EventHandler(this.CreateCollectionTask2);
            // 
            // перемешатьКоллекциюToolStripMenuItem1
            // 
            this.перемешатьКоллекциюToolStripMenuItem1.Name = "перемешатьКоллекциюToolStripMenuItem1";
            this.перемешатьКоллекциюToolStripMenuItem1.Size = new System.Drawing.Size(233, 22);
            this.перемешатьКоллекциюToolStripMenuItem1.Text = "Перемешать коллекцию";
            this.перемешатьКоллекциюToolStripMenuItem1.Click += new System.EventHandler(this.Shuffle_task2);
            // 
            // открытьToolStripMenuItem2
            // 
            this.открытьToolStripMenuItem2.Name = "открытьToolStripMenuItem2";
            this.открытьToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.открытьToolStripMenuItem2.Text = "Открыть...";
            this.открытьToolStripMenuItem2.Click += new System.EventHandler(this.Open_task3);
            // 
            // dgv_task1
            // 
            this.dgv_task1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_task1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgv_task1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_task1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RandomDouble});
            this.dgv_task1.Cursor = System.Windows.Forms.Cursors.Default;
            this.dgv_task1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_task1.Location = new System.Drawing.Point(3, 3);
            this.dgv_task1.MultiSelect = false;
            this.dgv_task1.Name = "dgv_task1";
            this.dgv_task1.ReadOnly = true;
            this.dgv_task1.RowHeadersVisible = false;
            this.dgv_task1.RowTemplate.Height = 24;
            this.dgv_task1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_task1.Size = new System.Drawing.Size(919, 372);
            this.dgv_task1.TabIndex = 0;
            // 
            // RandomDouble
            // 
            this.RandomDouble.HeaderText = "Случайное число";
            this.RandomDouble.Name = "RandomDouble";
            this.RandomDouble.ReadOnly = true;
            // 
            // bns_task1
            // 
            this.bns_task1.DataSource = typeof(HomeWorkLibrary.Applications);
            // 
            // Ofd_main
            // 
            this.Ofd_main.FileName = "openFileDialog1";
            // 
            // dgv_task2
            // 
            this.dgv_task2.AutoGenerateColumns = false;
            this.dgv_task2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_task2.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgv_task2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_task2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.deviceNameDataGridViewTextBoxColumn,
            this.deviceModelDataGridViewTextBoxColumn,
            this.typeProcessorDataGridViewTextBoxColumn,
            this.storageCapacityDataGridViewTextBoxColumn,
            this.screenDiagonalDataGridViewTextBoxColumn,
            this.defectDataGridViewTextBoxColumn,
            this.ownerNameDataGridViewTextBoxColumn});
            this.dgv_task2.Cursor = System.Windows.Forms.Cursors.Default;
            this.dgv_task2.DataSource = this.bns_task1;
            this.dgv_task2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_task2.Location = new System.Drawing.Point(3, 3);
            this.dgv_task2.MultiSelect = false;
            this.dgv_task2.Name = "dgv_task2";
            this.dgv_task2.ReadOnly = true;
            this.dgv_task2.RowHeadersVisible = false;
            this.dgv_task2.RowTemplate.Height = 24;
            this.dgv_task2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_task2.Size = new System.Drawing.Size(919, 372);
            this.dgv_task2.TabIndex = 1;
            // 
            // deviceNameDataGridViewTextBoxColumn
            // 
            this.deviceNameDataGridViewTextBoxColumn.DataPropertyName = "DeviceName";
            this.deviceNameDataGridViewTextBoxColumn.HeaderText = "Наименование ";
            this.deviceNameDataGridViewTextBoxColumn.Name = "deviceNameDataGridViewTextBoxColumn";
            this.deviceNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // deviceModelDataGridViewTextBoxColumn
            // 
            this.deviceModelDataGridViewTextBoxColumn.DataPropertyName = "DeviceModel";
            this.deviceModelDataGridViewTextBoxColumn.HeaderText = "Модель";
            this.deviceModelDataGridViewTextBoxColumn.Name = "deviceModelDataGridViewTextBoxColumn";
            this.deviceModelDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // typeProcessorDataGridViewTextBoxColumn
            // 
            this.typeProcessorDataGridViewTextBoxColumn.DataPropertyName = "TypeProcessor";
            this.typeProcessorDataGridViewTextBoxColumn.HeaderText = "Тип процессора";
            this.typeProcessorDataGridViewTextBoxColumn.Name = "typeProcessorDataGridViewTextBoxColumn";
            this.typeProcessorDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // storageCapacityDataGridViewTextBoxColumn
            // 
            this.storageCapacityDataGridViewTextBoxColumn.DataPropertyName = "StorageCapacity";
            this.storageCapacityDataGridViewTextBoxColumn.HeaderText = "ОЗУ";
            this.storageCapacityDataGridViewTextBoxColumn.Name = "storageCapacityDataGridViewTextBoxColumn";
            this.storageCapacityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // screenDiagonalDataGridViewTextBoxColumn
            // 
            this.screenDiagonalDataGridViewTextBoxColumn.DataPropertyName = "ScreenDiagonal";
            this.screenDiagonalDataGridViewTextBoxColumn.HeaderText = "Диагональ экрана";
            this.screenDiagonalDataGridViewTextBoxColumn.Name = "screenDiagonalDataGridViewTextBoxColumn";
            this.screenDiagonalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // defectDataGridViewTextBoxColumn
            // 
            this.defectDataGridViewTextBoxColumn.DataPropertyName = "Defect";
            this.defectDataGridViewTextBoxColumn.HeaderText = "Дефект";
            this.defectDataGridViewTextBoxColumn.Name = "defectDataGridViewTextBoxColumn";
            this.defectDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ownerNameDataGridViewTextBoxColumn
            // 
            this.ownerNameDataGridViewTextBoxColumn.DataPropertyName = "OwnerName";
            this.ownerNameDataGridViewTextBoxColumn.HeaderText = "ФИО Владельца";
            this.ownerNameDataGridViewTextBoxColumn.Name = "ownerNameDataGridViewTextBoxColumn";
            this.ownerNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dgv_task3
            // 
            this.dgv_task3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_task3.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgv_task3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_task3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.WordColumn,
            this.CountColumn});
            this.dgv_task3.Cursor = System.Windows.Forms.Cursors.Default;
            this.dgv_task3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_task3.Location = new System.Drawing.Point(0, 0);
            this.dgv_task3.MultiSelect = false;
            this.dgv_task3.Name = "dgv_task3";
            this.dgv_task3.ReadOnly = true;
            this.dgv_task3.RowHeadersVisible = false;
            this.dgv_task3.RowTemplate.Height = 24;
            this.dgv_task3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_task3.Size = new System.Drawing.Size(925, 378);
            this.dgv_task3.TabIndex = 2;
            // 
            // WordColumn
            // 
            this.WordColumn.HeaderText = "Слово";
            this.WordColumn.Name = "WordColumn";
            this.WordColumn.ReadOnly = true;
            // 
            // CountColumn
            // 
            this.CountColumn.HeaderText = "Количество";
            this.CountColumn.Name = "CountColumn";
            this.CountColumn.ReadOnly = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 450);
            this.Controls.Add(this.tcb_main);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tcb_main.ResumeLayout(false);
            this.tbp_task1.ResumeLayout(false);
            this.tbp_task2.ResumeLayout(false);
            this.tbp_task3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_task1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bns_task1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_task2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_task3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задача1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem собратьНовуюКоллекциюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem перемешатьКоллекциюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сортироватьПоУбываниюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задача2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem собратьНовуюКоллекциюToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem перемешатьКоллекциюToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem задача3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel Tss_lbl_info;
        private System.Windows.Forms.ToolStripStatusLabel Tss_lbl_count;
        private System.Windows.Forms.TabControl tcb_main;
        private System.Windows.Forms.TabPage tbp_task1;
        private System.Windows.Forms.DataGridView dgv_task1;
        private System.Windows.Forms.BindingSource bns_task1;
        private System.Windows.Forms.TabPage tbp_task2;
        private System.Windows.Forms.TabPage tbp_task3;
        private System.Windows.Forms.DataGridViewTextBoxColumn RandomDouble;
        private System.Windows.Forms.SaveFileDialog Sfd_main;
        private System.Windows.Forms.OpenFileDialog Ofd_main;
        private System.Windows.Forms.DataGridView dgv_task2;
        private System.Windows.Forms.DataGridViewTextBoxColumn deviceNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deviceModelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeProcessorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn storageCapacityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn screenDiagonalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn defectDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ownerNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dgv_task3;
        private System.Windows.Forms.DataGridViewTextBoxColumn WordColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn CountColumn;
    }
}

