﻿
namespace HomeWorkWindowForm
{
    partial class AboutProgramm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutProgramm));
            this.txb_aboutprogram = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txb_aboutprogram
            // 
            this.txb_aboutprogram.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txb_aboutprogram.Location = new System.Drawing.Point(342, 116);
            this.txb_aboutprogram.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txb_aboutprogram.Multiline = true;
            this.txb_aboutprogram.Name = "txb_aboutprogram";
            this.txb_aboutprogram.ReadOnly = true;
            this.txb_aboutprogram.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txb_aboutprogram.Size = new System.Drawing.Size(1218, 469);
            this.txb_aboutprogram.TabIndex = 0;
            this.txb_aboutprogram.Text = resources.GetString("txb_aboutprogram.Text");
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txb_aboutprogram);
            this.groupBox1.Location = new System.Drawing.Point(-328, -103);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.groupBox1.Size = new System.Drawing.Size(1724, 707);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "О программе";
            // 
            // AboutProgramm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1246, 499);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "AboutProgramm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AboutProgramm";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txb_aboutprogram;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}