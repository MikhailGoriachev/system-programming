﻿using HomeWorkLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWorkWindowForm
{
    public partial class MainForm : Form
    {

        public RandomDouble rd;
        public RepairShop rs;
        public TextHandling th;



        public MainForm()
        {
            InitializeComponent();
           
            // задача 1
            rd = new RandomDouble("test1taskWF.txt");       // путь для файла
            rd.CreateFile();                                // обработка по заданию
            DoubleListBind(dgv_task1, rd.DoubleList);       // привязка к DataGridView

            // задача 2
            rs = new RepairShop();
            rs.CreateFile("test2taskWF.txt");
            bns_task1.DataSource = rs.List;

            // задача 3
            th = new TextHandling();


        }


        #region ЗАДАЧА 1
        // привязка для первой задачи
        private void DoubleListBind(DataGridView dataGridView, List<Double> rd)
        {
            tcb_main.SelectedTab = tbp_task1;          // перейти на вкладку задача 1        
            

            dataGridView.Rows.Clear();

            int i = 0;
            foreach (var d in rd)
            {
                dataGridView.RowCount++;

                dataGridView[0, i].Value = d;
                dataGridView[0, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

               
                i++;
            } // foreach person

            Tss_lbl_count.Text = rd.Count.ToString();


        } // 

        // перемешать коллекцию
        private void Shuffle_task1(object sender, EventArgs e)
        {
            tcb_main.SelectedTab = tbp_task1;
            rd.ShuffleCollection();
            DoubleListBind(dgv_task1, rd.DoubleList);
        }

        // сортировать коллекцию по убыванию
        private void Sort_desk(object sender, EventArgs e)
        {
            tcb_main.SelectedTab = tbp_task1;
            rd.SortByDesc();
            DoubleListBind(dgv_task1, rd.DoubleList);
        }

        // собрать новую коллекцию
        private void CreateCollection(object sender, EventArgs e)
        {
            tcb_main.SelectedTab = tbp_task1;
            rd.CreateCollecyion();
            DoubleListBind(dgv_task1, rd.DoubleList);
        }

        // Сохранить
        private void Save_task1(object sender, EventArgs e)
        {
            // вызов диалога сохранения файла

            Sfd_main.Title = "Сохранение результатов";
            Sfd_main.InitialDirectory = "..\\..\\";
            Sfd_main.Filter = "Файлы TXT(*.txt)|*.txt";
            Sfd_main.FilterIndex = 1;

            if (Sfd_main.ShowDialog() == DialogResult.OK)
            {
                rd.FileName = Sfd_main.FileName;    // назначить папку и имя для сохранения
                rd.SaveFile();                      // записать файл

            } // if


            DoubleListBind(dgv_task1, rd.DoubleList);


        }

        // Открыть
        private void Open_task1(object sender, EventArgs e)
        {
            // вызов диалога открытия файла

            Ofd_main.Title = "Открыть ";
            Ofd_main.InitialDirectory = "..\\..\\";
            Ofd_main.Filter = "Файлы TXT(*.txt)|*.txt";
            Ofd_main.FilterIndex = 1;

            if (Ofd_main.ShowDialog() == DialogResult.OK)
            {
                rd.FileName = Ofd_main.FileName;    // назначить папку и имя для сохранения
                rd.OpenFile();                      // записать файл

            } // if

            DoubleListBind(dgv_task1, rd.DoubleList);



        }

        #endregion

        #region ЗАДАЧА 2
        // собрать новую коллекцию
        private void CreateCollectionTask2(object sender, EventArgs e)
        {
            tcb_main.SelectedTab = tbp_task2;
            rs.CreateList();
            bns_task1.DataSource = null;
            bns_task1.DataSource = rs.List;      
            Tss_lbl_count.Text = rs.List.Count.ToString();

        }

        // перемешать коллекцию
        private void Shuffle_task2(object sender, EventArgs e)
        {
            tcb_main.SelectedTab = tbp_task2;
            rs.ShuffleCollection();
            bns_task1.DataSource = null;
            bns_task1.DataSource = rs.List;
            Tss_lbl_count.Text = rs.List.Count.ToString();

        }


        // сериализация в формате JSON
        private void Save_task2(object sender, EventArgs e)
        {
            tcb_main.SelectedTab = tbp_task2;

            // вызов диалога сохранения файла

            Sfd_main.Title = "Сохранение результатов";
            Sfd_main.InitialDirectory = "..\\..\\";
            Sfd_main.Filter = "Файлы JSON(*.json)|*.json";
            Sfd_main.FilterIndex = 1;

            if (Sfd_main.ShowDialog() == DialogResult.OK)
            {
                rs.Serialize(Sfd_main.FileName);
            } // if

            Tss_lbl_count.Text = rs.List.Count.ToString();

        }

        // десериализация из формата JSON
        private void Open_task2(object sender, EventArgs e)
        {
            tcb_main.SelectedTab = tbp_task2;

            // вызов диалога сохранения файла

            Ofd_main.Title = "Открыть ";
            Ofd_main.InitialDirectory = "..\\..\\";
            Ofd_main.Filter = "Файлы JSON(*.json)|*.json";
            Ofd_main.FilterIndex = 1;

            //rs.List.Clear();

            if (Ofd_main.ShowDialog() == DialogResult.OK)
            {
                rs = RepairShop.Deserialize(Ofd_main.FileName);
            } // if

            // обновить привязку
            bns_task1.DataSource = null;
            bns_task1.DataSource = rs.List;
            Tss_lbl_count.Text = rs.List.Count.ToString();

        }



        #endregion

        #region ЗАДАЧА 3

        private void Open_task3(object sender, EventArgs e)
        {
            tcb_main.SelectedTab = tbp_task3;           // перейти на вкладку задача 3     

            // вызов диалога открытия файла

            Ofd_main.Title = "Открыть ";
            Ofd_main.InitialDirectory = "..\\..\\";
            Ofd_main.Filter = "Файлы TXT(*.txt)|*.txt";
            Ofd_main.FilterIndex = 1;

            if (Ofd_main.ShowDialog() == DialogResult.OK)
            {
                th.CreateDictionary( Ofd_main.FileName);    // назначить папку и имя для открытия файла                           

                dgv_task3.Rows.Clear();                     // очистить DataGridView

                int i = 0;
                foreach (var item in th.dictionary)
                {
                    dgv_task3.RowCount++;

                    dgv_task3[0, i].Value = item.Key;
                    dgv_task3[0, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

                    dgv_task3[1, i].Value = item.Value;
                    dgv_task3[1, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;


                    

                    i++;
                } // foreach person

                Tss_lbl_count.Text = th.dictionary.Count.ToString();

            } // if            

        }



        #endregion

        // выход
        private void Exit_click(object sender, EventArgs e)
        {
            this.Close();
        }

        // вызов окна о программе
        private void AboutProgramm_command(object sender, EventArgs e)
        {
            AboutProgramm aboutprg = new AboutProgramm();
            aboutprg.ShowDialog();  // модальное отображение формы
        }
    }
}
