﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

using ThreadsLibrary;
using ThreadsLibrary.Models;
using ThreadsLibrary.Helpers;

namespace ProcessingConsole
{
    class Program {
        static void Main(string[] args)  {

            Console.SetWindowSize(150, 30);

            List<LaptopRepair> laptopRepairs = new List<LaptopRepair>();
            for (int i = 0; i < Utils.GetRandom(5, 10); i++)
                laptopRepairs.Add(LaptopRepair.Generate());
            
            Processing processing = new Processing{
                BinFileName =  "Thread1Data.bin",
                JsonFileName = "Thread2Data.json",
                TextFileName = "Thread3Data.txt",
                LaptopRepairs = laptopRepairs
            };

            // создание и запуск потока
            List<Thread> threads = new List<Thread>(new[] {
                new Thread(processing.Process1_Console),
                new Thread(processing.Process2_Console),
                new Thread(processing.Process3_Console),
            });

            // запуск потоков на парвллельное исполнение
            threads.ForEach(t => t.Start());

            // ожидание завершения потоков
            threads.ForEach(t => t.Join());



        } // Main
    
    } // Program
}
