﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

using ThreadsLibrary.Helpers;

namespace ThreadsLibrary.Models
{
    // Класс заявка на ремонт ноутбука, содержащий поля:
    //          наименование устройства
    //          модель
    //          тип процессора
    //          объем оперативной памяти
    //          емкость накопителя
    //          диагональ экрана
    //          описание неисправности
    //          фамилия и инициалы владельца
    [DataContract]
    public class LaptopRepair {

        // наименование устройства
        private string _name;
        [DataMember]
        public string Name {
            get => _name;
            set => _name = !string.IsNullOrWhiteSpace(value) ? value : throw new Exception("Наименование устройства не может быть не задано!");
        } //Name

        // модель ноутбука
        private string _model;
        [DataMember]
        public string Model {
            get => _model;
            set => _model = !string.IsNullOrWhiteSpace(value) ? value : throw new Exception("Модель устройства не может быть не задана!");
        } // Model

        // тип процессора
        private string _processorType;
        [DataMember]
        public string ProcessorType {
            get => _processorType;
            set => _processorType = !string.IsNullOrWhiteSpace(value) ? value : throw new Exception("Тип процессора не может быть не задан!");
        } // ProcessorType

        // объем оперативной памяти
        private int _amountRAM;
        [DataMember]
        public int AmountRAM {
            get => _amountRAM;
            set => _amountRAM = value > 0 ? value : throw new Exception("Объем оперативной памяти не может быть равен нулю, или быть отрицательным!");
        } // AmountRAM

        // емкость накопителя
        private int _storageCapacity;
        [DataMember]
        public int StorageCapacity {
            get => _storageCapacity;
            set => value = value > 0 ? value : throw new Exception("Емкость накопителя не может быть равна нулю, или быть отрицательной!");
        } // StorageCapacity

        // диагональ экрана (в дюймах)
        private int _screenDiagonal;
        [DataMember]
        public int ScreenDiagonal {
            get => _screenDiagonal;
            set => _screenDiagonal = value > 0 ? value : throw new Exception("Диагональ экрана не может быть равна нулю, или быть отрицательной!");
        } // ScreenDiagonal

        // описание неисправности
        private string _faultDescription;
        [DataMember]
        public string FaultDescription {
            get => _faultDescription;
            set => _faultDescription = !string.IsNullOrWhiteSpace(value) ? value : throw new Exception("Описание дефекта не может быть не указано!");
        } // FaultDescription


        // фамилия инициалы владельца
        private string _fioOwner;
        [DataMember]
        public string FioOwner {
            get => _fioOwner;
            set => _fioOwner = !string.IsNullOrWhiteSpace(value) ? value : throw new Exception(" Фамилия и инициалы вледальца не могут быть не указаны!");
        } // FioOwner


        // конструктор по умолчанию
        public LaptopRepair() : this("HP 15d", "HP 15-db1", "AMD EPYC 7513", 16, 256, 22,
                                    "Не подключается к интернету", "Паучков И. И.") { }

        // конструктор с парамметрами
        public LaptopRepair(string name, string model, string processorType, int amountRam, int storageCapacity,
                            int screenDiagonal, string faultDescription, string fioOwner) {
            Name = name;
            Model = model;
            ProcessorType = processorType;
            AmountRAM = amountRam;
            StorageCapacity = storageCapacity;
            ScreenDiagonal = screenDiagonal;
            FaultDescription = faultDescription;
            FioOwner = fioOwner;
        }

        public override string ToString() => $"\tНазвание: {Name}, модель: {Model}, тип процессора: {ProcessorType}\n" +
                                    $"\tобъем RAM: {AmountRAM}, емкость накопителя: {StorageCapacity}, диагональ: {ScreenDiagonal}\n" +
                                    $"\tописание неисправности: {FaultDescription}, фамилия и инициалы владельца {FioOwner}";


        // Фабричный метод для случайного созданий данных 
        public static LaptopRepair Generate() {
            (string Name, string Model)[] data = {
                ("HP 15d", "HP 15-db1"), ("ASUS VB 540", "ASUS VivoBook X540"), 
                ("Prestigio SB 141", "Prestigio SmartBook 141 C5 "), ("ASUS VB 543", "ASUS VivoBook X543"), 
                ("ASUS VB 512", "ASUS VivoBook 15 X512 "), ("HP", "HP 17-ca2"),
                ("Lenovo IP145", "Lenovo IdeaPad S145"), ("ASUS ZB 14", "ASUS ZenBook 14 UX434"), 
                ("Xiaomi Mi NB Ai", "Xiaomi Mi Notebook Ai"), ("Xiaomi Mi NB Pro", "Xiaomi Mi Notebook Pro")
            };

            string[] processorType = new[] {
                "AMD EPYC 7513", "AMD EPYC 7443P", "AMD EPYC 7742", "AMD EPYC 74F3", "AMD EPYC 7702",
                "AMD EPYC 7543P", "AMD EPYC 75F3", "AMD EPYC 7662", "AMD EPYC 7713", "AMD EPYC 7643"
            };

            int[] amountRam = new[] {
                2,   4,  6,  8, 12,
                16, 18, 24, 26, 32
            };

            int[] storageCapacity = new[] {
                128, 256,  512, 1024, 2048
            };

            string[] faultDescription = new[] {
                "Не выводит изображения на экран", "Звук не воспроизводиться", "Не работает USB разъем", "Не работает клавиатура", "Ноутбук не включается"
            };

            string[] fioOwner = new[] {
                "Новикова В. М.", "Данилов А. Т.", "Волкова У. М.", "Еремин А. Д.", "Прохорова А. И.",
                "Ковалева С. А.", "Степанов А. М.", "Сорокин А. В.", "Горячев Е. Ф.", "Трофимов А. И."
            };

            int index = Utils.GetRandom(0, 9);
            return new LaptopRepair(data[index].Name, data[index].Model, processorType[index], amountRam[index],
                storageCapacity[Utils.GetRandom(0, storageCapacity.Length - 1)], Utils.GetRandom(12, 33),
                faultDescription[Utils.GetRandom(0, 4)], fioOwner[index]);

 
        } // Generate


    }
}
