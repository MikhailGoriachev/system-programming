﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using ThreadsLibrary.Helpers;
using ThreadsLibrary.Models;
using System.Runtime.Serialization.Json;

namespace ThreadsLibrary
{
    // Задания:
    // а)	создание файла случайных вещественных чисел(не более 20 чисел),
    //      создается при первом запуске, при последующих запусках – перемешивание данных в файле.
    //      Сортировка файла по убыванию и сохранение файла

    // б)   создание коллекции заявок на ремонт ноутбуков
    //      (наименование устройства, модель, тип процессора, объем оперативной памяти,
    //      емкость накопителя, диагональ экрана, описание неисправности, фамилия и инициалы владельца),
    //      сериализация этой коллекции при первом запуске; десериализация, перемешивание и сериализация
    //      при последующих запусках.Формат файла данных – JSON

    // в)   обработка текстового файла – подсчет(без учета регистра) частоты слов,
    //      результаты выводите в словарь(пары «слово – количество»)

    public class Processing
    {
        // Максимальное количество генерируемых элементов, для потока 1
        private const int MaxElement = 20;

        // имя бинарного файла
        private string _binFileName;
        public string BinFileName
        {
            get => _binFileName;

            //  При первом запуске создание файла случайных вещественных чисел(не более 20 чисел),
            //  при последующих запусках – перемешивание данных в файле.
            set
            {
                _binFileName = value;
                List<double> data;
                if (!File.Exists(_binFileName))
                {
                    data = Enumerable
                        .Repeat(0, Utils.GetRandom(7, MaxElement))
                        .Select(x => Utils.GetRandom(-10d, 20d))
                        .ToList();
                } // if
                else {
                    data = new List<double>();
                    using (BinaryReader brd = new BinaryReader(File.OpenRead(_binFileName))) {
                        while (brd.BaseStream.Position < brd.BaseStream.Length)
                            data.Add(brd.ReadDouble());
                    } // using
                    Shuffle(data);
                } //  else

                using (BinaryWriter bwr = new BinaryWriter(File.Create(_binFileName)))
                    data.ForEach(datum => bwr.Write(datum));

            } // set
        } // BinFileName

        // Коллекция заявок на ремонт ноутбука
        private List<LaptopRepair> _laptopRepairs;
        public List<LaptopRepair> LaptopRepairs{
            get => _laptopRepairs;
            set => _laptopRepairs = value;
        } // LaptopRepairs

        // Имя Json файла
        private string _jsonFileName;
        public string JsonFileName {
            get => _jsonFileName;
            set => _jsonFileName = !string.IsNullOrWhiteSpace(value) ? value : throw new Exception("Недопустимое имя файла!");
        } // JsonFileName

        // имя текстового файла
        public string TextFileName { get; set; }

        
        // -------------------------------------------------------------------------------------

        // метод для потока 1
        // Сортировка файла по убыванию и сохранение файла
        public void Process1_Console()
        {

            // чтение из файла в коллекцию
            List<double> data = new List<double>();
            using (BinaryReader brd = new BinaryReader(File.OpenRead(_binFileName)))
            {

                while (brd.BaseStream.Position < brd.BaseStream.Length)
                    data.Add(brd.ReadDouble());
            } // using
            StringBuilder sb = OutputToStrigBuilder(data, $"\n\n\tПоток 1: Исходные данные из файла \"{_binFileName}\":\n\t");

            // сортировка коллекции по убыванию
            data.Sort((x, y) => y.CompareTo(x));

            // запись в файл
            using (BinaryWriter bwr = new BinaryWriter(File.Create(_binFileName)))
                data.ForEach(datum => bwr.Write(datum));
            sb.Append(OutputToStrigBuilder(data, $"\n\n\tПоток 1: Данные отсортированы по убыванию, и записаны в файл \"{_binFileName}\":\n\t"));

            // вывод в консоль
            Console.WriteLine(sb);

        } // Process1_Console

        // перемешивание коллекции электроприборов по алгоритму "Тасование Фишера-Йетса"
        // https://vscode.ru/prog-lessons/kak-peremeshat-massiv-ili-spisok.html
        public void Shuffle(List<double> data)
        {

            // просматриваем массив с конца
            for (int i = data.Count() - 1; i >= 1; i--)
            {

                // определяем элемент, с которым меням элемент с индексами i
                int j = Utils.GetRandom(0, i);  // фактически генерится 0, ..., i

                // меняем местами элементы списка при помощи кортежа
                (data[i], data[j]) = (data[j], data[i]);
            } // for i
        } // Shuffle

        // вывод коллекции в StringBuilder
        private StringBuilder OutputToStrigBuilder(List<double> data, string title)
        {

            StringBuilder sb = new StringBuilder(title);

            int w = MaxElement;
            foreach (var d in data)
            {
                sb.Append($"{d,9:f3}");
                w--;
                if (w % 10 == 0) sb.Append("\n\t");
            }

            sb.AppendLine();
            return sb;
        } // OutputToStrigBuilder

        // -------------------------------------------------------------------------------------

        // метод для потока 2
        // Сериализация коллекции при первом запуске.
        // Десериализация, перемешивание и сериализация при последующих запусках.
        public void Process2_Console()
        {
            MessageBox.Show("Поток2: Запись и чтение из JSON файла не работает");
             
            // StringBuilder sb = OutputToStrigBuilder(LaptopRepairs, $"\n\n\tПоток 2: Данные из файла \"{JsonFileName}\":\n\t");
               StringBuilder sb = OutputToStrigBuilder(LaptopRepairs, $"\n\n\tПоток 2: Данные до перемешиваня:\n\t");

            //if (!File.Exists(JsonFileName))
            //    Serialization(JsonFileName);
            //else {
            //    Deserialization(JsonFileName);
                  Shuffle(LaptopRepairs);
            //    Serialization(JsonFileName);
            //} // else

            // sb = sb.Append(OutputToStrigBuilder(LaptopRepairs, $"\n\n\tПоток 2: Данные из файла \"{JsonFileName}\":\n\t")); 
            sb.Append(OutputToStrigBuilder(LaptopRepairs, $"\n\n\tПоток 2: Данные после перемешивания:\n\t")); 

            // вывод в консоль
            Console.WriteLine(sb);

        } // Process2_Console

        // перемешивание коллекции электроприборов по алгоритму "Тасование Фишера-Йетса"
        // https://vscode.ru/prog-lessons/kak-peremeshat-massiv-ili-spisok.html
        public void Shuffle(List<LaptopRepair> data) {

            // просматриваем массив с конца
            for (int i = data.Count() - 1; i >= 1; i--) {

                // определяем элемент, с которым меням элемент с индексами i
                int j = Utils.GetRandom(0, i);  // фактически генерится 0, ..., i

                // меняем местами элементы списка при помощи кортежа
                (data[i], data[j]) = (data[j], data[i]);
            } // for i
        } // Shuffle

        // сериализация в формате JSON
        public void Serialization(string fileName)  {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<LaptopRepair>));

            using (FileStream fs = new FileStream(fileName, FileMode.Create))
                jsonFormatter.WriteObject(fs, this);
        } // Serialization

        // десериализация формате JSON
        public void Deserialization(string fileName)   {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<LaptopRepair>));

            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate))  {
                List<LaptopRepair> temp = (List<LaptopRepair>)jsonFormatter.ReadObject(fs);
                LaptopRepairs = temp;
            }
        } // Deserialization

        private StringBuilder OutputToStrigBuilder(List<LaptopRepair> data, string title) {

            StringBuilder sb = new StringBuilder(title);

            foreach (var d in data)  {
                sb.Append($"\n\n{d}"); 
            }

            sb.AppendLine();
            return sb;
        } // OutputToStrigBuilder

        // -------------------------------------------------------------------------------------

        // метод для потока 3
        // Обработка текстового файла – подсчет(без учета регистра) частоты слов,
        // результаты выводите в словарь(пары «слово – количество»)
        public void Process3_Console() {
            // обработка по заданию
            List<string> strings = File.ReadAllLines(TextFileName).ToList();
            StringBuilder sb = OutputToStrigBuilder(strings, $"\n\n\tПоток 2: файл \"{TextFileName}\":\n");
            //string[] word;
            //var res = new Dictionary<string, int>();
            //foreach (var item in strings){
            //word = item.Split(".:,/?!".ToCharArray());

            //}

            var res = new Dictionary<string, int>();
            foreach (var line in strings)
                foreach (var word in line.Split(".:,/?! ".ToCharArray()))  {
                    var count = 0;
                    res.TryGetValue(word, out count);
                    res[word] = count + 1;
                }

            // вывод в консоль
            sb.Append(OutputToStrigBuilder(res, $"\n\tПоток 2: количество каждого слова в файле \"{TextFileName}\":\n"));
            Console.WriteLine(sb);
        } // Process3_Console
 
        // вывод списка строк в консоль
        private StringBuilder OutputToStrigBuilder(List<string> list, string title) {
            // сформировать вывод в StringBuilder'е
            StringBuilder sb = new StringBuilder(title);
            list.ForEach(item => sb.Append($"{item}\r\n"));

            // собсвенно вывод
            return sb;
        } // OutputToStrigBuilder

        // вывод словаря (пары «слово – количество»), в одной строке
        private StringBuilder OutputToStrigBuilder(Dictionary<string, int> dict, string title) {
            // сформировать вывод в StringBuilder'е
            StringBuilder sb = new StringBuilder(title); 

            foreach (var key in dict.Keys)
                sb.Append($"\t{key,15} => {dict[key],2}\r\n"); // foreach

            // собсвенно вывод
            return sb;
        } // OutputToStrigBuilder


    }
}
