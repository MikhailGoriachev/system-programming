﻿using ThreadsLib.Helpers;

namespace ThreadsLib
{
    // класс заявок 
    public class Order
    {
        //наименование устройства
        public string Name { get; set; }

        //модель
        public string Model { get; set; }

        //Тип процессора
        public string ProcessorType { get; set; }

        //Объем оперативной памяти
        public int MemoryVolume { get; set; }

        //Емкость накопителя
        public int HDDVolume { get; set; }

        //диагональ экрана
        public double Diagonal { get; set; }

        // описание неисправности
        public string Defect { get; set; }

        //фамилия инициалы владельца
        public string NameSP { get; set; }


        //фабричный метод формирования ноутбуков
        public static Order Generate()
        {
            //наименование устройства
            string[] names = new[] { "Ноутбук", "Ультрабук", "Игровой" };

            //массив моделей
            string[] brands = new[] { "Dell", "Apple", "HP", "Microsoft", "Asus", "Xiaomi", "Huawei" };

            //тип процессора
            string[] proc = new[] { "Apple", "Intel", "AMD" };

            //объем оперативной памяти в ГБ
            int[] memory = new[] { 8, 16, 32, 64, 12, };

            //емкость накопителя
            int[] volumes = new[] { 129, 256, 512, 1024, 1025, 2048 };

            //диагональ экрана
            double[] diagonals = new[] { 13.1, 14.5, 15.6, 17.7, 18.4, 19.3 };

            //описание неисправности
            string[] defects = new[] { "не включается", "не загружается", "нет изображения", "перегрев корпуса" };

            //имя фамилия клиента
            string[] clients = new[] { "Иванов И.А", "Петров В.А.", "Сидоров К.В.", "Тимохин Е.В.", "Кулишов В.А." };

            return new Order
            {
                Name = names[Utils.Random.Next(names.Length)],
                Model = brands[Utils.Random.Next(brands.Length)],
                ProcessorType = proc[Utils.Random.Next(proc.Length)],
                MemoryVolume = memory[Utils.Random.Next(memory.Length)],
                HDDVolume = volumes[Utils.Random.Next(memory.Length)],
                Diagonal = diagonals[Utils.Random.Next(diagonals.Length)],
                Defect = defects[Utils.Random.Next(defects.Length)],
                NameSP = clients[Utils.Random.Next(clients.Length)]
            };
        }
    }
}