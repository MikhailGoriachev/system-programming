﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadsLib
{
    public class Task3
    {
        public static readonly string FileName = "fish.txt";
        public static readonly string FishText = @"
Мы вынуждены отталкиваться от того, что экономическая повестка сегодняшнего дня способствует подготовке и реализации первоочередных требований. Вот вам яркий пример современных тенденций - высококачественный прототип будущего проекта не даёт нам иного выбора, кроме определения анализа существующих паттернов поведения. Но выбранный нами инновационный путь говорит о возможностях укрепления моральных ценностей. Имеется спорная точка зрения, гласящая примерно следующее: элементы политического процесса призывают нас к новым свершениям, которые, в свою очередь, должны быть представлены в исключительно положительном свете. С другой стороны, существующая теория способствует подготовке и реализации своевременного выполнения сверхзадачи. А ещё представители современных социальных резервов представлены в исключительно положительном свете.
Но базовые сценарии поведения пользователей, превозмогая сложившуюся непростую экономическую ситуацию, ассоциативно распределены по отраслям. Учитывая ключевые сценарии поведения, экономическая повестка сегодняшнего дня позволяет оценить значение вывода текущих активов.";


        public void Processing3()
        {
            if (File.Exists(FileName) == false)
                File.WriteAllText(FileName, FishText);

            var wordsWithCount = CountWords();

            OutputToConsole(wordsWithCount);
        }


        private void OutputToConsole(Dictionary<string, int> wordsWithCount)
        {
            var builder = new StringBuilder();

            builder.AppendLine($"Поток {Thread.CurrentThread.ManagedThreadId}");
            foreach (var pair in wordsWithCount)
            {
                builder.AppendLine($"{pair.Key} - {pair.Value}");
            }

            Console.WriteLine(builder);
        }


        private Dictionary<string, int> CountWords()
        {
            var dictionary = new Dictionary<string, int>(StringComparer.CurrentCultureIgnoreCase);

            foreach (var line in File.ReadLines(FileName))
            {
                var words = line.Split(" ,.!?;[](){}:\"'\\/".ToCharArray(),
                    StringSplitOptions.RemoveEmptyEntries);

                foreach (var word in words)
                {
                    if (dictionary.TryGetValue(word, out int count))
                        dictionary[word] = count + 1;
                    else
                        dictionary.Add(word, 1);
                }
            }

            return dictionary;

            /* Способ через LINQ
             return File.ReadLines(FileName)

                 .SelectMany(line => line.Split(" ,.!?;[](){}:\"'\\/".ToCharArray(),
                      StringSplitOptions.RemoveEmptyEntries))
                  .GroupBy(word => word, (word, occurances) => new
                  {
                      Word = word,
                      OccurancesCount = occurances.Count()
                  }, StringComparer.CurrentCultureIgnoreCase)
                  .ToDictionary(arg => arg.Word,
                      arg => arg.OccurancesCount);
             */
        }
    }
}