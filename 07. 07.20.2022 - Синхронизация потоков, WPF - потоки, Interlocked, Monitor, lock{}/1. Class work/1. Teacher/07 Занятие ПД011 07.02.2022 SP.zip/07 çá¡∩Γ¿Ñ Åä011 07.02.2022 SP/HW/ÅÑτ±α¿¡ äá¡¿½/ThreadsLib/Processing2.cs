﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using ThreadsLib.Helpers;

namespace ThreadsLib
{
    public class Processing2
    {
        //свойство файла 
        public string Filename { get; set; } = @"orders.json";

        //коллекция для обработки
        public List<Order> Temp { get; set; } = new List<Order>();

        // метод для генерации коллекций
        public List<Order> GenerateOrders()
        {
            int arraysize = Utils.Random.Next(10, 20);

            List<Order> orders = new List<Order>();

            for (int i = 0; i < arraysize; i++)
            {
                orders.Add( Order.Generate()) ;
            }

            return orders;  
        }
        
        //сериализация 
        public void Serialize(StreamWriter stream, List<Order> orders)
        {
            JsonSerializer serializer = new JsonSerializer()
            {
                Formatting = Formatting.Indented
            };
            serializer.Serialize(stream,orders);
        }

        // десериализация
        public List<Order> Deserialize(StreamReader stream)
        {
            JsonSerializer serializer = new JsonSerializer();

            List<Order> orders = (List<Order>) serializer.Deserialize(stream, typeof(List<Order>));

            return orders;
        }

        // метод для перемешивания цифр в массиве 
        public void Shuffle(List<Order> array)
        {
            for (int i = 0; i < array.Count; i++)
            {
                int randomIndex = Utils.Random.Next(array.Count);

                (array[i], array[randomIndex]) = (array[randomIndex], array[i]);
            }
        }

        //метод обработки по заданию 
        public void Process2()
        {
            if (!File.Exists(Filename))
            {
                //создать файл для записи
                using (StreamWriter sw = File.CreateText(Filename))
                {
                    //запись в файл
                    Serialize(sw, GenerateOrders());
                }

            }
            else
            {
                //прочитать список
                using (StreamReader sr = File.OpenText(Filename))
                {
                    Temp = Deserialize(sr);
                }

                //перемешать список 
                Shuffle(Temp);

                //сериализовать 
                using (StreamWriter sw = File.CreateText(Filename))
                {
                    Serialize(sw,Temp);
                }

                OutputToConsole();
            }
        }//Process2

        public void OutputToConsole()
        {
           

            Console.WriteLine($" Поток {Thread.CurrentThread.ManagedThreadId}: {File.ReadAllText(Filename)}");
        }
    }
}