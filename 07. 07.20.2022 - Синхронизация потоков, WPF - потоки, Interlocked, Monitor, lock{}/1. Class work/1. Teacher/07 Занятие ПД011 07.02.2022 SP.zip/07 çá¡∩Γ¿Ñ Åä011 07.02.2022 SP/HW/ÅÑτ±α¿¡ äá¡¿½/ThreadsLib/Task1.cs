﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Policy;
using System.Threading;
using ThreadsLib.Helpers;

namespace ThreadsLib
{
    /*Задача 1. Разработайте библиотеку классов для выполнения обработок:
а)	создание файла случайных вещественных чисел (не более 20 чисел), 
    создается при первом запуске, при последующих запусках – перемешивание данных в файле. 
    Сортировка файла по убыванию и сохранение файла
б)	создание коллекции заявок на ремонт ноутбуков (наименование устройства, модель, 
    тип процессора, объем оперативной памяти, емкость накопителя, диагональ экрана, описание неисправности, фамилия и инициалы владельца), сериализация этой коллекции при первом запуске; десериализация, перемешивание и сериализация при последующих запусках. Формат файла данных – JSON
в)	обработка текстового файла – подсчет (без учета регистра) частоты слов, 
    результаты выводите в словарь (пары «слово – количество»)
*/
    public class Processing
    {
        //создание файла случайных вещественных чисел
        public string Filename { get; } = @"numbers.txt";

        //лист для обработки по первому заданию
        public List<double> Temp { get; } = new List<double>();

        // метод для генерации массива случайных чисел
        public double[] CreateNumbers()
        {
            int arraysize = Utils.Random.Next(10, 20);

            List<double> array = new List<double>();

            for (int i = 0; i < arraysize; i++)
            {
                array.Add(Utils.GetRandom(1, 20));
            }

            return array.ToArray();
        }

        //метод для записи в файл
        private void WriteToFile(ICollection<double> numb, StreamWriter sw)
        {
            foreach (var item in numb)
            {
                sw.WriteLine(item);
            }
        }

        //метод для чтения в файл
        private void ReadFromFile(string filename)
        {
            using (StreamReader sr = File.OpenText(filename))
            {
                string s = "";
                while ((s = sr.ReadLine()) != null)
                {
                    Temp.Add(Convert.ToDouble(s));
                }
            }
        }

        // метод для перемешивания цифр в массиве 
        public void Shuffle(List<double> array)
        {
            for (int i=0; i< array.Count; i++)
            {
                int randomIndex = Utils.Random.Next(array.Count);

                (array[i], array[randomIndex]) = (array[randomIndex], array[i]);
            }
        }

        //метод для записи в файл, обработка по заданию а)
        public void Process1()
        {
            

            if (!File.Exists(Filename))
            {
                //создать файл для записи
                using (StreamWriter sw = File.CreateText(Filename))
                {
                    //запись массива в файл
                   WriteToFile(CreateNumbers(),sw);
                }
            }
            else
            {
                //прочитать в список
                ReadFromFile(Filename);
                // перемешать список
                Shuffle(Temp);
                // записать обратно в файл список
                using (StreamWriter sw = new StreamWriter(Filename))
                {
                    WriteToFile(Temp,sw);
                }

                // записать обратно в файл список
                using (StreamWriter sw = new StreamWriter(Filename))
                {
                    WriteToFile(SortByDesc(), sw);
                }

                //вывести в консоль
                OutputToConsole();
            }// else
        }// process 1

        //вывод в консоль
        private void OutputToConsole()
        {
            StringBuilder sb = new StringBuilder($"\t Поток {Thread.CurrentThread.ManagedThreadId}: \n");

            //Вывод листа в строку
            sb.Append("Задание 1: ");
            foreach (var item in Temp)
            {
                sb.AppendLine($"{item,4:f}");
            }

            Console.WriteLine(sb.ToString());

        }

        //сортировка по убыванию
        private List<double> SortByDesc()
        { 
            // сортировать в листе по убыванию
           return Temp.OrderByDescending(x => x).ToList();
        }

    }
}
