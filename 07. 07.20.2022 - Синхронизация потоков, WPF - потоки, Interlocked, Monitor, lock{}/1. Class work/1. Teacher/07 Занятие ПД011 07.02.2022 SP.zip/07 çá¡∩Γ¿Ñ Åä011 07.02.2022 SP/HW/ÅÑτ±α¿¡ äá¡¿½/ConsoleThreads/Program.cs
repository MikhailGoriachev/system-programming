﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using ThreadsLib;

namespace ConsoleThreads
{
    class Program
    {
        static void Main(string[] args)
        {
            Processing proc = new Processing();
            Processing2 proc2 = new Processing2();
            Task3 proc3 = new Task3();

            Thread thread1 = new Thread(proc.Process1);
            thread1.Start();

            Thread thread2 = new Thread(proc2.Process2);
            thread2.Start();

            Thread thread3 = new Thread(proc3.Processing3);
            thread3.Start();

            thread1.Join();
            thread2.Join();
            thread3.Join();
        }
    }
}
