﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Threads;

namespace WindowsFormsApp
{
    public partial class MainForm : Form {
        Task01 _task01;
        Task02 _task02;
        Task03 _task03;
        public MainForm() {
            InitializeComponent();

            _task01 = new Task01 { FileName = "Thread1Data.bin", Form = this, Tbx = TbxThread1 };
            _task02 = new Task02 { FileName = "laptops.json", Dgv = DgvThread2};
            _task03 = new Task03 { FileName = "Thread3Data.txt", Dgv = DgvThread3, Form = this, Tbx = TbxThread3 };
        }

        // выход
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        // Запуск первого потока
        private void Thread1_Command(object sender, EventArgs e) {
            OfdMain.Title = "Открыть файл";
            OfdMain.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            OfdMain.Filter = "Файлы BIN (*.bin)|*.bin";
            OfdMain.FilterIndex = 1;
            if (OfdMain.ShowDialog() != DialogResult.OK) return;
            _task01.FileName = OfdMain.FileName;
            Thread thread = new Thread(_task01.Process_WF);
            thread.Start();
        } // Thread1_Command

        // Запуск второго потока
        private void Thread2_Command(object sender, EventArgs e) {
            OfdMain.Title = "Открыть файл";
            OfdMain.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            OfdMain.Filter = "Файлы JSON (*.json)|*.json";
            OfdMain.FilterIndex = 1;
            if (OfdMain.ShowDialog() != DialogResult.OK) return;
            _task02.FileName = OfdMain.FileName;

            Thread thread = new Thread(_task02.Process_WF);
            thread.Start();
        } // Thread2_Command

        // Запуск третьего потока
        private void Thread3_Command(object sender, EventArgs e) {
            OfdMain.Title = "Открыть файл";
            OfdMain.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            OfdMain.Filter = "Файлы TXT (*.txt)|*.txt";
            OfdMain.FilterIndex = 1;
            if (OfdMain.ShowDialog() != DialogResult.OK) return;
            _task03.FileName = OfdMain.FileName;

            Thread thread = new Thread(_task03.Process_WF);
            thread.Start();
        } // Thread3_Command

        // Запуск всех потоков параллельно
        private void ThreadAll_Command(object sender, EventArgs e) {
            List<Thread> threads = new List<Thread>(new[] {
                new Thread(_task01.Process_WF),
                new Thread(_task02.Process_WF),
                new Thread(_task03.Process_WF)
            });

            // запуск потоков на парвллельное исполнение
            threads.ForEach(t => t.Start());
        } // ThreadAll_Command

        private void MainForm_Load(object sender, EventArgs e) =>
            ThreadAll_Command(this, EventArgs.Empty);
        
    }
}
