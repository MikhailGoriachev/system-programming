﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Threads
{
    /* Обработка 1.
     * Cоздание файла случайных вещественных чисел (не более 20 чисел), создается при первом запуске, 
     * при последующих запусках – перемешивание данных в файле. 
     * Сортировка файла по убыванию и сохранение файла.
     */
    public class Task01 {

        // имя бинарного файла
        private string _fileName;
        public string FileName {
            get => _fileName;

            // при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
            set {
                _fileName = value;

                if (!File.Exists(_fileName)) {
                    var data = Enumerable
                        .Repeat(0, Utils.GetRandom(8, 15))
                        .Select(x => Utils.GetRandom(-10d, 20d))
                        .ToList();

                    using (BinaryWriter bwr = new BinaryWriter(File.Create(_fileName)))
                        data.ForEach(datum => bwr.Write(datum));
                }
                // при последующих запусках – перемешивание данных в файле
                else {
                    // чтение из файла в коллекцию
                    List<double> data = new List<double>();
                    using (BinaryReader brd = new BinaryReader(File.OpenRead(_fileName))) {
                        while (brd.BaseStream.Position < brd.BaseStream.Length)
                            data.Add(brd.ReadDouble());
                    } // using

                    // Utils.Shuffle(data);
                     data = data
                        .OrderBy(item => Utils.Random.Next())
                        .ToList();

                    using (BinaryWriter bwr = new BinaryWriter(File.Create(_fileName)))
                        data.ForEach(datum => bwr.Write(datum));
                }// if
            } // set
        } // FileName


        // ссылка на форму, в которой размещены элементы управления,
        // в которые будем выводить результаты работы
        private Form _form;
        public Form Form {
            get => _form;
            set => _form = value;
        } // Form


        // контролы для вывода из потоков в форму
        public TextBox Tbx { get; set; }


        // обработка по заданию
        public StringBuilder Process() {

            // чтение из файла в коллекцию
            List<double> data = new List<double>();
            using (BinaryReader brd = new BinaryReader(File.OpenRead(_fileName))) {
                while (brd.BaseStream.Position < brd.BaseStream.Length)
                    data.Add(brd.ReadDouble());
            } // using
            StringBuilder sb = OutputToStrigBuilder(data, $"Поток 1: файл \"{Path.GetFileName(_fileName)}\":\r\n");


            // Сортировка по убыванию
            data.Sort((x, y) => y.CompareTo(x));

            // сохранение файла
            using (BinaryWriter bwr = new BinaryWriter(File.Create(_fileName)))
                data.ForEach(datum => bwr.Write(datum));

            sb.Append(OutputToStrigBuilder(data, $"\r\n\r\nПоток 1: файл \"{Path.GetFileName(_fileName)}\" упорядочен по убыванию:\r\n"));

            return sb;
        } // Process

        // обработка по заданию для консольного приложения
        public void Process_Console() {
            Console.WriteLine(Process());
        } // Process_Console

        // обработка по заданию для Windows Forms
        public void Process_WF() {
            StringBuilder sb  = Process();
            if (Tbx.InvokeRequired)
                _form.BeginInvoke((Action)(() => Tbx.Text = sb.ToString()));
            else
                Tbx.Text = sb.ToString();
        } // Process_WF

        // вывод коллекции в StringBuilder
        private StringBuilder OutputToStrigBuilder(List<double> data, string title)  {
            StringBuilder sb = new StringBuilder(title);

            int i = 1;
            data.ForEach(d => { sb.Append($"{d,8:f2}"); if (i++ % 6 == 0) sb.AppendLine(); });

            sb.AppendLine();
            return sb;
        } // OutputToStrigBuilder

    } // Task01
}
