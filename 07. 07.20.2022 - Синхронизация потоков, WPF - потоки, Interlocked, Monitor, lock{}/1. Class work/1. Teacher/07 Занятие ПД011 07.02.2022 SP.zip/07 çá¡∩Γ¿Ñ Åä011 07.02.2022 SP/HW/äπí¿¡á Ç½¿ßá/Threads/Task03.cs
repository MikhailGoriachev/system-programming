﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Threads
{
    /* Обработка 3.
     * Обработка текстового файла – подсчет (без учета регистра) частоты слов, 
     * результаты выводите в словарь (пары «слово – количество»)
     */
    public class Task03 {
        // имя файла
        public string FileName { get; set; }

        // ссылка на форму, в которой размещены элементы управления,
        // в которые будем выводить результаты работы
        private Form _form;
        public Form Form {
            get => _form;
            set => _form = value;
        } // Form


        // контролы для вывода из потоков в форму
        public TextBox Tbx { get; set; }       // текст из файла
        public DataGridView Dgv { get; set; }  // словарь 

        // создание частотного словаря из коллекции строк
        private Dictionary<string, int> CreateDictionary(List<string> strings) {
            Dictionary<string, int> words = new Dictionary<string, int>();

            var delimiters = " ,.:!?'\"\t\n-+".ToCharArray();
            strings.ForEach(
                s => s
                    .ToLower()
                    .Split(delimiters, StringSplitOptions.RemoveEmptyEntries)
                    .ToList()
                    .ForEach(word => {
                        // string key = word.ToLower();
                        if (!words.ContainsKey(word))
                            words[word] = 0;
                        words[word]++;
                    }));
            return words;
        }

        // обработка по заданию для консольного приложения
        public void Process_Console() {
            // обработка по заданию
            List<string> strings = File.ReadLines(FileName).ToList();
            StringBuilder sb = OutputToStrigBuilder(strings, $"\n\n\tПоток 3: файл \"{Path.GetFileName(FileName)}\":\n");

            Dictionary<string, int> words = CreateDictionary(strings);

            // вывод в 
            sb.Append(OutputToStrigBuilder(words.Select(w => $"{w.Key, -15} - {w.Value, 2}").ToList(), $"\n\tПоток 3: подсчет (без учета регистра) частоты слов:\n"));
            Console.WriteLine(sb);
        } // Process_Console

        // обработка по заданию для Windows Forms
        public void Process_WF() {
            // обработка по заданию
            List<string> strings = File.ReadLines(FileName).ToList();
            StringBuilder sb = OutputToStrigBuilder(strings, $"Поток 3: файл \"{Path.GetFileName(FileName)}\":\r\n");

            // вывод файла в TextBox
            if (Tbx.InvokeRequired)
                _form.BeginInvoke((Action)(() => Tbx.Text = sb.ToString()));
            else
                Tbx.Text = sb.ToString();

            // пары «слово – количество»
            Dictionary<string, int> words = CreateDictionary(strings);

            // получение списка из словаря
            // Dgv.DataSource = words.ToList();

            
            Dgv.Rows.Clear();

            // вывод в DataGridView 
            foreach (var word in words) {
                DataGridViewRow row = new DataGridViewRow();

                // Слово
                DataGridViewCell cell = new DataGridViewTextBoxCell();
                cell.Value = word.Key;
                cell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                row.Cells.Add(cell);

                // кол-во
                cell = new DataGridViewTextBoxCell();
                cell.Value = $"{word.Value}";
                cell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                row.Cells.Add(cell);
                Dgv.Rows.Add(row);
            } // foreach
            
        } // Process_WF

        // вывод списка строк в StringBuilder
        private StringBuilder OutputToStrigBuilder(List<string> list, string title) {
            // сформировать вывод в StringBuilder'е
            StringBuilder sb = new StringBuilder(title);
            list.ForEach(item => sb.Append($"\t{item}\r\n"));

            return sb;
        } // OutputToStrigBuilder
    } // Task03
}
