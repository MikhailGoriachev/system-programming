﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Threads
{
    /* Обработка 2.
     * Cоздание коллекции заявок на ремонт ноутбуков, сериализация этой коллекции
     * при первом запуске; десериализация, перемешивание и сериализация при
     * последующих запусках. Формат файла данных – JSON
     */
    public class Task02 {
        // коллекция заявок на ремонт ноутбуков 
        List<Laptop> _laptops;

        // имя файла
        private string _fileName;
        public string FileName {
            get => _fileName;

            // при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
            set {
                _fileName = value;

                if (!File.Exists(_fileName)) {
                    _laptops.Clear();
                    for (int i = 0; i < 15; i++)
                        _laptops.Add(Laptop.Generate());

                    SerializeData();
                }
                // при последующих запусках – десериализация
                else {
                    DeserializeData();
                }// if
            } // set
        } // FileName

        // контролы для вывода из потоков в форму
        public DataGridView Dgv { get; set; }

        // конструкторы
        public Task02():this(new List<Laptop>()) { } // Task02

        public Task02(List<Laptop> laptops) {
            _laptops = laptops;
        } // Task02

        // обработка по заданию
        public void Process() {
            DeserializeData();
            // перемешивание
            Utils.Shuffle(_laptops);
            SerializeData();
        } // Process

        // обработка по заданию консольного приложения
        public void Process_Console() {
            Process();
            // вывод в консоль
            Console.WriteLine(OutputToStrigBuilder(_laptops, $"\n\n\tПоток 2: файл \"{Path.GetFileName(_fileName)}\":\n"));
        } // Process_Console

        // обработка по заданию для Windows Forms
        public void Process_WF() {
            Process();
            // вывод в DataGridView
            //if (Dgv.InvokeRequired)
            //    _form.BeginInvoke((Action)(() => UserControl1.Text = sb.ToString()));
            //else
            //    Dgv.DataSource = _laptops;

            Dgv.DataSource = _laptops;
        } // Process_WF

        // вывод списка в StringBuilder
        private StringBuilder OutputToStrigBuilder(List<Laptop> list, string title) {
            // сформировать вывод в StringBuilder'е
            StringBuilder sb = new StringBuilder(title + Laptop.Header());
            list.ForEach(item => sb.AppendLine($"{item.ToTableRow()}"));

            sb.AppendLine(Laptop.Footer());
            // собсвенно вывод
            return sb;
        } // OutputToStrigBuilder

        // -----------------------------------------------------------------------------------

        // сериализация данных в формате JSON
        public void SerializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<Laptop>));

            // Запись объекта в JSON-файл
            using (FileStream fs = new FileStream(FileName, FileMode.Create)) {
                jsonFormatter.WriteObject(fs, _laptops);
            } // using
        } // SerializeData

        // десериализация данных из формата JSON
        public void DeserializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<Laptop>));

            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate)) {
                _laptops = (List<Laptop>)jsonFormatter.ReadObject(fs);
            } // using

        } // DeserializeData

        // -----------------------------------------------------------------------------------

    } // Task02
}
