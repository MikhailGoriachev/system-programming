﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Threads;

namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args) {
            Task01 task01 = new Task01 { FileName = "Thread1Data.bin" };
            Task02 task02 = new Task02 { FileName = "laptops.json" };
            Task03 task03 = new Task03 { FileName = "Thread3Data.txt" };

            // создание и запуск потока
            List<Thread> threads = new List<Thread>(new[] {
                new Thread(task01.Process_Console),
                new Thread(task02.Process_Console),
                new Thread(task03.Process_Console)
            });

            // запуск потоков на парвллельное исполнение
            threads.ForEach(t => t.Start());

            // ожидание завершения потоков
            threads.ForEach(t => t.Join());
        } // Main
    }
}
