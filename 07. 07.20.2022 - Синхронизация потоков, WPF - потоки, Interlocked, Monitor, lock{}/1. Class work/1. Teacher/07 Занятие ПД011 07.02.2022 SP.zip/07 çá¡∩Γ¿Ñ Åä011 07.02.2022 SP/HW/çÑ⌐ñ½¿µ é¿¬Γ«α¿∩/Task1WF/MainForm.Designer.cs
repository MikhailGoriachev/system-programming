﻿
namespace Task1WF
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MniMain = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniThread1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MniThread1Exec = new System.Windows.Forms.ToolStripMenuItem();
            this.MniThread2Exec = new System.Windows.Forms.ToolStripMenuItem();
            this.MniThread3Exec = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniThreadAllExec = new System.Windows.Forms.ToolStripMenuItem();
            this.TxbThread1 = new System.Windows.Forms.TextBox();
            this.TxbThread2 = new System.Windows.Forms.TextBox();
            this.DgwThread3 = new System.Windows.Forms.DataGridView();
            this.TxbThread3 = new System.Windows.Forms.TextBox();
            this.MniMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgwThread3)).BeginInit();
            this.SuspendLayout();
            // 
            // MniMain
            // 
            this.MniMain.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MniMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.MniThread1});
            this.MniMain.Location = new System.Drawing.Point(0, 0);
            this.MniMain.Name = "MniMain";
            this.MniMain.Size = new System.Drawing.Size(1028, 24);
            this.MniMain.TabIndex = 0;
            this.MniMain.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniExit});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // MniExit
            // 
            this.MniExit.Name = "MniExit";
            this.MniExit.Size = new System.Drawing.Size(180, 22);
            this.MniExit.Text = "Выход";
            this.MniExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniThread1
            // 
            this.MniThread1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniThread1Exec,
            this.MniThread2Exec,
            this.MniThread3Exec,
            this.toolStripMenuItem1,
            this.MniThreadAllExec});
            this.MniThread1.Name = "MniThread1";
            this.MniThread1.Size = new System.Drawing.Size(80, 20);
            this.MniThread1.Text = "Потоки";
            // 
            // MniThread1Exec
            // 
            this.MniThread1Exec.Name = "MniThread1Exec";
            this.MniThread1Exec.Size = new System.Drawing.Size(266, 22);
            this.MniThread1Exec.Text = "Запуск потока 1";
            this.MniThread1Exec.Click += new System.EventHandler(this.Thread1_Execut);
            // 
            // MniThread2Exec
            // 
            this.MniThread2Exec.Name = "MniThread2Exec";
            this.MniThread2Exec.Size = new System.Drawing.Size(266, 22);
            this.MniThread2Exec.Text = "Запуск потока 2";
            this.MniThread2Exec.Click += new System.EventHandler(this.Thread2_Execut);
            // 
            // MniThread3Exec
            // 
            this.MniThread3Exec.Name = "MniThread3Exec";
            this.MniThread3Exec.Size = new System.Drawing.Size(266, 22);
            this.MniThread3Exec.Text = "Запуск потока 3";
            this.MniThread3Exec.Click += new System.EventHandler(this.Thread3_Execut);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(263, 6);
            // 
            // MniThreadAllExec
            // 
            this.MniThreadAllExec.Name = "MniThreadAllExec";
            this.MniThreadAllExec.Size = new System.Drawing.Size(266, 22);
            this.MniThreadAllExec.Text = "Запуск всех потоков";
            this.MniThreadAllExec.Click += new System.EventHandler(this.ThreadAll_Execut);
            // 
            // TxbThread1
            // 
            this.TxbThread1.BackColor = System.Drawing.SystemColors.Window;
            this.TxbThread1.Location = new System.Drawing.Point(0, 27);
            this.TxbThread1.Multiline = true;
            this.TxbThread1.Name = "TxbThread1";
            this.TxbThread1.ReadOnly = true;
            this.TxbThread1.Size = new System.Drawing.Size(1020, 100);
            this.TxbThread1.TabIndex = 1;
            // 
            // TxbThread2
            // 
            this.TxbThread2.BackColor = System.Drawing.SystemColors.Window;
            this.TxbThread2.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbThread2.Location = new System.Drawing.Point(0, 133);
            this.TxbThread2.Multiline = true;
            this.TxbThread2.Name = "TxbThread2";
            this.TxbThread2.ReadOnly = true;
            this.TxbThread2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxbThread2.Size = new System.Drawing.Size(1020, 280);
            this.TxbThread2.TabIndex = 2;
            // 
            // DgwThread3
            // 
            this.DgwThread3.AllowDrop = true;
            this.DgwThread3.AllowUserToAddRows = false;
            this.DgwThread3.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgwThread3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgwThread3.Location = new System.Drawing.Point(0, 419);
            this.DgwThread3.MultiSelect = false;
            this.DgwThread3.Name = "DgwThread3";
            this.DgwThread3.ReadOnly = true;
            this.DgwThread3.RowHeadersVisible = false;
            this.DgwThread3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgwThread3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgwThread3.Size = new System.Drawing.Size(1020, 150);
            this.DgwThread3.TabIndex = 3;
            // 
            // TxbThread3
            // 
            this.TxbThread3.BackColor = System.Drawing.SystemColors.Window;
            this.TxbThread3.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbThread3.Location = new System.Drawing.Point(0, 419);
            this.TxbThread3.Multiline = true;
            this.TxbThread3.Name = "TxbThread3";
            this.TxbThread3.ReadOnly = true;
            this.TxbThread3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxbThread3.Size = new System.Drawing.Size(1020, 130);
            this.TxbThread3.TabIndex = 4;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ClientSize = new System.Drawing.Size(1028, 554);
            this.Controls.Add(this.TxbThread3);
            this.Controls.Add(this.DgwThread3);
            this.Controls.Add(this.TxbThread2);
            this.Controls.Add(this.TxbThread1);
            this.Controls.Add(this.MniMain);
            this.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MniMain;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание №6";
            this.MniMain.ResumeLayout(false);
            this.MniMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgwThread3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MniMain;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniExit;
        private System.Windows.Forms.ToolStripMenuItem MniThread1;
        private System.Windows.Forms.ToolStripMenuItem MniThread1Exec;
        private System.Windows.Forms.ToolStripMenuItem MniThread2Exec;
        private System.Windows.Forms.ToolStripMenuItem MniThread3Exec;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MniThreadAllExec;
        private System.Windows.Forms.TextBox TxbThread1;
        private System.Windows.Forms.TextBox TxbThread2;
        private System.Windows.Forms.DataGridView DgwThread3;
        private System.Windows.Forms.TextBox TxbThread3;
    }
}

