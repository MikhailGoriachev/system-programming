﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThreadsH_W6SP;

namespace Task1WF
{
    public partial class MainForm : Form
    {
        private Processing _processings;
        // в конструкторе создать объект для создания потоков 
        public MainForm()
        {
            InitializeComponent();

            _processings = new Processing
            {
                BinFileName = "Thread1Data.bin",
                JsonFileName = "Thread2Data.json",
                TextFileName = "Thread3Data.txt",

                Form = this,

                Executive1 = TxbThread1,
                Executive2 = TxbThread2,
                Executive3 = TxbThread3,               
            };


        }// MainForm

        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void Thread1_Execut(object sender, EventArgs e)
        {
            TxbThread1.Text = "";
            Thread thread = new Thread(_processings.Process1_WF);
            thread.Start();
        }// Thread1_Execut

        private void Thread2_Execut(object sender, EventArgs e)
        {
            TxbThread2.Text = "";
            Thread thread = new Thread(_processings.Process2_WF);
            thread.Start();
        }// Thread2_Execut

        private void Thread3_Execut(object sender, EventArgs e)
        {
            TxbThread3.Text = "";
            Thread thread = new Thread(_processings.Process3_WF);
            thread.Start();
        }// Thread3_Execut

        // запуск всех потков параллельно
        private void ThreadAll_Execut(object sender, EventArgs e)
        {
            TxbThread1.Text = TxbThread2.Text = TxbThread2.Text = "";

            List<Thread> threads = new List<Thread>(new[] {
                new Thread(_processings.Process1_WF),
                new Thread(_processings.Process2_WF),
                new Thread(_processings.Process3_WF),
            });

            // запуск потоков на парвллельное исполнение
            threads.ForEach(t => t.Start());
        }// ThreadAll_Execut

    }// class MainForm
}
