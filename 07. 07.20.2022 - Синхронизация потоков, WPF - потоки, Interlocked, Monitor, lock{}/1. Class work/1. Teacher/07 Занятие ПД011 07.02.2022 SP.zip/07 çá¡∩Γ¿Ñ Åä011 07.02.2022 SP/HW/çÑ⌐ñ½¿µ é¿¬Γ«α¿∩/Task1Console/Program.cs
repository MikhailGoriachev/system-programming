﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using ThreadsH_W6SP;

namespace Task1Console
{
    class Program
    {
        static void Main(string[] args)
        {
            // Настройка консоли 
            Console.Title = "Домашняя работа №6.";
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.Clear();
            Console.CursorVisible = false;


            Processing processings = new Processing
            {
                BinFileName = "Thread1Data.bin",
                JsonFileName = "Thread2Data.json",
                TextFileName = "Thread3Data.txt"
            };

            Thread thread1 = new Thread(processings.Process1_Console);
            Thread thread2 = new Thread(processings.Process2_Console);
            Thread thread3 = new Thread(processings.Process3_Console);

            thread1.Start();
            thread2.Start();
            thread3.Start();
            thread1.Join();
            thread2.Join();
            thread3.Join();



        }// Main
    }
}
