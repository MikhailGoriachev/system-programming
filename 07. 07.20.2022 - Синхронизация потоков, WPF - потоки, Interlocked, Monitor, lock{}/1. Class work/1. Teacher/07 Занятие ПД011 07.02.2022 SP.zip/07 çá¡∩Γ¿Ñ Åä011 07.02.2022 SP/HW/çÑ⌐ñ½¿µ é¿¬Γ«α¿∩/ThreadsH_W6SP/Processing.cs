﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Windows.Forms;
using ThreadsH_W6SP.Models;


namespace ThreadsH_W6SP
{

    // Разработайте библиотеку классов для выполнения обработок:
    // а)	создание файла случайных вещественных чисел(не более 20 чисел),
    // создается при первом запуске, при последующих запусках –
    // перемешивание данных в файле.Сортировка файла по убыванию и сохранение файла

    // б)	создание коллекции заявок на ремонт ноутбуков
    // (наименование устройства, модель, тип процессора, объем оперативной памяти,
    // емкость накопителя, диагональ экрана, описание неисправности,
    // фамилия и инициалы владельца), сериализация этой коллекции при первом запуске;
    // десериализация, перемешивание и сериализация при последующих запусках.
    // Формат файла данных – JSON

    // в)	обработка текстового файла – подсчет (без учета регистра)
    // частоты слов, результаты выводите в словарь (пары «слово – количество»)
    public class Processing
    {
        // данные для потоков
        #region Данные для потоков
        // имя текстового файла для потока 1
        private string _binFileName;
        public string BinFileName 
        { get => _binFileName;

            // при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
            set
            {
                _binFileName = value;

                if (!File.Exists(_binFileName))
                {
                    var data = Enumerable
                        .Repeat(0, Utils.GetRandom(10, 20))
                        .Select(x => Utils.GetRandom(-10d, 20d))
                        .ToList();

                    using (BinaryWriter bwr = new BinaryWriter(File.Create(_binFileName)))
                        data.ForEach(datum => bwr.Write(datum));
                } // if
            } // set 
        }// BinFileName


        // данные для потока 2
        private CollectionRepairLaptop _collectionRepair ;
        public CollectionRepairLaptop CollectionRepairLaptop => _collectionRepair;


        // имя Json файла для потока2
        private string _jsonFileName;
        public string JsonFileName
        {
            get => _jsonFileName;

            // при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
            set
            {
                _jsonFileName = value;
                _collectionRepair.Initialize();
                if (!File.Exists(_jsonFileName))
                {                    
                    DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(CollectionRepairLaptop));

                    using (FileStream fs = new FileStream(_jsonFileName, FileMode.Create)) {
                        jsonFormatter.WriteObject(fs, _collectionRepair);
                    } // using
                    
                } // if               
            } // set 
        }// JsonFileName


        // имя текстового файла для потока 3
        public string TextFileName { get; set; }

        // ссылка на форму, в которой размещены элементы управления,
        // в которые будем выводить результаты работы
        private Form _form;
        public Form Form
        {
            get => _form;
            set => _form = value;
        }

        // контролы для вывода из потоков в форму
        public TextBox Executive1 { get; set; }
        public TextBox Executive2 { get; set; }
        public TextBox Executive3 { get; set; }

        #endregion


        // конструкторы
        public Processing() : this(new CollectionRepairLaptop()) { }
        public Processing(CollectionRepairLaptop collectionRepair)
        {
            _collectionRepair = collectionRepair;
        }


        // метод для потока 1 - используется в консольном приложении
        // Cоздание файла случайных вещественных чисел, перемешивание данных в файле.
        // Сортировка файла по убыванию и сохранение файла
        public void Process1_Console()
        {
            // чтение из файла в коллекцию
            List<double> data = new List<double>();

            using (BinaryReader brd = new BinaryReader(File.OpenRead(_binFileName)))
            {
                while (brd.BaseStream.Position < brd.BaseStream.Length)
                    data.Add(brd.ReadDouble());
            } // using

            StringBuilder sb = OutputToStrigBuilder(data, $"\n\n Поток 1: файл \"{_binFileName}\":\n\t");

            Shuffle(data);
            data.OrderBy(a => a);

            // запись в файл
            using (BinaryWriter bwr = new BinaryWriter(File.Create(_binFileName)))
                data.ForEach(datum => bwr.Write(datum));

            sb.Append(OutputToStrigBuilder(data, $"\n\n Поток 1: массив вещественных чисел перемешан \"{_binFileName}\":\n\t"));

            // вывод в консоль
            Console.WriteLine(sb);
        } // Process1_Console


        // метод для потока 1 - используется в Windows Forms
        // Cоздание файла случайных вещественных чисел, перемешивание данных в файле.
        // Сортировка файла по убыванию и сохранение файла
        public void Process1_WF()
        {           
            // чтение из файла в коллекцию
            List<double> data = new List<double>();

            using (BinaryReader brd = new BinaryReader(File.OpenRead(_binFileName)))
            {
                while (brd.BaseStream.Position < brd.BaseStream.Length)
                    data.Add(brd.ReadDouble());
            } // using

            StringBuilder sb = OutputToStrigBuilder(data, $"\n\n Поток 1: файл \"{_binFileName}\":\r\n");

            Shuffle(data);
            data.OrderBy(a => a);

            // запись в файл
            using (BinaryWriter bwr = new BinaryWriter(File.Create(_binFileName)))
                data.ForEach(datum => bwr.Write(datum));

            sb.Append(OutputToStrigBuilder(data, $"\r\n\n Поток 1: массив вещественных чисел перемешан \"{_binFileName}\":\r\n"));

            // вывод в WF
            if (Executive1.InvokeRequired)
                _form.BeginInvoke((Action)(() => Executive1.Text = sb.ToString()));
            else
                Executive1.Text = sb.ToString();
        }// Process1_WF


        // метод для потока 2 - используется в консольном приложении
        // Cоздание коллекции заявок на ремонт ноутбуков
        // перемешивание и сериализация при последующих запусках
        public void Process2_Console()
        {
            StringBuilder sb = new StringBuilder($"\n\n Поток 2: {_collectionRepair.Show(" Данные сформированы:")}");

            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(CollectionRepairLaptop));
            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(_jsonFileName, FileMode.OpenOrCreate))
            {
                _collectionRepair = (CollectionRepairLaptop)jsonFormatter.ReadObject(fs);
            } // using

            Shuffle(_collectionRepair);

            jsonFormatter = new DataContractJsonSerializer(typeof(CollectionRepairLaptop));
            using (FileStream fs = new FileStream(_jsonFileName, FileMode.Create))
            {
                jsonFormatter.WriteObject(fs, _collectionRepair);
            } // using

            sb.Append($"\n Поток 2: {_collectionRepair.Show(" Вывод данных, коллекция после перемешивания:")}");
            // вывод в консоль
            Console.WriteLine(sb);
        }// Process2_Console


        // метод для потока 2 - используется в Windows Forms
        // Cоздание коллекции заявок на ремонт ноутбуков
        // перемешивание и сериализация при последующих запусках
        public void Process2_WF()
        {
            StringBuilder sb = new StringBuilder($"\n\n Поток 2: {_collectionRepair.Show(" Данные сформированы:\r\n")}");

            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(CollectionRepairLaptop));
            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(_jsonFileName, FileMode.OpenOrCreate))
            {
                _collectionRepair = (CollectionRepairLaptop)jsonFormatter.ReadObject(fs);
            } // using

            Shuffle(_collectionRepair);

            jsonFormatter = new DataContractJsonSerializer(typeof(CollectionRepairLaptop));
            using (FileStream fs = new FileStream(_jsonFileName, FileMode.Create))
            {
                jsonFormatter.WriteObject(fs, _collectionRepair);
            } // using

            sb.Append($"\r\n Поток 2: {_collectionRepair.Show(" Вывод данных, коллекция после перемешивания:")}\r\n");
            // вывод в WF
            if (Executive2.InvokeRequired)
                _form.BeginInvoke((Action)(() => Executive2.Text = sb.ToString()));
            else
                Executive2.Text = sb.ToString();
        }// Process2_WF


        // метод для потока 3 - используется в консольном приложении
        // Обработка текстового файла – подсчет частоты слов,
        // результаты выводите в словарь (пары «слово – количество»)
        public void Process3_Console()
        {
            Console.WriteLine("\n\n");
            // обработка по заданию
            var n = File.ReadAllText(TextFileName);

            // обработка по заданию
            var words = n.Split(' ', '-', ':', '.', ',', '!', '?').Where(q => !string.IsNullOrEmpty(q));
            var uniqWords = words.Select(q => q.ToLower().Trim()).Distinct();
            var result = new Dictionary<string, int>();
            foreach (var word in uniqWords)
            {
               result.Add(word, words.Count(q => q.Equals(word)));
            }
            result = result.OrderByDescending(q => q.Value).ToList().ToDictionary(key => key.Key, value => value.Value);
            foreach (var word in result)
            {
                Console.WriteLine($" Слово: {word.Key, -17} : Кол-во: {word.Value}");
            }

        } // Process3_Console


        // метод для потока 3 - используется в Windows Forms
        // Обработка текстового файла – подсчет частоты слов,
        // результаты выводите в словарь (пары «слово – количество»)
        public void Process3_WF()
        {
            StringBuilder sb = new StringBuilder();
            // обработка по заданию
            var n = File.ReadAllText(TextFileName);

            // обработка по заданию
            var words = n.Split(' ', '-', ':', '.', ',', '!', '?').Where(q => !string.IsNullOrEmpty(q));
            var uniqWords = words.Select(q => q.ToLower().Trim()).Distinct();
            var result = new Dictionary<string, int>();
            foreach (var word in uniqWords)
            {
                result.Add(word, words.Count(q => q.Equals(word)));
            }
            result = result.OrderByDescending(q => q.Value).ToList().ToDictionary(key => key.Key, value => value.Value);
            foreach (var word in result)
            {
                sb.Append($" Слово: {word.Key,-17} : Кол-во: {word.Value} \r\n");
            }

            // вывод в WF
            if (Executive2.InvokeRequired)
                _form.BeginInvoke((Action)(() => Executive3.Text = sb.ToString()));
            else
                Executive3.Text = sb.ToString();
        }// Process3_WF


        #region Вспомогательные методы
        // вывод списка строк в консоль
        private StringBuilder OutputToStrigBuilder(List<string> list, string title)
        {
            // сформировать вывод в StringBuilder'е
            StringBuilder sb = new StringBuilder(title);
            list.ForEach(item => sb.Append($"{item}\r\n"));

            // вывод
            return sb;
        } // OutputToStrigBuilder


        // перемешивание массива, метод для потока 1
        public void Shuffle(List<double> data)
        {
            for (int i = data.Count - 1; i >= 1; i--)
            {
                int temp = Utils.Random.Next(i + 1);
                (data[i], data[temp]) = (data[temp], data[i]);
            } // for i
        } // Shuffle


        // перемешивание массива, метод для потока 3
        public void Shuffle(CollectionRepairLaptop collectionRepair)
        {
            for (int i = collectionRepair.Count - 1; i >= 1; i--)
            {
                int temp = Utils.Random.Next(i + 1);
                (collectionRepair[i], collectionRepair[temp]) = (collectionRepair[temp], collectionRepair[i]);
            } // for i
        } // Shuffle


        // вывод коллекции в StringBuilder
        private StringBuilder OutputToStrigBuilder(List<double> data, string title)
        {
            StringBuilder sb = new StringBuilder(title);

            foreach (var d in data) {
                sb.Append($"{d,7:f2}");
            }

            sb.AppendLine();
            return sb;
        }// OutputToStrigBuilder

        #endregion

    }// class Processing
}
