﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterlockedCounterDemo
{
    // класс, представляющий совместно используемый ресурс
    // имитация общего ресурса - это ячейка памяти
    class Counter
    {
        public static int Сount;
    }
}
