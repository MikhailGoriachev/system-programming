﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterlockedCounterDemo
{
    // модель общего ресурса
    class TwoNumbers
    {
        public static int Number1;
        public static int Number2;
    }
}
