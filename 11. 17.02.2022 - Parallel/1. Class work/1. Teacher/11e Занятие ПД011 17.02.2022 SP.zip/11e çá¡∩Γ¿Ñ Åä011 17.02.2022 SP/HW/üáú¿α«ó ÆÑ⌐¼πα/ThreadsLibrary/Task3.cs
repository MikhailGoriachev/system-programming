﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreadsLibrary {
    public class Task3 {

        // имя текстового файла
        public string TextFileName { get; set; }


        // создание частотного словаря
        private Dictionary<string, int> CreateDictionary()  {
            List<string> strings = File.ReadAllLines(TextFileName).ToList();
            var res = new Dictionary<string, int>();
            var delimiters = " ,.:!?'\"\t\n-+".ToCharArray();
            strings.ForEach(
                s => s
                    .ToLower()
                    .Split(delimiters, StringSplitOptions.RemoveEmptyEntries)
                    .ToList()
                    .ForEach(word => {
                        if (!res.ContainsKey(word))
                            res[word] = 0;
                        res[word]++;
                    }));
            return res;
        } // CreateDictionary

        public void Process3_Console()  {
            // обработка по заданию
            List<string> strings = File.ReadAllLines(TextFileName).ToList();
            lock (typeof(Console))
                Show(strings, $"\n\n\tЗадача 3: файл \"{TextFileName}\":\n");

            var res = CreateDictionary();

            // вывод в консоль
            lock (typeof(Console))
                Show(res, $"\n\tЗадача 3: количество каждого слова в файле \"{TextFileName}\":\n"); 

        } // Process3_Console

        // обработка по заданию для приложения WPF
        public Dictionary<string, int> Process_WPF(out string fileText)  {
            fileText = $"Задача 3: файл \"{Path.GetFileName(TextFileName)}\":\r\n{File.ReadAllText(TextFileName)}";

            // пары «слово – количество»
            return CreateDictionary();
        } // Process_WPF


        // вывод списка строк в консоль
        private void Show(List<string> list, string title)  {
           
            Console.WriteLine($"\n{title}");
            
            list.ForEach(item => Console.WriteLine($"\t {item}"));

        } // OutputToStrigBuilder

        // вывод словаря (пары «слово – количество»), в одной строке
        private void Show(Dictionary<string, int> dict, string title)   {
            
            Console.WriteLine($"\n{title}");

            foreach (var key in dict.Keys)
                Console.WriteLine($"\t{key,15} => {dict[key],2}"); 

        } // OutputToStrigBuilder

    }
}
