﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ThreadsLibrary.Helpers;

namespace ThreadsLibrary
{
    public class Task1 {

        // Максимальное количество генерируемых элементов, для потока 1
        private const int MaxElement = 20;

        // имя бинарного файла
        private string _binFileName;
        public string BinFileName {
            get => _binFileName;

            //  При первом запуске создание файла случайных вещественных чисел(не более 20 чисел),
            //  при последующих запусках – перемешивание данных в файле.
            set  {
                _binFileName = value;
                List<double> data;
                if (!File.Exists(_binFileName))
                {
                    data = Enumerable
                        .Repeat(0, Utils.GetRandom(7, MaxElement))
                        .Select(x => Utils.GetRandom(-10d, 20d))
                        .ToList();
                } // if
                else {
                    data = new List<double>();
                    using (BinaryReader brd = new BinaryReader(File.OpenRead(_binFileName)))
                    {
                        while (brd.BaseStream.Position < brd.BaseStream.Length)
                            data.Add(brd.ReadDouble());
                    } // using
                    Shuffle(data);
                } //  else

                using (BinaryWriter bwr = new BinaryWriter(File.Create(_binFileName)))
                    data.ForEach(datum => bwr.Write(datum));

            } // set
        } // BinFileName

        // чтение коллекции из файла
        private List<double> GetAll()  {
            List<double> data = new List<double>();
            using (BinaryReader brd = new BinaryReader(File.OpenRead(_binFileName)))  {
                while (brd.BaseStream.Position < brd.BaseStream.Length)
                    data.Add(brd.ReadDouble());
            } // using

            return data;
        } // GetAll

        // запись коллекции в файл
        private void PutAll(List<double> data) {
            // запись в файл
            using (BinaryWriter bwr = new BinaryWriter(File.Create(_binFileName)))
                data.ForEach(datum => bwr.Write(datum));
        } // PutAll


        public void Process1_Console()    {

            // чтение из файла в коллекцию
            List<double> data = GetAll();
            
            lock(typeof(Console))
                Show(data, $"\n\n\tЗадача 1: Исходные данные из файла \"{_binFileName}\":\n\t");  

            // сортировка коллекции по убыванию
            data.Sort((x, y) => y.CompareTo(x));

            PutAll(data);
            lock (typeof(Console))
                Show(data, $"\n\n\tЗадача 1: Данные отсортированы по убыванию, и записаны в файл \"{_binFileName}\":\n\t");
 
        } // Process1_Console


        // обработка по заданию для WPF
        public StringBuilder Process_WPF()   {
            // чтение из файла в коллекцию
            List<double> data = GetAll(); 
            
            StringBuilder sb = OutputToStrigBuilder(data, $"Задача 1: файл \"{Path.GetFileName(_binFileName)}\":\r\n");

            // Сортировка по убыванию в другую коллекцию, для вывод исходных данных
            List<double> temp = data.OrderByDescending(x => x).ToList();

            // сохранение файла
            PutAll(temp);
             
            sb.AppendLine(OutputToStrigBuilder(temp, $"\r\n\r\nЗадача 1: файл \"{Path.GetFileName(_binFileName)}\" упорядочен по убыванию:\r\n").ToString());
 
            return sb;
        } // Process_WPF


        // перемешивание коллекции электроприборов по алгоритму "Тасование Фишера-Йетса"
        // https://vscode.ru/prog-lessons/kak-peremeshat-massiv-ili-spisok.html
        public void Shuffle(List<double> data)   {

            // просматриваем массив с конца
            for (int i = data.Count() - 1; i >= 1; i--)
            {

                // определяем элемент, с которым меням элемент с индексами i
                int j = Utils.GetRandom(0, i);  // фактически генерится 0, ..., i

                // меняем местами элементы списка при помощи кортежа
                (data[i], data[j]) = (data[j], data[i]);
            } // for i
        } // Shuffle

        // вывод коллекции 
        private void Show(List<double> data, string title) {

            Console.Write($"{title}\n\t");  

            int w = MaxElement;
            foreach (var d in data) {
                Console.Write($"{d,9:f3}");
                w--;
                if (w % 10 == 0) Console.Write("\n\t");
            }  
        } // Show

        // вывод коллекции в StringBuilder
        private StringBuilder OutputToStrigBuilder(List<double> data, string title) {
            StringBuilder sb = new StringBuilder(title);

            int i = 1;
            data.ForEach(d => { sb.Append( (i++ % 8 == 0) ? $"{d,8:f2}\n" : $"{d,8:f2}");});

            sb.AppendLine();
            return sb;
        } // OutputToStrigBuilder

    }
}
