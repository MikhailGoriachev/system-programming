﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using ThreadsLibrary.Helpers;
using ThreadsLibrary.Models;

namespace ThreadsLibrary {
    public class Task2  {
        // Коллекция заявок на ремонт ноутбука
        private List<LaptopRepair> _laptopRepairs;
        public List<LaptopRepair> LaptopRepairs {
            get => _laptopRepairs;
            set => _laptopRepairs = value;
        } // LaptopRepairs


        // Имя Json файла
        private string _jsonFileName;
        public string JsonFileName  {
            get => _jsonFileName;
            set {
                _jsonFileName = value;

                if (!File.Exists(_jsonFileName)) {
                    _laptopRepairs.Clear();
                    for (int i = 0; i < 6; i++)
                        _laptopRepairs.Add(LaptopRepair.Generate());

                    Serialization();
                } // if
                else {
                    Deserialization();
                    // перемешивание
                    // Shuffle(_laptopRepairs);
                    // Serialization();
                } // else
            } // set
        } // JsonFileName

        // Конструктор по умолчанию
        public Task2() : this(new List<LaptopRepair>()) { }
        
        // Конструктор с парамметрами
        public Task2(List<LaptopRepair> laptopRepairs) => _laptopRepairs = laptopRepairs;

        // метод для потока 2
        // Сериализация коллекции при первом запуске.
        // Десериализация, перемешивание и сериализация при последующих запусках.
        public void Process2_Console() {
            lock (typeof(Console))
                Console.WriteLine(OutputToStrigBuilder(_laptopRepairs, $"\n\n\tЗадача 2: файл \"{Path.GetFileName(_jsonFileName)}\" до обработки:\n"));
 
            Shuffle(_laptopRepairs);
            
            lock (typeof(Console))
                Console.WriteLine(OutputToStrigBuilder(_laptopRepairs, $"\n\n\tЗадача 2: файл \"{Path.GetFileName(_jsonFileName)}\" после обработки:\n"));
    
            Serialization();

        } // Process2_Console

        // обработка по заданию для WPF
        public List<LaptopRepair> Process_WPF(out List<LaptopRepair> temp) {
            temp = _laptopRepairs;
            Shuffle(_laptopRepairs); 
            Serialization();
            return _laptopRepairs;
        } // Process_WPF


        // перемешивание коллекции электроприборов по алгоритму "Тасование Фишера-Йетса"
        // https://vscode.ru/prog-lessons/kak-peremeshat-massiv-ili-spisok.html
        public void Shuffle(List<LaptopRepair> data)  {
            // просматриваем массив с конца
            for (int i = data.Count() - 1; i >= 1; i--) {

                // определяем элемент, с которым меням элемент с индексами i
                int j = Utils.GetRandom(0, i);  // фактически генерится 0, ..., i

                // меняем местами элементы списка при помощи кортежа
                (data[i], data[j]) = (data[j], data[i]);
            } // for i
        } // Shuffle

 
        private StringBuilder OutputToStrigBuilder(List<LaptopRepair> data, string title) {

            StringBuilder sb = new StringBuilder(title);

            foreach (var d in data) {
                sb.Append($"\n{d}");
            }

            sb.AppendLine();
            return sb;
        } // OutputToStrigBuilder


        // сериализация в формате JSON
        public void Serialization() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<LaptopRepair>));

            // Запись объекта в JSON-файл
            using (FileStream fs = new FileStream(JsonFileName, FileMode.Create)) {
                jsonFormatter.WriteObject(fs, _laptopRepairs);
            } // using
        } // Serialization

        // десериализация данных из формата JSON
        public void Deserialization()  {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<LaptopRepair>));

            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(JsonFileName, FileMode.OpenOrCreate)) {
                _laptopRepairs = (List<LaptopRepair>)jsonFormatter.ReadObject(fs);
            } // using
        } // Deserialization





    }
}
