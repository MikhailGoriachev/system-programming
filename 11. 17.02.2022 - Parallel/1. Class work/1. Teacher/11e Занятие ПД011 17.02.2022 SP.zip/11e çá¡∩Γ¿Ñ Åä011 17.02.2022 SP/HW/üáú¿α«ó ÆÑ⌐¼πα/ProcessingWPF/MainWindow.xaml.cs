﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Win32;

using ThreadsLibrary;
using ThreadsLibrary.Models;

namespace ProcessingWPF
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Task1 _task01;
        Task2 _task02;
        Task3 _task03;
        public MainWindow()
        {
            InitializeComponent();
            _task01 = new Task1 { BinFileName = "Thread1Data.bin" };
            _task02 = new Task2 { JsonFileName = "Thread2Data.json" };
            _task03 = new Task3 { TextFileName = "Thread3Data.txt" };
        }

        private void Exit_Command(object sender, RoutedEventArgs e) => Close();


        // Запуск первого потока
        private void ExecTask1_Command(object sender, RoutedEventArgs e)
        {

            // при задании имени файла - перемешивание 
            _task01.BinFileName = _task01.BinFileName;

            OpenFileDialog ofd = new OpenFileDialog
            {
                Multiselect = false,
                Title = "Файл данных для загрузки",
                Filter = "Файлы BIN (*.bin)|*.bin",
                FilterIndex = 0,
                InitialDirectory = AppDomain.CurrentDomain.BaseDirectory
            };

            if (ofd.ShowDialog() != true) return;
            _task01.BinFileName = ofd.FileName;
            Task task = new Task(() => OutputToTextBox(TbxThread1, _task01.Process_WPF().ToString()));
            task.Start();
        } // ExecTask1_Command


        // Запуск второго потока
        private void ExecTask2_Command(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                Multiselect = false,
                Title = "Файл данных для загрузки",
                Filter = "Файлы JSON (*.json)|*.json",
                FilterIndex = 0,
                InitialDirectory = AppDomain.CurrentDomain.BaseDirectory
            };

            if (ofd.ShowDialog() != true) return;
            _task02.JsonFileName = ofd.FileName;

            Task task = new Task(() =>
            {
                // вывод перемешанной коллекции
                OutputToDataGrid(DgThread2Result, _task02.Process_WPF(out List<LaptopRepair> list));
                // вывод исходной коллекции
                OutputToDataGrid(DgThread2, list);
            });
            task.Start();
        } // ExecTask2_Command


        // Запуск третьего потока
        private void ExecTask3_Command(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                Multiselect = false,
                Title = "Файл данных для загрузки",
                Filter = "Файлы TXT (*.txt)|*.txt",
                FilterIndex = 0,
                InitialDirectory = AppDomain.CurrentDomain.BaseDirectory
            };

            if (ofd.ShowDialog() != true) return;
            _task03.TextFileName = ofd.FileName;
            Task task = new Task(() =>
            {
                var words = _task03.Process_WPF(out string fileText); // пары «слово – количество»

                // вывод текста файла в TbxThread3
                OutputToTextBox(TbxThread3, fileText);
                // вывод пар «слово – количество» в DgThread3
                OutputToDataGrid(DgThread3, words);
            });
            task.Start();
        } // ExecTask3_Command


        // Запуск всех потоков
        private void ExecAllTask_Command(object sender, RoutedEventArgs e)
        {

            // при задании имени файла - перемешивание 
            _task01.BinFileName  = _task01.BinFileName;
            _task02.JsonFileName = _task02.JsonFileName;
            // создание и запуск потока
            List<Task> threads = new List<Task>(new[] {
                // поток 1
                new Task(() => OutputToTextBox(TbxThread1, _task01.Process_WPF().ToString())),
                // поток 2
                new Task(() => {  // вывод перемешанной коллекции
                                    OutputToDataGrid(DgThread2Result, _task02.Process_WPF(out List<LaptopRepair> list));
                                    // вывод исходной коллекции
                                    OutputToDataGrid(DgThread2, list); }),
                // поток 3
                new Task(() => {  var words = _task03.Process_WPF(out string fileText); // пары «слово – количество»

                                    // вывод текста файла в TbxThread3
                                    OutputToTextBox(TbxThread3, fileText);
                                    // вывод пар «слово – количество» в DgThread3
                                    OutputToDataGrid(DgThread3, words);
                                    })
                });

            // запуск потоков на парвллельное исполнение
            threads.ForEach(t => t.Start());
        } // ExecAllTask_Command


        // вывод текста в TextBox
        private void OutputToTextBox(TextBox textBox, string text) {
            Dispatcher.BeginInvoke(
                DispatcherPriority.Normal,
                (ThreadStart)(() => textBox.Text = text));
        } // AddTextToTextBox

        // вывод коллекции в DataGrid
        private void OutputToDataGrid(DataGrid dataGrid, System.Collections.IEnumerable collection) {
            Dispatcher.BeginInvoke(
                DispatcherPriority.Normal,
                (ThreadStart)(() => dataGrid.ItemsSource = collection));
        } // AddTextToTextBox
    }
}
