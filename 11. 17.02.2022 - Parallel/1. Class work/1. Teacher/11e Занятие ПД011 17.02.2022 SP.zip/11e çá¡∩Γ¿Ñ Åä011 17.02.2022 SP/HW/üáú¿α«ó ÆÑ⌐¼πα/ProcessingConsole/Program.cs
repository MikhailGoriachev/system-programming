﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

using ThreadsLibrary; 
using ThreadsLibrary.Models; 

namespace ProcessingConsole
{
    class Program {
        static void Main(string[] args)  {

            Console.SetWindowSize(150, 30);

            Task1 task1 = new Task1 { BinFileName = "Thread1Data.bin" };
            Task2 task2 = new Task2 { JsonFileName = "Thread2Data.json" };
            Task3 task3 = new Task3 { TextFileName = "Thread3Data.txt" };

            // создание и запуск потока
            List<Task> tasks = new List<Task>(new[] {
                new Task(task1.Process1_Console),
                new Task(task2.Process2_Console),
                new Task(task3.Process3_Console),
            });

            // запуск задач на парвллельное исполнение
            tasks.ForEach(t => t.Start());
            
            // !!! При синхронном запуску, блоки lock в файлах "Task(1,2,3).cs" не нужны
            // tasks.ForEach(t => t.RunSynchronously());

            // ожидание завершения потоков
            Task.WaitAll(tasks.ToArray());


            Console.ReadKey(false);
        } // Main
    
    } // Program
}
