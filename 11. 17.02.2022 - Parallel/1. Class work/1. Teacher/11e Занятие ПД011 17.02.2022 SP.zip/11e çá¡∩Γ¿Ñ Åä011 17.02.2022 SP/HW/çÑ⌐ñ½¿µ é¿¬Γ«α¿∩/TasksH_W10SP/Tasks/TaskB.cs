﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TasksH_W10SP.Models;

namespace TasksH_W10SP.Tasks
{
    // б) создание коллекции заявок на ремонт ноутбуков,
    // сериализация этой коллекции при первом запуске;
    // десериализация, перемешивание и сериализация при последующих запусках.
    // Формат файла данных – JSON
    public class TaskB
    {
        // данные для потока 2
        private CollectionRepairLaptop _collectionRepair;
        public CollectionRepairLaptop CollectionRepairLaptop => _collectionRepair;


        // имя Json файла для потока2
        private string _jsonFileName;
        public string JsonFileName
        {
            get => _jsonFileName;

            // при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
            set
            {
                _jsonFileName = value;
                _collectionRepair.Initialize();
                if (!File.Exists(_jsonFileName))
                {
                    SerializeData();

                }
                // при последующих запусках – десериализация
                else
                {
                    DeserializeData();
                }// if               
            } // set 
        }// JsonFileName

        // контролы для вывода из потоков в форму
        public DataGridView DgvExecutive2 { get; set; }

        // конструкторы
        public TaskB() : this(new CollectionRepairLaptop()) { }
        public TaskB(CollectionRepairLaptop collectionRepair)
        {
            _collectionRepair = collectionRepair;
        }


        // обработка по заданию для WF
        public void Process2_WF()
        {
            DeserializeData();

            Shuffle(_collectionRepair);

            SerializeData();

            // вывод в WF в DataGridView
            DgvExecutive2.DataSource = _collectionRepair.RepairLaptops;
        }// Process2_WF

        // обработка по заданию для WPF
        public List<RepairLaptop> Process_WPF()
        {
            DeserializeData();
            Shuffle(_collectionRepair);
            SerializeData();
            return _collectionRepair.RepairLaptops;
        } // Process_WPF



        #region Вспомогательные методы


        // перемешивание массива, метод для потока 3
        public void Shuffle(CollectionRepairLaptop collectionRepair)
        {
            for (int i = collectionRepair.Count - 1; i >= 1; i--)
            {
                int temp = Utils.Random.Next(i + 1);
                (collectionRepair[i], collectionRepair[temp]) = (collectionRepair[temp], collectionRepair[i]);
            } // for i
        } // Shuffle


        // сериализация данных в формате JSON
        public void SerializeData()
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(CollectionRepairLaptop));
            using (FileStream fs = new FileStream(_jsonFileName, FileMode.Create))
            {
                jsonFormatter.WriteObject(fs, _collectionRepair);
            } // using

        }// SerializeData


        // десериализация данных из формата JSON
        public void DeserializeData()
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(CollectionRepairLaptop));
            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(_jsonFileName, FileMode.OpenOrCreate))
            {
                _collectionRepair = (CollectionRepairLaptop)jsonFormatter.ReadObject(fs);
            } // using

        }// DeserializeData

        // вывод коллекции в StringBuilder
        private StringBuilder OutputToStrigBuilder(List<double> data, string title)
        {
            StringBuilder sb = new StringBuilder(title);

            foreach (var d in data)
            {
                sb.Append($"{d,7:f2}");
            }

            sb.AppendLine();
            return sb;
        }// OutputToStrigBuilder


        // вывод списка строк в консоль
        private StringBuilder OutputToStrigBuilder(List<string> list, string title)
        {
            // сформировать вывод в StringBuilder'е
            StringBuilder sb = new StringBuilder(title);
            list.ForEach(item => sb.Append($"{item}\r\n"));

            // вывод
            return sb;
        } // OutputToStrigBuilder

        #endregion

    }// class TaskB
}
