﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TasksH_W10SP.Tasks
{
    // в) обработка текстового файла – подсчет (без учета регистра) частоты слов,
    // результаты выводите в словарь (пары «слово – количество»)
    public class TaskC
    {
        // имя текстового файла для потока 3
        public string TextFileName { get; set; }

        // контролы для вывода из потоков в форму

        // ссылка на форму, в которой размещены элементы управления,
        // в которые будем выводить результаты работы
        private Form _form;
        public Form Form
        {
            get => _form;
            set => _form = value;
        } // Form

        // текст из файла
        public TextBox TbxExecutive3 { get; set; }       
        public DataGridView DgvExecutive3 { get; set; }


        // создание частотного словаря из коллекции строк
        private Dictionary<string, int> CreateDictionary()
        {
            Dictionary<string, int> words = new Dictionary<string, int>();

            var del = " ', -:.,!?\\\n".ToCharArray();

            File.ReadAllText(TextFileName)
                     .ToLower()
                     .Split(del, StringSplitOptions.RemoveEmptyEntries)
                     .ToList()
                     .ForEach(word => {
                         if (!words.ContainsKey(word))
                             words[word] = 0;
                         words[word]++;
                     });

            return words;
        }// CreateDictionary


        // обработка по заданию для Windows Forms
        public void Process3_WF()
        {
            // обработка по заданию
            List<string> strings = File.ReadLines(TextFileName).ToList();
            StringBuilder sb = OutputToStrigBuilder(strings, $"Поток 3: файл \"{Path.GetFileName(TextFileName)}\":\r\n");

            // вывод файла в TextBox
            if (TbxExecutive3.InvokeRequired)
                _form.BeginInvoke((Action)(() => TbxExecutive3.Text = sb.ToString()));
            else
                TbxExecutive3.Text = sb.ToString();

            // пары «слово – количество»
            Dictionary<string, int> words = CreateDictionary();

            // получение списка из словаря
            // Dgv.DataSource = words.ToList();


            DgvExecutive3.Rows.Clear();

            // вывод в DataGridView 
            foreach (var word in words)
            {
                DataGridViewRow row = new DataGridViewRow();

                // Слово
                DataGridViewCell cell = new DataGridViewTextBoxCell();
                cell.Value = word.Key;
                row.Cells.Add(cell);

                // кол-во
                cell = new DataGridViewTextBoxCell();
                cell.Value = $"{word.Value}";
                row.Cells.Add(cell);
                DgvExecutive3.Rows.Add(row);
            } // foreach

        } // Process3_WF


        // обработка по заданию для приложения WPF
        public Dictionary<string, int> Process3_WPF(out string fileText)
        {
            fileText = $"Поток 3: файл \"{Path.GetFileName(TextFileName)}\":\r\n{File.ReadAllText(TextFileName)}";

            // пары «слово – количество»
            return CreateDictionary();
        } // Process3_WPF


        // вывод списка строк в StringBuilder
        private StringBuilder OutputToStrigBuilder(List<string> list, string title)
        {
            // сформировать вывод в StringBuilder'е
            StringBuilder sb = new StringBuilder(title);
            list.ForEach(item => sb.Append($"{item}\r\n"));

            return sb;
        } // OutputToStrigBuilder

    }// class TaskC
}
