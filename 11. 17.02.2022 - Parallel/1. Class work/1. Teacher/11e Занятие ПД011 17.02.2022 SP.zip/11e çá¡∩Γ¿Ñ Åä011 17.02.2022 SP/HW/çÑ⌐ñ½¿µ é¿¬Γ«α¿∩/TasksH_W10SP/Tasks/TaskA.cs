﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Forms;

namespace TasksH_W10SP.Tasks
{
    // а)	создание файла случайных вещественных чисел(не более 20 чисел),
    // создается при первом запуске, при последующих запусках –
    // перемешивание данных в файле.Сортировка файла по убыванию и сохранение файла
    public class TaskA
    {
        // имя бинарного файла для потока 1
        private string _binFileName;
        public string BinFileName
        {
            get => _binFileName;

            // при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
            set
            {
                _binFileName = value;

                if (!File.Exists(_binFileName))
                {
                    var data = Enumerable
                        .Repeat(0, Utils.GetRandom(10, 20))
                        .Select(x => Utils.GetRandom(-10d, 20d))
                        .ToList();

                    WrightToBinary(_binFileName, data);
                }
                // при последующих запусках – перемешивание данных в файле
                else
                {
                    // чтение из файла в коллекцию
                    List<double> data = new List<double>();
                    ReadToBinary(_binFileName, data);

                    // Shuffle(data);
                    data = data
                       .OrderBy(item => Utils.Random.Next())
                       .ToList();
                    WrightToBinary(_binFileName, data);
                }// if
            } // set 
        }// BinFileName

        // ссылка на форму, в которой размещены элементы управления,
        // в которые будем выводить результаты работы
        private Form _form;
        public Form Form
        {
            get => _form;
            set => _form = value;
        } // Form


        // контролы для вывода из потоков в форму
        public TextBox Executive1 { get; set; }


        // обработка по заданию для Windows Forms
        public void Process_WF()
        {
            StringBuilder sb = Process();
            if (Executive1.InvokeRequired)
                _form.BeginInvoke((Action)(() => Executive1.Text = sb.ToString()));
            else
                Executive1.Text = sb.ToString();
        } // Process_WF


        // обработка по заданию для WPF
        public StringBuilder Process_WPF()
        {
            // чтение из файла в коллекцию
            List<double> data = new List<double>();

            ReadToBinary(_binFileName, data);

            StringBuilder sb = OutputToStrigBuilder(data, $"Поток 1: файл \"{Path.GetFileName(_binFileName)}\":\r\n");

            // Сортировка по убыванию в другую коллекцию, для вывод исходных данных
            List<double> temp = data.OrderByDescending(x => x).ToList();

            // сохранение файла
            WrightToBinary(_binFileName, temp);

            sb.AppendLine(OutputToStrigBuilder(temp, $"Поток 1: файл \"{Path.GetFileName(_binFileName)}\" упорядочен по убыванию:\r\n").ToString());

            return sb;
        } // Process_WPF

        #region Вспомогательные методы


        public StringBuilder Process()
        {
            // чтение из файла в коллекцию
            List<double> data = new List<double>();
            ReadToBinary(_binFileName, data);

            StringBuilder sb = OutputToStrigBuilder(data, $"\n\n Поток 1: массив вещественных чисел прочитан из файла \"{_binFileName}\":\r\n");

            // Сортировка по убыванию
            List<double> temp = data.OrderByDescending(a => a).ToList();

            // сохранение файла
            WrightToBinary(_binFileName, temp);

            sb.Append(OutputToStrigBuilder(temp, $"\n\n Поток 1: массив вещественных чисел отсортирован по убыванию \"{_binFileName}\":\r\n"));

            return sb;
        } // Process

        // перемешивание массива, метод для потока 1
        public void Shuffle(List<double> data)
        {
            for (int i = data.Count - 1; i >= 1; i--)
            {
                int temp = Utils.Random.Next(i + 1);
                (data[i], data[temp]) = (data[temp], data[i]);
            } // for i
        } // Shuffle


        // запись в бинарный файл
        public void WrightToBinary(string fileName, List<double> data)
        {
            // запись в файл
            using (BinaryWriter bwr = new BinaryWriter(File.Create(_binFileName)))
                data.ForEach(datum => bwr.Write(datum));
        }// WrightToBinary


        // чтение бинарного файл
        public void ReadToBinary(string fileName, List<double> data)
        {
            using (BinaryReader brd = new BinaryReader(File.OpenRead(fileName)))
            {
                while (brd.BaseStream.Position < brd.BaseStream.Length)
                    data.Add(brd.ReadDouble());

            } // using
        }// ReadToBinary


        // вывод коллекции
        public void ShowArray(List<double> data)
        {
            foreach (var d in data)
            {
                Console.Write($"{d,7:f2}");
            }
        }// ShowArray


        // вывод коллекции в StringBuilder
        private StringBuilder OutputToStrigBuilder(List<double> data, string title)
        {
            StringBuilder sb = new StringBuilder(title);

            foreach (var d in data)
            {
                sb.Append($"{d,7:f2}");
            }
            sb.AppendLine();
            return sb;
        }// OutputToStrigBuilder




        #endregion

    }// class TaskA
}
