﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using TasksH_W10SP.Tasks;
using TasksH_W10SP.Models;


namespace Task1WF
{
    public partial class MainForm : Form
    {
        TaskA _taskA;
        TaskB _taskB;
        TaskC _taskC;
        // в конструкторе создать объект для создания потоков 
        public MainForm()
        {
            InitializeComponent();

            _taskA = new TaskA { BinFileName = "Thread1Data.bin", Form = this, Executive1 = TxbTask1 };
            _taskB = new TaskB { JsonFileName = "Thread2Data.json", DgvExecutive2 = DgvTask2 };
            _taskC = new TaskC { TextFileName = "Thread3Data.txt", DgvExecutive3 = DgvTask3, Form = this, TbxExecutive3 = TxbTask3 };
        }// MainForm

        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        
        private void Task1_Execut(object sender, EventArgs e)
        {
            TxbTask1.Text = "";
            Task task = new Task(_taskA.Process_WF);

            task.Start();
        }// Task1_Execut

        private void Task2_Execut(object sender, EventArgs e)
        {
            DgvTask2.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            Task task = new Task(_taskB.Process2_WF);

            task.Start();
        }// Task2_Execut

        private void Thread3_Execut(object sender, EventArgs e)
        {
            DgvTask3.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            TxbTask3.Text = "";
            Task task = new Task(_taskC.Process3_WF);

            task.Start();
        }// Thread3_Execut

        // запуск всех потков параллельно
        private void TaskAll_Execut(object sender, EventArgs e)
        {
            TxbTask1.Text = TxbTask3.Text = "";

            List<Task> tasks = new List<Task>(new[] {
                new Task(_taskA.Process_WF),
                new Task(_taskB.Process2_WF),
                new Task(_taskC.Process3_WF),
            });

            // запуск потоков на парaллельное исполнение
            tasks.ForEach(t => t.Start());
        }// TaskAll_Execut

    }// class MainForm
}
