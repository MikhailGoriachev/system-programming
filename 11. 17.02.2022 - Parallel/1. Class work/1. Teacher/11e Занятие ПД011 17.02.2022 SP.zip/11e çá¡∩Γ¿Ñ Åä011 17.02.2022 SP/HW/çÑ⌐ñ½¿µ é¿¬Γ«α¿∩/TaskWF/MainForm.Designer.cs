﻿
namespace Task1WF
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MniMain = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniThread1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MniThread1Exec = new System.Windows.Forms.ToolStripMenuItem();
            this.MniThread2Exec = new System.Windows.Forms.ToolStripMenuItem();
            this.MniThread3Exec = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniThreadAllExec = new System.Windows.Forms.ToolStripMenuItem();
            this.TxbTask1 = new System.Windows.Forms.TextBox();
            this.DgvTask3 = new System.Windows.Forms.DataGridView();
            this.TxbTask3 = new System.Windows.Forms.TextBox();
            this.DgvTask2 = new System.Windows.Forms.DataGridView();
            this.ClnWord = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClnCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameLaptopDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.processorTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountOfRAMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.storageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diagonalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.defectDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fullNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.repairLaptopBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.MniMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTask3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTask2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repairLaptopBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // MniMain
            // 
            this.MniMain.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MniMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.MniThread1});
            this.MniMain.Location = new System.Drawing.Point(0, 0);
            this.MniMain.Name = "MniMain";
            this.MniMain.Size = new System.Drawing.Size(1028, 24);
            this.MniMain.TabIndex = 0;
            this.MniMain.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniExit});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // MniExit
            // 
            this.MniExit.Name = "MniExit";
            this.MniExit.Size = new System.Drawing.Size(126, 22);
            this.MniExit.Text = "Выход";
            this.MniExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniThread1
            // 
            this.MniThread1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniThread1Exec,
            this.MniThread2Exec,
            this.MniThread3Exec,
            this.toolStripMenuItem1,
            this.MniThreadAllExec});
            this.MniThread1.Name = "MniThread1";
            this.MniThread1.Size = new System.Drawing.Size(80, 20);
            this.MniThread1.Text = "Потоки";
            // 
            // MniThread1Exec
            // 
            this.MniThread1Exec.Name = "MniThread1Exec";
            this.MniThread1Exec.Size = new System.Drawing.Size(266, 22);
            this.MniThread1Exec.Text = "Запуск потока 1";
            this.MniThread1Exec.Click += new System.EventHandler(this.Task1_Execut);
            // 
            // MniThread2Exec
            // 
            this.MniThread2Exec.Name = "MniThread2Exec";
            this.MniThread2Exec.Size = new System.Drawing.Size(266, 22);
            this.MniThread2Exec.Text = "Запуск потока 2";
            this.MniThread2Exec.Click += new System.EventHandler(this.Task2_Execut);
            // 
            // MniThread3Exec
            // 
            this.MniThread3Exec.Name = "MniThread3Exec";
            this.MniThread3Exec.Size = new System.Drawing.Size(266, 22);
            this.MniThread3Exec.Text = "Запуск потока 3";
            this.MniThread3Exec.Click += new System.EventHandler(this.Thread3_Execut);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(263, 6);
            // 
            // MniThreadAllExec
            // 
            this.MniThreadAllExec.Name = "MniThreadAllExec";
            this.MniThreadAllExec.Size = new System.Drawing.Size(266, 22);
            this.MniThreadAllExec.Text = "Запуск всех потоков";
            this.MniThreadAllExec.Click += new System.EventHandler(this.TaskAll_Execut);
            // 
            // TxbTask1
            // 
            this.TxbTask1.BackColor = System.Drawing.SystemColors.Window;
            this.TxbTask1.Location = new System.Drawing.Point(0, 27);
            this.TxbTask1.Multiline = true;
            this.TxbTask1.Name = "TxbTask1";
            this.TxbTask1.ReadOnly = true;
            this.TxbTask1.Size = new System.Drawing.Size(1020, 100);
            this.TxbTask1.TabIndex = 1;
            // 
            // DgvTask3
            // 
            this.DgvTask3.AllowDrop = true;
            this.DgvTask3.AllowUserToAddRows = false;
            this.DgvTask3.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvTask3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvTask3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClnWord,
            this.ClnCount});
            this.DgvTask3.Location = new System.Drawing.Point(485, 368);
            this.DgvTask3.MultiSelect = false;
            this.DgvTask3.Name = "DgvTask3";
            this.DgvTask3.ReadOnly = true;
            this.DgvTask3.RowHeadersVisible = false;
            this.DgvTask3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvTask3.Size = new System.Drawing.Size(535, 181);
            this.DgvTask3.TabIndex = 3;
            // 
            // TxbTask3
            // 
            this.TxbTask3.BackColor = System.Drawing.SystemColors.Window;
            this.TxbTask3.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbTask3.Location = new System.Drawing.Point(0, 368);
            this.TxbTask3.Multiline = true;
            this.TxbTask3.Name = "TxbTask3";
            this.TxbTask3.ReadOnly = true;
            this.TxbTask3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxbTask3.Size = new System.Drawing.Size(479, 181);
            this.TxbTask3.TabIndex = 4;
            // 
            // DgvTask2
            // 
            this.DgvTask2.AllowDrop = true;
            this.DgvTask2.AutoGenerateColumns = false;
            this.DgvTask2.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvTask2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvTask2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameLaptopDataGridViewTextBoxColumn,
            this.modelDataGridViewTextBoxColumn,
            this.processorTypeDataGridViewTextBoxColumn,
            this.amountOfRAMDataGridViewTextBoxColumn,
            this.storageDataGridViewTextBoxColumn,
            this.diagonalDataGridViewTextBoxColumn,
            this.defectDataGridViewTextBoxColumn,
            this.fullNameDataGridViewTextBoxColumn});
            this.DgvTask2.DataSource = this.repairLaptopBindingSource;
            this.DgvTask2.Location = new System.Drawing.Point(0, 133);
            this.DgvTask2.Name = "DgvTask2";
            this.DgvTask2.ReadOnly = true;
            this.DgvTask2.RowHeadersVisible = false;
            this.DgvTask2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvTask2.ShowCellToolTips = false;
            this.DgvTask2.Size = new System.Drawing.Size(1020, 229);
            this.DgvTask2.TabIndex = 5;
            this.DgvTask2.TabStop = false;
            // 
            // ClnWord
            // 
            this.ClnWord.HeaderText = "Слово";
            this.ClnWord.Name = "ClnWord";
            this.ClnWord.ReadOnly = true;
            this.ClnWord.Width = 270;
            // 
            // ClnCount
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 0);
            this.ClnCount.DefaultCellStyle = dataGridViewCellStyle1;
            this.ClnCount.HeaderText = "Количество";
            this.ClnCount.Name = "ClnCount";
            this.ClnCount.ReadOnly = true;
            this.ClnCount.Width = 260;
            // 
            // nameLaptopDataGridViewTextBoxColumn
            // 
            this.nameLaptopDataGridViewTextBoxColumn.DataPropertyName = "NameLaptop";
            this.nameLaptopDataGridViewTextBoxColumn.FillWeight = 200F;
            this.nameLaptopDataGridViewTextBoxColumn.HeaderText = "Наименование";
            this.nameLaptopDataGridViewTextBoxColumn.Name = "nameLaptopDataGridViewTextBoxColumn";
            this.nameLaptopDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameLaptopDataGridViewTextBoxColumn.Width = 130;
            // 
            // modelDataGridViewTextBoxColumn
            // 
            this.modelDataGridViewTextBoxColumn.DataPropertyName = "Model";
            this.modelDataGridViewTextBoxColumn.FillWeight = 150F;
            this.modelDataGridViewTextBoxColumn.HeaderText = "Модель";
            this.modelDataGridViewTextBoxColumn.Name = "modelDataGridViewTextBoxColumn";
            this.modelDataGridViewTextBoxColumn.ReadOnly = true;
            this.modelDataGridViewTextBoxColumn.Width = 130;
            // 
            // processorTypeDataGridViewTextBoxColumn
            // 
            this.processorTypeDataGridViewTextBoxColumn.DataPropertyName = "ProcessorType";
            this.processorTypeDataGridViewTextBoxColumn.HeaderText = "Процессор";
            this.processorTypeDataGridViewTextBoxColumn.Name = "processorTypeDataGridViewTextBoxColumn";
            this.processorTypeDataGridViewTextBoxColumn.ReadOnly = true;
            this.processorTypeDataGridViewTextBoxColumn.Width = 130;
            // 
            // amountOfRAMDataGridViewTextBoxColumn
            // 
            this.amountOfRAMDataGridViewTextBoxColumn.DataPropertyName = "AmountOfRAM";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(0, 0, 20, 0);
            this.amountOfRAMDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.amountOfRAMDataGridViewTextBoxColumn.HeaderText = "RAM(ГБ)";
            this.amountOfRAMDataGridViewTextBoxColumn.Name = "amountOfRAMDataGridViewTextBoxColumn";
            this.amountOfRAMDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // storageDataGridViewTextBoxColumn
            // 
            this.storageDataGridViewTextBoxColumn.DataPropertyName = "Storage";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle3.Padding = new System.Windows.Forms.Padding(0, 0, 20, 0);
            this.storageDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.storageDataGridViewTextBoxColumn.HeaderText = "SSD(ГБ)";
            this.storageDataGridViewTextBoxColumn.Name = "storageDataGridViewTextBoxColumn";
            this.storageDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // diagonalDataGridViewTextBoxColumn
            // 
            this.diagonalDataGridViewTextBoxColumn.DataPropertyName = "Diagonal";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle4.Padding = new System.Windows.Forms.Padding(0, 0, 20, 0);
            this.diagonalDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.diagonalDataGridViewTextBoxColumn.HeaderText = "Диагональ";
            this.diagonalDataGridViewTextBoxColumn.Name = "diagonalDataGridViewTextBoxColumn";
            this.diagonalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // defectDataGridViewTextBoxColumn
            // 
            this.defectDataGridViewTextBoxColumn.DataPropertyName = "Defect";
            this.defectDataGridViewTextBoxColumn.FillWeight = 200F;
            this.defectDataGridViewTextBoxColumn.HeaderText = "Дефект";
            this.defectDataGridViewTextBoxColumn.Name = "defectDataGridViewTextBoxColumn";
            this.defectDataGridViewTextBoxColumn.ReadOnly = true;
            this.defectDataGridViewTextBoxColumn.Width = 180;
            // 
            // fullNameDataGridViewTextBoxColumn
            // 
            this.fullNameDataGridViewTextBoxColumn.DataPropertyName = "FullName";
            this.fullNameDataGridViewTextBoxColumn.FillWeight = 150F;
            this.fullNameDataGridViewTextBoxColumn.HeaderText = "ФИО владельца";
            this.fullNameDataGridViewTextBoxColumn.Name = "fullNameDataGridViewTextBoxColumn";
            this.fullNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.fullNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // repairLaptopBindingSource
            // 
            this.repairLaptopBindingSource.DataSource = typeof(TasksH_W10SP.Models.RepairLaptop);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ClientSize = new System.Drawing.Size(1028, 554);
            this.Controls.Add(this.DgvTask2);
            this.Controls.Add(this.TxbTask3);
            this.Controls.Add(this.DgvTask3);
            this.Controls.Add(this.TxbTask1);
            this.Controls.Add(this.MniMain);
            this.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MniMain;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание №10";
            this.MniMain.ResumeLayout(false);
            this.MniMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTask3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTask2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repairLaptopBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MniMain;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniExit;
        private System.Windows.Forms.ToolStripMenuItem MniThread1;
        private System.Windows.Forms.ToolStripMenuItem MniThread1Exec;
        private System.Windows.Forms.ToolStripMenuItem MniThread2Exec;
        private System.Windows.Forms.ToolStripMenuItem MniThread3Exec;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MniThreadAllExec;
        private System.Windows.Forms.TextBox TxbTask1;
        private System.Windows.Forms.DataGridView DgvTask3;
        private System.Windows.Forms.TextBox TxbTask3;
        private System.Windows.Forms.DataGridView DgvTask2;
        private System.Windows.Forms.BindingSource repairLaptopBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameLaptopDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn processorTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountOfRAMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn storageDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diagonalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn defectDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fullNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClnWord;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClnCount;
    }
}

