﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using TasksH_W10SP.Models;
using TasksH_W10SP.Tasks;

namespace TaskWPF
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        TaskA _taskA;
        TaskB _taskB;
        TaskC _taskC;
        public MainWindow()
        {
            InitializeComponent();

            _taskA = new TaskA { BinFileName = "Task1Data.bin" };
            _taskB = new TaskB { JsonFileName = "Task2Data.json" };
            _taskC = new TaskC { TextFileName = "Task3Data.txt" };

        }

        // Завершение приложения - команда меню
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        } // Exit_Click


        // Запуск первого потока
        private void Task1_Execut(object sender, RoutedEventArgs e)
        {
            TxbTask1.Text = "";
            Task task = new Task(() => OutputToTextBox(TxbTask1, _taskA.Process_WPF().ToString()));

            task.Start();
        }// Task1_Execut


        // Запуск второго потока
        private void Task2_Execut(object sender, RoutedEventArgs e)
        {
            Task task = new Task(() => {
                // вывод отсортированной коллекции
                OutputToDataGrid(DgTask2, _taskB.Process_WPF().ToArray());
            });
            task.Start();
        } // Task2_Execut


        // Запуск третьего потока
        private void Task3_Execut(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                Multiselect = false,
                Title = "Файл данных для загрузки",
                Filter = "Файлы TXT (*.txt)|*.txt",
                InitialDirectory = AppDomain.CurrentDomain.BaseDirectory
            };

            if (ofd.ShowDialog() != true) return;
            _taskC.TextFileName = ofd.FileName;
            Task task = new Task(() => {
                var words = _taskC.Process3_WPF(out string fileText); // пары «слово – количество»

                // вывод текста файла в TbxTask3
                OutputToTextBox(TbxTask3, fileText);
                // вывод пар «слово – количество» в DgTask3
                OutputToDataGrid(DgTask3, words);
            });
            task.Start();
        } // Task3_Execut


        // Запуск всех потоков
        private void TaskAll_Execut(object sender, RoutedEventArgs e)
        {
            TxbTask1.Text = TbxTask3.Text = "";
            // при задании имени файла - перемешивание 
            _taskA.BinFileName = _taskA.BinFileName;
            _taskB.JsonFileName = _taskB.JsonFileName;

            // создание и запуск задач для потока
            List<Task> tasks = new List<Task>(new[] {
                new Task(() => OutputToTextBox(TxbTask1, _taskA.Process_WPF().ToString())),
                new Task(() => {
                              // вывод отсортированной коллекции
                              OutputToDataGrid(DgTask2, _taskB.Process_WPF().ToArray());
                               }),
                new Task(() => {
                               var words = _taskC.Process3_WPF(out string fileText); // пары «слово – количество»

                               // вывод текста файла в TbxTask3
                               OutputToTextBox(TbxTask3, fileText);
                               // вывод пар «слово – количество» в DgTask3
                               OutputToDataGrid(DgTask3, words);
                               }),
            });
            
            // запуск потоков на парaллельное исполнение
            tasks.ForEach(t => t.Start());
        }// TaskAll_Execut


        // вывод текста в TextBox
        private void OutputToTextBox(TextBox textBox, string text)
        {
            Dispatcher.BeginInvoke(
                DispatcherPriority.Normal,
                (Action)(() => textBox.Text = text));
        } // OutputToTextBox

        // вывод коллекции в DataGrid
        private void OutputToDataGrid(DataGrid dataGrid, System.Collections.IEnumerable collection)
        {
            Dispatcher.BeginInvoke(
                DispatcherPriority.Normal,
                (Action)(() => dataGrid.ItemsSource = collection));
        }// OutputToDataGrid

    }// class MainWindow
}
