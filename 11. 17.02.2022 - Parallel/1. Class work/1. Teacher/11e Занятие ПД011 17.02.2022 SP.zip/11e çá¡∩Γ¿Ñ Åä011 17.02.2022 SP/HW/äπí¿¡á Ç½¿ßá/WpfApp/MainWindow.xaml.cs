﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Threads;

namespace WpfApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {
        Task01 _task01;
        Task02 _task02;
        Task03 _task03;
        public MainWindow() {
            InitializeComponent();
            _task01 = new Task01 { FileName = "Thread1Data.bin"};
            _task02 = new Task02 { FileName = "laptops.json"};
            _task03 = new Task03 { FileName = "Thread3Data.txt"};
        }

        private void Exit_Command(object sender, RoutedEventArgs e) => Close();


        // Запуск первой задачи
        private void ExecTask1_Command(object sender, RoutedEventArgs e) {

            // при задании имени файла - перемешивание 
            _task01.FileName = _task01.FileName;

            OpenFileDialog ofd = new OpenFileDialog {
                Multiselect = false,
                Title = "Файл данных для загрузки",
                Filter = "Файлы BIN (*.bin)|*.bin",
                FilterIndex = 0,
                InitialDirectory = AppDomain.CurrentDomain.BaseDirectory
            };

            if (ofd.ShowDialog() != true) return;
            _task01.FileName = ofd.FileName;

            Task.Factory.StartNew(() => OutputToTextBox(TbxTask1, _task01.Process().ToString()));
        } // ExecTask1_Command


        // Запуск второй задачи
        private void ExecTask2_Command(object sender, RoutedEventArgs e) {
            OpenFileDialog ofd = new OpenFileDialog {
                Multiselect = false,
                Title = "Файл данных для загрузки",
                Filter = "Файлы JSON (*.json)|*.json",
                FilterIndex = 0,
                InitialDirectory = AppDomain.CurrentDomain.BaseDirectory
            };

            if (ofd.ShowDialog() != true) return;
            _task02.FileName = ofd.FileName;

            Task.Factory.StartNew(() => OutputToDataGrid(DgTask2, _task02.Process()));
        } // ExecTask2_Command


        // Запуск третьей задачи
        private void ExecTask3_Command(object sender, RoutedEventArgs e) {
            OpenFileDialog ofd = new OpenFileDialog {
                Multiselect = false,
                Title = "Файл данных для загрузки",
                Filter = "Файлы TXT (*.txt)|*.txt",
                FilterIndex = 0,
                InitialDirectory = AppDomain.CurrentDomain.BaseDirectory
            };

            if (ofd.ShowDialog() != true) return;
            _task03.FileName = ofd.FileName;

            Task.Factory.StartNew(() => {
                var words = _task03.Process(out string fileText); // пары «слово – количество»
                // вывод текста файла в TbxThread3
                OutputToTextBox(TbxTask3, fileText);
                // вывод пар «слово – количество» в DgThread3
                OutputToDataGrid(DgTask3, words);
            });
        } // ExecTask3_Command


        // Запуск всех задач
        private void ExecAllThreads_Command(object sender, RoutedEventArgs e) {
            // при задании имени файла - перемешивание 
            _task01.FileName = _task01.FileName;
            // задача 1
            Task.Factory.StartNew(() => OutputToTextBox(TbxTask1, _task01.Process().ToString()));
            // задача 2
            Task.Factory.StartNew(() => OutputToDataGrid(DgTask2, _task02.Process()));
            // задача 3
            Task.Factory.StartNew(() => {
                var words = _task03.Process(out string fileText); // пары «слово – количество»
                // вывод текста файла в TbxThread3
                OutputToTextBox(TbxTask3, fileText);
                // вывод пар «слово – количество» в DgThread3
                OutputToDataGrid(DgTask3, words);
            });
        } // ExecAllThreads_Command


        // вывод текста в TextBox
        private void OutputToTextBox(TextBox textBox, string text) {
            Dispatcher.BeginInvoke(
                DispatcherPriority.Normal,
                (ThreadStart)(() => textBox.Text = text));
        } // OutputToTextBox

        // вывод коллекции в DataGrid
        private void OutputToDataGrid(DataGrid dataGrid, System.Collections.IEnumerable collection) {
            Dispatcher.BeginInvoke(
                DispatcherPriority.Normal,
                (ThreadStart)(() => dataGrid.ItemsSource = collection));
        } // OutputToDataGridVIew
    }
}
