﻿namespace WindowsFormsApp
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.потокиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запускПотока1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запускПотока2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запускПотока3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.запускВсехПотоковToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TbxTask1 = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.DgvTask3 = new System.Windows.Forms.DataGridView();
            this.TbxTask3 = new System.Windows.Forms.TextBox();
            this.DgvTask2 = new System.Windows.Forms.DataGridView();
            this.modelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPUManufacturerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diagonalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.capacityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rAMSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ownerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.laptopBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTask3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTask2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.laptopBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.потокиToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1306, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // потокиToolStripMenuItem
            // 
            this.потокиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.запускПотока1ToolStripMenuItem,
            this.запускПотока2ToolStripMenuItem,
            this.запускПотока3ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.запускВсехПотоковToolStripMenuItem});
            this.потокиToolStripMenuItem.Name = "потокиToolStripMenuItem";
            this.потокиToolStripMenuItem.Size = new System.Drawing.Size(74, 24);
            this.потокиToolStripMenuItem.Text = "Потоки";
            // 
            // запускПотока1ToolStripMenuItem
            // 
            this.запускПотока1ToolStripMenuItem.Name = "запускПотока1ToolStripMenuItem";
            this.запускПотока1ToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.запускПотока1ToolStripMenuItem.Text = "Запуск потока 1";
            this.запускПотока1ToolStripMenuItem.Click += new System.EventHandler(this.Task1_Command);
            // 
            // запускПотока2ToolStripMenuItem
            // 
            this.запускПотока2ToolStripMenuItem.Name = "запускПотока2ToolStripMenuItem";
            this.запускПотока2ToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.запускПотока2ToolStripMenuItem.Text = "Запуск потока 2";
            this.запускПотока2ToolStripMenuItem.Click += new System.EventHandler(this.Task2_Command);
            // 
            // запускПотока3ToolStripMenuItem
            // 
            this.запускПотока3ToolStripMenuItem.Name = "запускПотока3ToolStripMenuItem";
            this.запускПотока3ToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.запускПотока3ToolStripMenuItem.Text = "Запуск потока 3";
            this.запускПотока3ToolStripMenuItem.Click += new System.EventHandler(this.Task3_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(230, 6);
            // 
            // запускВсехПотоковToolStripMenuItem
            // 
            this.запускВсехПотоковToolStripMenuItem.Name = "запускВсехПотоковToolStripMenuItem";
            this.запускВсехПотоковToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.запускВсехПотоковToolStripMenuItem.Text = "Запуск всех потоков";
            this.запускВсехПотоковToolStripMenuItem.Click += new System.EventHandler(this.TaskAll_Command);
            // 
            // TbxTask1
            // 
            this.TbxTask1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TbxTask1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxTask1.Location = new System.Drawing.Point(0, 27);
            this.TbxTask1.Multiline = true;
            this.TbxTask1.Name = "TbxTask1";
            this.TbxTask1.ReadOnly = true;
            this.TbxTask1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TbxTask1.ShortcutsEnabled = false;
            this.TbxTask1.Size = new System.Drawing.Size(396, 399);
            this.TbxTask1.TabIndex = 1;
            this.TbxTask1.TabStop = false;
            this.TbxTask1.WordWrap = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 432);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1306, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 16);
            // 
            // DgvTask3
            // 
            this.DgvTask3.AllowUserToAddRows = false;
            this.DgvTask3.AllowUserToDeleteRows = false;
            this.DgvTask3.AllowUserToResizeRows = false;
            this.DgvTask3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvTask3.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DgvTask3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvTask3.ColumnHeadersHeight = 29;
            this.DgvTask3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DgvTask3.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DgvTask3.Location = new System.Drawing.Point(902, 209);
            this.DgvTask3.MultiSelect = false;
            this.DgvTask3.Name = "DgvTask3";
            this.DgvTask3.ReadOnly = true;
            this.DgvTask3.RowHeadersVisible = false;
            this.DgvTask3.RowHeadersWidth = 51;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.DgvTask3.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DgvTask3.RowTemplate.Height = 24;
            this.DgvTask3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvTask3.ShowCellToolTips = false;
            this.DgvTask3.Size = new System.Drawing.Size(396, 217);
            this.DgvTask3.TabIndex = 4;
            this.DgvTask3.TabStop = false;
            // 
            // TbxTask3
            // 
            this.TbxTask3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TbxTask3.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxTask3.Location = new System.Drawing.Point(902, 28);
            this.TbxTask3.Multiline = true;
            this.TbxTask3.Name = "TbxTask3";
            this.TbxTask3.ReadOnly = true;
            this.TbxTask3.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TbxTask3.ShortcutsEnabled = false;
            this.TbxTask3.Size = new System.Drawing.Size(396, 175);
            this.TbxTask3.TabIndex = 5;
            this.TbxTask3.TabStop = false;
            // 
            // DgvTask2
            // 
            this.DgvTask2.AllowUserToAddRows = false;
            this.DgvTask2.AllowUserToDeleteRows = false;
            this.DgvTask2.AllowUserToResizeRows = false;
            this.DgvTask2.AutoGenerateColumns = false;
            this.DgvTask2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DgvTask2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvTask2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvTask2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.modelDataGridViewTextBoxColumn,
            this.cPUManufacturerDataGridViewTextBoxColumn,
            this.diagonalDataGridViewTextBoxColumn,
            this.capacityDataGridViewTextBoxColumn,
            this.rAMSizeDataGridViewTextBoxColumn,
            this.ownerDataGridViewTextBoxColumn});
            this.DgvTask2.DataSource = this.laptopBindingSource;
            this.DgvTask2.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DgvTask2.Location = new System.Drawing.Point(398, 27);
            this.DgvTask2.MultiSelect = false;
            this.DgvTask2.Name = "DgvTask2";
            this.DgvTask2.ReadOnly = true;
            this.DgvTask2.RowHeadersVisible = false;
            this.DgvTask2.RowHeadersWidth = 51;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.DgvTask2.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.DgvTask2.RowTemplate.Height = 24;
            this.DgvTask2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvTask2.ShowCellToolTips = false;
            this.DgvTask2.Size = new System.Drawing.Size(498, 399);
            this.DgvTask2.TabIndex = 6;
            this.DgvTask2.TabStop = false;
            // 
            // modelDataGridViewTextBoxColumn
            // 
            this.modelDataGridViewTextBoxColumn.DataPropertyName = "Model";
            this.modelDataGridViewTextBoxColumn.HeaderText = "Модель";
            this.modelDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.modelDataGridViewTextBoxColumn.Name = "modelDataGridViewTextBoxColumn";
            this.modelDataGridViewTextBoxColumn.ReadOnly = true;
            this.modelDataGridViewTextBoxColumn.Width = 66;
            // 
            // cPUManufacturerDataGridViewTextBoxColumn
            // 
            this.cPUManufacturerDataGridViewTextBoxColumn.DataPropertyName = "CPUManufacturer";
            this.cPUManufacturerDataGridViewTextBoxColumn.HeaderText = "Тип процессора";
            this.cPUManufacturerDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cPUManufacturerDataGridViewTextBoxColumn.Name = "cPUManufacturerDataGridViewTextBoxColumn";
            this.cPUManufacturerDataGridViewTextBoxColumn.ReadOnly = true;
            this.cPUManufacturerDataGridViewTextBoxColumn.Width = 95;
            // 
            // diagonalDataGridViewTextBoxColumn
            // 
            this.diagonalDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.diagonalDataGridViewTextBoxColumn.DataPropertyName = "Diagonal";
            this.diagonalDataGridViewTextBoxColumn.HeaderText = "Диагональ";
            this.diagonalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.diagonalDataGridViewTextBoxColumn.Name = "diagonalDataGridViewTextBoxColumn";
            this.diagonalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // capacityDataGridViewTextBoxColumn
            // 
            this.capacityDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.capacityDataGridViewTextBoxColumn.DataPropertyName = "Capacity";
            this.capacityDataGridViewTextBoxColumn.HeaderText = "Емкость накопителя";
            this.capacityDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.capacityDataGridViewTextBoxColumn.Name = "capacityDataGridViewTextBoxColumn";
            this.capacityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rAMSizeDataGridViewTextBoxColumn
            // 
            this.rAMSizeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.rAMSizeDataGridViewTextBoxColumn.DataPropertyName = "RAMSize";
            this.rAMSizeDataGridViewTextBoxColumn.HeaderText = "Объем оперативной памяти";
            this.rAMSizeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.rAMSizeDataGridViewTextBoxColumn.Name = "rAMSizeDataGridViewTextBoxColumn";
            this.rAMSizeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ownerDataGridViewTextBoxColumn
            // 
            this.ownerDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ownerDataGridViewTextBoxColumn.DataPropertyName = "Owner";
            this.ownerDataGridViewTextBoxColumn.HeaderText = "Владелец";
            this.ownerDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ownerDataGridViewTextBoxColumn.Name = "ownerDataGridViewTextBoxColumn";
            this.ownerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // laptopBindingSource
            // 
            this.laptopBindingSource.DataSource = typeof(Threads.Repair);
            // 
            // OfdMain
            // 
            this.OfdMain.FileName = "openFileDialog1";
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1306, 454);
            this.Controls.Add(this.DgvTask2);
            this.Controls.Add(this.TbxTask3);
            this.Controls.Add(this.DgvTask3);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.TbxTask1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 16.02.2022";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTask3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTask2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.laptopBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TextBox TbxTask1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem потокиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запускПотока1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запускПотока2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запускПотока3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem запускВсехПотоковToolStripMenuItem;
        private System.Windows.Forms.TextBox TbxTask3;
        private System.Windows.Forms.DataGridView DgvTask3;
        private System.Windows.Forms.DataGridView DgvTask2;
        private System.Windows.Forms.BindingSource laptopBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPUManufacturerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diagonalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn capacityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rAMSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ownerDataGridViewTextBoxColumn;
        private System.Windows.Forms.OpenFileDialog OfdMain;
    }
}

