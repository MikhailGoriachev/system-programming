﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Threads;

namespace WindowsFormsApp
{
    public partial class MainForm : Form {
        Task01 _task01;
        Task02 _task02;
        Task03 _task03;
        public MainForm() {
            InitializeComponent();
            _task01 = new Task01 { FileName = "Thread1Data.bin"};
            _task02 = new Task02 { FileName = "laptops.json"};
            _task03 = new Task03 { FileName = "Thread3Data.txt"};
        }

        // выход
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        // Запуск первой задачи
        private void Task1_Command(object sender, EventArgs e) {
            OfdMain.Title = "Открыть файл";
            OfdMain.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            OfdMain.Filter = "Файлы BIN (*.bin)|*.bin";
            OfdMain.FilterIndex = 1;

            if (OfdMain.ShowDialog() != DialogResult.OK) return;
            _task01.FileName = OfdMain.FileName;

            Task.Factory.StartNew(() => OutputToTextBox(TbxTask1, _task01.Process().ToString()));
        } // Task1_Command

        // Запуск второй задачи
        private void Task2_Command(object sender, EventArgs e) {
            OfdMain.Title = "Открыть файл";
            OfdMain.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            OfdMain.Filter = "Файлы JSON (*.json)|*.json";
            OfdMain.FilterIndex = 1;
            if (OfdMain.ShowDialog() != DialogResult.OK) return;
            _task02.FileName = OfdMain.FileName;

            Task.Factory.StartNew(() => OutputToDataGridView(DgvTask2, _task02.Process()));
        } // Task2_Command

        // Запуск третьей задачи
        private void Task3_Command(object sender, EventArgs e) {
            OfdMain.Title = "Открыть файл";
            OfdMain.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            OfdMain.Filter = "Файлы TXT (*.txt)|*.txt";
            OfdMain.FilterIndex = 1;
            if (OfdMain.ShowDialog() != DialogResult.OK) return;
            _task03.FileName = OfdMain.FileName;

            Task.Factory.StartNew(() => {
                var words = _task03.Process(out string fileText); // пары «слово – количество»
                // вывод текста файла в TbxTask3
                OutputToTextBox(TbxTask3, fileText);
                // вывод пар «слово – количество» в DgvTask3
                OutputToDataGridView(DgvTask3, words);
            });
        } // Task3_Command

        // Запуск всех задач
        private void TaskAll_Command(object sender, EventArgs e) {
            // при задании имени файла - перемешивание 
            _task01.FileName = _task01.FileName;
            // задача 1
            Task.Factory.StartNew(() => OutputToTextBox(TbxTask1, _task01.Process().ToString()));
            // задача 2
            Task.Factory.StartNew(() => OutputToDataGridView(DgvTask2, _task02.Process()));
            // задача 3
            Task.Factory.StartNew(() => {
                var words = _task03.Process(out string fileText); // пары «слово – количество»
                // вывод текста файла в TbxTask3
                OutputToTextBox(TbxTask3, fileText);
                // вывод пар «слово – количество» в DgvTask3
                OutputToDataGridView(DgvTask3, words.ToArray());
            });
        } // TaskAll_Command

        // вывод текста в TextBox
        private void OutputToTextBox(TextBox textBox, string text) {
            if (textBox.InvokeRequired)
                BeginInvoke((Action)(() => textBox.Text = text));
            else textBox.Text = text;
        } // OutputToTextBox

        // вывод коллекции в DataGridView
        private void OutputToDataGridView(DataGridView dataGridView, System.Collections.IEnumerable collection) {
            if (dataGridView.InvokeRequired)
                BeginInvoke((Action)(() => dataGridView.DataSource = collection));
            else dataGridView.DataSource = collection;
        } // OutputToDataGridView
    }
}
