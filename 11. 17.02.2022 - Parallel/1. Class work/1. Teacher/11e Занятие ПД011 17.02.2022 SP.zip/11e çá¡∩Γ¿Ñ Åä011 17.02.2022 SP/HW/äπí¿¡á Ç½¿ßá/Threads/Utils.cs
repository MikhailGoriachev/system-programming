﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Threads
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils {

        // объект для получения случайных чисел
        public static readonly Random Random = new Random(Environment.TickCount);

        // Получение случайного числа
        // краткая форма записи метода - это не лямбда выражение
        public static int GetRandom(int lo, int hi) => Random.Next(lo, hi + 1);

        public static double GetRandom(double lo, double hi) {
            double t = lo + (hi - lo) * Random.NextDouble();
            return Math.Abs(t) < 1.9 ? 0 : t;
        }

        // формирование случайных целых чисел в заданном диапазоне (lo, hi),
        // исключая указанное параметром exclude число
        public static int GetRandomExclude(int lo, int hi, int exclude) {
            int number = 0;
            do
                number = Random.Next(lo, hi);
            while (number == exclude);

            return number;
        } // GetRandomExclude

        // перемешивание элементов коллекции
        public static void Shuffle<T>(List<T> list) {
            int n = list.Count;
            while (n > 1) {
                n--;
                int k = Random.Next(n + 1);
                (list[k], list[n]) = (list[n], list[k]);
            } // while
        } // Shuffle

        // бренды и модели ноутбуков
        public static string[] Brands = new[] {
             "Samsung", "ASUS", "HP", "Acer", "Lenovo",
             "MSI"
        };

        public static string GetBrand()
        {
            int i = GetRandom(0, Utils.Brands.Length - 1);
            return Brands[i];
        }

        // номенклатура диагоналей экранов 
        public static double[] Diagonals = new[] {
            11.6, 12.5, 13.3, 14, 15, 15.6, 17, 19
        };

        // объемы оперативной памяти 
        public static int[] RAM = new[] { 4, 8, 16, 32 };

        // емкость накопителя
        public static int[] Capacity = new[] { 128, 256, 512, 1024 };

        // типы процессоров
        public static string[] CPUManufacturers = new[] { "Intel", "AMD", "Qualcomm" };


        // фамилии и инициалы для формирования персональных данных
        public static string[] FullNames = new[] {
            "Петрова Д.А.", "Цыбенко Р.А.", "Юдина Н.А.", "Фортранова Б.В.", "Шавыркина П.А.",
            "Фаронова Р.В.", "Щупак Д.Ю.", "Златопольский Д.М.", "Абрамян М.Э.", "Васильев А.Н.",
            "Федорова В.О.", "Мурадов И.с.", "Штурлак А.В.", "Гамджашвили Ю.И.", "Баранова Е.В.",
            "Маслова Е.В", "Федорин М.Н."
        };

        // описания дефекта и стоимость ремонта дефекта 
        public static string[] DefectDescriptions = new [] {
            "нет звука", "искажения цвета", "полосы на изображении",
            "зависает", "шумит при зарядке", "не включается"
        };
    } // class Utils
}