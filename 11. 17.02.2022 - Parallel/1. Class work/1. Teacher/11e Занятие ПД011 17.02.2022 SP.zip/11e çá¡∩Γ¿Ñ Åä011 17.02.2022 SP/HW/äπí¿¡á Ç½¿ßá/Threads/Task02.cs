﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace Threads
{
    /* Обработка 2.
     * Cоздание коллекции заявок на ремонт ноутбуков, сериализация этой коллекции
     * при первом запуске; десериализация, перемешивание и сериализация при
     * последующих запусках. Формат файла данных – JSON
     * Обработка коллекции – сортировка по убыванию стоимости ремонта. 
     * Выводить исходную коллекцию и отсортированную коллекцию
     */
    public class Task02
    {
        // коллекция заявок на ремонт ноутбуков 
        List<Repair> _laptops;

        // имя файла
        private string _fileName;
        public string FileName
        {
            get => _fileName;

            // при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
            set {
                _fileName = value;

                if (!File.Exists(_fileName)) {
                    _laptops.Clear();
                    for (int i = 0; i < 15; i++)
                        _laptops.Add(Repair.Generate());

                    SerializeData();
                }
                // при последующих запусках – перемешивание
                else {
                    DeserializeData();
                    // перемешивание
                    _laptops =_laptops.OrderBy(item => Utils.Random.Next()).ToList();
                    SerializeData();
                }// if
            } // set
        } // FileName


        // конструкторы
        public Task02() : this(new List<Repair>()) { } // Task02

        public Task02(List<Repair> laptops) {
            _laptops = laptops;
        } // Task02


        // обработка по заданию
        public List<Repair> Process() {
            _laptops = _laptops.OrderBy(item => Utils.Random.Next()).ToList();
            SerializeData();
            return _laptops;
        } // Process

        // -----------------------------------------------------------------------------------

        // сериализация данных в формате JSON
        public void SerializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<Repair>));

            // Запись объекта в JSON-файл
            using (FileStream fs = new FileStream(FileName, FileMode.Create)) {
                jsonFormatter.WriteObject(fs, _laptops);
            } // using
        } // SerializeData

        // десериализация данных из формата JSON
        public void DeserializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<Repair>));

            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate)) {
                _laptops = (List<Repair>)jsonFormatter.ReadObject(fs);
            } // using

        } // DeserializeData

        // -----------------------------------------------------------------------------------

    } // Task02
}
