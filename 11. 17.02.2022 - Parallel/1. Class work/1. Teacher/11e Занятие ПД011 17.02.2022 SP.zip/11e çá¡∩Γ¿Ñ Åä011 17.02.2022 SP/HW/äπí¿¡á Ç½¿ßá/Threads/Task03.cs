﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Threads
{
    /* Обработка 3.
     * Обработка текстового файла – подсчет (без учета регистра) частоты слов, 
     * результаты выводите в словарь (пары «слово – количество»)
     */
    public class Task03 {
        // имя файла
        public string FileName { get; set; }

        // создание частотного словаря
        private Dictionary<string, int> CreateDictionary() {
            Dictionary<string, int> words = new Dictionary<string, int>();

            var delimiters = " ,.:!?'\"\t\n-+\r".ToCharArray();
            File.ReadAllText(FileName)
                .ToLower()
                .Split(delimiters, StringSplitOptions.RemoveEmptyEntries)
                .ToList()
                .ForEach(word => {
                    if (!words.ContainsKey(word))
                        words[word] = 0;
                    words[word]++;
                });
            return words;
        } // CreateDictionary


        // обработка по заданию
        public Dictionary<string, int> Process(out string fileText) {
            fileText = $"Поток 3: файл \"{Path.GetFileName(FileName)}\":\r\n{File.ReadAllText(FileName)}";
            
            // пары «слово – количество»
            return CreateDictionary();
        } // Process
    } // Task03
}
