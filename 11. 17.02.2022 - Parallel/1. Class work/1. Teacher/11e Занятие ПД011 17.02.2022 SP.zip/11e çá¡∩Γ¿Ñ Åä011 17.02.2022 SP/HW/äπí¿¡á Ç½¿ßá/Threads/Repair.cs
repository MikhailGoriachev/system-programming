﻿using System;
using System.Runtime.Serialization;

namespace Threads
{
    /*
     * Класс заявок на ремонт ноутбуков  (наименование устройства, модель, тип процессора, 
     * объем оперативной памяти, емкость накопителя, диагональ экрана,
     * описание неисправности, фамилия и инициалы владельца, стоимость ремонта)
     */
    [DataContract]
    public class Repair {
        // наименование устройства
        private string _name;
        [DataMember]
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Laptop. Должно быть задано адрес наименование устройства");

                _name = value;
            } // set
        } // Name


        // модель
        private string _model;
        [DataMember]
        public string Model {
            get => _model;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Laptop. Должна быть задана модель ноутбука");

                _model = value;
            }// set
        } // Model


        // тип процессора
        private string _cpuManufacturer;
        [DataMember]
        public string CPUManufacturer {
            get => _cpuManufacturer;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Laptop. Должен быть задан тип процессора");

                _cpuManufacturer = value;
            }// set
        } // CPUManufacturer


        // диагональ экрана
        private double _diagonal;
        [DataMember]
        public double Diagonal {
            get => _diagonal;
            set {
                if (value < 0)
                    throw new ArgumentException("Laptop. Задана не корректная диагональ экрана");

                _diagonal = value;
            }
        } // Diagonal


        // емкость накопителя
        private int _capacity;
        [DataMember]
        public int Capacity {
            get => _capacity;
            set {
                if (value < 0)
                    throw new ArgumentException("Laptop. Задана не корректная емкость накопителя");

                _capacity = value;
            } // set
        } // Capacity


        // объем оперативной памяти
        private int _ramSize;
        [DataMember]
        public int RAMSize  {
            get => _ramSize;
            set {
                if (value < 0)
                    throw new ArgumentException("Laptop. Задан не корректный объем оперативной памяти");

                _ramSize = value;
            } // set
        } // RAMSize


        // описание дефекта
        private string _defectDescription;
        [DataMember]
        public string DefectDescription {
            get => _defectDescription;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Laptop. Должно быть задано описание дефекта");

                _defectDescription = value;
            }
        } // DefectDescription


        // фамилия и инициалами владельца
        private string _owner;
        [DataMember]
        public string Owner {
            get => _owner;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Laptop. Должны быть заданы фамилия и инициалы владельца");

                _owner = value;
            }
        } // Owner

        // стоимость ремонта
        private int _price;
        [DataMember]
        public int Price  {
            get => _price;
            set {
                if (value < 0)
                    throw new ArgumentException("Laptop. Задана не корректная стоимость ремонта");

                _price = value;
            } // set
        } // Price


        // Шапка таблицы, статическое свойство
        public static string Header() =>
            $"    ┌────────────────┬──────────┬────────────────┬─────┬────────────────┬───────────┬───────────────────┬───────────┐\n" +
            $"    │ Наименование   │ Модель   │ Тип процессора │ RAM │ Ёмкость накоп. │ Диагональ │ Владелец          │ Стоимость │\n" +
            $"    ├────────────────┼──────────┼────────────────┼─────┼────────────────┼───────────┼───────────────────┼───────────┤";


        // формирование строки в табличном представлениии
        public string ToTableRow() =>
            $"    " +
            $"│ {_name, -14} │ {_model,-8} │ {_cpuManufacturer,-14} │ {_ramSize,3} │ {_capacity,14} │ " +
            $"{_diagonal,9:n1} │ {_owner, -18}│ {_price,-9:f2} │";

        // Подвал таблицы, статическое свойство
        public static string Footer() =>
            $"    └────────────────┴──────────┴────────────────┴─────┴────────────────┴───────────┴───────────────────┴───────────┘\n";


        // конструкторы
        public Repair(): this("Ноутбук №1", "ASUS", 15d, "нет звука", 
            "AMD", 8, 512, "Левша Р.Р.", 2000) {
        } // Laptop

        // валидируем данные при создании объекта
        public Repair(string name, string model, double diagonal, string defectDescription, 
                           string cpuManufacturer, int ramSize, int capacity, string owner, int price) {
            Name = name;
            Model = model;
            Diagonal = diagonal;
            CPUManufacturer = cpuManufacturer;
            RAMSize = ramSize;
            Capacity = capacity;
            DefectDescription = defectDescription;
            Owner = owner;
            Price = price;
        } // Laptop


        // фабричный метод для создания заявки
        public static Repair Generate() {
            // создание объекта из массивов шаблонных данных, валидация при создании не нужна
            return new Repair {
                _name = $"Ноутбук №{Utils.GetRandom(10, 340) * 1000}",
                _model = Utils.GetBrand(),
                _diagonal = Utils.Diagonals[Utils.GetRandom(0, Utils.Diagonals.Length - 1)],
                _defectDescription = Utils.DefectDescriptions[Utils.GetRandom(0, Utils.DefectDescriptions.Length - 1)],
                _owner = Utils.FullNames[Utils.GetRandom(0, Utils.FullNames.Length - 1)],
                _cpuManufacturer = Utils.CPUManufacturers[Utils.GetRandom(0, Utils.CPUManufacturers.Length -1)],
                _ramSize = Utils.RAM[Utils.GetRandom(0, Utils.RAM.Length - 1)],
                _capacity = Utils.Capacity[Utils.GetRandom(0, Utils.GetRandom(0, Utils.Capacity.Length - 1))],
                _price = Utils.GetRandom(1, 20) * 100
            };
        } // Laptop
        
    } // class Laptop
}
