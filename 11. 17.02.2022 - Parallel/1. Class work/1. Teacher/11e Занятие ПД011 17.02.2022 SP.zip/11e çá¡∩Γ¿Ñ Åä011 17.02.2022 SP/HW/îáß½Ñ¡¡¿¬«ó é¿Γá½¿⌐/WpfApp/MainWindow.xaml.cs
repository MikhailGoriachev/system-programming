﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using HandlingLib;
using Microsoft.Win32;

namespace WpfApp
{
	/// <summary>
	/// Логика взаимодействия для MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private RandomDoublesFile _randomDoublesFile;
		private LaptopOrders _laptopOrders;
		private WordsOccurrences _wordsOccurrences;


		public MainWindow()
		{
			InitializeComponent();

			_randomDoublesFile = new RandomDoublesFile { BinFileName = "DoublesBinary.bin", Window = this, TbxWpf = TbxThread1 };
			_laptopOrders = new LaptopOrders { FileName = "laptops.json", Window = this, DgWpf = DgThread2 };
			_wordsOccurrences = new WordsOccurrences { FileName = "TextData.txt", DgWpf = DgThread3, Window = this, TbxWpf = TbxThread3 };
		}

		private void Exit_Command(object sender, RoutedEventArgs e) => Close();

		private void ExecThread1_Command(object sender, RoutedEventArgs e)
		{
			OpenFileDialog ofd = CreateOpenfileDialog("Файл данных для загрузки", "Файлы BIN (*.bin)|*.bin");

			if (ofd.ShowDialog() != true) return;

			_randomDoublesFile.BinFileName = ofd.FileName;

			Task.Run(_randomDoublesFile.OutputWPFControl);
		}

		private void ExecThread2_Command(object sender, RoutedEventArgs e)
		{
			OpenFileDialog ofd = CreateOpenfileDialog("Файл данных для загрузки", "Файлы JSON (*.json)|*.json");
		
			if (ofd.ShowDialog() != true) return;

			_laptopOrders.FileName = ofd.FileName;

			Task.Run(_laptopOrders.ProcessWpf);
		}

		private void ExecThread3_Command(object sender, RoutedEventArgs e)
		{
			OpenFileDialog ofd = CreateOpenfileDialog("Файл данных для загрузки", "Файлы TXT (*.txt)|*.txt");

			if (ofd.ShowDialog() != true) return;

			_wordsOccurrences.FileName = ofd.FileName;

			Task.Run(_wordsOccurrences.ProcessWpf);
		}

		private void ExecAllThreads_Command(object sender, RoutedEventArgs e)
		{
			Task.Run(_randomDoublesFile.OutputWPFControl);
			Task.Run(_laptopOrders.ProcessWpf);
			Task.Run(_wordsOccurrences.ProcessWpf);
		}

		private void MainWindow_OnLoaded(object sender, RoutedEventArgs e) =>
			ExecAllThreads_Command(sender, e);

		OpenFileDialog CreateOpenfileDialog(string title, string filter) => new OpenFileDialog
		{
			Multiselect = false,
			Title = title,
			Filter = filter,
			FilterIndex = 0,
			InitialDirectory = AppDomain.CurrentDomain.BaseDirectory
		};

		private void Tbx_OnMouseEnter(object sender, MouseEventArgs e) => (sender as TextBox).BorderThickness = new Thickness(3);
		private void Dg_OnMouseEnter(object sender, MouseEventArgs e) => (sender as DataGrid).BorderThickness = new Thickness(3);

		private void Tbx_OnMouseLeave(object sender, MouseEventArgs e) => (sender as TextBox).BorderThickness = new Thickness(2);
		private void Dg_OnMouseLeave(object sender, MouseEventArgs e) => (sender as DataGrid).BorderThickness = new Thickness(2);
	}
}
