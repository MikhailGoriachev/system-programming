﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using HandlingLib;

namespace WinFormsApp
{
	public partial class MainForm : Form
	{

		RandomDoublesFile _randomDoublesFile;
		LaptopOrders      _laptopOrders;
		WordsOccurrences  _wordsOccurrences;

		public MainForm()
		{
			InitializeComponent();

			_randomDoublesFile = new RandomDoublesFile { BinFileName = "DoublesBinary.bin", Form = this, Tbx = TbxThread1 };
			_laptopOrders = new LaptopOrders { FileName = "laptops.json", Form = this, Dgv = DgvThread2 };
			_wordsOccurrences = new WordsOccurrences { FileName = "TextData.txt", Dgv = DgvThread3, Form = this, Tbx = TbxThread3 };
		}

		private void Thread3_Command(object sender, EventArgs e)
		{
			SetOfd("Открыть файл", "Файлы TXT (*.txt)|*.txt");

			if (OfdMain.ShowDialog() != DialogResult.OK) return;

			_wordsOccurrences.FileName = OfdMain.FileName;

			Task.Run(_wordsOccurrences.ProcessWinForms);
		}

		private void Thread2_Command(object sender, EventArgs e)
		{
			SetOfd("Открыть файл", "Файлы JSON (*.json)|*.json");
		
			if (OfdMain.ShowDialog() != DialogResult.OK) return;

			_laptopOrders.FileName = OfdMain.FileName;

			Task.Run(_laptopOrders.ProcessWinForms);
		}

		private void Thread1_Command(object sender, EventArgs e)
		{
			SetOfd("Открыть файл", "Файлы BIN (*.bin)|*.bin");
			
			if (OfdMain.ShowDialog() != DialogResult.OK) return;
			
			_randomDoublesFile.BinFileName = OfdMain.FileName;
		
			Task.Run(_randomDoublesFile.OutputToUserControl);
		}

		private void SetOfd(string title, string filter)
		{
			OfdMain.Title = title;
			OfdMain.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
			OfdMain.Filter = filter;
			OfdMain.FilterIndex = 1;
		}

		private void Exit_Command(object sender, EventArgs e) => Application.Exit();

		private void ThreadAll_Command(object sender, EventArgs e)
		{
			Task.Run(_randomDoublesFile.OutputToUserControl);
			Task.Run(_laptopOrders.ProcessWinForms);
			Task.Run(_wordsOccurrences.ProcessWinForms);
		}

		private void MainForm_Load(object sender, EventArgs e) =>
			ThreadAll_Command(this, EventArgs.Empty);
	}
}
