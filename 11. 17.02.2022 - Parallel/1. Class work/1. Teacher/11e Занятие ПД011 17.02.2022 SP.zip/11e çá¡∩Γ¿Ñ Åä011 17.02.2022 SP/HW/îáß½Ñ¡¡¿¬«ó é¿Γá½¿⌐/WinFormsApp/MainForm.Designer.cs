﻿
namespace WinFormsApp
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.потокиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.запускПотока1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.запускПотока2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.запускПотока3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
			this.запускВсехПотоковToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.OfdMain = new System.Windows.Forms.OpenFileDialog();
			this.DgvThread2 = new System.Windows.Forms.DataGridView();
			this.panel1 = new System.Windows.Forms.Panel();
			this.DgvThread3 = new System.Windows.Forms.DataGridView();
			this.TbxThread3 = new System.Windows.Forms.TextBox();
			this.TbxThread1 = new System.Windows.Forms.TextBox();
			this.statusStrip1.SuspendLayout();
			this.menuStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvThread2)).BeginInit();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvThread3)).BeginInit();
			this.SuspendLayout();
			// 
			// statusStrip1
			// 
			this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
			this.statusStrip1.Location = new System.Drawing.Point(0, 432);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(1306, 22);
			this.statusStrip1.TabIndex = 4;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// toolStripStatusLabel1
			// 
			this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
			this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
			// 
			// menuStrip1
			// 
			this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.потокиToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(1306, 24);
			this.menuStrip1.TabIndex = 3;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// файлToolStripMenuItem
			// 
			this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
			this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
			this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
			this.файлToolStripMenuItem.Text = "Файл";
			// 
			// выходToolStripMenuItem
			// 
			this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
			this.выходToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.выходToolStripMenuItem.Text = "Выход";
			this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
			// 
			// потокиToolStripMenuItem
			// 
			this.потокиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.запускПотока1ToolStripMenuItem,
            this.запускПотока2ToolStripMenuItem,
            this.запускПотока3ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.запускВсехПотоковToolStripMenuItem});
			this.потокиToolStripMenuItem.Name = "потокиToolStripMenuItem";
			this.потокиToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
			this.потокиToolStripMenuItem.Text = "Потоки";
			// 
			// запускПотока1ToolStripMenuItem
			// 
			this.запускПотока1ToolStripMenuItem.Name = "запускПотока1ToolStripMenuItem";
			this.запускПотока1ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.запускПотока1ToolStripMenuItem.Text = "Запуск потока 1";
			this.запускПотока1ToolStripMenuItem.Click += new System.EventHandler(this.Thread1_Command);
			// 
			// запускПотока2ToolStripMenuItem
			// 
			this.запускПотока2ToolStripMenuItem.Name = "запускПотока2ToolStripMenuItem";
			this.запускПотока2ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.запускПотока2ToolStripMenuItem.Text = "Запуск потока 2";
			this.запускПотока2ToolStripMenuItem.Click += new System.EventHandler(this.Thread2_Command);
			// 
			// запускПотока3ToolStripMenuItem
			// 
			this.запускПотока3ToolStripMenuItem.Name = "запускПотока3ToolStripMenuItem";
			this.запускПотока3ToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.запускПотока3ToolStripMenuItem.Text = "Запуск потока 3";
			this.запускПотока3ToolStripMenuItem.Click += new System.EventHandler(this.Thread3_Command);
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new System.Drawing.Size(184, 6);
			// 
			// запускВсехПотоковToolStripMenuItem
			// 
			this.запускВсехПотоковToolStripMenuItem.Name = "запускВсехПотоковToolStripMenuItem";
			this.запускВсехПотоковToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.запускВсехПотоковToolStripMenuItem.Text = "Запуск всех потоков";
			this.запускВсехПотоковToolStripMenuItem.Click += new System.EventHandler(this.ThreadAll_Command);
			// 
			// OfdMain
			// 
			this.OfdMain.FileName = "openFileDialog1";
			// 
			// DgvThread2
			// 
			this.DgvThread2.AllowUserToAddRows = false;
			this.DgvThread2.AllowUserToDeleteRows = false;
			this.DgvThread2.AllowUserToResizeRows = false;
			this.DgvThread2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			this.DgvThread2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
			this.DgvThread2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvThread2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.DgvThread2.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.DgvThread2.Location = new System.Drawing.Point(396, 24);
			this.DgvThread2.MultiSelect = false;
			this.DgvThread2.Name = "DgvThread2";
			this.DgvThread2.ReadOnly = true;
			this.DgvThread2.RowHeadersVisible = false;
			this.DgvThread2.RowHeadersWidth = 51;
			dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
			this.DgvThread2.RowsDefaultCellStyle = dataGridViewCellStyle3;
			this.DgvThread2.RowTemplate.Height = 24;
			this.DgvThread2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvThread2.ShowCellToolTips = false;
			this.DgvThread2.Size = new System.Drawing.Size(541, 408);
			this.DgvThread2.TabIndex = 9;
			this.DgvThread2.TabStop = false;
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.DgvThread3);
			this.panel1.Controls.Add(this.TbxThread3);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel1.Location = new System.Drawing.Point(937, 24);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(369, 408);
			this.panel1.TabIndex = 10;
			// 
			// DgvThread3
			// 
			this.DgvThread3.AllowUserToAddRows = false;
			this.DgvThread3.AllowUserToDeleteRows = false;
			this.DgvThread3.AllowUserToResizeRows = false;
			this.DgvThread3.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			this.DgvThread3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
			this.DgvThread3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvThread3.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvThread3.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.DgvThread3.Location = new System.Drawing.Point(0, 176);
			this.DgvThread3.MultiSelect = false;
			this.DgvThread3.Name = "DgvThread3";
			this.DgvThread3.ReadOnly = true;
			this.DgvThread3.RowHeadersVisible = false;
			this.DgvThread3.RowHeadersWidth = 51;
			dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
			this.DgvThread3.RowsDefaultCellStyle = dataGridViewCellStyle4;
			this.DgvThread3.RowTemplate.Height = 24;
			this.DgvThread3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvThread3.ShowCellToolTips = false;
			this.DgvThread3.Size = new System.Drawing.Size(369, 232);
			this.DgvThread3.TabIndex = 6;
			this.DgvThread3.TabStop = false;
			// 
			// TbxThread3
			// 
			this.TbxThread3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.TbxThread3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.TbxThread3.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.TbxThread3.Location = new System.Drawing.Point(0, 0);
			this.TbxThread3.Multiline = true;
			this.TbxThread3.Name = "TbxThread3";
			this.TbxThread3.ReadOnly = true;
			this.TbxThread3.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.TbxThread3.ShortcutsEnabled = false;
			this.TbxThread3.Size = new System.Drawing.Size(369, 408);
			this.TbxThread3.TabIndex = 7;
			this.TbxThread3.TabStop = false;
			// 
			// TbxThread1
			// 
			this.TbxThread1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.TbxThread1.Dock = System.Windows.Forms.DockStyle.Left;
			this.TbxThread1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.TbxThread1.Location = new System.Drawing.Point(0, 24);
			this.TbxThread1.Multiline = true;
			this.TbxThread1.Name = "TbxThread1";
			this.TbxThread1.ReadOnly = true;
			this.TbxThread1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.TbxThread1.ShortcutsEnabled = false;
			this.TbxThread1.Size = new System.Drawing.Size(396, 408);
			this.TbxThread1.TabIndex = 8;
			this.TbxThread1.TabStop = false;
			this.TbxThread1.WordWrap = false;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.ClientSize = new System.Drawing.Size(1306, 454);
			this.Controls.Add(this.DgvThread2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.TbxThread1);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.menuStrip1);
			this.Font = new System.Drawing.Font("Tahoma", 10.2F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Приложение Windows Forms";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvThread2)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvThread3)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem потокиToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem запускПотока1ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem запускПотока2ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem запускПотока3ToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem запускВсехПотоковToolStripMenuItem;
		private System.Windows.Forms.OpenFileDialog OfdMain;
		private System.Windows.Forms.DataGridView DgvThread2;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.DataGridView DgvThread3;
		private System.Windows.Forms.TextBox TbxThread3;
		private System.Windows.Forms.TextBox TbxThread1;
	}
}

