﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandlingLib.Models
{
	public class Laptop
	{
		public string Name { get; set; }

		public string Model { get; set; }

		public string CpuType { get; set; }

		public int RamSize { get; set; }

		public int DiskCapacity { get; set; }

		public int Diagonal { get; set; }

		public string Defect { get; set; }

		public string OwnerName { get; set; }

		public static Laptop Generate() => new Laptop
			{
				Name = $"Ноутбук №{Utils.GetRandom(10000, 99999)}",
				Model = Utils.Brands[Utils.GetRandom(0, Utils.Brands.Length - 1)],
				Diagonal = Utils.Diagonals[Utils.GetRandom(0, Utils.Diagonals.Length - 1)],
				Defect = Utils.DefectDescriptions[Utils.GetRandom(0, Utils.DefectDescriptions.Length - 1)],
				OwnerName = Utils.FullNames[Utils.GetRandom(0, Utils.FullNames.Length - 1)],
				CpuType = Utils.CpuTypes[Utils.GetRandom(0, Utils.CpuTypes.Length - 1)],
				RamSize = Utils.RamSizes[Utils.GetRandom(0, Utils.RamSizes.Length - 1)],
				DiskCapacity = Utils.DiskCapacities[Utils.GetRandom(0, Utils.GetRandom(0, Utils.DiskCapacities.Length - 1))]
			};

	}
}
