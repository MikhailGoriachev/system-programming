﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HandlingLib
{
	public class WordsOccurrences
	{
		// имя файла
		private string _fileName;

		public string FileName
		{
			get => _fileName;
			set
			{
				_fileName = value;

				if (!File.Exists(_fileName) || new FileInfo(_fileName).Length == 0)
				{
					File.WriteAllText(_fileName, Utils.TextDemo);
				}
			}
		}

		// ссылка на форму, в которой размещены элементы управления,
		// в которые будем выводить результаты работы
		private Form _form;
		public Form Form
		{
			get => _form;
			set => _form = value;
		} // Form

		// ссылка на окно WPF, в которой размещены элементы управления,
		// в которые будем выводить результаты работы
		public System.Windows.Window Window { get; set; }


		// контролы для вывода из потоков для WF
		public TextBox Tbx { get; set; }       // текст из файла
		public DataGridView Dgv { get; set; }  // словарь 

		// контролы для вывода из потоков для WPF
		public System.Windows.Controls.TextBox TbxWpf { get; set; }  // текст из файла
		public System.Windows.Controls.DataGrid DgWpf { get; set; }  // словарь 

		// создание частотного словаря из коллекции строк
		private Dictionary<string, int> CreateDictionary(string text)
        {
            Dictionary<string, int> words = new Dictionary<string, int>();

            var delimiters = " ,.:!?'\"\t\n\r-+".ToCharArray();
            
            text.ToLower()  
	            .Split(delimiters, StringSplitOptions.RemoveEmptyEntries)
	            .ToList()
                .ForEach(word => {
                        if (!words.ContainsKey(word))
                            words[word] = 0;
                        words[word]++;
                    });
            return words;
        }

		
        // обработка по заданию для Windows Forms
        public void ProcessWinForms()
		{
			// обработка по заданию
			string text = File.ReadAllText(FileName);
			StringBuilder sb = OutputToStringBuilder(text, $"Поток 3: файл \"{Path.GetFileName(FileName)}\":\r\n");

			// вывод файла в TextBox
			if (Tbx.InvokeRequired)
				_form.BeginInvoke((Action)(() => Tbx.Text = sb.ToString()));
			else
				Tbx.Text = sb.ToString();

			// пары «слово – количество»
			Dictionary<string, int> words = CreateDictionary(text);

			// вывод списка из словаря
			if (Dgv.InvokeRequired)
				Form.BeginInvoke((Action) (() => DataGridSet(words)));
			else DataGridSet(words);

		}

        // обработка по заданию для WPF
        public void ProcessWpf()
        {
	        // обработка по заданию
	        string text = File.ReadAllText(FileName);
	        StringBuilder sb = OutputToStringBuilder(text, $"Поток 3: файл \"{Path.GetFileName(FileName)}\":\r\n");

	        // вывод файла в TextBox
	        Window.Dispatcher.BeginInvoke((ThreadStart) (() => TbxWpf.Text = sb.ToString()));
	        
	        // пары «слово – количество»
	        Dictionary<string, int> words = CreateDictionary(text);

			// вывод списка из словаря
			Window.Dispatcher.BeginInvoke((ThreadStart)(() =>
			{
				DgWpf.ItemsSource = null;
				DgWpf.ItemsSource = words.ToList();
			}));
        }

		// Настройка DataGrid для Windows Forms
		public void DataGridSet(Dictionary<string, int> words)
        {
	        Dgv.DataSource = words.ToList();
	        Dgv.Columns[0].HeaderText = "Слово";
	        Dgv.Columns[1].HeaderText = "Количество";
		}

		// вывод списка строк в StringBuilder
		private StringBuilder OutputToStringBuilder(string text, string title = "")
        {
            // сформировать вывод в StringBuilder'е
            StringBuilder sb = new StringBuilder(title);
            sb.Append($"  {text}\r\n");

            return sb;
        } 
    }
}
