﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using HandlingLib.Models;
using Newtonsoft.Json;

namespace HandlingLib
{
	public class LaptopOrders
	{
		// коллекция заявок на ремонт ноутбуков 
		List<Laptop> _laptops = new List<Laptop>();

		// имя файла
		private string _fileName;
		public string FileName
		{
			get => _fileName;

			// при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
			set
			{
				_fileName = value;

				if (!File.Exists(_fileName) || new FileInfo(_fileName).Length == 0)
				{
					_laptops = Enumerable.Repeat(new Laptop(), 15).Select(x => Laptop.Generate()).ToList();

					SerializeData();
				}
				else
					DeserializeData();
			} 
		}

		// ссылка на форму, в которой размещены элементы управления,
		// в которые будем выводить результаты работы
		public Form Form { get; set; }

		// ссылка на окно WPF, в которой размещены элементы управления,
		// в которые будем выводить результаты работы
		public System.Windows.Window Window { get; set; }

		// контрол для вывода в DataGridView WindowsForms
		public DataGridView Dgv { get; set; }

		// контрол для вывода в DataGrid WPF
		public System.Windows.Controls.DataGrid DgWpf { get; set; }

		// обработка по заданию
		public void Process()
		{
			DeserializeData();
			
			// перемешивание
			_laptops = _laptops.OrderBy(x => Utils.Random.Next()).ToList();
			
			SerializeData();
		}

		// обработка по заданию для Windows Forms
		public void ProcessWinForms()
		{
			Process();
			// вывод в DataGridView
			if (Dgv.InvokeRequired)
				Form.BeginInvoke((Action)(() => Dgv.DataSource = _laptops));
			else
			    Dgv.DataSource = _laptops;
		}

		// обработка по заданию для Wpf
		public void ProcessWpf()
		{
			Process();
			// вывод в DataGrid
			Window.Dispatcher.BeginInvoke((ThreadStart) (() =>
			{
				DgWpf.ItemsSource = null;
				DgWpf.ItemsSource = _laptops;
			}));
		}

		private void DeserializeData()
		{
			using (StreamReader file = File.OpenText(FileName))
			{
				JsonSerializer serializer = new JsonSerializer();
				_laptops = (List<Laptop>)serializer.Deserialize(file, typeof(List<Laptop>));
			}
		}

		private void SerializeData()
		{
			using (StreamWriter file = File.CreateText(FileName))
			{
				new JsonSerializer { Formatting = Formatting.Indented }.Serialize(file, _laptops);
			}
		}
		
	}
}
