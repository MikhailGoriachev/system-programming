﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;




namespace HandlingLib
{
	// Класс с обработками по первому заданию
	/*
	 Cоздание файла случайных вещественных чисел (не более 20 чисел), 
	 создается при первом запуске,
	 при последующих запусках – перемешивание данных в файле. 
	 Сортировка файла по убыванию и сохранение файла
	 */
	public class RandomDoublesFile
    {
		#region Данные

		// массив для обработки
		public List<double> Data { get; set; }

		// минимальное и максимальное количества для генерации чисел
		private readonly int _minElements = 10;
		private readonly int _maxElements = 20;

		// диапазон для генерации чисел
		private readonly double _minRange = 10;
		private readonly double _maxRange = 20;

		// имя бинарного файла
		private string _binFileName;

		public string BinFileName
		{
			get => _binFileName;

			// при задании имени файла проверяем наличие файла и создаем файл при его отсутствии
			set
			{
				_binFileName = value;

				if (!File.Exists(_binFileName) || new FileInfo(_binFileName).Length == 0)
				{
					Generate();
					Save();
				}
				else
				{
					Data = new List<double>();
					Read();
					Shuffling();
					Save();
				}
				 
			}
		}

		// ссылка на форму, в которой размещены элементы управления,
		// в которые будем выводить результаты работы
		private Form _form;
		public Form Form
		{
			get => _form;
			set => _form = value;
		}

		// ссылка на окно WPF, в которой размещены элементы управления,
		// в которые будем выводить результаты работы
		public System.Windows.Window Window { get; set; }


		// контрол для вывода из потоков в WF
		public System.Windows.Forms.TextBox Tbx { get; set; }

		// контрол для вывода из потоков в WPF
		public System.Windows.Controls.TextBox TbxWpf { get; set; }

		#endregion


		// Генерация данных 
		public void Generate() => Data = Enumerable
				.Repeat(0, Utils.GetRandom(_minElements, _maxElements))
				.Select(x => Utils.GetRandom(_minRange, _maxRange))
				.ToList();
			

		// Чтение из файла
		public void Read()
		{
			Data.Clear();
			using (BinaryReader brd = new BinaryReader(File.OpenRead(_binFileName)))
			{
				while (brd.BaseStream.Position < brd.BaseStream.Length)
					Data.Add(brd.ReadDouble());
			}
		}

		// Сохранение в файл
		public void Save()
		{
			using (BinaryWriter bwr = new BinaryWriter(File.Create(_binFileName)))
				Data.ForEach(datum => bwr.Write(datum));
		}

		// Перемешивание данных в массиве 
		public void Shuffling() => Data = Data
				.OrderBy(item => Utils.Random.Next())
				.ToList();

		// Обработка по заданию
		public StringBuilder Processing()
		{
			Read();

			Shuffling();

			StringBuilder sb = OutputToStringBuilder(Data, $"  Поток 1: файл \"{Path.GetFileName(_binFileName)}\":\r\n");
			sb.Append(OutputToStringBuilder(Data, $"\r\n\r\n  Поток 1: файл \"{Path.GetFileName(_binFileName)}\" упорядочен по убыванию:\r\n"));
			
			// Сортировка по убыванию
			Data.Sort((x, y) => y.CompareTo(x));

			// сохранение файла
			Save();

			return sb;
		}

		// Вывод в элемент управления WPF
		public void OutputWPFControl()
		{
			StringBuilder sb = Processing();
			Window.Dispatcher.BeginInvoke((ThreadStart) (() => TbxWpf.Text = sb.ToString()));
		}


		// Вывод в элемент управления WF
		public void OutputToUserControl()
		{
			StringBuilder sb = Processing();
			if (Tbx.InvokeRequired)
				_form.BeginInvoke((Action)(() => Tbx.Text = sb.ToString()));
			else
				Tbx.Text = sb.ToString();
		}

		private StringBuilder OutputToStringBuilder(List<double> data, string title)
		{
			StringBuilder sb = new StringBuilder(title);

			int i = 1;
			data.ForEach(d => { sb.Append($"{d,8:f2}"); if (i++ % 6 == 0) sb.AppendLine(); });

			sb.AppendLine();
			return sb;
		}

	}
}
