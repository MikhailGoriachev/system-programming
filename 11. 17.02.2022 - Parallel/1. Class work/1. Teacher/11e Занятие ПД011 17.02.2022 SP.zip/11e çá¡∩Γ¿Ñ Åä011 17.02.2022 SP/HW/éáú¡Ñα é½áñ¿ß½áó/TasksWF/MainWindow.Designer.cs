﻿namespace TasksWF
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.First_Task = new System.Windows.Forms.ToolStripMenuItem();
            this.Second_Task = new System.Windows.Forms.ToolStripMenuItem();
            this.Thrid_Task = new System.Windows.Forms.ToolStripMenuItem();
            this.All_Tasks = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Tbx_Task_1 = new System.Windows.Forms.TextBox();
            this.Dgv_Laptops = new System.Windows.Forms.DataGridView();
            this.Dgv_Dictionary = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Laptops)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Dictionary)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.First_Task,
            this.Second_Task,
            this.Thrid_Task,
            this.All_Tasks});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(678, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // First_Task
            // 
            this.First_Task.Name = "First_Task";
            this.First_Task.Size = new System.Drawing.Size(98, 20);
            this.First_Task.Text = "Первая задача";
            this.First_Task.Click += new System.EventHandler(this.First_Task_Click);
            // 
            // Second_Task
            // 
            this.Second_Task.Name = "Second_Task";
            this.Second_Task.Size = new System.Drawing.Size(96, 20);
            this.Second_Task.Text = "Вторая задача";
            this.Second_Task.Click += new System.EventHandler(this.Second_Task_Click);
            // 
            // Thrid_Task
            // 
            this.Thrid_Task.Name = "Thrid_Task";
            this.Thrid_Task.Size = new System.Drawing.Size(94, 20);
            this.Thrid_Task.Text = "Третья задача";
            this.Thrid_Task.Click += new System.EventHandler(this.Thrid_Task_Click);
            // 
            // All_Tasks
            // 
            this.All_Tasks.Name = "All_Tasks";
            this.All_Tasks.Size = new System.Drawing.Size(135, 20);
            this.All_Tasks.Text = "Запустить все задачи";
            this.All_Tasks.Click += new System.EventHandler(this.All_Tasks_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Tbx_Task_1);
            this.groupBox1.Location = new System.Drawing.Point(19, 39);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(651, 200);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Пункт 1: вещественные числа";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Dgv_Laptops);
            this.groupBox2.Location = new System.Drawing.Point(15, 245);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(651, 200);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Пункт 2: мастреская";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Dgv_Dictionary);
            this.groupBox3.Location = new System.Drawing.Point(15, 451);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(651, 200);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Пункт 3: частотный словарь";
            // 
            // Tbx_Task_1
            // 
            this.Tbx_Task_1.Location = new System.Drawing.Point(3, 16);
            this.Tbx_Task_1.Multiline = true;
            this.Tbx_Task_1.Name = "Tbx_Task_1";
            this.Tbx_Task_1.ReadOnly = true;
            this.Tbx_Task_1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.Tbx_Task_1.Size = new System.Drawing.Size(639, 169);
            this.Tbx_Task_1.TabIndex = 0;
            // 
            // Dgv_Laptops
            // 
            this.Dgv_Laptops.AllowUserToAddRows = false;
            this.Dgv_Laptops.AllowUserToDeleteRows = false;
            this.Dgv_Laptops.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Laptops.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Laptops.Location = new System.Drawing.Point(6, 19);
            this.Dgv_Laptops.MultiSelect = false;
            this.Dgv_Laptops.Name = "Dgv_Laptops";
            this.Dgv_Laptops.ReadOnly = true;
            this.Dgv_Laptops.RowHeadersVisible = false;
            this.Dgv_Laptops.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.Dgv_Laptops.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_Laptops.Size = new System.Drawing.Size(639, 169);
            this.Dgv_Laptops.TabIndex = 0;
            // 
            // Dgv_Dictionary
            // 
            this.Dgv_Dictionary.AllowUserToAddRows = false;
            this.Dgv_Dictionary.AllowUserToDeleteRows = false;
            this.Dgv_Dictionary.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Dictionary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Dictionary.Location = new System.Drawing.Point(6, 19);
            this.Dgv_Dictionary.Name = "Dgv_Dictionary";
            this.Dgv_Dictionary.ReadOnly = true;
            this.Dgv_Dictionary.RowHeadersVisible = false;
            this.Dgv_Dictionary.Size = new System.Drawing.Size(639, 169);
            this.Dgv_Dictionary.TabIndex = 1;
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 672);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainWindow";
            this.Text = "Задание на 16.02.22";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Laptops)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Dictionary)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem First_Task;
        private System.Windows.Forms.ToolStripMenuItem Second_Task;
        private System.Windows.Forms.ToolStripMenuItem Thrid_Task;
        private System.Windows.Forms.ToolStripMenuItem All_Tasks;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox Tbx_Task_1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView Dgv_Laptops;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView Dgv_Dictionary;
    }
}

