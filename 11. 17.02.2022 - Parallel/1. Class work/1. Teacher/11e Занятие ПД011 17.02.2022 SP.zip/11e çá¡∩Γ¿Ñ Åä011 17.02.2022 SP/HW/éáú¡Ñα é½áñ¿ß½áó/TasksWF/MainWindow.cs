﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThreadsLib;

namespace TasksWF
{
    public partial class MainWindow : Form
    {
        Task_WF _taskWF;
        public MainWindow()
        {
            InitializeComponent();
            _taskWF = new Task_WF();
        }

        private void First_Task_Click(object sender, EventArgs e)
        {

            if (_taskWF == null)
                return;
            Tbx_Task_1.Text = "";
            //Создание задачи
            Task task = new Task(() => _taskWF.Process_A(this, Tbx_Task_1));
            //Запуск
            task.Start();
        }

        private void Second_Task_Click(object sender, EventArgs e)
        {
            if (_taskWF == null)
                return;

            //Создание задачи
            Task task = new Task(() => _taskWF.Process_B(this, Dgv_Laptops));
            //Запуск
            task.Start();
        }

        private void Thrid_Task_Click(object sender, EventArgs e)
        {

            if (_taskWF == null)
                return;

            //Создание задачи
            Task task = new Task(() => _taskWF.Process_C(this, Dgv_Dictionary));
            //Запуск
            task.Start();
        }

        private void All_Tasks_Click(object sender, EventArgs e)
        {
            if (_taskWF == null)
                return;

            Tbx_Task_1.Text = "";

            //Список задач 
            List<Task> tasks = new List<Task>()
            {
                new Task(() => _taskWF.Process_A(this, Tbx_Task_1)),
                new Task(() => _taskWF.Process_C(this, Dgv_Dictionary)),
                new Task(() => _taskWF.Process_B(this, Dgv_Laptops))

            };


            //Запуск задач 
            tasks.ForEach(task => task.Start());
        }
    }
}
