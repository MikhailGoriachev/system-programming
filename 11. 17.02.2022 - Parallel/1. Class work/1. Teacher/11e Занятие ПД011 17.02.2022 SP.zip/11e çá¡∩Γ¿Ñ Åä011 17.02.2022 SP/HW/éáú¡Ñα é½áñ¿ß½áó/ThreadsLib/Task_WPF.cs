﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using ThreadsLib.UtilitiesWPF;
using ThreadsLib.Models;
using System.Runtime.Serialization.Json;

namespace ThreadsLib
{
    public class Task_WPF
    {

        //Имя бинарного файла Пункт_1
        public string BinFileName
        {
            get;
            set;
        }

        //Имя файла для сохранения ноутбуков
        public string LapTopFileName
        {
            get;
            set;

        }

        //Имя текстовго файла для пункта 3
        public string TxtFileName
        {
            get;
            set;
        }



        #region Конструкторы 

        public Task_WPF() : this("Numbers.bin", "LapTops.json", "Words.txt")
        {

        }

        public Task_WPF(string BinFName, string LaptopFName, string TxtFName)
        {
            BinFileName = BinFName;
            LapTopFileName = LaptopFName;
            TxtFileName = TxtFName;
            DefaultLoad();
        }

        #endregion

        #region Запись и создание файлов
        //Начальное чтение/запись всех файлов
        public void DefaultLoad()
        {
            //Задаём имена файлов и папки
            string DirName = @"..\App_Data";
            BinFileName = DirName + @"\" + BinFileName;
            LapTopFileName = DirName + @"\" + LapTopFileName;
            TxtFileName = DirName + @"\" + TxtFileName;

            //Создаём объекты управления 
            DirectoryInfo dirInfo = new DirectoryInfo(DirName);

            //Управление файлами 
            FileInfo binFile = new FileInfo(BinFileName);
            FileInfo LapTopFile = new FileInfo(LapTopFileName);
            FileInfo TxtFile = new FileInfo(TxtFileName);

            //Создание/заполнение файлов 
            if (!dirInfo.Exists)
                dirInfo.Create();

            //Если файл не существует - создать и заполнить его 
            if (!binFile.Exists)
                CreateAndFillFile(1);
            else
                ShuffleNumbers();
            //Если файл не существует - создать и заполнить его 
            if (!TxtFile.Exists)
                CreateAndFillFile(2);

            //Если не существует файл с ноутбуками - создать его
            if (!LapTopFile.Exists)
                CreateAndFillFile(3);
            else if (LapTopFile.Exists && LapTopFile.Length <= 0)
                CreateAndFillFile(3);



        }

        //Создать и заполнить файл с вещественными числами
        public void CreateAndFillFile(int FileType)
        {

            switch (FileType)
            {
                //Файл вещественнх чисел
                case 1:
                    {
                        int n = Utils.GetRandom(8,15);
                        using (FileStream fs = File.Create(BinFileName))
                        {
                            // Средство записи в файл 
                            BinaryWriter Bw = new BinaryWriter(fs);

                            //Создаём коллекцию посредством расширяющих методов LINQ
                            var Data = Enumerable.Repeat(1d, n)
                                 .Select(num => Utils.GetRandom(-10d, 10d))
                                 .ToList();

                            foreach (var elem in Data)
                                Bw.Write(elem);
                        }
                    }
                    break;

                //Текстовый файл
                case 2:
                    {
                        StringBuilder sb = new StringBuilder("Решение проблемы состоит в том, чтобы синхронизировать потоки и ограничить доступ к разделяемым ресурсам на время их \n");
                        sb.Append("использования каким-нибудь потоком. \n");
                        sb.Append("Для этого используется ключевое слово lock. \n");
                        sb.Append("Оператор lock определяет блок кода, внутри которого весь код блокируется и становится \n");
                        sb.Append("недоступным для других потоков до завершения работы текущего потока. \n");
                        sb.Append("Остальный потоки помещаются в очередь ожидания и ждут, \n");
                        sb.Append("пока текущий поток не освободит данный блок кода. \n");

                        //Запись строки в файл 
                        File.WriteAllText(TxtFileName, sb.ToString());

                    }
                    break;

                //JSON файл с ноутбуками
                case 3:
                    {
                        List<LaptopModel> laptops = Enumerable.Repeat(0, 16)
                                                              .Select(l => LaptopModel.GenerateLapTop())
                                                              .ToList();
                        SaveLaptops(laptops);
                    }
                    break;

                default:
                    break;
            }

        }
        #endregion

        #region Работа с вещественными числами

        //Перемешивание чисел файла 
        public void ShuffleNumbers()
        {
            //Открыть файл 
            using (FileStream fs = File.Open(BinFileName, FileMode.Open))
            {
                //Обект для чтения из файла 
                BinaryReader Br = new BinaryReader(fs);
                //Обект для чтения из файла 
                BinaryWriter Bw = new BinaryWriter(fs);

                //Получаем длинну файла в кол-ве элементов 
                //int size = (int)File.Open(BinFileName, FileMode.Open).Length / sizeof(double);

                int size = (int)new FileInfo(BinFileName).Length / sizeof(double);

                for (int i = 0; i < size; i++)
                {
                    //Меняем местами элемент с текущим индексом на элемент с радомным индексом
                    Swap(fs, Bw, Br, i, Utils.GetRandom(0, size));
                }

            } //using


        }

        //Замена элементов местами 
        public void Swap(FileStream fs, BinaryWriter Bw, BinaryReader Br, int k, int j)
        {
            //Если индексы равны - уходим, аргументы некорректны
            /* if (k == j)
                 return;*/

            //Перевод корретки на нужную длину записей файла относительно начала
            fs.Seek(k * sizeof(double), SeekOrigin.Begin);

            //Получение double записи файла 
            double FirstElem = Br.ReadDouble();

            //Перевод корретки на нужную длину записей файла относительно начала
            fs.Seek(j * sizeof(double), SeekOrigin.Begin);

            //Получение double записи файла 
            double SecondElem = Br.ReadDouble();

            //Переводим указатель обратно на позицию k для записи значения позиции j (SecondElem)
            fs.Seek(k * sizeof(double), SeekOrigin.Begin);

            //Пишем значение из позиции j в значение элемента на позиции k
            Bw.Write(SecondElem);

            //Переводим указатель обратно на позицию j для записи значения позиции k (First elem)
            fs.Seek(j * sizeof(double), SeekOrigin.Begin);

            //Пишем значение из позиции j в значение элемента на позиции k
            Bw.Write(FirstElem);

        }

        //Получить коллекцию значений из файла 
        public StringBuilder GetNumbers(string header = "Вещественные числа")
        {
            //Коллекция для записи 
            List<double> numbers = new List<double>();

            //Открытие файла для чтения
            using (FileStream fs = File.OpenRead(BinFileName))
            {
                //Указатель для чтения 
                BinaryReader Br = new BinaryReader(fs);

                //Читаем до конца 
                while (Br.BaseStream.Position < Br.BaseStream.Length)
                    numbers.Add(Br.ReadDouble());

            } //Using 

            //Создаём строку 
            StringBuilder sb = new StringBuilder($"{header}\r\n");
            numbers.ForEach(elem =>
            {
                if (elem < 0d)
                    sb.Append($"│{elem:f2}\r\n│\r\n");
                else
                    sb.Append($"│ {elem:f2}\r\n│\r\n");

            }
            );

            return sb;
        }

        //Сортировка значений файла
        public void SortFile()
        {

            //Коллекция для записи 
            List<double> data = new List<double>();

            //Открытие файла для чтения
            using (FileStream fs = File.OpenRead(BinFileName))
            {
                //Указатель для чтения 
                BinaryReader Br = new BinaryReader(fs);

                //Читаем до конца 
                while (Br.BaseStream.Position < Br.BaseStream.Length)
                    data.Add(Br.ReadDouble());

            } //Using 

            //Сортируем коллекцию 
            data.Sort((x, y) => y.CompareTo(x));

            //Пишем в файл 
            using (FileStream fs = File.OpenWrite(BinFileName))
            {
                BinaryWriter Bw = new BinaryWriter(fs);

                data.ForEach(elem => Bw.Write(elem));
            }
        }

        //Вывод в TextBox
        //В аргументы передаём форму содержащую TextBox

        public void OutPutToTbx(Window window,TextBox textBox, string OutPut)
        {

           window.Dispatcher.BeginInvoke(DispatcherPriority.Normal,
                 (ThreadStart)(() => textBox.Text += OutPut));
        }

        #endregion

        //Метод пункта 1 для потока 
        public void Process_A(Window window, TextBox Tbx)
        {
            //Перемешиваем числа в файле
            ShuffleNumbers();

            //Строка для записи textbox
            StringBuilder sb = GetNumbers("Вещественные числа перемешаны, до сортировки\n");

            OutPutToTbx(window,Tbx,sb.ToString());
            sb.Clear();
            //Сортируем числа файла
            SortFile();

            //добавляем данные в строку после сортировки 
            sb.Append(GetNumbers("\r\n\nЧисла после сортировки\n"));
            OutPutToTbx(window, Tbx, sb.ToString());
        }

        //Метод пункта 2 для потока
        public void Process_B(Window window, DataGrid DG)
        {
            //Перемешать ноутбуки в файле
            ShuffleLaptops();

            //Прочитать из файла и записать в DataGrid
            Utils.OutPutToDataGrid(window,DG,ReadLaptops());
            
        }
        //Метод пункта 3 для потока 
        public void Process_C(Window window, DataGrid DG)
        {
            //Задаём отсортированную коллекцию ключ - значение
            List<KeyValuePair<string, int>> keyValuePairs = FrequenceDictionary().OrderByDescending(elem => elem.Key.Length).ToList();
            Utils.OutPutToDataGrid(window,DG,keyValuePairs);
        }

        #region Словарь частотности слов
        //Чтение текстового файла 
        public string GetText()
            => File.ReadAllText(TxtFileName);

        //Создание словаря. Возвращаем
        public Dictionary<string, int> FrequenceDictionary()
        {
            //Коллекция
            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            

            //Получение коллекции строк 
            List<string> words = GetText().Split(" ;:.,!\n\t".ToCharArray(), StringSplitOptions.RemoveEmptyEntries)
                .Select(word => word.ToLower())
                .ToList();

            //Запись значений в словарь
            foreach (string word in words)
            {
                //Чтобы не считать буквы
                if (word.Length < 2)
                    continue;

                dictionary[word] = words.Count(w => w == word);

            }

            return dictionary;
           
        }

        #endregion

        #region Ноутбуки
        //Записать в файл 
        public void SaveLaptops(List<LaptopModel> laptops)
        {
            using (Stream st = new FileStream(LapTopFileName,FileMode.Create))
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(List<LaptopModel>));

                //Пишем в файл 
                serializer.WriteObject(st,laptops);
            }//using
        }//using

        //Чтение коллекции
        public List<LaptopModel> ReadLaptops()
        {
            List<LaptopModel> laptops = new List<LaptopModel>();

            //Защита при отсутствии данных в файле
            if (new FileInfo(LapTopFileName).Length <= 0)
                CreateAndFillFile(3);

            //Открываем фалй
            using (Stream st = new FileStream(LapTopFileName, FileMode.Open))
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(List<LaptopModel>));

                //Чтение данных из файла 
                laptops = (List<LaptopModel>)serializer.ReadObject(st);
            }//Using 

            return laptops;
        }

        //Перемешать ноутбуки из файла 
        public void ShuffleLaptops()
        {
            List<LaptopModel> laptops = ReadLaptops();
            int size = laptops.Count;

            for (int i = 0, n = 0; i < size; i++)
            {
                n = Utils.GetRandom(i,size);
                (laptops[i], laptops[n]) = (laptops[n], laptops[i]);
            }

            //Пишем обратно в файл 
            SaveLaptops(laptops);
        }

        #endregion
    }
}
