﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThreadsLib.UtilitiesWPF;

namespace ThreadsLib.Models
{
   public class LaptopModel
    {
        // наименование устройства
        private string _laptopType;

        public string LaptopType
        {
            get => _laptopType;
            set => _laptopType = value;
        }


        // модель
        private string _model;

        public string Model
        {
            get => _model;
            set => _model = value;
        }


        // тип процессора
        private string _processor;

        public string Processor
        {
            get => _processor;
            set => _processor = value;
        }


        // объем оперативной памяти
        private int _ram;

        public int Ram
        {
            get => _ram;
            set => _ram = value;
        }


        // емкость накопителя
        private int _drive;

        public int Drive
        {
            get => _drive;
            set => _drive = value;
        }


        // диагональ экрана
        private double _diagonal;

        public double Diagonal
        {
            get => _diagonal;
            set => _diagonal = value;
        }


        // описание неисправности
        private string _defect;

        public string Defect
        {
            get => _defect;
            set => _defect = value;
        }


        // фамилия и инициалы владельца
        private string _owner;

        public string Owner
        {
            get => _owner;
            set => _owner = value;
        }

        //Генерация ноутбука
        public static LaptopModel GenerateLapTop()
            => new LaptopModel
            {
                LaptopType = Utils.GetLaptopType(),
                Ram = Utils.GetRam(),
                Drive = Utils.GetRandom(2,10)*100,
                Diagonal = Utils.GetDiagonal(),
                Defect = Utils.GetDefect(),
                Owner = Utils.GetPerson(),
                Model = Utils.GetModel(),
                Processor = Utils.GetProcessor(),
            };

        public void Generate()
        {
            _laptopType = Utils.GetLaptopType();
            _ram = Utils.GetRam();
            _drive = Utils.GetRandom(2, 10) * 100;
            _diagonal = Utils.GetDiagonal();
            _defect = Utils.GetDefect();
            _owner = Utils.GetPerson();
            _model = Utils.GetModel();
            _processor = Utils.GetProcessor();
        }

    }
}
