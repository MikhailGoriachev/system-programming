﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ThreadsLib;

namespace TasksWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Task_WPF _taskWPF;
        public MainWindow()
        {
            InitializeComponent();
            _taskWPF = new Task_WPF();
        }

        private void FirstThread_Click(object sender, RoutedEventArgs e)
        {
            if (_taskWPF == null)
                return;
            Tbx_Thread_1.Text = "";

            //Создание задачи
            Task task = new Task(() => _taskWPF.Process_A(this, Tbx_Thread_1));
            //Запуск
            task.Start();
        }

        private void SecondThread_Click(object sender, RoutedEventArgs e)
        {

            if (_taskWPF == null)
                return;

            //Создание задачи
            Task task = new Task(() => _taskWPF.Process_C(this, DG_Dictionary));
            //Запуск
            task.Start();
        }
        //Пункт с ноутбуками 
        private void ThridThread_Click(object sender, RoutedEventArgs e)
        {

            if (_taskWPF == null)
                return;

            //Создание задачи
            Task task = new Task(() => _taskWPF.Process_B(this, DG_Laptops));
            //Запуск
            task.Start();
        }

        //Запуск всех задач
        private void AllThredsStart_Click(object sender, RoutedEventArgs e)
        {
            if (_taskWPF == null)
                return;

            Tbx_Thread_1.Text = "";

            //Список задач 
            List<Task> tasks = new List<Task>()
            {
                new Task(() => _taskWPF.Process_A(this, Tbx_Thread_1)),
                new Task(() => _taskWPF.Process_C(this, DG_Dictionary)),
                new Task(() => _taskWPF.Process_B(this, DG_Laptops))

            };


            //Запуск задач 
            tasks.ForEach(task => task.Start());

        }

       
    }
}
