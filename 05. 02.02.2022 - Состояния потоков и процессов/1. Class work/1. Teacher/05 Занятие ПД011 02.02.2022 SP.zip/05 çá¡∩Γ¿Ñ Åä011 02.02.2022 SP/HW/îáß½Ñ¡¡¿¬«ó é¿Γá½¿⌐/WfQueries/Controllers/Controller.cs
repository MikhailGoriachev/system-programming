﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarRentQueriesLibrary;
using CarRentQueriesLibrary.Models;

namespace WFQueries.Controllers
{
	public class Controller
	{
		private CarRentDataContext _dataContext;

		private Queries _queries;

		public Controller() : this(new CarRentDataContext())
		{
		}

		public Controller(CarRentDataContext dataContext)
		{
			_dataContext = dataContext;
			_queries = new Queries(_dataContext);
		}

		public void AddCar(CarRentQueriesLibrary.Models.Cars car)
		{
			if (!_queries.FindColor(car.Color))
			{
				_queries.AddColor(car.Color);
				_dataContext.SubmitChanges();
			}

			if (!_queries.FindBrandModel(car.BrandModel))
			{
				_queries.AddBrandModel(car.BrandModel);
				_dataContext.SubmitChanges();
			}

			_queries.AddCar(car);
			_dataContext.SubmitChanges();
		}

		public CarRentQueriesLibrary.Models.Cars GetCarWhereId(int id) => _queries.GetCarWhereId(id);

		public void UpdateCar(int id, CarRentQueriesLibrary.Models.Cars car)
		{
			_queries.UpdateCar(id, car);
			_dataContext.SubmitChanges();
		}


		public List<CarRentQueriesLibrary.Models.Cars> GetCarsAll() =>
			_queries.GetCarsAll();

		public List<CarRentQueriesLibrary.Models.Clients> GetClientsAll() =>
			_queries.GetClientsAll();

		public List<CarRentQueriesLibrary.Models.RentalFacts> GetRentalFactsAll() =>
			_queries.GetRentalFactsAll();

		public List<CarRentQueriesLibrary.Models.RentalFactsWhereAuto> Query01(string regNum) =>
			_queries.GetRentalFactsWhereRegNum(regNum);

		public List<CarRentQueriesLibrary.Models.RentalFactsWhereAuto> Query02(string brandModel) =>
			_queries.GetRentalFactsWhereBrandModel(brandModel);

		public List<CarRentQueriesLibrary.Models.Clients> Query03(string passport) =>
			_queries.GetClientsWherePassport(passport);

		public List<CarRentQueriesLibrary.Models.RentalFactCost> Query04() =>
			_queries.GetRentalFactsCost();

		public List<CarRentQueriesLibrary.Models.ClientRentalInfo> Query05() =>
			_queries.GetClientsRentalInfos();

		public List<CarRentQueriesLibrary.Models.CarRentalInfo> Query06() =>
			_queries.GetCarsRentalInfos();
	}
}
