﻿

namespace WFQueries.Views
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.TbcMain = new System.Windows.Forms.TabControl();
			this.TbcItemCars = new System.Windows.Forms.TabPage();
			this.label9 = new System.Windows.Forms.Label();
			this.DgvCars = new System.Windows.Forms.DataGridView();
			this.TbcClients = new System.Windows.Forms.TabPage();
			this.label10 = new System.Windows.Forms.Label();
			this.DgvClients = new System.Windows.Forms.DataGridView();
			this.TbcItemRentalFacts = new System.Windows.Forms.TabPage();
			this.label11 = new System.Windows.Forms.Label();
			this.DgvRentFacts = new System.Windows.Forms.DataGridView();
			this.TbcItem01 = new System.Windows.Forms.TabPage();
			this.label1 = new System.Windows.Forms.Label();
			this.DgvQuery01 = new System.Windows.Forms.DataGridView();
			this.TbcItem02 = new System.Windows.Forms.TabPage();
			this.label2 = new System.Windows.Forms.Label();
			this.DgvQuery02 = new System.Windows.Forms.DataGridView();
			this.TbcItem03 = new System.Windows.Forms.TabPage();
			this.label4 = new System.Windows.Forms.Label();
			this.DgvQuery03 = new System.Windows.Forms.DataGridView();
			this.TbcItem04 = new System.Windows.Forms.TabPage();
			this.label5 = new System.Windows.Forms.Label();
			this.DgvQuery04 = new System.Windows.Forms.DataGridView();
			this.TbcItem05 = new System.Windows.Forms.TabPage();
			this.label6 = new System.Windows.Forms.Label();
			this.DgvQuery05 = new System.Windows.Forms.DataGridView();
			this.TbcItem06 = new System.Windows.Forms.TabPage();
			this.label7 = new System.Windows.Forms.Label();
			this.DgvQuery06 = new System.Windows.Forms.DataGridView();
			this.MniMain = new System.Windows.Forms.MenuStrip();
			this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
			this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.TsbMain = new System.Windows.Forms.ToolStrip();
			this.MniTables = new System.Windows.Forms.ToolStripMenuItem();
			this.MniTablesCars = new System.Windows.Forms.ToolStripMenuItem();
			this.MniTablesClients = new System.Windows.Forms.ToolStripMenuItem();
			this.MniTablesRentalCars = new System.Windows.Forms.ToolStripMenuItem();
			this.MniQueries = new System.Windows.Forms.ToolStripMenuItem();
			this.MniQueries1 = new System.Windows.Forms.ToolStripMenuItem();
			this.MniQueries2 = new System.Windows.Forms.ToolStripMenuItem();
			this.MniQueries3 = new System.Windows.Forms.ToolStripMenuItem();
			this.MniQueries4 = new System.Windows.Forms.ToolStripMenuItem();
			this.MniQueries5 = new System.Windows.Forms.ToolStripMenuItem();
			this.MniQueries6 = new System.Windows.Forms.ToolStripMenuItem();
			this.TsbAddCar = new System.Windows.Forms.ToolStripButton();
			this.TsbEditCar = new System.Windows.Forms.ToolStripButton();
			this.TsbRentCar = new System.Windows.Forms.ToolStripButton();
			this.TsbExit = new System.Windows.Forms.ToolStripButton();
			this.ExtendCarRental = new System.Windows.Forms.ToolStripButton();
			this.TsbAbout = new System.Windows.Forms.ToolStripButton();
			this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
			this.TbcMain.SuspendLayout();
			this.TbcItemCars.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvCars)).BeginInit();
			this.TbcClients.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvClients)).BeginInit();
			this.TbcItemRentalFacts.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvRentFacts)).BeginInit();
			this.TbcItem01.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).BeginInit();
			this.TbcItem02.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).BeginInit();
			this.TbcItem03.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery03)).BeginInit();
			this.TbcItem04.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery04)).BeginInit();
			this.TbcItem05.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery05)).BeginInit();
			this.TbcItem06.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).BeginInit();
			this.MniMain.SuspendLayout();
			this.TsbMain.SuspendLayout();
			this.SuspendLayout();
			// 
			// TbcMain
			// 
			this.TbcMain.Controls.Add(this.TbcItemCars);
			this.TbcMain.Controls.Add(this.TbcClients);
			this.TbcMain.Controls.Add(this.TbcItemRentalFacts);
			this.TbcMain.Controls.Add(this.TbcItem01);
			this.TbcMain.Controls.Add(this.TbcItem02);
			this.TbcMain.Controls.Add(this.TbcItem03);
			this.TbcMain.Controls.Add(this.TbcItem04);
			this.TbcMain.Controls.Add(this.TbcItem05);
			this.TbcMain.Controls.Add(this.TbcItem06);
			this.TbcMain.Location = new System.Drawing.Point(0, 72);
			this.TbcMain.Name = "TbcMain";
			this.TbcMain.SelectedIndex = 0;
			this.TbcMain.Size = new System.Drawing.Size(814, 416);
			this.TbcMain.TabIndex = 0;
			this.TbcMain.SelectedIndexChanged += new System.EventHandler(this.TbcMain_SelectedIndexChanged);
			// 
			// TbcItemCars
			// 
			this.TbcItemCars.Controls.Add(this.label9);
			this.TbcItemCars.Controls.Add(this.DgvCars);
			this.TbcItemCars.Location = new System.Drawing.Point(4, 26);
			this.TbcItemCars.Name = "TbcItemCars";
			this.TbcItemCars.Size = new System.Drawing.Size(806, 386);
			this.TbcItemCars.TabIndex = 8;
			this.TbcItemCars.Text = "Автомобили";
			this.TbcItemCars.UseVisualStyleBackColor = true;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label9.Location = new System.Drawing.Point(0, 0);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(169, 19);
			this.label9.TabIndex = 3;
			this.label9.Text = "Таблица автомобилей:";
			// 
			// DgvCars
			// 
			this.DgvCars.AllowUserToAddRows = false;
			this.DgvCars.AllowUserToDeleteRows = false;
			this.DgvCars.AllowUserToResizeRows = false;
			this.DgvCars.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvCars.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvCars.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvCars.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvCars.Location = new System.Drawing.Point(0, 27);
			this.DgvCars.MultiSelect = false;
			this.DgvCars.Name = "DgvCars";
			this.DgvCars.ReadOnly = true;
			this.DgvCars.RowHeadersVisible = false;
			this.DgvCars.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvCars.Size = new System.Drawing.Size(806, 359);
			this.DgvCars.TabIndex = 2;
			// 
			// TbcClients
			// 
			this.TbcClients.Controls.Add(this.label10);
			this.TbcClients.Controls.Add(this.DgvClients);
			this.TbcClients.Location = new System.Drawing.Point(4, 26);
			this.TbcClients.Name = "TbcClients";
			this.TbcClients.Size = new System.Drawing.Size(806, 386);
			this.TbcClients.TabIndex = 9;
			this.TbcClients.Text = "Клиенты";
			this.TbcClients.UseVisualStyleBackColor = true;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label10.Location = new System.Drawing.Point(0, 0);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(140, 19);
			this.label10.TabIndex = 5;
			this.label10.Text = "Таблица клиентов:";
			// 
			// DgvClients
			// 
			this.DgvClients.AllowUserToAddRows = false;
			this.DgvClients.AllowUserToDeleteRows = false;
			this.DgvClients.AllowUserToResizeRows = false;
			this.DgvClients.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvClients.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvClients.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvClients.Location = new System.Drawing.Point(0, 27);
			this.DgvClients.MultiSelect = false;
			this.DgvClients.Name = "DgvClients";
			this.DgvClients.ReadOnly = true;
			this.DgvClients.RowHeadersVisible = false;
			this.DgvClients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvClients.Size = new System.Drawing.Size(806, 359);
			this.DgvClients.TabIndex = 4;
			// 
			// TbcItemRentalFacts
			// 
			this.TbcItemRentalFacts.Controls.Add(this.label11);
			this.TbcItemRentalFacts.Controls.Add(this.DgvRentFacts);
			this.TbcItemRentalFacts.Location = new System.Drawing.Point(4, 26);
			this.TbcItemRentalFacts.Name = "TbcItemRentalFacts";
			this.TbcItemRentalFacts.Size = new System.Drawing.Size(806, 386);
			this.TbcItemRentalFacts.TabIndex = 10;
			this.TbcItemRentalFacts.Text = "Факты аренды";
			this.TbcItemRentalFacts.UseVisualStyleBackColor = true;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label11.Location = new System.Drawing.Point(0, 0);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(183, 19);
			this.label11.TabIndex = 5;
			this.label11.Text = "Таблица фактов аренды:";
			// 
			// DgvRentFacts
			// 
			this.DgvRentFacts.AllowUserToAddRows = false;
			this.DgvRentFacts.AllowUserToDeleteRows = false;
			this.DgvRentFacts.AllowUserToResizeRows = false;
			this.DgvRentFacts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvRentFacts.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvRentFacts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvRentFacts.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvRentFacts.Location = new System.Drawing.Point(0, 27);
			this.DgvRentFacts.MultiSelect = false;
			this.DgvRentFacts.Name = "DgvRentFacts";
			this.DgvRentFacts.ReadOnly = true;
			this.DgvRentFacts.RowHeadersVisible = false;
			this.DgvRentFacts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvRentFacts.Size = new System.Drawing.Size(806, 359);
			this.DgvRentFacts.TabIndex = 4;
			// 
			// TbcItem01
			// 
			this.TbcItem01.Controls.Add(this.label1);
			this.TbcItem01.Controls.Add(this.DgvQuery01);
			this.TbcItem01.Location = new System.Drawing.Point(4, 26);
			this.TbcItem01.Name = "TbcItem01";
			this.TbcItem01.Padding = new System.Windows.Forms.Padding(3);
			this.TbcItem01.Size = new System.Drawing.Size(806, 386);
			this.TbcItem01.TabIndex = 0;
			this.TbcItem01.Text = "Запрос 1";
			this.TbcItem01.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label1.Location = new System.Drawing.Point(0, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(483, 19);
			this.label1.TabIndex = 1;
			this.label1.Text = "Информация обо всех фактах проката автомобиля с госномером :";
			// 
			// DgvQuery01
			// 
			this.DgvQuery01.AllowUserToAddRows = false;
			this.DgvQuery01.AllowUserToDeleteRows = false;
			this.DgvQuery01.AllowUserToResizeRows = false;
			this.DgvQuery01.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery01.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery01.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery01.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery01.Location = new System.Drawing.Point(3, 24);
			this.DgvQuery01.MultiSelect = false;
			this.DgvQuery01.Name = "DgvQuery01";
			this.DgvQuery01.ReadOnly = true;
			this.DgvQuery01.RowHeadersVisible = false;
			this.DgvQuery01.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvQuery01.Size = new System.Drawing.Size(800, 359);
			this.DgvQuery01.TabIndex = 0;
			// 
			// TbcItem02
			// 
			this.TbcItem02.Controls.Add(this.label2);
			this.TbcItem02.Controls.Add(this.DgvQuery02);
			this.TbcItem02.Location = new System.Drawing.Point(4, 26);
			this.TbcItem02.Name = "TbcItem02";
			this.TbcItem02.Padding = new System.Windows.Forms.Padding(3);
			this.TbcItem02.Size = new System.Drawing.Size(806, 386);
			this.TbcItem02.TabIndex = 1;
			this.TbcItem02.Text = "Запрос 2";
			this.TbcItem02.UseVisualStyleBackColor = true;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label2.Location = new System.Drawing.Point(0, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(602, 19);
			this.label2.TabIndex = 2;
			this.label2.Text = "Информация обо всех фактах проката автомобиля с заданной моделью/брендом :";
			// 
			// DgvQuery02
			// 
			this.DgvQuery02.AllowUserToAddRows = false;
			this.DgvQuery02.AllowUserToDeleteRows = false;
			this.DgvQuery02.AllowUserToResizeRows = false;
			this.DgvQuery02.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery02.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery02.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery02.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery02.Location = new System.Drawing.Point(3, 24);
			this.DgvQuery02.MultiSelect = false;
			this.DgvQuery02.Name = "DgvQuery02";
			this.DgvQuery02.ReadOnly = true;
			this.DgvQuery02.RowHeadersVisible = false;
			this.DgvQuery02.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvQuery02.Size = new System.Drawing.Size(800, 359);
			this.DgvQuery02.TabIndex = 1;
			// 
			// TbcItem03
			// 
			this.TbcItem03.Controls.Add(this.label4);
			this.TbcItem03.Controls.Add(this.DgvQuery03);
			this.TbcItem03.Location = new System.Drawing.Point(4, 26);
			this.TbcItem03.Name = "TbcItem03";
			this.TbcItem03.Size = new System.Drawing.Size(806, 386);
			this.TbcItem03.TabIndex = 2;
			this.TbcItem03.Text = "Запрос 3";
			this.TbcItem03.UseVisualStyleBackColor = true;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Dock = System.Windows.Forms.DockStyle.Top;
			this.label4.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label4.Location = new System.Drawing.Point(0, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(412, 19);
			this.label4.TabIndex = 3;
			this.label4.Text = "Информация о клиентах по серии и номером паспорта :";
			// 
			// DgvQuery03
			// 
			this.DgvQuery03.AllowUserToAddRows = false;
			this.DgvQuery03.AllowUserToDeleteRows = false;
			this.DgvQuery03.AllowUserToResizeRows = false;
			this.DgvQuery03.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery03.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery03.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery03.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery03.Location = new System.Drawing.Point(0, 24);
			this.DgvQuery03.MultiSelect = false;
			this.DgvQuery03.Name = "DgvQuery03";
			this.DgvQuery03.ReadOnly = true;
			this.DgvQuery03.RowHeadersVisible = false;
			this.DgvQuery03.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvQuery03.Size = new System.Drawing.Size(806, 362);
			this.DgvQuery03.TabIndex = 1;
			// 
			// TbcItem04
			// 
			this.TbcItem04.Controls.Add(this.label5);
			this.TbcItem04.Controls.Add(this.DgvQuery04);
			this.TbcItem04.Location = new System.Drawing.Point(4, 26);
			this.TbcItem04.Name = "TbcItem04";
			this.TbcItem04.Size = new System.Drawing.Size(806, 386);
			this.TbcItem04.TabIndex = 3;
			this.TbcItem04.Text = "Запрос 4";
			this.TbcItem04.UseVisualStyleBackColor = true;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Dock = System.Windows.Forms.DockStyle.Top;
			this.label5.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label5.Location = new System.Drawing.Point(0, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(428, 19);
			this.label5.TabIndex = 3;
			this.label5.Text = "Для каждого факта проката вычислена стоимость проката:";
			// 
			// DgvQuery04
			// 
			this.DgvQuery04.AllowUserToAddRows = false;
			this.DgvQuery04.AllowUserToDeleteRows = false;
			this.DgvQuery04.AllowUserToResizeRows = false;
			this.DgvQuery04.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery04.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery04.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery04.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery04.Location = new System.Drawing.Point(0, 24);
			this.DgvQuery04.MultiSelect = false;
			this.DgvQuery04.Name = "DgvQuery04";
			this.DgvQuery04.ReadOnly = true;
			this.DgvQuery04.RowHeadersVisible = false;
			this.DgvQuery04.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvQuery04.Size = new System.Drawing.Size(806, 362);
			this.DgvQuery04.TabIndex = 1;
			// 
			// TbcItem05
			// 
			this.TbcItem05.Controls.Add(this.label6);
			this.TbcItem05.Controls.Add(this.DgvQuery05);
			this.TbcItem05.Location = new System.Drawing.Point(4, 26);
			this.TbcItem05.Name = "TbcItem05";
			this.TbcItem05.Size = new System.Drawing.Size(806, 386);
			this.TbcItem05.TabIndex = 4;
			this.TbcItem05.Text = "Запрос 5";
			this.TbcItem05.UseVisualStyleBackColor = true;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Dock = System.Windows.Forms.DockStyle.Top;
			this.label6.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label6.Location = new System.Drawing.Point(0, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(614, 19);
			this.label6.TabIndex = 3;
			this.label6.Text = "Количество фактов проката, суммарное количество дней проката для всех клиентов:";
			// 
			// DgvQuery05
			// 
			this.DgvQuery05.AllowUserToAddRows = false;
			this.DgvQuery05.AllowUserToDeleteRows = false;
			this.DgvQuery05.AllowUserToResizeRows = false;
			this.DgvQuery05.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery05.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery05.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery05.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery05.Location = new System.Drawing.Point(0, 24);
			this.DgvQuery05.MultiSelect = false;
			this.DgvQuery05.Name = "DgvQuery05";
			this.DgvQuery05.ReadOnly = true;
			this.DgvQuery05.RowHeadersVisible = false;
			this.DgvQuery05.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvQuery05.Size = new System.Drawing.Size(806, 362);
			this.DgvQuery05.TabIndex = 1;
			// 
			// TbcItem06
			// 
			this.TbcItem06.Controls.Add(this.label7);
			this.TbcItem06.Controls.Add(this.DgvQuery06);
			this.TbcItem06.Location = new System.Drawing.Point(4, 26);
			this.TbcItem06.Name = "TbcItem06";
			this.TbcItem06.Size = new System.Drawing.Size(806, 386);
			this.TbcItem06.TabIndex = 5;
			this.TbcItem06.Text = "Запрос 6";
			this.TbcItem06.UseVisualStyleBackColor = true;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Dock = System.Windows.Forms.DockStyle.Top;
			this.label7.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label7.Location = new System.Drawing.Point(0, 0);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(763, 19);
			this.label7.TabIndex = 3;
			this.label7.Text = "Количество фактов проката, сумма за прокаты, суммарная длительность прокатов для " +
    "всех автомобилей:";
			// 
			// DgvQuery06
			// 
			this.DgvQuery06.AllowUserToAddRows = false;
			this.DgvQuery06.AllowUserToDeleteRows = false;
			this.DgvQuery06.AllowUserToResizeRows = false;
			this.DgvQuery06.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery06.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery06.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery06.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery06.Location = new System.Drawing.Point(0, 24);
			this.DgvQuery06.MultiSelect = false;
			this.DgvQuery06.Name = "DgvQuery06";
			this.DgvQuery06.ReadOnly = true;
			this.DgvQuery06.RowHeadersVisible = false;
			this.DgvQuery06.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvQuery06.Size = new System.Drawing.Size(806, 362);
			this.DgvQuery06.TabIndex = 1;
			// 
			// MniMain
			// 
			this.MniMain.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.MniMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniTables,
            this.MniQueries,
            this.MniHelp});
			this.MniMain.Location = new System.Drawing.Point(0, 0);
			this.MniMain.Name = "MniMain";
			this.MniMain.Size = new System.Drawing.Size(814, 27);
			this.MniMain.TabIndex = 4;
			this.MniMain.Text = "menuStrip1";
			// 
			// MniFile
			// 
			this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator3,
            this.MniFileExit});
			this.MniFile.Name = "MniFile";
			this.MniFile.Size = new System.Drawing.Size(53, 23);
			this.MniFile.Text = "Файл";
			// 
			// toolStripSeparator3
			// 
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			this.toolStripSeparator3.Size = new System.Drawing.Size(115, 6);
			// 
			// MniHelp
			// 
			this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
			this.MniHelp.Name = "MniHelp";
			this.MniHelp.Size = new System.Drawing.Size(74, 23);
			this.MniHelp.Text = "Справка";
			// 
			// MniHelpAbout
			// 
			this.MniHelpAbout.Name = "MniHelpAbout";
			this.MniHelpAbout.Size = new System.Drawing.Size(164, 24);
			this.MniHelpAbout.Text = "О программе";
			this.MniHelpAbout.Click += new System.EventHandler(this.AboutForm_Command);
			// 
			// TsbMain
			// 
			this.TsbMain.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.TsbMain.ImageScalingSize = new System.Drawing.Size(32, 32);
			this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbAddCar,
            this.TsbEditCar,
            this.TsbRentCar,
            this.TsbExit,
            this.ExtendCarRental,
            this.TsbAbout});
			this.TsbMain.Location = new System.Drawing.Point(0, 27);
			this.TsbMain.Name = "TsbMain";
			this.TsbMain.Size = new System.Drawing.Size(814, 39);
			this.TsbMain.TabIndex = 5;
			this.TsbMain.Text = "toolStrip1";
			// 
			// MniTables
			// 
			this.MniTables.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTablesCars,
            this.MniTablesClients,
            this.MniTablesRentalCars});
			this.MniTables.Name = "MniTables";
			this.MniTables.Size = new System.Drawing.Size(76, 23);
			this.MniTables.Text = "Таблицы";
			// 
			// MniTablesCars
			// 
			this.MniTablesCars.Name = "MniTablesCars";
			this.MniTablesCars.Size = new System.Drawing.Size(180, 24);
			this.MniTablesCars.Text = "Автомобили";
			this.MniTablesCars.Click += new System.EventHandler(this.MniTablesCars_Click);
			// 
			// MniTablesClients
			// 
			this.MniTablesClients.Name = "MniTablesClients";
			this.MniTablesClients.Size = new System.Drawing.Size(180, 24);
			this.MniTablesClients.Text = "Клиенты";
			this.MniTablesClients.Click += new System.EventHandler(this.MniTablesClients_Click);
			// 
			// MniTablesRentalCars
			// 
			this.MniTablesRentalCars.Name = "MniTablesRentalCars";
			this.MniTablesRentalCars.Size = new System.Drawing.Size(180, 24);
			this.MniTablesRentalCars.Text = "Факты аренды";
			this.MniTablesRentalCars.Click += new System.EventHandler(this.MniTablesRentalCars_Click);
			// 
			// MniQueries
			// 
			this.MniQueries.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniQueries1,
            this.MniQueries2,
            this.MniQueries3,
            this.MniQueries4,
            this.MniQueries5,
            this.MniQueries6});
			this.MniQueries.Name = "MniQueries";
			this.MniQueries.Size = new System.Drawing.Size(76, 23);
			this.MniQueries.Text = "Запросы";
			// 
			// MniQueries1
			// 
			this.MniQueries1.Name = "MniQueries1";
			this.MniQueries1.Size = new System.Drawing.Size(180, 24);
			this.MniQueries1.Text = "Запрос 1";
			this.MniQueries1.Click += new System.EventHandler(this.MniQueries1_Click);
			// 
			// MniQueries2
			// 
			this.MniQueries2.Name = "MniQueries2";
			this.MniQueries2.Size = new System.Drawing.Size(180, 24);
			this.MniQueries2.Text = "Запрос 2";
			this.MniQueries2.Click += new System.EventHandler(this.MniQueries2_Click);
			// 
			// MniQueries3
			// 
			this.MniQueries3.Name = "MniQueries3";
			this.MniQueries3.Size = new System.Drawing.Size(180, 24);
			this.MniQueries3.Text = "Запрос 3";
			this.MniQueries3.Click += new System.EventHandler(this.MniQueries3_Click);
			// 
			// MniQueries4
			// 
			this.MniQueries4.Name = "MniQueries4";
			this.MniQueries4.Size = new System.Drawing.Size(180, 24);
			this.MniQueries4.Text = "Запрос 4";
			this.MniQueries4.Click += new System.EventHandler(this.MniQueries4_Click);
			// 
			// MniQueries5
			// 
			this.MniQueries5.Name = "MniQueries5";
			this.MniQueries5.Size = new System.Drawing.Size(180, 24);
			this.MniQueries5.Text = "Запрос 5";
			this.MniQueries5.Click += new System.EventHandler(this.MniQueries5_Click);
			// 
			// MniQueries6
			// 
			this.MniQueries6.Name = "MniQueries6";
			this.MniQueries6.Size = new System.Drawing.Size(180, 24);
			this.MniQueries6.Text = "Запрос 6";
			this.MniQueries6.Click += new System.EventHandler(this.MniQueries6_Click);
			// 
			// TsbAddCar
			// 
			this.TsbAddCar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbAddCar.Image = ((System.Drawing.Image)(resources.GetObject("TsbAddCar.Image")));
			this.TsbAddCar.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbAddCar.Name = "TsbAddCar";
			this.TsbAddCar.Size = new System.Drawing.Size(36, 36);
			this.TsbAddCar.Text = "Добавить данные об автомобиле";
			this.TsbAddCar.ToolTipText = "Добавить данные об автомобиле";
			this.TsbAddCar.Click += new System.EventHandler(this.TsbAddCar_Click);
			// 
			// TsbEditCar
			// 
			this.TsbEditCar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbEditCar.Image = ((System.Drawing.Image)(resources.GetObject("TsbEditCar.Image")));
			this.TsbEditCar.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbEditCar.Name = "TsbEditCar";
			this.TsbEditCar.Size = new System.Drawing.Size(36, 36);
			this.TsbEditCar.Text = "Редактировать данные об автомобиле";
			this.TsbEditCar.Click += new System.EventHandler(this.TsbEditCar_Click);
			// 
			// TsbRentCar
			// 
			this.TsbRentCar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbRentCar.Image = ((System.Drawing.Image)(resources.GetObject("TsbRentCar.Image")));
			this.TsbRentCar.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbRentCar.Name = "TsbRentCar";
			this.TsbRentCar.Size = new System.Drawing.Size(36, 36);
			this.TsbRentCar.Text = "Сдать автомобиль в прокат";
			// 
			// TsbExit
			// 
			this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
			this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbExit.Image = global::WFQueries.Properties.Resources.exit;
			this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbExit.Name = "TsbExit";
			this.TsbExit.Size = new System.Drawing.Size(36, 36);
			this.TsbExit.Text = "Выход";
			this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// ExtendCarRental
			// 
			this.ExtendCarRental.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.ExtendCarRental.Image = ((System.Drawing.Image)(resources.GetObject("ExtendCarRental.Image")));
			this.ExtendCarRental.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.ExtendCarRental.Name = "ExtendCarRental";
			this.ExtendCarRental.Size = new System.Drawing.Size(36, 36);
			this.ExtendCarRental.Text = "автомобиля";
			// 
			// TsbAbout
			// 
			this.TsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbAbout.Image = global::WFQueries.Properties.Resources.about;
			this.TsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbAbout.Name = "TsbAbout";
			this.TsbAbout.Size = new System.Drawing.Size(36, 36);
			this.TsbAbout.Text = "О программе";
			this.TsbAbout.Click += new System.EventHandler(this.AboutForm_Command);
			// 
			// MniFileExit
			// 
			this.MniFileExit.Image = global::WFQueries.Properties.Resources.exit;
			this.MniFileExit.Name = "MniFileExit";
			this.MniFileExit.Size = new System.Drawing.Size(118, 24);
			this.MniFileExit.Text = "Выход";
			this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.ClientSize = new System.Drawing.Size(814, 484);
			this.Controls.Add(this.TsbMain);
			this.Controls.Add(this.MniMain);
			this.Controls.Add(this.TbcMain);
			this.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Домашняя работа";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.TbcMain.ResumeLayout(false);
			this.TbcItemCars.ResumeLayout(false);
			this.TbcItemCars.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvCars)).EndInit();
			this.TbcClients.ResumeLayout(false);
			this.TbcClients.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvClients)).EndInit();
			this.TbcItemRentalFacts.ResumeLayout(false);
			this.TbcItemRentalFacts.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvRentFacts)).EndInit();
			this.TbcItem01.ResumeLayout(false);
			this.TbcItem01.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).EndInit();
			this.TbcItem02.ResumeLayout(false);
			this.TbcItem02.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).EndInit();
			this.TbcItem03.ResumeLayout(false);
			this.TbcItem03.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery03)).EndInit();
			this.TbcItem04.ResumeLayout(false);
			this.TbcItem04.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery04)).EndInit();
			this.TbcItem05.ResumeLayout(false);
			this.TbcItem05.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery05)).EndInit();
			this.TbcItem06.ResumeLayout(false);
			this.TbcItem06.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).EndInit();
			this.MniMain.ResumeLayout(false);
			this.MniMain.PerformLayout();
			this.TsbMain.ResumeLayout(false);
			this.TsbMain.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TabControl TbcMain;
		private System.Windows.Forms.TabPage TbcItem01;
		private System.Windows.Forms.TabPage TbcItem02;
		private System.Windows.Forms.TabPage TbcItem03;
		private System.Windows.Forms.TabPage TbcItem04;
		private System.Windows.Forms.TabPage TbcItem05;
		private System.Windows.Forms.TabPage TbcItem06;
		private System.Windows.Forms.MenuStrip MniMain;
		private System.Windows.Forms.ToolStripMenuItem MniFile;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
		private System.Windows.Forms.ToolStripMenuItem MniFileExit;
		private System.Windows.Forms.ToolStripMenuItem MniHelp;
		private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
		private System.Windows.Forms.ToolStrip TsbMain;
		private System.Windows.Forms.ToolStripButton TsbExit;
		private System.Windows.Forms.ToolStripButton TsbAbout;
		private System.Windows.Forms.DataGridView DgvQuery01;
		private System.Windows.Forms.DataGridView DgvQuery02;
		private System.Windows.Forms.DataGridView DgvQuery03;
		private System.Windows.Forms.DataGridView DgvQuery04;
		private System.Windows.Forms.DataGridView DgvQuery05;
		private System.Windows.Forms.DataGridView DgvQuery06;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TabPage TbcItemCars;
		private System.Windows.Forms.TabPage TbcClients;
		private System.Windows.Forms.TabPage TbcItemRentalFacts;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.DataGridView DgvCars;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.DataGridView DgvClients;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.DataGridView DgvRentFacts;
		private System.Windows.Forms.ToolStripButton TsbAddCar;
		private System.Windows.Forms.ToolStripButton TsbEditCar;
		private System.Windows.Forms.ToolStripButton TsbRentCar;
		private System.Windows.Forms.ToolStripButton ExtendCarRental;
		private System.Windows.Forms.ToolStripMenuItem MniTables;
		private System.Windows.Forms.ToolStripMenuItem MniTablesCars;
		private System.Windows.Forms.ToolStripMenuItem MniTablesClients;
		private System.Windows.Forms.ToolStripMenuItem MniTablesRentalCars;
		private System.Windows.Forms.ToolStripMenuItem MniQueries;
		private System.Windows.Forms.ToolStripMenuItem MniQueries1;
		private System.Windows.Forms.ToolStripMenuItem MniQueries2;
		private System.Windows.Forms.ToolStripMenuItem MniQueries3;
		private System.Windows.Forms.ToolStripMenuItem MniQueries4;
		private System.Windows.Forms.ToolStripMenuItem MniQueries5;
		private System.Windows.Forms.ToolStripMenuItem MniQueries6;
	}
}
