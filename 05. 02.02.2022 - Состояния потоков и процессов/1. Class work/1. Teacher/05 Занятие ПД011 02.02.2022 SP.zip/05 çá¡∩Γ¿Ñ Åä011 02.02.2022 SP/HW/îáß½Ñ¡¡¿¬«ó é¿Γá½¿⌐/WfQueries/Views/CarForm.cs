﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarRentQueriesLibrary;
using CarRentQueriesLibrary.Models;

namespace WFQueries.Views
{
	public partial class CarForm : Form
	{
		private CarRentQueriesLibrary.Models.Cars _car;

		public CarRentQueriesLibrary.Models.Cars Car
		{
			get => _car;
			set => _car = value;
		}

		public CarForm()
		{
			InitializeComponent();
			_car = new CarRentQueriesLibrary.Models.Cars();
		}

		public CarForm(CarRentQueriesLibrary.Models.Cars car)
		{
			InitializeComponent();
			BtnOk.Text = "Coхранить";
			_car = car;
			SetControlsValues();
		}

		public void SetControlsValues()
		{
			TxbBrandModel.Text = _car.BrandModel;
			TxbColor.Text =      _car.Color;
			TxbDayCost.Text =    _car.DayCost.ToString();
			TxbInsurCost.Text =  _car.InsuranceCost.ToString();
			TxbYear.Text =       _car.YearMade.ToString();
			TxbRegNum.Text =     _car.RegNumber;
		}

		private void BtnOk_Click(object sender, EventArgs e)
		{
			_car.BrandModel    = TxbBrandModel.Text;
			_car.Color         = TxbColor.Text;  
			_car.RegNumber     = TxbRegNum.Text;  
			_car.DayCost	   = int.Parse(TxbDayCost.Text);
			_car.InsuranceCost = int.Parse(TxbInsurCost.Text);
			_car.YearMade      = int.Parse(TxbYear.Text);

			DialogResult = DialogResult.OK;
			Close();
		}
	}
}
