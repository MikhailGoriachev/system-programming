﻿
namespace WFQueries.Views
{
	partial class CarForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.LblBrandModel = new System.Windows.Forms.Label();
			this.TxbBrandModel = new System.Windows.Forms.TextBox();
			this.TxbColor = new System.Windows.Forms.TextBox();
			this.LblColor = new System.Windows.Forms.Label();
			this.TxbInsurCost = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.TxbDayCost = new System.Windows.Forms.TextBox();
			this.LblDayCost = new System.Windows.Forms.Label();
			this.TxbYear = new System.Windows.Forms.TextBox();
			this.LblYearMade = new System.Windows.Forms.Label();
			this.BtnOk = new System.Windows.Forms.Button();
			this.BtnCancel = new System.Windows.Forms.Button();
			this.LblRegNum = new System.Windows.Forms.Label();
			this.TxbRegNum = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// LblBrandModel
			// 
			this.LblBrandModel.AutoSize = true;
			this.LblBrandModel.Location = new System.Drawing.Point(26, 24);
			this.LblBrandModel.Name = "LblBrandModel";
			this.LblBrandModel.Size = new System.Drawing.Size(140, 25);
			this.LblBrandModel.TabIndex = 0;
			this.LblBrandModel.Text = "Бренд/модель:";
			// 
			// TxbBrandModel
			// 
			this.TxbBrandModel.Location = new System.Drawing.Point(26, 56);
			this.TxbBrandModel.Name = "TxbBrandModel";
			this.TxbBrandModel.Size = new System.Drawing.Size(400, 33);
			this.TxbBrandModel.TabIndex = 1;
			// 
			// TxbColor
			// 
			this.TxbColor.Location = new System.Drawing.Point(26, 128);
			this.TxbColor.Name = "TxbColor";
			this.TxbColor.Size = new System.Drawing.Size(174, 33);
			this.TxbColor.TabIndex = 3;
			// 
			// LblColor
			// 
			this.LblColor.AutoSize = true;
			this.LblColor.Location = new System.Drawing.Point(26, 96);
			this.LblColor.Name = "LblColor";
			this.LblColor.Size = new System.Drawing.Size(58, 25);
			this.LblColor.TabIndex = 2;
			this.LblColor.Text = "Цвет:";
			// 
			// TxbInsurCost
			// 
			this.TxbInsurCost.Location = new System.Drawing.Point(26, 208);
			this.TxbInsurCost.Name = "TxbInsurCost";
			this.TxbInsurCost.Size = new System.Drawing.Size(174, 33);
			this.TxbInsurCost.TabIndex = 5;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(26, 176);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(202, 25);
			this.label3.TabIndex = 4;
			this.label3.Text = "Страховая стоимость:";
			// 
			// TxbDayCost
			// 
			this.TxbDayCost.Location = new System.Drawing.Point(252, 208);
			this.TxbDayCost.Name = "TxbDayCost";
			this.TxbDayCost.Size = new System.Drawing.Size(174, 33);
			this.TxbDayCost.TabIndex = 7;
			// 
			// LblDayCost
			// 
			this.LblDayCost.AutoSize = true;
			this.LblDayCost.Location = new System.Drawing.Point(258, 176);
			this.LblDayCost.Name = "LblDayCost";
			this.LblDayCost.Size = new System.Drawing.Size(170, 25);
			this.LblDayCost.TabIndex = 6;
			this.LblDayCost.Text = "Стоимость в день:";
			// 
			// TxbYear
			// 
			this.TxbYear.Location = new System.Drawing.Point(252, 128);
			this.TxbYear.Name = "TxbYear";
			this.TxbYear.Size = new System.Drawing.Size(174, 33);
			this.TxbYear.TabIndex = 9;
			// 
			// LblYearMade
			// 
			this.LblYearMade.AutoSize = true;
			this.LblYearMade.Location = new System.Drawing.Point(258, 96);
			this.LblYearMade.Name = "LblYearMade";
			this.LblYearMade.Size = new System.Drawing.Size(122, 25);
			this.LblYearMade.TabIndex = 8;
			this.LblYearMade.Text = "Год выпуска:";
			// 
			// BtnOk
			// 
			this.BtnOk.Location = new System.Drawing.Point(24, 352);
			this.BtnOk.Name = "BtnOk";
			this.BtnOk.Size = new System.Drawing.Size(128, 40);
			this.BtnOk.TabIndex = 10;
			this.BtnOk.Text = "Добавить";
			this.BtnOk.UseVisualStyleBackColor = true;
			this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
			// 
			// BtnCancel
			// 
			this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.BtnCancel.Location = new System.Drawing.Point(296, 352);
			this.BtnCancel.Name = "BtnCancel";
			this.BtnCancel.Size = new System.Drawing.Size(128, 40);
			this.BtnCancel.TabIndex = 11;
			this.BtnCancel.Text = "Отмена";
			this.BtnCancel.UseVisualStyleBackColor = true;
			// 
			// LblRegNum
			// 
			this.LblRegNum.AutoSize = true;
			this.LblRegNum.Location = new System.Drawing.Point(24, 256);
			this.LblRegNum.Name = "LblRegNum";
			this.LblRegNum.Size = new System.Drawing.Size(233, 25);
			this.LblRegNum.TabIndex = 12;
			this.LblRegNum.Text = "Регистрационный номер:";
			// 
			// TxbRegNum
			// 
			this.TxbRegNum.Location = new System.Drawing.Point(24, 296);
			this.TxbRegNum.Name = "TxbRegNum";
			this.TxbRegNum.Size = new System.Drawing.Size(400, 33);
			this.TxbRegNum.TabIndex = 13;
			// 
			// CarForm
			// 
			this.AcceptButton = this.BtnOk;
			this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 25F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.BtnCancel;
			this.ClientSize = new System.Drawing.Size(452, 412);
			this.Controls.Add(this.TxbRegNum);
			this.Controls.Add(this.LblRegNum);
			this.Controls.Add(this.BtnCancel);
			this.Controls.Add(this.BtnOk);
			this.Controls.Add(this.TxbYear);
			this.Controls.Add(this.LblYearMade);
			this.Controls.Add(this.TxbDayCost);
			this.Controls.Add(this.LblDayCost);
			this.Controls.Add(this.TxbInsurCost);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.TxbColor);
			this.Controls.Add(this.LblColor);
			this.Controls.Add(this.TxbBrandModel);
			this.Controls.Add(this.LblBrandModel);
			this.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Margin = new System.Windows.Forms.Padding(6);
			this.MaximizeBox = false;
			this.Name = "CarForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Данные об автомобиле";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label LblBrandModel;
		private System.Windows.Forms.TextBox TxbBrandModel;
		private System.Windows.Forms.TextBox TxbColor;
		private System.Windows.Forms.Label LblColor;
		private System.Windows.Forms.TextBox TxbInsurCost;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox TxbDayCost;
		private System.Windows.Forms.Label LblDayCost;
		private System.Windows.Forms.TextBox TxbYear;
		private System.Windows.Forms.Label LblYearMade;
		private System.Windows.Forms.Button BtnOk;
		private System.Windows.Forms.Button BtnCancel;
		private System.Windows.Forms.Label LblRegNum;
		private System.Windows.Forms.TextBox TxbRegNum;
	}
}