﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFQueries.Views
{
	public partial class RentCarForm : Form
	{
		private List<CarRentQueriesLibrary.Models.Clients> _clients;
		
		private CarRentQueriesLibrary.Models.Cars _car;

		public CarRentQueriesLibrary.Models.RentalFacts RentalFact { get; set; }

		public RentCarForm(List<CarRentQueriesLibrary.Models.Clients> clients, 
			CarRentQueriesLibrary.Models.Cars car)
		{
			InitializeComponent();
			_clients = clients;
			_car = car;

			CbxSurnameNP.DataSource = _clients.Select(x => $"{x.Surname} {x.Name[0]}.{x.Patronymic[0]}.").ToList();
			CbxPassport.DataSource = _clients.Select(x => x.Passport).ToList();
		}
	}
}
