﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Railway.Views;
using WFQueries.Controllers;
using WFQueries.Helpers;

namespace WFQueries.Views
{
	public partial class MainForm : Form
	{
		private Controller _controller;

		public MainForm() : this(new Controller())
		{}

		public MainForm(Controller controller)
		{
			InitializeComponent();
			_controller = controller;
		}


		private void MainForm_Load(object sender, EventArgs e)
		{
			DgvCars.DataSource = _controller.GetCarsAll();
			DgvClients.DataSource = _controller.GetClientsAll();
			DgvRentFacts.DataSource = _controller.GetRentalFactsAll();
			DgvQuery01.DataSource = _controller.Query01(QueriesArgsLists.GetRegNumRand);
			DgvQuery02.DataSource = _controller.Query02(QueriesArgsLists.GetBrandModelRand);
			DgvQuery03.DataSource = _controller.Query03(QueriesArgsLists.GetRegPassportRand);
			DgvQuery04.DataSource = _controller.Query04();
			DgvQuery05.DataSource = _controller.Query05();
			DgvQuery06.DataSource = _controller.Query06();

			
			//DgvQuery01.Columns[0].HeaderText = "Идентификатор";
		}

		private void Exit_Command(object sender, EventArgs e) => this.Close();

		private void AboutForm_Command(object sender, EventArgs e) => new AboutForm().ShowDialog();

		private void MniTablesCars_Click(object sender, EventArgs e)
		{
			DgvCars.DataSource = _controller.GetCarsAll();
			TbcMain.SelectedTab = TbcItemCars;
		}

		private void MniTablesClients_Click(object sender, EventArgs e)
		{
			DgvClients.DataSource = _controller.GetClientsAll();
			TbcMain.SelectedTab = TbcClients;
		}

		private void MniTablesRentalCars_Click(object sender, EventArgs e)
		{
			DgvRentFacts.DataSource = _controller.GetRentalFactsAll();
			TbcMain.SelectedTab = TbcItemRentalFacts;
		}

		private void MniQueries1_Click(object sender, EventArgs e)
		{
			DgvQuery01.DataSource = _controller.Query01(QueriesArgsLists.GetRegNumRand);
			TbcMain.SelectedTab = TbcItem01;
		}

		private void MniQueries2_Click(object sender, EventArgs e)
		{
			DgvQuery02.DataSource = _controller.Query02(QueriesArgsLists.GetBrandModelRand);
			TbcMain.SelectedTab = TbcItem02;
		}

		private void MniQueries3_Click(object sender, EventArgs e)
		{
			DgvQuery03.DataSource = _controller.Query03(QueriesArgsLists.GetRegPassportRand);
			TbcMain.SelectedTab = TbcItem03;
		}

		private void MniQueries4_Click(object sender, EventArgs e)
		{
			DgvQuery04.DataSource = _controller.Query04();
			TbcMain.SelectedTab = TbcItem04;
		}

		private void MniQueries5_Click(object sender, EventArgs e)
		{
			DgvQuery05.DataSource = _controller.Query05();
			TbcMain.SelectedTab = TbcItem05;
		}

		private void MniQueries6_Click(object sender, EventArgs e)
		{
			DgvQuery06.DataSource = _controller.Query06();
			TbcMain.SelectedTab = TbcItem06;
		}

		private void TsbAddCar_Click(object sender, EventArgs e)
		{
			TbcMain.SelectedTab = TbcItemCars;

			CarForm carForm = new CarForm();

			if (carForm.ShowDialog() != DialogResult.OK)
				return;

			_controller.AddCar(carForm.Car);

			DgvCars.DataSource = _controller.GetCarsAll();
		}

		private void TsbEditCar_Click(object sender, EventArgs e)
		{
			if (DgvCars.SelectedRows.Count == 0) return;

			// id выбранного автомобиля
			int id = int.Parse(DgvCars.CurrentRow.Cells[0].Value.ToString());

			// получить модель данных по id
			CarRentQueriesLibrary.Models.Cars car = _controller.GetCarWhereId(id);

			CarForm carForm = new CarForm(car);

			if(carForm.ShowDialog() != DialogResult.OK)
				return;

			_controller.UpdateCar(id, carForm.Car);

			DgvCars.DataSource = _controller.GetCarsAll();
		}

		private void TbcMain_SelectedIndexChanged(object sender, EventArgs e)
		{
			TsbAddCar.Enabled = TsbEditCar.Enabled = TbcMain.SelectedTab == TbcItemCars;

			switch (TbcMain.SelectedIndex)
			{
				case 0:
					DgvCars.DataSource = _controller.GetCarsAll();
					break;
				case 1:
					DgvClients.DataSource = _controller.GetClientsAll();
					break;
				case 2:
					DgvRentFacts.DataSource = _controller.GetRentalFactsAll();
					break;
				case 3:
					DgvQuery01.DataSource = _controller.Query01(QueriesArgsLists.GetRegNumRand);
					break;
				case 4:
					DgvQuery02.DataSource = _controller.Query02(QueriesArgsLists.GetBrandModelRand);
					break;
				case 5:
					DgvQuery03.DataSource = _controller.Query03(QueriesArgsLists.GetRegPassportRand);
					break;
				case 6:
					DgvQuery04.DataSource = _controller.Query04();
					break;
				case 7:
					DgvQuery05.DataSource = _controller.Query05();
					break;
				case 8:
					DgvQuery06.DataSource = _controller.Query06();
					break;
			}
		}
	}
}
