﻿
namespace WFQueries.Views
{
	partial class RentCarForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.LblClientSurnameNP = new System.Windows.Forms.Label();
			this.CbxSurnameNP = new System.Windows.Forms.ComboBox();
			this.CbxPassport = new System.Windows.Forms.ComboBox();
			this.LblClientPassport = new System.Windows.Forms.Label();
			this.LblStartDate = new System.Windows.Forms.Label();
			this.LblDuration = new System.Windows.Forms.Label();
			this.BtnOk = new System.Windows.Forms.Button();
			this.BtnCancel = new System.Windows.Forms.Button();
			this.TbxDateStart = new System.Windows.Forms.TextBox();
			this.TbxDuration = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// LblClientSurnameNP
			// 
			this.LblClientSurnameNP.AutoSize = true;
			this.LblClientSurnameNP.Location = new System.Drawing.Point(32, 24);
			this.LblClientSurnameNP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
			this.LblClientSurnameNP.Name = "LblClientSurnameNP";
			this.LblClientSurnameNP.Size = new System.Drawing.Size(144, 25);
			this.LblClientSurnameNP.TabIndex = 0;
			this.LblClientSurnameNP.Text = "Ф.И.О. клиента:";
			// 
			// CbxSurnameNP
			// 
			this.CbxSurnameNP.FormattingEnabled = true;
			this.CbxSurnameNP.Location = new System.Drawing.Point(32, 64);
			this.CbxSurnameNP.Name = "CbxSurnameNP";
			this.CbxSurnameNP.Size = new System.Drawing.Size(304, 33);
			this.CbxSurnameNP.TabIndex = 1;
			// 
			// CbxPassport
			// 
			this.CbxPassport.FormattingEnabled = true;
			this.CbxPassport.Location = new System.Drawing.Point(32, 152);
			this.CbxPassport.Name = "CbxPassport";
			this.CbxPassport.Size = new System.Drawing.Size(304, 33);
			this.CbxPassport.TabIndex = 3;
			// 
			// LblClientPassport
			// 
			this.LblClientPassport.AutoSize = true;
			this.LblClientPassport.Location = new System.Drawing.Point(32, 112);
			this.LblClientPassport.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
			this.LblClientPassport.Name = "LblClientPassport";
			this.LblClientPassport.Size = new System.Drawing.Size(298, 25);
			this.LblClientPassport.TabIndex = 2;
			this.LblClientPassport.Text = "Номер и серия паспора клиента:";
			// 
			// LblStartDate
			// 
			this.LblStartDate.AutoSize = true;
			this.LblStartDate.Location = new System.Drawing.Point(32, 200);
			this.LblStartDate.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
			this.LblStartDate.Name = "LblStartDate";
			this.LblStartDate.Size = new System.Drawing.Size(194, 25);
			this.LblStartDate.TabIndex = 4;
			this.LblStartDate.Text = "Дата начала аренды:";
			// 
			// LblDuration
			// 
			this.LblDuration.AutoSize = true;
			this.LblDuration.Location = new System.Drawing.Point(32, 288);
			this.LblDuration.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
			this.LblDuration.Name = "LblDuration";
			this.LblDuration.Size = new System.Drawing.Size(207, 25);
			this.LblDuration.TabIndex = 6;
			this.LblDuration.Text = "Длительность аренды:";
			// 
			// BtnOk
			// 
			this.BtnOk.Location = new System.Drawing.Point(32, 384);
			this.BtnOk.Name = "BtnOk";
			this.BtnOk.Size = new System.Drawing.Size(128, 40);
			this.BtnOk.TabIndex = 8;
			this.BtnOk.Text = "Ок";
			this.BtnOk.UseVisualStyleBackColor = true;
			// 
			// BtnCancel
			// 
			this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.BtnCancel.Location = new System.Drawing.Point(208, 384);
			this.BtnCancel.Name = "BtnCancel";
			this.BtnCancel.Size = new System.Drawing.Size(128, 40);
			this.BtnCancel.TabIndex = 9;
			this.BtnCancel.Text = "Отмена";
			this.BtnCancel.UseVisualStyleBackColor = true;
			// 
			// TbxDateStart
			// 
			this.TbxDateStart.Location = new System.Drawing.Point(32, 240);
			this.TbxDateStart.Name = "TbxDateStart";
			this.TbxDateStart.Size = new System.Drawing.Size(304, 33);
			this.TbxDateStart.TabIndex = 10;
			// 
			// TbxDuration
			// 
			this.TbxDuration.Location = new System.Drawing.Point(32, 328);
			this.TbxDuration.Name = "TbxDuration";
			this.TbxDuration.Size = new System.Drawing.Size(304, 33);
			this.TbxDuration.TabIndex = 11;
			// 
			// RentCarForm
			// 
			this.AcceptButton = this.BtnOk;
			this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 25F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.BtnCancel;
			this.ClientSize = new System.Drawing.Size(363, 456);
			this.Controls.Add(this.TbxDuration);
			this.Controls.Add(this.TbxDateStart);
			this.Controls.Add(this.BtnCancel);
			this.Controls.Add(this.BtnOk);
			this.Controls.Add(this.LblDuration);
			this.Controls.Add(this.LblStartDate);
			this.Controls.Add(this.CbxPassport);
			this.Controls.Add(this.LblClientPassport);
			this.Controls.Add(this.CbxSurnameNP);
			this.Controls.Add(this.LblClientSurnameNP);
			this.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
			this.MaximizeBox = false;
			this.Name = "RentCarForm";
			this.ShowIcon = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Сдать автомобиль в аренду";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label LblClientSurnameNP;
		private System.Windows.Forms.ComboBox CbxSurnameNP;
		private System.Windows.Forms.ComboBox CbxPassport;
		private System.Windows.Forms.Label LblClientPassport;
		private System.Windows.Forms.Label LblStartDate;
		private System.Windows.Forms.Label LblDuration;
		private System.Windows.Forms.Button BtnOk;
		private System.Windows.Forms.Button BtnCancel;
		private System.Windows.Forms.TextBox TbxDateStart;
		private System.Windows.Forms.TextBox TbxDuration;
	}
}