﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentQueriesLibrary.Models
{
	public class RentalFactsWhereAuto
	{
		public int Id { get; set; }

		public string Client { get; set; }

		public string BrandModel { get; set; }

		public string RegNum { get; set; }

		public DateTime BeginDate { get; set; }

		public int Duration { get; set; }
	}
}
