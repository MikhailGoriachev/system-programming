﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentQueriesLibrary.Models
{
	public class RentalFacts
	{
		public int Id { get; set; }

		public string Client { get; set; }

		public string BrandModel { get; set; }

		public string Color { get; set; }

		public int YearMade { get; set; }

		public int InsuranceCost { get; set; }

		public int DayCost { get; set; }

		public DateTime BeginDate { get; set; }

		public int RentDays { get; set; }
	}
}
