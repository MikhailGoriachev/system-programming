﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentQueriesLibrary.Models
{
	public class ClientRentalInfo
	{
		public int Id { get; set; }

		public string Client { get; set; }
		
		public string Passport { get; set; }

		public int RentsCount { get; set; }

		public int? TotalRentDays { get; set; }
	}
}
