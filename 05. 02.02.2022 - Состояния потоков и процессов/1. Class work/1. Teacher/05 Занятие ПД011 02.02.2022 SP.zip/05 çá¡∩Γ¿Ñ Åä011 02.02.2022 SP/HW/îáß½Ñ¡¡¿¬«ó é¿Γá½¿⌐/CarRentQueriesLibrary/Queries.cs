﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarRentQueriesLibrary.Models;

namespace CarRentQueriesLibrary
{
    public class Queries
    {
	    // связь с базой данных
	    private CarRentDataContext _dataContext;



	    #region Конструкторы

	    public Queries() : this(new CarRentDataContext()) { }

	    public Queries(CarRentDataContext dataContext)
	    {
			_dataContext = dataContext;
			
	    }

		#endregion

		public Models.Cars GetCarWhereId(int id) =>
			_dataContext.Cars.Where(x => x.Id == id).Select(x => new Models.Cars
			{
				BrandModel = x.BrandModels.BrandModel,
				Color = x.Colors.Color,
				DayCost = x.DayCost,
				Id = x.Id,
				InsuranceCost = x.InsuranceCost,
				RegNumber = x.RegNumber,
				YearMade = x.YearMade
			}).Single();

		public bool FindColor(string color) =>
			_dataContext.Colors.Select(c => c.Color).Contains(color);

		public bool FindBrandModel(string brandModel) =>
			_dataContext.BrandModels.Select(b => b.BrandModel).Contains(brandModel);

		
		#region CRUD

		public void AddCar(Models.Cars car)
		{
			Cars newCar = new Cars()
			{
				RegNumber = car.RegNumber,
				IdBrandModel = _dataContext.BrandModels.Where(x => x.BrandModel == car.BrandModel)
					.Select(x => x.Id).FirstOrDefault(),
				IdColor = _dataContext.Colors.Where(x => x.Color == car.Color).Select(x => x.Id).FirstOrDefault(),
				InsuranceCost = car.InsuranceCost,
				YearMade = car.YearMade,
				DayCost = car.DayCost
			};

			_dataContext.Cars.InsertOnSubmit(newCar);
		}

		public void AddColor(string color) => 
			_dataContext.Colors.InsertOnSubmit(new Colors(){Color = color});

		public void AddBrandModel(string brandModel) => 
			_dataContext.BrandModels.InsertOnSubmit(new BrandModels { BrandModel = brandModel});


		public void UpdateCar(int id, Models.Cars changed)
		{
			var subj = _dataContext.Cars.Where(x => x.Id == id).Select(x => x).FirstOrDefault();

			subj.BrandModels.BrandModel = changed.BrandModel;
			subj.Colors.Color = changed.Color;
			subj.DayCost = changed.DayCost;
			subj.InsuranceCost = changed.InsuranceCost;
			subj.RegNumber = changed.RegNumber;
			subj.YearMade = changed.YearMade;
		}

		#endregion


		#region Запросы для вывода таблиц

		public List<Models.Colors> GetColorsAll() => 
			_dataContext.Colors.Select(c => new Models.Colors
		{
			Id    = c.Id,
			Color = c.Color
		}).ToList();

		public List<Models.BrandModels> GetBrandModelsAll() => 
			_dataContext.BrandModels.Select(b => new Models.BrandModels
		{
			Id          = b.Id,
		    BrandModel	= b.BrandModel
		}).ToList();

		public List<Models.Clients> GetClientsAll() =>
			_dataContext.Clients.Select(c => new Models.Clients
		{
			Id			= c.Id,
			Name		= c.Name,
			Surname		= c.Surname,
			Patronymic	= c.Patronymic,
			Passport	= c.Passport
		}).ToList();

		public List<Models.Cars> GetCarsAll() => _dataContext.Cars.Select(c => new Models.Cars
		{
			Id				= c.Id,
			BrandModel		= c.BrandModels.BrandModel,
			Color			= c.Colors.Color,
			YearMade		= c.YearMade,
			RegNumber       = c.RegNumber,  
			InsuranceCost	= c.InsuranceCost,
			DayCost			= c.DayCost
		}).ToList();

		public List<Models.RentalFacts> GetRentalFactsAll() =>
			_dataContext.RentalFacts.Select(r => new Models.RentalFacts
		{
			Id				= r.Id,
			Client          = $"{r.Clients.Surname} {r.Clients.Name[0]}.{r.Clients.Patronymic[0]}.",
			BrandModel		= r.Cars.BrandModels.BrandModel,
			Color			= r.Cars.Colors.Color,
			YearMade		= r.Cars.YearMade,
			InsuranceCost	= r.Cars.InsuranceCost,
			DayCost			= r.Cars.DayCost,
			BeginDate		= r.BeginDate,
			RentDays		= r.RentDays
		}).ToList();

		#endregion


		#region Запросы
		// 1	Выборка данных
		// Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
		public List<Models.RentalFactsWhereAuto> GetRentalFactsWhereRegNum(string regNum) =>
			_dataContext.RentalFacts.Where(x => x.Cars.RegNumber == regNum)
				.Select(x => new RentalFactsWhereAuto()
				{
					Id = x.Id,
					Client = $"{x.Clients.Surname} {x.Clients.Name[0]}.{x.Clients.Patronymic[0]}.",
					BrandModel = x.Cars.BrandModels.BrandModel,
					RegNum = x.Cars.RegNumber,
					BeginDate = x.BeginDate,
					Duration = x.RentDays,
				}).ToList();


		// 2	Выборка данных
		// Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
		public List<Models.RentalFactsWhereAuto> GetRentalFactsWhereBrandModel(string brandModel) =>
			_dataContext.RentalFacts.Where(x => x.Cars.BrandModels.BrandModel == brandModel)
				.Select(x => new RentalFactsWhereAuto
				{
					Id = x.Id,
					Client = $"{x.Clients.Surname} {x.Clients.Name[0]}.{x.Clients.Patronymic[0]}.",
					BrandModel = x.Cars.BrandModels.BrandModel,
					RegNum = x.Cars.RegNumber,
					BeginDate = x.BeginDate,
					Duration = x.RentDays,
				}).ToList();

		// 3	Выборка данных
		// Выбирает информацию о клиентах по серии и номеру паспорта
		public List<Models.Clients> GetClientsWherePassport(string passport) =>
			_dataContext.Clients.Where(x => x.Passport == passport)
				.Select(x => new Models.Clients
				{
					Id = x.Id,
					Surname = x.Surname,
					Name = x.Name,
					Patronymic = x.Patronymic,
					Passport = x.Passport
				}).ToList();

		// 4	Выборка данных
		// Вычисляет для каждого факта проката стоимость проката.
		// Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
		// Сортировка по полю Дата проката
		public List<Models.RentalFactCost> GetRentalFactsCost() =>
			_dataContext.RentalFacts.Select(x => new RentalFactCost
			{
				Id = x.Id,
				BeginDate = x.BeginDate,
				RegNum = x.Cars.RegNumber,
				BrandModel = x.Cars.BrandModels.BrandModel,
				DayCost = x.Cars.DayCost,
				Duration = x.RentDays,
				TotalCost = x.Cars.DayCost * x.RentDays
			}).OrderBy(x => x.BeginDate).ToList();


		// 5	Запрос с левым соединением
		// Для всех клиентов прокатной фирмы вычисляет количество фактов проката, суммарное количество дней проката,
		// упорядочивание по убыванию суммарного количества дней проката
		public List<Models.ClientRentalInfo> GetClientsRentalInfos() =>
			_dataContext.Clients
				.GroupJoin(_dataContext.RentalFacts,
					client => client.Id,
					rent => rent.IdClient,
					(client, group_join) => new
					{
						client, group_join
					})
				.SelectMany(t => t.group_join.DefaultIfEmpty(),
					(t, subRent) => new
					{
						t.client.Id,
						Client = $"{t.client.Surname} {t.client.Name[0]}.{t.client.Patronymic[0]}.",
						t.client.Passport,
						RentDays = (int?) subRent.RentDays
					}).ToList()
				.GroupBy(g => new {g.Id, g.Client, g.Passport}, (key, group) => new ClientRentalInfo()
				{
					Id = key.Id,
					Client = key.Client,
					Passport = key.Passport,
					RentsCount = group.Count(g => g.RentDays != 0),
					TotalRentDays = group.Sum(g => g.RentDays)
				}).OrderByDescending(x => x.TotalRentDays).ToList();

		// 6	Запрос с левым соединением
		// Для всех автомобилей прокатной фирмы определите количество фактов проката, сумма за прокаты,
		// суммарная длительность прокатов
		public List<Models.CarRentalInfo> GetCarsRentalInfos() =>
			_dataContext.Cars
				.GroupJoin(_dataContext.RentalFacts,
					cars => cars.Id,
					rent => rent.IdCar,
					(car, group_join) => new
					{
						car,
						group_join
					})
				.SelectMany(c => c.group_join.DefaultIfEmpty(),
					(c, subRent) => new
					{
						c.car.Id,
						c.car.BrandModels.BrandModel,
						c.car.Colors.Color,
						c.car.RegNumber,
						c.car.YearMade,
						DayCost = (int?)subRent.Cars.DayCost,
						RentDays = (int?)subRent.RentDays
					}).ToList()
				.GroupBy(g => new { g.Id, g.BrandModel, g.RegNumber, g.YearMade, g.Color }, (key, group) => 
					new CarRentalInfo
					{
						Id = key.Id,
						BrandModel = key.BrandModel,
						YearMade = key.YearMade,
						Color = key.Color,
						RentsCount = group.Count(g => g.RentDays != 0),
						TotalRentDays = group.Sum(g => g.RentDays),
						TotalRentalsCost = group.Sum(g => g.DayCost * g.RentDays)
					}).OrderByDescending(x => x.TotalRentDays).ToList();


		#endregion
	}
}
