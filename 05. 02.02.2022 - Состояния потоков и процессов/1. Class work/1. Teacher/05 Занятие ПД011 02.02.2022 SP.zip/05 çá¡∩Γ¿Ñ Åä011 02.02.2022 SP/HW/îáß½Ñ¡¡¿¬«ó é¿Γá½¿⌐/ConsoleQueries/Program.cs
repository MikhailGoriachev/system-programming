﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleQueries.Application;
using ConsoleQueries.Helpers;

namespace ConsoleQueries
{
	class Program
	{
		static void Main(string[] args)
		{
			new Utilities.ColorSet() { Foreground = ConsoleColor.Yellow, Background = ConsoleColor.Black }
				.SetToConsole();

			new App().Run();
		}
	}
}
