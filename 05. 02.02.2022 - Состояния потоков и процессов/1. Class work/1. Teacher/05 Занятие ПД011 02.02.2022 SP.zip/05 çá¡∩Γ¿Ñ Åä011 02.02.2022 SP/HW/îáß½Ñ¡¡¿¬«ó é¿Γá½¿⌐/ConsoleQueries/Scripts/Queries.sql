﻿

-- Отображение всех данных таблциы-представления фактов аренды
select
	*
from 
	RentalFactsView;
go

-- Запросы по заданию

--1	Запрос к представлению
--	Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
declare @number nvarchar(6) = N'В467АР';

select
	RegNumber
	, BrandModel
	, Client
	, Passport
	, BeginDate
	, RentDays
from 
	RentalFactsView
where
	RegNumber = @number;
go


--2	Запрос к представлению
--	Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
declare @model nvarchar(30) = N'Mercedes Vito';

select
	RegNumber
	, BrandModel
	, Client
	, Passport
	, BeginDate
	, RentDays
from 
	RentalFactsView
where
	BrandModel = @model;
go


--3	Запрос к представлению
--	Выбирает информацию об автомобиле с заданным госномером
declare @number nvarchar(6) = N'В467АР';

select
	Id
	, RegNumber
	, BrandModel
	, Color
	, YearMade
	, InsuranceCost
	, DayCost
from 
	CarsView
where
	RegNumber = @number;
go

--4	Запрос с параметром
--	Выбирает информацию о клиентах по серии и номеру паспорта
declare @passport nvarchar(15) = N'9317024758';

select
	Id
	, Surname
	, Name
	, Patronymic
	, Passport
from	
	Clients
where Passport = @passport;
go

--5	Запрос к представлению	
--	Выбирает информацию обо всех зафиксированных фактах проката автомобилей
--	в некоторый заданный интервал времени.
declare @from date = '2021-05-01', @to date = '2021-08-01'

select
	RegNumber
	, BrandModel
	, Client
	, Passport
	, BeginDate
	, RentDays
from 
	RentalFactsView
where 
	BeginDate between @from and @to;
go


--6	Запрос к представлению	
--	Вычисляет для каждого факта проката стоимость проката. Включает поля Дата проката,
--	Госномер автомобиля, Модель автомобиля, Стоимость проката. Сортировка по полю Дата проката

select
	BeginDate
	, RegNumber
	, BrandModel
	, RentPrice
from 
	RentalFactsView
order by
	BeginDate;
go


--7	Запрос с левым соединением	
--	Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
--	суммарное количество дней проката, упорядочивание по убыванию суммарного
--	количества дней проката
select
	Clients.Surname
	, Clients.Name
	, Clients.Patronymic
	, Clients.Passport
	, Sum(RentDays) as TotalRentDays
	, Count(RentDays) as RentsCount
from  Clients left join RentalFactsView on Clients.Passport = RentalFactsView.Passport
group by
	Clients.Name
	, Clients.Surname
	, Clients.Patronymic
	, Clients.Passport
order by
	TotalRentDays;
go


--8	Итоговый запрос	
--	Выполняет группировку по полю Модель автомобиля.
--	Для каждой модели вычисляет количество фактов проката, сумму за прокат	
select
	BrandModel
	, Count(RentDays) as RentsCount
	, Sum(RentDays)	  as TotalRentDays
from	
	RentalFactsView
group by
	BrandModel;
go



--9	Запрос на добавление	
--	Добавляет данные о новом клиенте. Данные передавайте параметрами
declare @surname nvarchar(60) = N'Иванов', @name nvarchar(50) = N'Пётр', 
		@patronymic nvarchar(60) = N'Сергеевич', @passport nvarchar(15) = N'9321123456';

select * from Clients;

insert into RentalFactsView
	(Surname, Name, Patronymic, Passport)
values
	(@surname, @name, @patronymic, @passport);

select * from Clients;
go


--10	Запрос на обновление	
--	Изменяет данные клиента (все поля, кроме идентификатора). Данные передавайте параметрами
declare @passport nvarchar(15) = N'9320063452', @newPassport nvarchar(15) = N'9320999999',
		 @surname nvarchar(60) = N'Ливингстон', @name nvarchar(50) = N'Джонатан', 
		@patronymic nvarchar(60) = N'Чайкович';

select * from Clients;

update RentalFactsView
set
	Surname = @surname
	, Name = @name
	, Patronymic = @patronymic
	, Passport = @newPassport
where
	Passport = @passport;

select * from Clients;

go

--11	Запрос на обновление	
--	Изменяет данные автомобиля (все поля, кроме идентификатора). Данные передавайте параметрами
declare
@curRegNum nvarchar(6) = N'А550ЕР'

,@brandModel	nvarchar(30) = N'Toyota Corolla'
,@color		nvarchar(20) = N'Gray'	
,@yearMade	int			 = 2021	
,@regNumber	nvarchar(6)  = N'A123PO'	
,@insuranceCost	int		 = 100000
,@dayCost		int	     = 500;

select * from CarsView;

go

update Cars
set
	IdBrandModel = (select Id from BrandModels where BrandModel = @brandModel)
	, IdColor = (select Id from Colors where Color = @color)
	, YearMade = @yearMade
	, RegNumber = @regNumber
	, InsuranceCost = @insuranceCost
	, DayCost = @dayCost
where
	RegNumber = @curRegNum;

select * from CarsView;
