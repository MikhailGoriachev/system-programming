﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarRentQueriesLibrary;
using CarRentQueriesLibrary.Models;

namespace ConsoleQueries.Controllers
{
	
	public class Controller
	{
		private CarRentDataContext _dataContext;

		private Queries _queries;

		public Controller() :this(new CarRentDataContext())
		{
		}

		public Controller(CarRentDataContext dataContext)
		{
			_dataContext = dataContext;
			_queries = new Queries(_dataContext);
		}

		public List<CarRentQueriesLibrary.Models.RentalFactsWhereAuto> Query01(string regNum) => 
			_queries.GetRentalFactsWhereRegNum(regNum);

		public List<CarRentQueriesLibrary.Models.RentalFactsWhereAuto> Query02(string brandModel) => 
			_queries.GetRentalFactsWhereBrandModel(brandModel);

		public List<CarRentQueriesLibrary.Models.Clients> Query03(string passport) => 
			_queries.GetClientsWherePassport(passport);

		public List<CarRentQueriesLibrary.Models.RentalFactCost> Query04() => 
			_queries.GetRentalFactsCost();

		public List<CarRentQueriesLibrary.Models.ClientRentalInfo> Query05() => 
			_queries.GetClientsRentalInfos();
	}
}
