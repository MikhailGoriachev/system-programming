﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Alba.CsConsoleFormat;
using ConsoleQueries.Controllers;
using ConsoleQueries.Helpers;

namespace ConsoleQueries.Application
{
	public class App
	{
		private static Controller _controller;

		private static int _counter = 1;

		public App() : this(new Controller())
		{
		}

		public App(Controller controller)
		{
			_controller = controller;
		}

		public void Run()
		{
			Timer timer = new Timer(TimerMethod, null, 100, 2000);

			Console.ReadKey();
		}

		private static void TimerMethod(object obj)
		{
			Console.Clear();

			string arg;
			switch (_counter % 5)
			{
				case 0:
					arg = QueriesArgsLists.GetRegNumRand;
					Console.WriteLine($"\n\n    Информация обо всех фактах проката автомобиля с госномером {arg}:");
					_controller.Query01(arg).ConsoleOutput();
					break;
				case 1:
					arg = QueriesArgsLists.GetBrandModelRand;
					Console.WriteLine(
						$"\n\n    Информация обо всех фактах проката автомобиля с заданной моделью/брендом {arg}:");
					_controller.Query02(QueriesArgsLists.GetBrandModelRand).ConsoleOutput();
					break;
				case 2:
					arg = QueriesArgsLists.GetRegPassportRand;
					Console.WriteLine($"\n\n    Информация о клиентах по серии и номером паспорта {arg}:");
					_controller.Query03(QueriesArgsLists.GetRegPassportRand).ConsoleOutput();
					break;
				case 3:
					Console.WriteLine($"\n\n    Для каждого факта проката вычислена стоимость проката:");
					_controller.Query04().ConsoleOutput();
					break;
				case 4:
					Console.WriteLine(
						$"\n\n    Для всех клиентов прокатной фирмы вычислено количество фактов проката, суммарное количество дней проката,\n" +
						$"    упорядочивание по убыванию суммарного количества дней проката:");
					_controller.Query05().ConsoleOutput();
					break;
			}

			_counter++;
		}
	}
}
