﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleQueries.Helpers
{
	public static class QueriesArgsLists
	{
		public static string GetRegNumRand => RegNumbers[Utilities.GenerateInt(0, RegNumbers.Length)];
		public static string GetBrandModelRand => BrandModels[Utilities.GenerateInt(0, BrandModels.Length)];
		public static string GetRegPassportRand => Passports[Utilities.GenerateInt(0, Passports.Length)];

		public static string[] RegNumbers =
		{
			"А550ЕР",
			"В467АР",
			"А247ВВ",
			"Н791МВ",
			"Е155РХ",
			"С441УЕ",
			"В789РО",
			"В990СМ",
			"C656ЧВ",
			"В635НЕ"
		};

	
		public static string[] BrandModels =
		{
			"Mitsubishi Lancer",
			"Mercedes Vito	",
			"Hyundai Solaris",
			"Honda Accord",
			"Ford Fusion",
			"Volkswagen Passat",
			"Lexus RX",
			"Mazda 6",
			"Toyota Aqua",
			"Honda Civic"
		};

		public static string[] Passports =
		{
			"9320063452",
			"9317063685",
			"9317024758",
			"9318016981",
			"9316063233",
			"9319005575",
			"9320001479",
			"9316063474",
			"9316060547",
			"9319063779",
			"9321044681",
			"9320126153",
			"9320146876"
		};

		
	}
}
