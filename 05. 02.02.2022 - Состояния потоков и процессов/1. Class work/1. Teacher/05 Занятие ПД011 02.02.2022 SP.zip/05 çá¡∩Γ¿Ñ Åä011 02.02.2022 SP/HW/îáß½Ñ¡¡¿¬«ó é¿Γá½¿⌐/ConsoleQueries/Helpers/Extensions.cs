﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Alba.CsConsoleFormat;
using static System.ConsoleColor;
using Alba.CsConsoleFormat.Fluent;
using Colors = Alba.CsConsoleFormat.Fluent.Colors;

namespace ConsoleQueries.Helpers
{
	public static class Extensions
	{
		private static readonly LineThickness headerThickness = new LineThickness(LineWidth.Double, LineWidth.Single);

		private static readonly ConsoleColor HeaderColor = ConsoleColor.Yellow;
		private static readonly ConsoleColor StrokeColor = ConsoleColor.Gray;
		private static readonly ConsoleColor CellColor = ConsoleColor.White;

		public static void ConsoleOutput(this List<CarRentQueriesLibrary.Models.RentalFactsWhereAuto> data)
		{
			
			var doc = new Document(
				new Grid
				{
					Color = DarkGreen,
					Margin = new Thickness(4, 2, 0, 0),
					StrokeColor = StrokeColor,
					Columns = { GridLength.Auto, GridLength.Auto, GridLength.Auto, GridLength.Auto, GridLength.Auto, GridLength.Auto },
					Children = {
						new Cell("Id") { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						new Cell("Фамилия И.О.")          { Stroke = headerThickness, Color = HeaderColor ,
							Padding = new Thickness(2,0)},
						new Cell("Модель автомобиля")        { Stroke = headerThickness, Color = HeaderColor ,
							Padding = new Thickness(2,0)},
						new Cell("Госномер автомобиля")          { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						new Cell("Дата начала аренды") { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						new Cell("Длительность аренды") { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						data.Select(item => new[] {
							new Cell(item.Id){Color = CellColor, Align = Align.Center},
							new Cell(item.Client){Color = CellColor, Padding = new Thickness(1,0)},
							new Cell(item.BrandModel){Color = CellColor, Padding = new Thickness(1,0)},
							new Cell(item.RegNum){Color = CellColor, Padding = new Thickness(1,0)},
							new Cell($"{item.BeginDate:dd/MM/yyyy}") {Color = CellColor, Padding = new Thickness(1,0)},
							new Cell(item.Duration) { Align = Align.Right, Color = CellColor }
						})
					}
				}
			);

			ConsoleRenderer.RenderDocument(doc);
		}

		public static void ConsoleOutput(this List<CarRentQueriesLibrary.Models.Clients> data)
		{
			var doc = new Document(
				new Grid
				{
					Color = DarkGreen,
					Margin = new Thickness(4, 2, 0, 0),
					StrokeColor = StrokeColor,
					Columns = { GridLength.Auto, GridLength.Auto, GridLength.Auto, GridLength.Auto, GridLength.Auto },
					Children = {
						new Cell("Id") { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						new Cell("Фамилия")          { Stroke = headerThickness, Color = HeaderColor ,
							Padding = new Thickness(2,0)},
						new Cell("Имя") { Stroke = headerThickness, Color = HeaderColor ,
							Padding = new Thickness(2,0)},
						new Cell("Отчество")          { Stroke = headerThickness, Color = HeaderColor ,
							Padding = new Thickness(2,0)},
						new Cell("Серия паспорта")        { Stroke = headerThickness, Color = HeaderColor ,
							Padding = new Thickness(2,0)},

						data.Select(item => new[] {
							new Cell(item.Id){Color = CellColor, Align = Align.Center},
							new Cell(item.Surname){Color = CellColor, Padding = new Thickness(1,0)},
							new Cell(item.Name){Color = CellColor, Padding = new Thickness(1,0)},
							new Cell(item.Patronymic){Color = CellColor, Padding = new Thickness(1,0)},
							new Cell(item.Passport){Color = CellColor, Padding = new Thickness(1,0)}
						})
					}
				}
			);

			ConsoleRenderer.RenderDocument(doc);
		}

		public static void ConsoleOutput(this List<CarRentQueriesLibrary.Models.RentalFactCost> data)
		{
			var doc = new Document(
				new Grid
				{
					Color = DarkGreen,
					Margin = new Thickness(4, 2, 0, 0),
					StrokeColor = StrokeColor,
					Columns = { GridLength.Auto, GridLength.Auto, GridLength.Auto, GridLength.Auto, GridLength.Auto, GridLength.Auto, GridLength.Auto },
					Children = {
						new Cell("Id") { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						new Cell("Дата начала аренды") { Stroke = headerThickness, Color = HeaderColor ,
							Padding = new Thickness(2,0)},
						new Cell("Госномер автомобиля")        { Stroke = headerThickness, Color = HeaderColor ,
							Padding = new Thickness(2,0)},
						new Cell("Модель автомобиля")          { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						new Cell("Стоимость в день") { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						new Cell("Количество дней") { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						new Cell("Итоговая стоимость") { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						data.Select(item => new[] {
							new Cell(item.Id){Color = CellColor, Align = Align.Center},
							new Cell($"{item.BeginDate:dd/MM/yyyy}") {Color = CellColor, Padding = new Thickness(1,0)},
							new Cell(item.RegNum) {Color = CellColor, Padding = new Thickness(1,0)},
							new Cell(item.BrandModel){Color = CellColor, Padding = new Thickness(1,0)},
							new Cell(item.DayCost) { Align = Align.Right, Color = CellColor },
							new Cell(item.Duration) { Align = Align.Right, Color = CellColor },
							new Cell(item.TotalCost) { Align = Align.Right, Color = CellColor }
						})
					}
				}
			);

			ConsoleRenderer.RenderDocument(doc);
		}


		public static void ConsoleOutput(this List<CarRentQueriesLibrary.Models.ClientRentalInfo> data)
		{
			var doc = new Document(
				new Grid
				{
					Color = DarkGreen,
					Margin = new Thickness(4, 2, 0, 0),
					StrokeColor = StrokeColor,
					Columns = { GridLength.Auto, GridLength.Auto, GridLength.Auto, GridLength.Auto, GridLength.Auto },
					Children = {
						new Cell("Id") { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						new Cell("Фамилия И.О.")          { Stroke = headerThickness, Color = HeaderColor ,
							Padding = new Thickness(2,0)},
						new Cell("Серия паспорта")        { Stroke = headerThickness, Color = HeaderColor ,
							Padding = new Thickness(2,0)},
						new Cell("Кол-во аренд")          { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						new Cell("Всего дней аренды") { Stroke = headerThickness, Color = HeaderColor,
							Padding = new Thickness(2,0)},
						data.Select(item => new[] {
							new Cell(item.Id){Color = CellColor, Align = Align.Center},
							new Cell(item.Client){Color = CellColor, Padding = new Thickness(1,0)},
							new Cell(item.Passport){Color = CellColor, Padding = new Thickness(1,0)},
							new Cell(item.RentsCount) { Align = Align.Right, Color = CellColor },
							new Cell(item.TotalRentDays) { Align = Align.Right, Color = CellColor }
						})
					}
				}
			);

			ConsoleRenderer.RenderDocument(doc);
		}
	}
}
