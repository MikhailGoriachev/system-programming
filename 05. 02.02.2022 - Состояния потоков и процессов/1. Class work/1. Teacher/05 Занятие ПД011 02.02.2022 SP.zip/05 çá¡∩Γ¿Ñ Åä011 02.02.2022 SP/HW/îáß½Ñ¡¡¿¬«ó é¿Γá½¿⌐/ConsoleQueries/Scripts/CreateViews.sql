﻿drop view if exists RentalFactsView;
drop view if exists CarsView;
go

-- представление с выборкой данных из таблицы фактов аренды
create view RentalFactsView as
	select
		RentalFacts.Id
		, BrandModels.BrandModel	 -- бренд-модель авто
		, Colors.Color				 -- цвет авто
		, Cars.YearMade				 -- год пр-ва авто
		, Cars.RegNumber			 -- гос номер авто
		, Cars.InsuranceCost		 -- страх. ст-сть авто
		, Cars.DayCost				 -- дневная ст-сть аренды авто
		, Clients.Surname			 -- фамилия клиента
		, Clients.Name				 -- имя клиента
		, Clients.Patronymic		 -- отчество клиента
		, Surname + N' ' + Substring([Name], 1, 1) 
				  + N'.' + Substring(Patronymic, 1, 1) 
				  + N'.' as Client   -- Фамилия И.О. клиента
		, Clients.Passport			 -- номер паспорта клиента
		--							 
		, RentalFacts.BeginDate		 -- дата начала аренды
		, RentalFacts.RentDays		 -- кол-во дней аренды
		, RentDays * DayCost as RentPrice -- полная стоимость аренды
from
	RentalFacts join (Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id
						   join Colors	    on Cars.IdColor	     = Colors.Id) on RentalFacts.IdCar = Cars.Id
				join Clients on RentalFacts.IdClient = Clients.Id;
go

-- представление с выборкой данных из таблицы клиентов
create view CarsView as
	select
		Cars.Id
		, Cars.RegNumber
		, BrandModels.BrandModel
		, Colors.Color
		, Cars.YearMade
		, Cars.InsuranceCost
		, Cars.DayCost
	from Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id
			  join Colors	    on Cars.IdColor	     = Colors.Id;
go
