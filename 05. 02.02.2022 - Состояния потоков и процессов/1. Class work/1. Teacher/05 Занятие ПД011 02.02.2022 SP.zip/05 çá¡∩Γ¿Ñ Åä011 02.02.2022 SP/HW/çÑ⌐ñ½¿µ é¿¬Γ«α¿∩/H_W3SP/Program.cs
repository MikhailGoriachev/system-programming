﻿using H_W3SP.Application;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;        // для ADO.NET
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Configuration;


namespace H_W3SP
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Домашнее задание № 3.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1.База данных «Прокат автомобилей» таблица КЛИЕНТЫ." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1.База данных «Прокат автомобилей» таблица АВТОМОБИЛИ." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1.База данных «Прокат автомобилей» таблица ФАКТЫ_ПРОКАТА." },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 1.Выбирает все факты проката автомобиля с заданным госномером." },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 1.Выбирает все факты проката автомобиля с заданной моделью/брендом." },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Задача 1.Выбирает информацию о клиентах по серии и номеру паспорта." },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Задача 1.Вычисляет для каждого факта проката стоимость проката." },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Задача 1.Для всех клиентов прокатной фирмы вычисляет количество фактов проката." },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Задача 1.Для всех автомобилей прокатной фирмы вычисляет количество фактов проката." },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2.Приложение, по таймеру, с интервалом 2 секунды, выполняющее запросы 1, …, 5. ." },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

                // Создание экземпляра класса приложения
                App app = new App();

                // главный цикл приложения
                while (true)
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkCyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(20, 5, "Меню приложения База данных «Прокат автомобилей»", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        // База данных «Прокат автомобилей» таблица КЛИЕНТЫ.
                        case ConsoleKey.Q:
                           app.QueryTableClient();
                            break;

                        // База данных «Прокат автомобилей» таблица АВТОМОБИЛИ
                        case ConsoleKey.W:
                           app.QueryTableCar();
                            break;

                        // База данных «Прокат автомобилей» таблица ФАКТЫ_ПРОКАТА
                        case ConsoleKey.E:
                            app.QueryTableRental();
                            break;

                        // Выбирает все факты проката автомобиля с заданным госномером
                        case ConsoleKey.R:
                            app.Query01();
                            break;

                        // Выбирает все факты проката автомобиля с заданной моделью/брендом
                        case ConsoleKey.T:
                            app.Query02();
                            break;

                        // Выбирает информацию о клиентах по серии и номеру паспорта
                        case ConsoleKey.Y:
                            app.Query03();
                            break;

                        // Вычисляет для каждого факта проката стоимость проката
                        case ConsoleKey.U:
                            app.Query04();
                            break;

                        // Для всех клиентов прокатной фирмы вычисляет количество фактов проката
                        case ConsoleKey.I:
                            app.Query05();
                            break;

                        // Для всех автомобилей прокатной фирмы определите количество фактов проката
                        case ConsoleKey.O:
                            app.Query06();
                            break;

                        // Приложение, по таймеру, с интервалом 2 секунды, выполняющее запросы 1, …, 5. 
                        case ConsoleKey.A:
                            app.QueryTimer();
                            break;

                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                            Console.CursorVisible = true;
                            return;
                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                    Console.ReadKey(true);
                
                } // while

            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}");
                //throw;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;

        }// Main
    }
}
