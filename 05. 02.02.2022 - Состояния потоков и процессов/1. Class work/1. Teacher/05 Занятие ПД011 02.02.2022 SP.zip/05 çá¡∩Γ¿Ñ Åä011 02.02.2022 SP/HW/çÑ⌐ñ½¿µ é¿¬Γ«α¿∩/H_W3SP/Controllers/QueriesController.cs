﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarRentalLibrary;


namespace H_W3SP.Controllers
{
    public class QueriesController
    {
        // связь с базой данных
        private CarRentalDataContext _db;

        public QueriesController() : this(new CarRentalDataContext()) { }

        public QueriesController(CarRentalDataContext db)
        {
            _db = db;
        } // QueriesController

        // Таблицы базы данных «Прокат автомобилей»

        public void TableClients()
        {
            var query = _db.Clients.ToList();

            Console.WriteLine("\n\n\n Таблица КЛИЕНТЫ :\n" +
                  "--------------------------------------------------------------------------------------\n" +
                  "  Идентификатор    Фамилия        Имя             Отчество       Паспортные данные\n" +
                  "--------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Id,12}   {p.Surname,-15} {p.Name,-15}  {p.Patronymic,-15}  " +
                                  $"{p.PassportNum,10}");
            } // for p
            Console.WriteLine("--------------------------------------------------------------------------------------" +
                "\n");
        }// TableClients


        public void TableCars()
        {
            var query = _db.Cars
                .Select(cars => new
                {
                    cars.Id,
                    cars.Models.Model,
                    cars.Colors.Color,
                    cars.CarNumber,
                    cars.Year,
                    cars.InsurancePay,
                    cars.PayRentalDay
                }).ToList();

            Console.WriteLine("\n\n\n Таблица АВТОМОБИЛИ :\n" +
               "---------------------------------------------------------------------------------------------------\n" +
               "  ID    Модель     Цвет      Госномер     Год выпуска  Страховая стоимость  Стоимость 1дн. проката\n" +
               "---------------------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Id,3}   {p.Model,-10} {p.Color,-12} {p.CarNumber, 6}  " +
                                  $"{p.Year,10} {p.InsurancePay, 19} {p.PayRentalDay, 20}");
            } // for p
            Console.WriteLine("---------------------------------------------------------------------------------------------------" +
                "\n");
        }// TableCars


        public void TableRentals()
        {
            var query = _db.Rentals
                .Select(rental => new
                {
                    rental.Id,
                    rental.Cars.Models.Model,
                    rental.RentalStartDate,
                    rental.Duration
                })
                .ToList();

            Console.WriteLine("\n\n\n Таблица ФАКТЫ_ПРОКАТА :\n" +
                "----------------------------------------------------------------------------\n" +
                "  Идентификатор    Модель   Дата начала проката     Количество дн. проката\n" +
                "----------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Id,10}        {p.Model,-10} {p.RentalStartDate,15:d}  {p.Duration, 25} ");
            } // for p
            Console.WriteLine("----------------------------------------------------------------------------" +
                "\n");
        }// TableRentals

        // Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
        public void Query01()
        {
            var query = _db.Rentals
                .Where(rental => rental.Cars.CarNumber == "X739OC")
                .Select(r => new
                {
                    Client = r.Clients.Surname + " " + r.Clients.Name[0] + "." + r.Clients.Patronymic[0] + ".",
                    r.Cars.Models.Model,
                    r.Cars.CarNumber,
                    r.RentalStartDate,
                    r.Cars.PayRentalDay,
                    r.Duration
                })
                .ToList();

            Console.WriteLine("\n\n\n Факты проката автомобиля с заданным госномером :\n" +
               "------------------------------------------------------------------------------------------------------------\n" +
               "  Клиенты           Модель    Госномер   Дата начала проката  Стоимость 1дн.проката  Количество дн.проката\n" +
               "------------------------------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Client,-17}   {p.Model,-2} {p.CarNumber, 12} {p.RentalStartDate,17:d}  " +
                                  $" {p.PayRentalDay,20} {p.Duration,19} ");
            } // for p
            Console.WriteLine("------------------------------------------------------------------------------------------------------------" +
                "\n");
        }// Query01


        // Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
        public void Query02()
        {
            var query = _db.Rentals
                .Where(rental => rental.Cars.Models.Model == "Lexus")
                .Select(r => new
                {
                    Client = r.Clients.Surname + " " + r.Clients.Name[0] + "." + r.Clients.Patronymic[0] + ".",
                    r.Cars.Models.Model,
                    r.Cars.CarNumber,
                    r.RentalStartDate,
                    r.Cars.PayRentalDay,
                    r.Duration
                })
                .ToList();

            Console.WriteLine("\n\n\n Факты проката автомобиля с заданным заданной моделью/брендом:\n" +
               "------------------------------------------------------------------------------------------------------------\n" +
               "  Клиенты           Модель    Госномер   Дата начала проката  Стоимость 1дн.проката  Количество дн.проката\n" +
               "------------------------------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Client,-17}   {p.Model,-2} {p.CarNumber,12} {p.RentalStartDate,17:d}  " +
                                  $" {p.PayRentalDay,20} {p.Duration,19} ");
            } // for p
            Console.WriteLine("------------------------------------------------------------------------------------------------------------" +
                "\n");
        }// Query02


        // Выбирает информацию о клиентах по серии и номеру паспорта
        public void Query03()
        {
            var query = _db.Clients
                .Where(client => client.PassportNum == "OH830853")
                .ToList();

            Console.WriteLine("\n\n\n Информация о клиентах по серии и номеру паспорта:\n" +
                  "--------------------------------------------------------------------------------------\n" +
                  "  Идентификатор    Фамилия        Имя             Отчество       Паспортные данные\n" +
                  "--------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Id,12}   {p.Surname,-15} {p.Name,-15}  {p.Patronymic,-15}  " +
                                  $"{p.PassportNum,10}");
            } // for p
            Console.WriteLine("--------------------------------------------------------------------------------------" +
                "\n");

        }// Query03


        // Вычисляет для каждого факта проката стоимость проката.
        // Включает поля Дата проката, Госномер автомобиля,
        // Модель автомобиля, Стоимость проката.
        // Сортировка по полю Дата проката
        public void Query04()
        {
            var query = _db.Rentals
                .Select(r => new
                {
                    r.RentalStartDate,
                    r.Cars.CarNumber,
                    r.Cars.Models.Model,
                    CostRental = r.Cars.PayRentalDay * r.Duration
                })
                .OrderBy(r => r.RentalStartDate)
                .ToList();

            Console.WriteLine("\n\n\n Вычисляет для каждого факта проката стоимость проката :\n" +
               "-------------------------------------------------------------------------\n" +
               "  Дата начала проката     Госномер      Модель       Стоимость проката\n" +
               "-------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.RentalStartDate,18:d} {p.CarNumber,12}        {p.Model, -12} {p.CostRental, 14} ");
            } // for p
            Console.WriteLine("-------------------------------------------------------------------------" +
                "\n");
        }// Query04


        // Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
        // суммарное количество дней проката, упорядочивание по
        // убыванию суммарного количества дней проката
        public void Query05()
        {
            var query = _db.Rentals.GroupBy(r => r.IdClient, (key, group) => new
            {
                SurnameNP = group.Where(s => s.IdClient == key).Select(s => s.Clients.Surname + " " + s.Clients.Name[0] + "." + s.Clients.Patronymic[0] + ".").First(),
                AmountRental = group.Count(),
                SumRentalDays = group.Sum(r => r.Duration)
            })
            .OrderByDescending(r => r.SumRentalDays)
            .ToList();

            Console.WriteLine("\n\n\n Для всех клиентов прокатной фирмы вычисляет количество фактов проката:\n" +
                "--------------------------------------------------------------------------------------\n" +
                "   ФИО клиента         Кол-во фактов проката   Суммарное кол-во дн.проката\n" +
                "--------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($"  {p.SurnameNP,-15}   {p.AmountRental,20} {p.SumRentalDays, 20} ");
            } // for p
            Console.WriteLine("--------------------------------------------------------------------------------------" +
                "\n");
        }// Query05


        // Для всех автомобилей прокатной фирмы определите количество фактов проката,
        // сумма за прокаты, суммарная длительность прокатов
        public void Query06()
        {
            var query = _db.Rentals.GroupBy(r => r.IdCar, (key, group) => new
            {
                CarsModel = group.Where(r => r.IdCar == key).Select(c => c.Cars.Models.Model).First(),
                AmountRental = group.Count(),
                TotalRental = group.Sum(r => r.Duration * r.Cars.PayRentalDay),
                TotalDuration = group.Sum(r => r.Duration)
            })
            .ToList();

            Console.WriteLine("\n\n\n Для всех автомобилей прокатной фирмы определите количество фактов проката:\n" +
               "-------------------------------------------------------------------------------------------\n" +
               "   Модель авто         Кол-во фактов проката   Cумма за прокаты   Сумма длительн.проката\n" +
               "-------------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($"    {p.CarsModel,-15}   {p.AmountRental,20} {p.TotalRental, 20} {p.TotalDuration,20} ");
            } // for p
            Console.WriteLine("-------------------------------------------------------------------------------------------" +
                "\n");
        }// Query06

    }// class QueriesController
}
