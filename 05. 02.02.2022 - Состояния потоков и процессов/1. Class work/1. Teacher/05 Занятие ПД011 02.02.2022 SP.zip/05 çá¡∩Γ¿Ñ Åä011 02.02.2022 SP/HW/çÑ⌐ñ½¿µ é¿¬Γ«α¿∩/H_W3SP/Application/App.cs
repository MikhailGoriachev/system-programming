﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using H_W3SP.Controllers;

namespace H_W3SP.Application
{
    // Класс приложения - обработка по заданию
    internal partial class App
    {
        private QueriesController _queriesController;

        // конструктор с внедрением зависимостей
        public App() : this(new QueriesController()) { }

        public App(QueriesController db)
        {
            _queriesController = db;
        } // App

    }// class App
}
