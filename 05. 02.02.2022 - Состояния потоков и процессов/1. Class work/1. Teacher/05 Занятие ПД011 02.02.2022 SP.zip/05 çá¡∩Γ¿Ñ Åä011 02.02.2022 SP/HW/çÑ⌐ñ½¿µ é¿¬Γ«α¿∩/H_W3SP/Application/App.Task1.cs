﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;       // для класса Timer

namespace H_W3SP.Application
{
    internal partial class App
    {
        public void QueryTableClient()
        {
            Utils.ShowNavBarTask("   База данных «Прокат автомобилей» таблица КЛИЕНТЫ.");

            _queriesController.TableClients();
        }// QueryTableClient


        public void QueryTableCar()
        {
            Utils.ShowNavBarTask("   База данных «Прокат автомобилей» таблица АВТОМОБИЛИ.");

            _queriesController.TableCars();
        }// QueryTableCar

        public void QueryTableRental()
        {
            Utils.ShowNavBarTask("   База данных «Прокат автомобилей» таблица ФАКТЫ_ПРОКАТА.");

            _queriesController.TableRentals();
        }// QueryTableRental


        public void Query01()
        {
            Utils.ShowNavBarTask("   Выбирает информацию обо всех фактах" +
                " проката автомобиля с заданным госномером.");

            _queriesController.Query01();
        }// Query01

        public void Query02()
        {
            Utils.ShowNavBarTask("   Выбирает информацию обо всех фактах проката" +
                " автомобиля с заданной моделью/брендом.");

            _queriesController.Query02();
        }// Query02


        public void Query03()
        {
            Utils.ShowNavBarTask("   Выбирает информацию о клиентах по серии и номеру паспорта.");

            _queriesController.Query03();
        }// Query03


        public void Query04()
        {
            Utils.ShowNavBarTask("   Вычисляет для каждого факта проката стоимость проката.\n" +
                "  Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.\n" +
                "  Сортировка по полю Дата проката.");

            _queriesController.Query04();
        }// Query04


        public void Query05()
        {
            Utils.ShowNavBarTask("   Для всех клиентов прокатной фирмы вычисляет количество фактов проката,\n" +
                "  суммарное количество дней проката, упорядочивание по убыванию\n" +
                "  суммарного количества дней проката.");

            _queriesController.Query05();
        }// Query05


        public void Query06()
        {
            Utils.ShowNavBarTask("   Для всех автомобилей прокатной фирмы определите количество фактов проката,\n" +
                "  сумма за прокаты, суммарная длительность прокатов.");

            _queriesController.Query06();
        }// Query06


        // Разработайте консольное приложение, по таймеру, с интервалом 2 секунды,
        // выполняющее запросы 1, …, 5. После выполнения запроса 5 требуется перейти к
        // выполнению запроса 1 и т.д., в бесконечном цикле.
        public void QueryTimer()
        {
            int counter = 1;
            Timer timer = new Timer(o => {

                switch (counter % 5)
                {
                    case 1:
                        Console.Write("\t\tЗапрос 1");
                        _queriesController.Query01();
                        Thread.Sleep(2000);
                        break;
                    case 2:
                        Console.Write("\t\tЗапрос 2");
                        _queriesController.Query02();
                        Thread.Sleep(2000);
                        break;
                    case 3:
                        Console.Write("\t\tЗапрос 3");
                        _queriesController.Query03();
                        Thread.Sleep(2000);
                        break;
                    case 4:
                        Console.Write("\t\tЗапрос 4");
                        _queriesController.Query04();
                        Thread.Sleep(2000);
                        break;
                    default:
                        Console.Write("\t\tЗапрос 5");
                        _queriesController.Query05();
                        Thread.Sleep(2000);
                        break;                        
                } // switch

                ++counter;
                Console.Clear();
            });
            
            // запуск с задержкой 1000 мс, затем период запуска 3000 мс
            timer.Change(2000, 3000);
        }// QueryTimer

    }// class App
}
