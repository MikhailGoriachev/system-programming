﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarRentalLibrary;

namespace Task3WFLINQtoSQL.Controllers
{
    public class QueriesController
    {
        // связь с базой данных
        private CarRentalDataContext _db;

        public QueriesController() : this(new CarRentalDataContext()) { }

        public QueriesController(CarRentalDataContext db)
        {
            _db = db;
        } // QueriesController

        // Таблицы базы данных «Прокат автомобилей»
        public IEnumerable TableClients() => _db.Clients.ToList();
        public IEnumerable TableCars() => 
            _db.Cars
            .Select(cars => new
            {
                cars.Id,
                cars.Models.Model,
                cars.Colors.Color,
                cars.CarNumber,
                cars.Year,
                cars.InsurancePay,
                cars.PayRentalDay
            })
            .ToList();

        public IEnumerable TableRentals() => _db.Rentals
           .Select(rental => new
           {
               rental.Id,
               rental.Cars.Models.Model,
               rental.RentalStartDate,
               rental.Duration
           })
           .ToList();

        // Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
        public IEnumerable Query01() => _db.Rentals
            .Where(rental => rental.Cars.CarNumber == "X739OC")
            .Select(r => new
            {
               Client = r.Clients.Surname + " " + r.Clients.Name[0] + "." + r.Clients.Patronymic[0] + ".",
               r.Cars.Models.Model,
               r.Cars.CarNumber,
               r.RentalStartDate,
               r.Cars.PayRentalDay,
               r.Duration
            })
            .ToList();


    }// class QueriesController
}
