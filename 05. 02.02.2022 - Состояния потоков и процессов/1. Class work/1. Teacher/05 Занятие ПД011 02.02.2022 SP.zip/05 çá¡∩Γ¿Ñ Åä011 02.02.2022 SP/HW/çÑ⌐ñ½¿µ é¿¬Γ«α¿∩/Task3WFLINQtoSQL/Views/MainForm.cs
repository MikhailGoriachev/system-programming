﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task3WFLINQtoSQL.Controllers;


namespace Task3WFLINQtoSQL.Views
{
    public partial class MainForm : Form
    {
        private QueriesController _queriesController;

        public MainForm() : this(new QueriesController()) { }
        public MainForm(QueriesController queriesController)
        {
            InitializeComponent();

            _queriesController = queriesController;


        } // MainForm


        private void MainForm_Load(object sender, EventArgs e)
        {

            DgvTableClients.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvTableClients.DataSource = _queriesController.TableClients();
            DgvTableClients.ClearSelection();
            LblTblСlients.Text = "Таблица КЛИЕНТЫ";

            DgvTblClients.DataSource = _queriesController.TableCars();
            LblTblCars.Text = "Таблица АВТОМОБИЛИ";

            DgvTblRentals.DataSource = _queriesController.TableRentals();
            LblTblRentals.Text = "Таблица ФАКТЫ_ПРОКАТА";
        }// MainForm_Load

        private void Exit_Command(object sender, EventArgs e) => Application.Exit();


        private void About_Command(object sender, EventArgs e) =>
            new AboutForm().ShowDialog();

        private void TableClients_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbcTblClients;

            DgvTableClients.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvTableClients.DataSource = _queriesController.TableClients();

            DgvTableClients.ClearSelection();
            LblTblСlients.Text = "Таблица КЛИЕНТЫ";
        }// TableClients_Command

        private void TableCars_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbcTblCars;

            DgvTblClients.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvTblClients.DataSource = _queriesController.TableCars();

            DgvTblClients.ClearSelection();
            LblTblCars.Text = "Таблица АВТОМОБИЛИ";
        }// TableCars_Command

        private void TableRentals_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbcTblRentals;

            DgvTblRentals.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvTblRentals.DataSource = _queriesController.TableRentals();

            DgvTblRentals.ClearSelection();
            LblTblRentals.Text = "Таблица ФАКТЫ_ПРОКАТА";
        }// TableRentals_Command

        // вывод к первому запросу в DataGridView
        private void Query01_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbcQuery01;
            DgvQuery01.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvQuery01.DataSource = _queriesController.Query01();

            DgvQuery01.ClearSelection();
            LblQuery01.Text = "Выбирает информацию обо всех фактах проката автомобиля с заданным госномером";
        }// Query01_Command

    }// class MainForm
}
