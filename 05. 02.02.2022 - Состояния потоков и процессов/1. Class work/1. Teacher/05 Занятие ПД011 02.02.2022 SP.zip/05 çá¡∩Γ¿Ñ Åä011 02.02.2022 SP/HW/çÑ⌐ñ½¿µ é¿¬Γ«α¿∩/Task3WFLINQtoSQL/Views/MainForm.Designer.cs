﻿
namespace Task3WFLINQtoSQL.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnuMain = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbMain = new System.Windows.Forms.ToolStrip();
            this.таблицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbcTblClients = new System.Windows.Forms.TabPage();
            this.TbcTblCars = new System.Windows.Forms.TabPage();
            this.LblTblСlients = new System.Windows.Forms.Label();
            this.DgvTableClients = new System.Windows.Forms.DataGridView();
            this.LblTblCars = new System.Windows.Forms.Label();
            this.DgvTblClients = new System.Windows.Forms.DataGridView();
            this.TbcTblRentals = new System.Windows.Forms.TabPage();
            this.LblTblRentals = new System.Windows.Forms.Label();
            this.DgvTblRentals = new System.Windows.Forms.DataGridView();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TcbTableClients = new System.Windows.Forms.ToolStripButton();
            this.TcbTableCars = new System.Windows.Forms.ToolStripButton();
            this.TcbTableRentals = new System.Windows.Forms.ToolStripButton();
            this.TcbQuery01 = new System.Windows.Forms.ToolStripButton();
            this.TcbAboutProgram = new System.Windows.Forms.ToolStripButton();
            this.MniExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTblСlients = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTblСars = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTblRentals = new System.Windows.Forms.ToolStripMenuItem();
            this.MniAboutProgram = new System.Windows.Forms.ToolStripMenuItem();
            this.TbcQuery01 = new System.Windows.Forms.TabPage();
            this.LblQuery01 = new System.Windows.Forms.Label();
            this.DgvQuery01 = new System.Windows.Forms.DataGridView();
            this.MnuMain.SuspendLayout();
            this.TsbMain.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbcTblClients.SuspendLayout();
            this.TbcTblCars.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTableClients)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTblClients)).BeginInit();
            this.TbcTblRentals.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTblRentals)).BeginInit();
            this.TbcQuery01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).BeginInit();
            this.SuspendLayout();
            // 
            // MnuMain
            // 
            this.MnuMain.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.таблицыToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.MnuMain.Location = new System.Drawing.Point(0, 0);
            this.MnuMain.Name = "MnuMain";
            this.MnuMain.Size = new System.Drawing.Size(984, 24);
            this.MnuMain.TabIndex = 0;
            this.MnuMain.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniExit});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // TsbMain
            // 
            this.TsbMain.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TcbTableClients,
            this.TcbTableCars,
            this.TcbTableRentals,
            this.toolStripSeparator1,
            this.TcbQuery01,
            this.toolStripSeparator2,
            this.TcbAboutProgram});
            this.TsbMain.Location = new System.Drawing.Point(0, 24);
            this.TsbMain.Name = "TsbMain";
            this.TsbMain.Size = new System.Drawing.Size(984, 39);
            this.TsbMain.TabIndex = 1;
            this.TsbMain.Text = "toolStrip1";
            // 
            // таблицыToolStripMenuItem
            // 
            this.таблицыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTblСlients,
            this.MniTblСars,
            this.MniTblRentals});
            this.таблицыToolStripMenuItem.Name = "таблицыToolStripMenuItem";
            this.таблицыToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.таблицыToolStripMenuItem.Text = "Таблицы";
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbcTblClients);
            this.TbcMain.Controls.Add(this.TbcTblCars);
            this.TbcMain.Controls.Add(this.TbcTblRentals);
            this.TbcMain.Controls.Add(this.TbcQuery01);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Location = new System.Drawing.Point(0, 63);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(984, 498);
            this.TbcMain.TabIndex = 2;
            // 
            // TbcTblClients
            // 
            this.TbcTblClients.Controls.Add(this.DgvTableClients);
            this.TbcTblClients.Controls.Add(this.LblTblСlients);
            this.TbcTblClients.Location = new System.Drawing.Point(4, 26);
            this.TbcTblClients.Name = "TbcTblClients";
            this.TbcTblClients.Padding = new System.Windows.Forms.Padding(3);
            this.TbcTblClients.Size = new System.Drawing.Size(976, 468);
            this.TbcTblClients.TabIndex = 0;
            this.TbcTblClients.Text = "Таблица клиенты";
            this.TbcTblClients.UseVisualStyleBackColor = true;
            // 
            // TbcTblCars
            // 
            this.TbcTblCars.Controls.Add(this.DgvTblClients);
            this.TbcTblCars.Controls.Add(this.LblTblCars);
            this.TbcTblCars.Location = new System.Drawing.Point(4, 26);
            this.TbcTblCars.Name = "TbcTblCars";
            this.TbcTblCars.Padding = new System.Windows.Forms.Padding(3);
            this.TbcTblCars.Size = new System.Drawing.Size(976, 468);
            this.TbcTblCars.TabIndex = 1;
            this.TbcTblCars.Text = "Таблица автомобили";
            this.TbcTblCars.UseVisualStyleBackColor = true;
            // 
            // LblTblСlients
            // 
            this.LblTblСlients.Location = new System.Drawing.Point(3, 3);
            this.LblTblСlients.Name = "LblTblСlients";
            this.LblTblСlients.Size = new System.Drawing.Size(965, 51);
            this.LblTblСlients.TabIndex = 3;
            this.LblTblСlients.Text = "Прокат автомобилей";
            this.LblTblСlients.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // DgvTableClients
            // 
            this.DgvTableClients.AllowDrop = true;
            this.DgvTableClients.AllowUserToAddRows = false;
            this.DgvTableClients.AllowUserToDeleteRows = false;
            this.DgvTableClients.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvTableClients.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvTableClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvTableClients.Location = new System.Drawing.Point(6, 57);
            this.DgvTableClients.MultiSelect = false;
            this.DgvTableClients.Name = "DgvTableClients";
            this.DgvTableClients.ReadOnly = true;
            this.DgvTableClients.RowHeadersVisible = false;
            this.DgvTableClients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvTableClients.Size = new System.Drawing.Size(967, 408);
            this.DgvTableClients.TabIndex = 4;
            // 
            // LblTblCars
            // 
            this.LblTblCars.Location = new System.Drawing.Point(3, 3);
            this.LblTblCars.Name = "LblTblCars";
            this.LblTblCars.Size = new System.Drawing.Size(965, 51);
            this.LblTblCars.TabIndex = 4;
            this.LblTblCars.Text = "Прокат автомобилей";
            this.LblTblCars.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // DgvTblClients
            // 
            this.DgvTblClients.AllowDrop = true;
            this.DgvTblClients.AllowUserToAddRows = false;
            this.DgvTblClients.AllowUserToDeleteRows = false;
            this.DgvTblClients.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvTblClients.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvTblClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvTblClients.Location = new System.Drawing.Point(6, 57);
            this.DgvTblClients.MultiSelect = false;
            this.DgvTblClients.Name = "DgvTblClients";
            this.DgvTblClients.ReadOnly = true;
            this.DgvTblClients.RowHeadersVisible = false;
            this.DgvTblClients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvTblClients.Size = new System.Drawing.Size(967, 405);
            this.DgvTblClients.TabIndex = 5;
            // 
            // TbcTblRentals
            // 
            this.TbcTblRentals.Controls.Add(this.DgvTblRentals);
            this.TbcTblRentals.Controls.Add(this.LblTblRentals);
            this.TbcTblRentals.Location = new System.Drawing.Point(4, 26);
            this.TbcTblRentals.Name = "TbcTblRentals";
            this.TbcTblRentals.Padding = new System.Windows.Forms.Padding(3);
            this.TbcTblRentals.Size = new System.Drawing.Size(976, 468);
            this.TbcTblRentals.TabIndex = 2;
            this.TbcTblRentals.Text = "Таблица прокатов";
            this.TbcTblRentals.UseVisualStyleBackColor = true;
            // 
            // LblTblRentals
            // 
            this.LblTblRentals.Location = new System.Drawing.Point(5, 3);
            this.LblTblRentals.Name = "LblTblRentals";
            this.LblTblRentals.Size = new System.Drawing.Size(965, 51);
            this.LblTblRentals.TabIndex = 5;
            this.LblTblRentals.Text = "Прокат автомобилей";
            this.LblTblRentals.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // DgvTblRentals
            // 
            this.DgvTblRentals.AllowDrop = true;
            this.DgvTblRentals.AllowUserToAddRows = false;
            this.DgvTblRentals.AllowUserToDeleteRows = false;
            this.DgvTblRentals.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvTblRentals.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvTblRentals.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvTblRentals.Location = new System.Drawing.Point(3, 57);
            this.DgvTblRentals.MultiSelect = false;
            this.DgvTblRentals.Name = "DgvTblRentals";
            this.DgvTblRentals.ReadOnly = true;
            this.DgvTblRentals.RowHeadersVisible = false;
            this.DgvTblRentals.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvTblRentals.Size = new System.Drawing.Size(967, 408);
            this.DgvTblRentals.TabIndex = 6;
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniAboutProgram});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TcbTableClients
            // 
            this.TcbTableClients.BackColor = System.Drawing.Color.AntiqueWhite;
            this.TcbTableClients.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbTableClients.Image = global::Task3WFLINQtoSQL.Properties.Resources.mario;
            this.TcbTableClients.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbTableClients.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbTableClients.Name = "TcbTableClients";
            this.TcbTableClients.Size = new System.Drawing.Size(36, 36);
            this.TcbTableClients.Text = "toolStripButton1";
            this.TcbTableClients.ToolTipText = "Таблица клиенты";
            this.TcbTableClients.Click += new System.EventHandler(this.TableClients_Command);
            // 
            // TcbTableCars
            // 
            this.TcbTableCars.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.TcbTableCars.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbTableCars.Image = global::Task3WFLINQtoSQL.Properties.Resources.автомобиль_32;
            this.TcbTableCars.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbTableCars.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbTableCars.Name = "TcbTableCars";
            this.TcbTableCars.Size = new System.Drawing.Size(36, 36);
            this.TcbTableCars.Text = "toolStripButton2";
            this.TcbTableCars.ToolTipText = "Таблица автомобили";
            this.TcbTableCars.Click += new System.EventHandler(this.TableCars_Command);
            // 
            // TcbTableRentals
            // 
            this.TcbTableRentals.BackColor = System.Drawing.Color.AntiqueWhite;
            this.TcbTableRentals.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbTableRentals.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.TcbTableRentals.Image = global::Task3WFLINQtoSQL.Properties.Resources.car_rental_32;
            this.TcbTableRentals.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbTableRentals.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbTableRentals.Name = "TcbTableRentals";
            this.TcbTableRentals.Size = new System.Drawing.Size(36, 36);
            this.TcbTableRentals.Text = "toolStripButton3";
            this.TcbTableRentals.ToolTipText = "Таблица факты проката";
            this.TcbTableRentals.Click += new System.EventHandler(this.TableRentals_Command);
            // 
            // TcbQuery01
            // 
            this.TcbQuery01.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbQuery01.Image = global::Task3WFLINQtoSQL.Properties.Resources.цифра_1_32;
            this.TcbQuery01.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbQuery01.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbQuery01.Name = "TcbQuery01";
            this.TcbQuery01.Size = new System.Drawing.Size(36, 36);
            this.TcbQuery01.Text = "toolStripButton1";
            this.TcbQuery01.ToolTipText = "Запрос 1";
            this.TcbQuery01.Click += new System.EventHandler(this.Query01_Command);
            // 
            // TcbAboutProgram
            // 
            this.TcbAboutProgram.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbAboutProgram.Image = global::Task3WFLINQtoSQL.Properties.Resources.help;
            this.TcbAboutProgram.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbAboutProgram.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbAboutProgram.Name = "TcbAboutProgram";
            this.TcbAboutProgram.Size = new System.Drawing.Size(36, 36);
            this.TcbAboutProgram.Text = "toolStripButton1";
            this.TcbAboutProgram.ToolTipText = "О программе..";
            this.TcbAboutProgram.Click += new System.EventHandler(this.About_Command);
            // 
            // MniExit
            // 
            this.MniExit.Image = global::Task3WFLINQtoSQL.Properties.Resources.выход_28;
            this.MniExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniExit.Name = "MniExit";
            this.MniExit.Size = new System.Drawing.Size(138, 34);
            this.MniExit.Text = "Выход";
            this.MniExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniTblСlients
            // 
            this.MniTblСlients.Image = global::Task3WFLINQtoSQL.Properties.Resources.mario;
            this.MniTblСlients.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTblСlients.Name = "MniTblСlients";
            this.MniTblСlients.Size = new System.Drawing.Size(222, 38);
            this.MniTblСlients.Text = "Клиенты";
            this.MniTblСlients.Click += new System.EventHandler(this.TableClients_Command);
            // 
            // MniTblСars
            // 
            this.MniTblСars.Image = global::Task3WFLINQtoSQL.Properties.Resources.автомобиль_32;
            this.MniTblСars.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTblСars.Name = "MniTblСars";
            this.MniTblСars.Size = new System.Drawing.Size(222, 38);
            this.MniTblСars.Text = "Автомобили";
            this.MniTblСars.Click += new System.EventHandler(this.TableCars_Command);
            // 
            // MniTblRentals
            // 
            this.MniTblRentals.Image = global::Task3WFLINQtoSQL.Properties.Resources.car_rental_32;
            this.MniTblRentals.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTblRentals.Name = "MniTblRentals";
            this.MniTblRentals.Size = new System.Drawing.Size(222, 38);
            this.MniTblRentals.Text = "Факты проката";
            this.MniTblRentals.Click += new System.EventHandler(this.TableRentals_Command);
            // 
            // MniAboutProgram
            // 
            this.MniAboutProgram.Image = global::Task3WFLINQtoSQL.Properties.Resources.help;
            this.MniAboutProgram.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniAboutProgram.Name = "MniAboutProgram";
            this.MniAboutProgram.Size = new System.Drawing.Size(222, 38);
            this.MniAboutProgram.Text = "О программе..";
            this.MniAboutProgram.Click += new System.EventHandler(this.About_Command);
            // 
            // TbcQuery01
            // 
            this.TbcQuery01.Controls.Add(this.DgvQuery01);
            this.TbcQuery01.Controls.Add(this.LblQuery01);
            this.TbcQuery01.Location = new System.Drawing.Point(4, 26);
            this.TbcQuery01.Name = "TbcQuery01";
            this.TbcQuery01.Padding = new System.Windows.Forms.Padding(3);
            this.TbcQuery01.Size = new System.Drawing.Size(976, 468);
            this.TbcQuery01.TabIndex = 3;
            this.TbcQuery01.Text = "Запрос 1";
            this.TbcQuery01.UseVisualStyleBackColor = true;
            // 
            // LblQuery01
            // 
            this.LblQuery01.Location = new System.Drawing.Point(3, 3);
            this.LblQuery01.Name = "LblQuery01";
            this.LblQuery01.Size = new System.Drawing.Size(965, 51);
            this.LblQuery01.TabIndex = 6;
            this.LblQuery01.Text = "Прокат автомобилей";
            this.LblQuery01.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // DgvQuery01
            // 
            this.DgvQuery01.AllowDrop = true;
            this.DgvQuery01.AllowUserToAddRows = false;
            this.DgvQuery01.AllowUserToDeleteRows = false;
            this.DgvQuery01.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery01.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvQuery01.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery01.Location = new System.Drawing.Point(3, 57);
            this.DgvQuery01.MultiSelect = false;
            this.DgvQuery01.Name = "DgvQuery01";
            this.DgvQuery01.ReadOnly = true;
            this.DgvQuery01.RowHeadersVisible = false;
            this.DgvQuery01.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery01.Size = new System.Drawing.Size(967, 405);
            this.DgvQuery01.TabIndex = 7;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.TsbMain);
            this.Controls.Add(this.MnuMain);
            this.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnuMain;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximumSize = new System.Drawing.Size(1100, 600);
            this.MinimumSize = new System.Drawing.Size(1000, 566);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание №8";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MnuMain.ResumeLayout(false);
            this.MnuMain.PerformLayout();
            this.TsbMain.ResumeLayout(false);
            this.TsbMain.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.TbcTblClients.ResumeLayout(false);
            this.TbcTblCars.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvTableClients)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTblClients)).EndInit();
            this.TbcTblRentals.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvTblRentals)).EndInit();
            this.TbcQuery01.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnuMain;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniExit;
        private System.Windows.Forms.ToolStrip TsbMain;
        private System.Windows.Forms.ToolStripMenuItem таблицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniTblСlients;
        private System.Windows.Forms.ToolStripMenuItem MniTblСars;
        private System.Windows.Forms.ToolStripMenuItem MniTblRentals;
        private System.Windows.Forms.ToolStripButton TcbTableClients;
        private System.Windows.Forms.ToolStripButton TcbTableCars;
        private System.Windows.Forms.ToolStripButton TcbTableRentals;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbcTblClients;
        private System.Windows.Forms.TabPage TbcTblCars;
        private System.Windows.Forms.DataGridView DgvTableClients;
        private System.Windows.Forms.Label LblTblСlients;
        private System.Windows.Forms.DataGridView DgvTblClients;
        private System.Windows.Forms.Label LblTblCars;
        private System.Windows.Forms.TabPage TbcTblRentals;
        private System.Windows.Forms.DataGridView DgvTblRentals;
        private System.Windows.Forms.Label LblTblRentals;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniAboutProgram;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton TcbAboutProgram;
        private System.Windows.Forms.ToolStripButton TcbQuery01;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.TabPage TbcQuery01;
        private System.Windows.Forms.DataGridView DgvQuery01;
        private System.Windows.Forms.Label LblQuery01;
    }
}