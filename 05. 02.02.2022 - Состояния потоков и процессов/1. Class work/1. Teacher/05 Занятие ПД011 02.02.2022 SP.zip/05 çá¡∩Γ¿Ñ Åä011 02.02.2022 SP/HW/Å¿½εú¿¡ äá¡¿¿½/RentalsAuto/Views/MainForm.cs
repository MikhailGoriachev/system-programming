﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentalsAuto.Controllers;
using RentalsAuto.Views;

namespace RentalsAuto
{
    public partial class MainForm : Form
    {
        private AppController controller;
        public MainForm()
        {
            InitializeComponent();
            controller = new AppController();
        }

        private void Exit_Command(object sender, EventArgs e) => Close();

        private void Load_Command(object sender, EventArgs e)
        {
            dataGridView1.DataSource = controller.Query1("AA 2344");
            dataGridView2.DataSource = controller.Query2("Audi");
            dataGridView3.DataSource = controller.Query3("9808 654654");
            dataGridView4.DataSource = controller.Query4();
            dataGridView6.DataSource = controller.Query6();
            dataGridView7.DataSource = controller.QueryAutos();
        }

        private void EnterFirstTabPage_Command(object sender, EventArgs e)
        {
            InputForm form = new InputForm(1);
            
            if(form.ShowDialog() == DialogResult.OK)
                dataGridView1.DataSource = controller.Query1(form.value);
        }

        private void EnterSecondTabPage_Command(object sender, EventArgs e)
        {
            InputForm form = new InputForm(2);

            if (form.ShowDialog() == DialogResult.OK)
                dataGridView2.DataSource = controller.Query2(form.value);
        }

        private void EnterThirdTabPage_Command(object sender, EventArgs e)
        {
            InputForm form = new InputForm(3);

            if (form.ShowDialog() == DialogResult.OK)
                dataGridView3.DataSource = controller.Query3(form.value);
        }

        private void EnterFourthTabPage_Command(object sender, EventArgs e) 
            => dataGridView4.DataSource = controller.Query4();

        private void EnterFifthTabPage_Command(object sender, EventArgs e)
        {

        }

        private void EnterSixthTabPage_Command(object sender, EventArgs e) 
            => dataGridView6.DataSource = controller.Query6();

        private void EnterSeventhTabPage_Command(object sender, EventArgs e) => dataGridView7.DataSource = controller.QueryAutos();

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            AutoForm form = new AutoForm();
            if (form.ShowDialog() == DialogResult.OK)
                controller.AddAuto(form.auto);

            tabControl1.SelectedTab = tabPage7;
        }
    }
}
