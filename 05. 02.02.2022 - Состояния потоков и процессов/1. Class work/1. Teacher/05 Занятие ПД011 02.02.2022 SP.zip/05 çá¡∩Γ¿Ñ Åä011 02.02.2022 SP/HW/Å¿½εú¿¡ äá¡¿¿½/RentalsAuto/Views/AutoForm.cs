﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentalsAutoLab;

namespace RentalsAuto.Views
{
    public partial class AutoForm : Form
    {
        public Autos auto;
        public AutoForm()
        {
            InitializeComponent();
            auto = new Autos
            {
                Brands = new Brands(), Colors = new Colors()// , InsurancePay = 1000, Plate = "РР100Р", YearMount = 2002
            };
        }

        private void button1_Click(object sender, EventArgs e)
        {

            auto.Brands.Brand = textBox1.Text;
            auto.Colors.Color = textBox2.Text;
            auto.Plate = textBox3.Text;
            auto.YearMount = (int)numericUpDown1.Value;
            auto.InsurancePay = (int)numericUpDown2.Value;
            auto.Rental = (int)numericUpDown3.Value;
        }
    }
}
