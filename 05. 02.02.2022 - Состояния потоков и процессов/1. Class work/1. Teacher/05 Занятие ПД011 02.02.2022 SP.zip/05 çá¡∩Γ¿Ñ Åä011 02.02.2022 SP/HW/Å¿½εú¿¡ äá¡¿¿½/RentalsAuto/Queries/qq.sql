﻿--1	Запрос к представлению	
--Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
select
	DateStart
	,Dur
	,Plate
	,Surname
	,[Name]
	,Patronymic
	,Passport
from ViewRentals
where Plate = 'AA 2344'
--2	Запрос к представлению	
--Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
select
	DateStart
	,Dur
	,Plate
	,Surname
	,[Name]
	,Patronymic
	,Passport
from ViewRentals
where Brand ='Audi'
--3	Запрос к представлению	
--Выбирает информацию об автомобиле с заданным госномером
select
	Brand
	,Color
	,InsurancePay
	,Plate
	,Rental
	,YearMount
from ViewRentals
where Plate = 'AA 1234'
--4	Запрос с параметром		
--Выбирает информацию о клиентах по серии и номеру паспорта
select
	Surname
	,[Name]
	,Patronymic
	,Passport
from ViewRentals
where Passport = '9808 654654'
--5	Запрос к представлению	
--Выбирает информацию обо всех зафиксированных фактах проката автомобилей 
--в некоторый заданный интервал времени.
select
	*
from ViewRentals
where DateStart between '2021-01-01' and '2021-11-20'
--6	Запрос к представлению	
--Вычисляет для каждого факта проката стоимость проката. Включает поля Дата проката, 
--Госномер автомобиля, Модель автомобиля, Стоимость проката. Сортировка по полю Дата проката
select
	DateStart	as [Дата проката]
	,Brand		as [Модель автомобиля]
	,Plate		as [Госномер автомобиля]
	,Rental		as [Стоимость проката]
	,Dur		as [Длительность проката]
	,Rental * Dur as [Общая стоимость]
from ViewRentals
--7	Запрос с левым соединением	
--Для всех клиентов прокатной фирмы вычисляет 
--количество фактов проката, суммарное количество дней проката, 
--упорядочивание по убыванию суммарного количества дней проката
select
	Surname
	,count(*)	as [Kоличество фактов проката]
	,sum(Dur)	as [Cуммарное количество дней проката] 
from Clients left join Rentals on Clients.Id = Rentals.idClient
group by Surname
order by [Cуммарное количество дней проката] desc
--8	Итоговый запрос	
--Выполняет группировку по полю Модель автомобиля. 
--Для каждой модели вычисляет количество фактов проката, сумму за прокат
select
	Brand
	,count(*)	as [Kоличество фактов проката]
	,sum(Dur * Rental)	as [Cуммa за прокат] 
from ViewRentals
group by Brand
--с левым соединением
select
	Brand
	,count(Rentals.idAuto)	as [Kоличество фактов проката]
	,sum(Dur * Rental)	as [Cуммa за прокат] 
from Brands left join (Autos join Rentals on Autos.Id = Rentals.idAuto) on Brands.Id = Autos.idBrand
group by Brand
--9	Запрос на добавление	
--Добавляет данные о новом клиенте. Данные передавайте параметрами
declare @sur nvarchar(40) = N'Тимашов'
		,@nm nvarchar(40) = N'Александр'
		,@ptr nvarchar(40) = N'Вольфович'
		,@psp nvarchar(40) = '9475 645384'

insert into Clients
	(Surname,[Name], Patronymic, Passport)
values
	(@sur,@nm,@ptr,@psp)

select 	* from Clients

--10	Запрос на обновление	
--Изменяет данные клиента (все поля, кроме идентификатора). Данные передавайте параметрами
declare @sur nvarchar(40) = N'Вокса'
		,@nm nvarchar(40) = N'Петр'
		,@ptr nvarchar(40) = N'Иванович'
		,@psp nvarchar(40) = '4321 234219'

update Clients
set Surname = @sur
	,[Name] = @nm
	,Patronymic = @ptr
	,Passport = @psp
where Passport = '9475 645384'
--11	Запрос на обновление	
--Изменяет данные автомобиля (все поля, кроме идентификатора). Данные передавайте параметрами
declare @br	 int = 4
		,@cl int = 2
		,@pl nvarchar(40) = 'AA 3112'
		,@ym int = 2021
		,@ip int = 3000
		,@rnt int = 1000
update Autos
set idBrand = @br
	,idColor = @cl
	,Plate = @pl
	,YearMount = @ym
	,InsurancePay = @ip
	,Rental = @rnt
where Plate = 'AA 6897'

select * from Autos























--1 Запрос с параметром 
--Выбирает из таблицы АВТОМОБИЛИ информацию 
--об автомобилях заданной модели (например, ВАЗ-2110) 
select
	Brand
	,Color
	,Autos.InsurancePay
	,Autos.Plate
	,Autos.Rental
	,Autos.YearMount
from Autos join Brands on Autos.idBrand = Brands.id
			join Colors on Autos.idColor = Colors.id
where Brand in (select Brand from Brands where Brand = 'Skoda')
--2 Запрос с параметром 
--Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, 
--изготовленных до заданного года (например, до 2016) 
select
	Brand
	,Color
	,Autos.InsurancePay
	,Autos.Plate
	,Autos.Rental
	,Autos.YearMount
from Autos join Brands on Autos.idBrand = Brands.id
			join Colors on Autos.idColor = Colors.id
where YearMount in (select YearMount from Autos where YearMount < 2016)
--3 Запрос с параметром 
--Выбирает из таблицы АВТОМОБИЛИ информацию 
--об автомобилях, имеющих заданные модель и цвет, изготовленных после 
--заданного года
select
	Brand
	,Color
	,Autos.InsurancePay
	,Autos.Plate
	,Autos.Rental
	,Autos.YearMount
from Autos join Brands on Autos.idBrand = Brands.id
			join Colors on Autos.idColor = Colors.id
where Autos.Id in (select id from Autos where YearMount > 2014 
					and Brand = 'BMW' 
					and Color = N'Черный') 
--4 Запрос с параметром
--Выбирает из таблицы АВТОМОБИЛИ информацию об
--автомобиле с заданным госномером.
select
	Brand
	,Color
	,Autos.InsurancePay
	,Autos.Plate
	,Autos.Rental
	,Autos.YearMount
from Autos join Brands on Autos.idBrand = Brands.id
			join Colors on Autos.idColor = Colors.id
where Autos.Id in (select id from Autos where Plate = 'AA 2344' )
--5 Запрос с параметром
--Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и
--ФАКТЫ_ПРОКАТА информацию обо всех
--зафиксированных фактах проката автомобилей (ФИО
--клиента, Модель автомобиля, Госномер автомобиля,
--дата проката) в некоторый заданный интервал
--времени. Нижняя и верхняя границы интервала
--задаются при выполнении запроса
select
	PName
	,PSurname
	,PPatronymic
	,Brand
	,Autos.Plate
	,Rentals.DateStart
from Rentals
		join (Clients join PNames on Clients.idName = PNames.Id
					join PSurnames on Clients.idSurname = PSurnames.Id
					join PPatronymics on Clients.idPatronymic = PPatronymics.Id)
		on Rentals.idClient = Clients.Id
		join (Autos join Brands on Autos.idBrand  = Brands.Id
					join Colors on Autos.idColor = Colors.Id)
		on Rentals.idAuto = Autos.Id

--6 Запрос с
--вычисляемыми
--полями
--Вычисляет для каждого факта проката стоимость
--проката. Включает поля Дата проката, Госномер
--автомобиля, Модель автомобиля, Стоимость
--проката. Сортировка по полю Дата проката
--7 Запрос с левым
--соединением
--Для всех автомобилей прокатной фирмы вычисляет
--количество фактов проката, сумму за прокаты
--8 Итоговый запрос Выполняет группировку по полю Год выпуска
--автомобиля. Для каждого года вычисляет
--минимальное и максимальное значения по
--полю Стоимость одного дня проката
--9 Запрос на
--добавление
--Добавляет в таблицу ФАКТЫ_ПРОКАТА данные о
--факте проката
--10 Запрос на
--добавление
--Добавляет в таблицу АВТОМОБИЛИ данные о новом
--автомобиле в прокатной фирме
--11 Запрос на
--удаление
--Удаляет из таблицы ФАКТЫ_ПРОКАТА запись по
--идентификатору
--12 Запрос на
--удаление
--Удаляет из таблицы ФАКТЫ_ПРОКАТА записи за
--указанный период для заданного клиента
--13 Запрос на
--обновление
--Увеличивает значение в поле Стоимость одного дня
--проката на заданное количество процентов для
--автомобилей, изготовленных после заданного года
--14 Запрос на
--обновление
--Изменяет данные клиента по его идентификатору на
--указанные в параметрах запроса значение