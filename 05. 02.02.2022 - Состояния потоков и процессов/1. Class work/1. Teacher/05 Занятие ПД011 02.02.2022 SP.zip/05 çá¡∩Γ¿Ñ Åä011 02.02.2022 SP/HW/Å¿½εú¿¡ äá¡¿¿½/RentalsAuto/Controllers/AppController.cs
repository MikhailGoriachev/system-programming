﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RentalsAutoLab;

namespace RentalsAuto.Controllers
{
    class AppController
    {
        //контроллер запросов
        public QueryController controller;

        //конструктор
        public AppController()
        {
            controller = new QueryController();
        }
        #region Запросы по заданию с 1 по 6
        public List<RentalFact> Query1(string p) => controller.Query1(p);
        public List<RentalFact> Query2(string p) => controller.Query2(p);
        public List<Clients> Query3(string p) => controller.Query3(p);
        public List<RentalPrice> Query4() => controller.Query4();
        public IEnumerable Query6() => controller.Query6();
        public List<Auto> QueryAutos() => controller.QueryAuto();
        public void AddAuto(Autos a) => controller.AddAuto(a);
        #endregion
    }
}
