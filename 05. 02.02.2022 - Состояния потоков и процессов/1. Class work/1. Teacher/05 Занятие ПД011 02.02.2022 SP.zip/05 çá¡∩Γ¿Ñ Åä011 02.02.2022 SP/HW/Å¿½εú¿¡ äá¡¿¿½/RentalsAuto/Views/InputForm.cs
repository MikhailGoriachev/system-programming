﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentalsAuto.Views
{
    public partial class InputForm : Form
    {
        public string value;
        public InputForm()
        {
            InitializeComponent();
        }

        public InputForm(int i) : this()
        {
            switch(i)
            {
                case 1:
                    label1.Text = "Введите гос номер:";
                    break;
                case 2:
                    label1.Text = "Введите название бренда:";
                    break;
                case 3:
                    label1.Text = "Введите серию номер паспорта:";
                    break;
            }
        }

        private void Ok_Command(object sender, EventArgs e)
        {
            value = textBox1.Text;
        }
    }
}
