﻿drop table if exists Rentals
drop table if exists Autos
drop table if exists Clients
drop table if exists Colors
drop table if exists Brands

--создание таблицы брендов
CREATE TABLE [dbo].Brands
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    Brand NVARCHAR(40) NOT NULL                 --Бренд
)

go

--создание таблицы цветов
CREATE TABLE [dbo].Colors
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    Color NVARCHAR(40) NOT NULL                 --Цвет
)

go

--создание таблицы клиентов
CREATE TABLE [dbo].[Clients]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Surname] NVARCHAR(40) NOT NULL,            --Фамилия
    [Name] NVARCHAR(40) NOT NULL,               --Имя
    [Patronymic] NVARCHAR(40) NOT NULL,         --Отчество
    [Passport] NVARCHAR(11) NOT NULL            --Пасспорт
)

go


--создание таблицы автопарка
CREATE TABLE [dbo].[Autos]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [idBrand] INT NOT NULL,                     --Бренд 
    [idColor] INT NOT NULL,                     --Цвет автомобиля 
    [Plate] NVARCHAR(10) NOT NULL,              --Госномер автомобиля
    [YearMount] INT NOT NULL,                   --Год выпуска автомобиля
    [InsurancePay] INT NOT NULL,                --Страховая стоимость автомобиля
    [Rental] INT NOT NULL,                      --Стоимость одного дня проката
    CONSTRAINT [CK_Autos_idBrand] CHECK (idBrand > 0), 
    CONSTRAINT [CK_Autos_idColor] CHECK (idColor > 0), 
    CONSTRAINT [CK_Autos_YearMount] CHECK (YearMount > 1), 
    CONSTRAINT [CK_Autos_InsurancePay] CHECK (InsurancePay > 1),
    CONSTRAINT [CK_Autos_Rental] CHECK (Rental > 1),

    CONSTRAINT [FK_Autos_Brands] FOREIGN KEY ([idBrand]) REFERENCES Brands(id), 
    CONSTRAINT [FK_Autos_Colors] FOREIGN KEY ([idColor]) REFERENCES Colors(id) 
)

go

--создание таблицы прокатов
CREATE TABLE [dbo].[Rentals]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [idClient] INT NOT NULL,                --Клиент  
    [idAuto] INT NOT NULL,                  --Авто
    [DateStart] DATE NOT NULL,              --Дата начала проката
    [Dur] INT NOT NULL,                --Количество дней проката
    
    CONSTRAINT [CK_Rentals_idClient] CHECK (idClient > 0), 
    CONSTRAINT [CK_Rentals_idCar] CHECK (idAuto > 0), 
    CONSTRAINT [CK_Rentals_Duration] CHECK (Dur > 0 and Dur < 16), 
    
                   
    CONSTRAINT [FK_Rentals_Clients] FOREIGN KEY ([idClient]) REFERENCES Clients(id), 
    CONSTRAINT [FK_Rentals_Autos] FOREIGN KEY ([idAuto]) REFERENCES Autos(id) 
)

go