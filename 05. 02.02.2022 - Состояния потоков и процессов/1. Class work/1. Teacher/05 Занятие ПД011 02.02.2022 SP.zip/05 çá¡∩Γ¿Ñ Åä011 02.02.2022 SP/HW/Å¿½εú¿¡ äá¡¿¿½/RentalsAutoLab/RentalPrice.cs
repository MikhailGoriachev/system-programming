﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentalsAutoLab
{
    //модель представления 4 запроса
    public class RentalPrice
    {
        public DateTime DateStart { get; set; }
        public string Plate { get; set; }
        public string Brand { get; set; }
        public int Price { get; set; }

        //конструктор
        public RentalPrice(Rentals r)
        {
            DateStart = r.DateStart;
            Plate = r.Autos.Plate;
            Brand = r.Autos.Brands.Brand;
            Price = r.Dur * r.Autos.Rental;
        }
    }
}
