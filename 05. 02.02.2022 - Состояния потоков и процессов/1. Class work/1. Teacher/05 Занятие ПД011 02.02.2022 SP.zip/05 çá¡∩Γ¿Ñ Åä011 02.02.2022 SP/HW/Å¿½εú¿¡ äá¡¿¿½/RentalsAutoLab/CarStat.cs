﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentalsAutoLab
{
    //модель представления 6 запроса
    class CarStat
    {
        public string Brand { get; set; }
        public int AmountRentals { get; set; }
        public int PriceOfRentals { get; set; }

    }
}
