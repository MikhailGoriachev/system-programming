﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentalsAutoLab
{
    //модель представления для 1, 2 запросов
    public class RentalFact
    {

        public DateTime DateStart { get; set; }
        public int Duration { get; set; }
        public string Brand { get; set; }
        public string Plate { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Patronymic { get; set; }
        public string Passport { get; set; }

        public RentalFact(Rentals r)
        {
            DateStart = r.DateStart;
            Duration = r.Dur;
            Brand = r.Autos.Brands.Brand;
            Plate = r.Autos.Plate;
            Surname = r.Clients.Surname;
            Name = r.Clients.Name;
            Patronymic = r.Clients.Patronymic;
            Passport = r.Clients.Passport;
        }

    }
}
