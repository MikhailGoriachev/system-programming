﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentalsAutoLab
{
    //модель для 3 задачи
    public class Auto
    {
        public string Brand { get; set; }
        public string Color { get; set; }
        public string Plate { get; set; }
        public int YearMount { get; set; }
        public int InsurancePay { get; set; }
        public int Rental { get; set; }

        //конструктор
        public Auto(Autos a)
        {
            Brand = a.Brands.Brand;
            Color = a.Colors.Color;
            Plate = a.Plate;
            YearMount = a.YearMount;
            InsurancePay = a.InsurancePay;
            Rental = a.Rental;
        }
    }
}
