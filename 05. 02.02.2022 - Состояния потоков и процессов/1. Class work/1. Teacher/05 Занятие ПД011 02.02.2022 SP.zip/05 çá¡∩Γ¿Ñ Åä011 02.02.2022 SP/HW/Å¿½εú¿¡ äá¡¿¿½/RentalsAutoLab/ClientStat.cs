﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentalsAutoLab
{
    //модель представления 5 запроса
    class ClientStat
    {
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Patronymic { get; set; }
        public string Passport { get; set; }
        public int AmountRentals { get; set; }
        public int PriceOfRentals { get; set; }
    }
}
