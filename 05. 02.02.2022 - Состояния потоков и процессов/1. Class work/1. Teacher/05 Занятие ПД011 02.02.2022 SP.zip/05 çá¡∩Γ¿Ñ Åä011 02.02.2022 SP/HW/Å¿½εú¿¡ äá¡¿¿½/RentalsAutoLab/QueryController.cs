﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace RentalsAutoLab
{
    public class QueryController
    {
        //модель базы данных
        public dbDataContext db;

        //конструктор
        public QueryController() => db = new dbDataContext();

        #region Запросы по заданию с 1 по 6

        //1	Выборка данных  
        //Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
        public List<RentalFact> Query1(string p) => db.Rentals
            .Where(q => q.Autos.Plate == p)
            .Select(q => new RentalFact(q))
            .ToList();

        //2	Выборка данных  
        //Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
        public List<RentalFact> Query2(string b) => db.Rentals
            .Where(q => q.Autos.Brands.Brand == b)
            .Select(q => new RentalFact(q))
            .ToList();
        //3	Выборка данных  
        //Выбирает информацию о клиентах по серии и номеру паспорта
        public List<Clients> Query3(string p) => db.Clients
            .Where(q => q.Passport == p)
            .ToList();

        //4	Выборка данных  
        //Вычисляет для каждого факта проката стоимость проката.Включает поля Дата проката, 
        //Госномер автомобиля, Модель автомобиля, Стоимость проката.Сортировка по полю Дата проката
        public List<RentalPrice> Query4() => db.Rentals
            .Select(q => new RentalPrice(q))
            .ToList();

        //5	Запрос с левым соединением  
        //Для всех клиентов прокатной фирмы вычисляет количество фактов проката, суммарное 
        //количество дней проката, упорядочивание по убыванию суммарного количества дней проката

        //6	Запрос с левым соединением  
        //Для всех автомобилей прокатной фирмы определите количество фактов проката, сумма 
        //за прокаты, суммарная длительность прокатов
        //public IEnumerable Query6() => 
        //    from brands in db.Brands
        //    join autos in db.Autos
        //                           on brands.Id equals autos.idBrand into autosResult
        //                           from cars in autosResult
        //                           join rentals in db.Rentals
        //                           on cars.Id equals rentals.idAuto into rentalsResult
        //                           from result in rentalsResult.DefaultIfEmpty()
        //                           group result by new { result.Autos.Id, result.Autos.Brands.Brand, result.Dur, result.Autos.Rental } into Group
        //                           select new 
        //                           {
        //                               Group.Key.Brand,
        //                               Count = Group.Count(p => p != null),
        //                               SumPrice = Group.Sum(q => q.Dur * q.Autos.Rental)
        //                           };

        public IEnumerable Query6() =>
            from auto in db.Autos
            join rental in db.Rentals
                on auto.Id equals rental.idAuto into autoResults
            from result in autoResults.DefaultIfEmpty()
            group result by new {result.Autos.Id, result.Autos.Brands.Brand, Dur = result == null?0:result.Dur, Rental = result == null?0:result.Autos.Rental}
            into Group
            select new
            {
                Group.Key.Brand,
                Count = Group.Count(p => p.Dur != 0),
                SumPrice = Group.Sum(q => q.Dur * q.Autos.Rental)
            };


        //выборка авто
        public List<Auto> QueryAuto() => db.Autos
            .Select(q => new Auto(q))
            .ToList();
        //добавление авто
        public void AddAuto(Autos a)
        {
            db.Autos.InsertOnSubmit(a);
            db.SubmitChanges();
        }
        #endregion
    }
}
