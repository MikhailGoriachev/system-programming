﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;


namespace ClassCarRental.Controllers
{
    class Controller
    {
        //класс для подключения к базе данных
        public CarHireDataContext _db;

        public Controller(): this(new CarHireDataContext()) {}

        public Controller(CarHireDataContext db)
        {
            _db = db;
        }

        // Запрос 1. Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
        public ICollection Query1() => _db.Hires.Where(x => x.Car.Plate == "О169РК").ToArray();

        // Запрос 2. Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
        public ICollection Query2() =>
            _db.Hires.Where(x => x.Car.BrandModel.BrandModel1 == "Volkswagen Polo").ToArray();

        // Запрос 3. Выбирает информацию о клиентах по серии и номеру паспорта
        public ICollection Query3() => _db.Clients.Where(x => x.Passport == "11 21 098181").ToArray();

        // Запрос 4. Вычисляет для каждого факта проката стоимость проката.
        // Включает поля Дата проката, Госномер автомобиля, Модель автомобиля,
        // Стоимость проката. Сортировка по полю Дата проката

        public ICollection Query4() => _db.Hires
            .Select(x => new {x.DateStart, x.Car.Plate, x.Car.BrandModel.BrandModel1, Cost = x.Car.Rental * x.Duration})
            .OrderBy(x => x.DateStart).ToArray();
        // Запрос 5. Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
        // суммарное количество дней проката, упорядочивание по убыванию суммарного количества
        // дней проката
        public ICollection Query5() => _db.Clients.GroupJoin(_db.Hires, x => x.Id, x => x.IdClient,
            (c, h) => new
            {
                c,
                hires = h.DefaultIfEmpty()
            }).Select(x => new
        {
            x.c.Name,
            x.c.Surname,
            Count = (int?) x.hires.Count(q=>q!=null) ?? 0,
            Rents = (int?) x.hires.Sum(q => q.Duration) ?? 0
        }).OrderBy(x => x.Rents)
            .ToArray();


        // Запрос 6. Для всех автомобилей прокатной фирмы определите количество фактов проката,
        // сумма за прокаты, суммарная длительность прокатов
        public ICollection Query6() => _db.Cars.GroupJoin(_db.Hires, c => c.Id, h => h.IdCar,
            (c, h) => new
            {
                c,
                hires = h.DefaultIfEmpty()
            }).Select(x => new
        {
            SumRents = (int?) x.hires.Sum(q => q.Duration * x.c.Rental) ?? 0,
            Duration = (int?) x.hires.Sum(q => q.Duration) ?? 0
        }).ToArray();

    }
}
