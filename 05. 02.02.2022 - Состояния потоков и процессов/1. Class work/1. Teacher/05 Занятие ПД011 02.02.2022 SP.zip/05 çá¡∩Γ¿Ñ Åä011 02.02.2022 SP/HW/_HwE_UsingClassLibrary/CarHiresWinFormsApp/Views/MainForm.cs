﻿using System;
using System.Windows.Forms;
using CarHires;
using CarHiresWinFormsApp.Infrastructure;

namespace CarHiresWinFormsApp.Views
{
    // вывод результатов запросов к базе данных фактов проката по заданию
    public partial class MainForm : Form
    {
        private CarHireQueries _carHireQueries;

        public MainForm() : this(new CarHireQueries()) { }

        public MainForm(CarHireQueries carHireQueries) {
            InitializeComponent();

            _carHireQueries = carHireQueries;
        } // MainForm

        private void Quit_Command(object sender, System.EventArgs e) => Application.Exit();

        // Получить и вывести данные из таблицы производителей и моделей автомобилей
        private void QueryToBrandModels(object sender, EventArgs e) {
            TbcResults.SelectedTab = TbpTables;
            DgvTables.DataSource = _carHireQueries.GetBrandModelsAll();

            StlStatus.Text = $"Всего записей в таблице BrandModels: {DgvTables.RowCount}";
        } // QueryToBrandModels


        // Получить и вывести данные из таблицы цветов автомобилей
        private void QueryToColors(object sender, EventArgs e) {
            TbcResults.SelectedTab = TbpTables;
            DgvTables.DataSource = _carHireQueries.GetColorsAll();

            StlStatus.Text = $"Всего записей в таблице Colors: {DgvTables.RowCount}" ;
        } // QueryToColors

        
        // Получить и вывести данные из таблицы клиентов прокатной фирмы
        private void QueryToClients(object sender, EventArgs e) {
            TbcResults.SelectedTab = TbpTables;
            DgvTables.DataSource = _carHireQueries.GetClientsAll();

            StlStatus.Text = $"Всего записей в таблице Clients: {DgvTables.RowCount}";
        } // QueryToClients


        // Получить и вывести данные из таблицы (вообще-то представления) автомобилей
        // прокатной фирмы
        private void QueryToCars(object sender, EventArgs e) {
            TbcResults.SelectedTab = TbpTables;
            DgvTables.DataSource = _carHireQueries.GetCarsAll();

            StlStatus.Text = $"Всего записей в таблице Cars: {DgvTables.RowCount}" ;
        } // QueryToCars


        // Получить и вывести данные из таблицы фактов проката автомобилей прокатной фирмы
        // вообще-то выводим данные из предсталвения
        private void QueryToHires(object sender, EventArgs e) {
            TbcResults.SelectedTab = TbpTables;
            DgvTables.DataSource = _carHireQueries.GetHiresAll();

            StlStatus.Text = $"Всего записей в таблице Hires: {DgvTables.RowCount}" ;
        } // QueryToHires


        // Запрос 1. Выборка данных.
        // Выбирает информацию обо всех фактах проката автомобиля с заданным
        // госномером
        private void Query01_Exec(object sender, EventArgs e) {
            // переход на вкладку вывода результатов запросов
            TbcResults.SelectedTab = TbpQueries;

            // формирование параметра запроса
            var cars = _carHireQueries.GetCarsAll();
            string plate = cars[Utils.GetRandom(0, cars.Count - 1)].Plate;
            DgvQueries.DataSource = _carHireQueries.Query01(plate);

            StlStatus.Text = $"Запрос 1. Всего выбрано записей о фактах проката " +
                             $"автомобиля с гос. номером {plate}: {DgvQueries.RowCount}";
        } // Query01_Exec


        // Запрос 2. Выборка данных.
        // Выбирает информацию обо всех фактах проката автомобиля с заданной
        // моделью/брендом
        private void Query02_Exec(object sender, EventArgs e) {
            // переход на вкладку вывода результатов запросов
            TbcResults.SelectedTab = TbpQueries;

            // формирование параметра запроса
            var brandModels = _carHireQueries.GetBrandModelsAll();
            string brandModel = brandModels[Utils.GetRandom(0, brandModels.Count - 1)].BrandModel;
            DgvQueries.DataSource = _carHireQueries.Query02(brandModel);

            StlStatus.Text = $"Запрос 2. Всего выбрано записей о фактах проката " +
                             $"автомобилей производителя/модели \"{brandModel}\": {DgvQueries.RowCount}";
        } // Query02_Exec

        // Запрос 3. Выборка данных.
        // Выбирает информацию о клиентах по серии и номеру паспорта
        private void Query03_Exec(object sender, EventArgs e) {
            // переход на вкладку вывода результатов запросов
            TbcResults.SelectedTab = TbpQueries;

            // формирование параметра запроса
            var clients = _carHireQueries.GetClientsAll();
            string passport = clients[Utils.GetRandom(0, clients.Count - 1)].Passport;
            DgvQueries.DataSource = _carHireQueries.Query03(passport);

            StlStatus.Text = $"Запрос 3. Всего выбрано записей о клиентах " +
                             $"с паспортом \"{passport}\": {DgvQueries.RowCount}";
        } // Query03_Exec

        // Запрос 4. Выборка данных.
        // Вычисляет для каждого факта проката стоимость проката. Включает поля
        // Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
        // Сортировка по полю Дата проката
        private void Query04_Exec(object sender, EventArgs e) {
            // переход на вкладку вывода результатов запросов
            TbcResults.SelectedTab = TbpQueries;

            DgvQueries.DataSource = _carHireQueries.Query04();

            StlStatus.Text = $"Запрос 4. Всего выбрано записей: {DgvQueries.RowCount}";
        } // Query04_Exec

        // Запрос 5. Запрос с левым соединением
        // Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
        // суммарное количество дней проката, упорядочивание по убыванию суммарного
        // количества дней проката
        private void Query05_Exec(object sender, EventArgs e) {
            // переход на вкладку вывода результатов запросов
            TbcResults.SelectedTab = TbpQueries;

            DgvQueries.DataSource = _carHireQueries.Query05();

            StlStatus.Text = $"Запрос 5. Всего выбрано записей: {DgvQueries.RowCount}";
        } // Query05_Exec

        // Запрос 6. Запрос с левым соединением
        // Для всех автомобилей прокатной фирмы определите количество фактов
        // проката, сумма за прокаты, суммарная длительность прокатов
        private void Query06_Exec(object sender, EventArgs e) {
            TbcResults.SelectedTab = TbpQueries;

            DgvQueries.DataSource = _carHireQueries.Query06();

            StlStatus.Text = $"Запрос 6. Всего выбрано записей: {DgvQueries.RowCount}";
        } // Query06_Exec
    } // class MainForm
}
