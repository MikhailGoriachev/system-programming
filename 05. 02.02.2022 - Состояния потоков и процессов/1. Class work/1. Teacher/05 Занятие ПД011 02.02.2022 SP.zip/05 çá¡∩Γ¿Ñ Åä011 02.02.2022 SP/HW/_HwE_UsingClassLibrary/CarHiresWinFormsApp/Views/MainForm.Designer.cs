﻿namespace CarHiresWinFormsApp.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileQuit = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTablesBrandModels = new System.Windows.Forms.ToolStripMenuItem();
            this.цветаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиентыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.автомобилиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.фактыПрокатаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запросыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.запрос5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.операцииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавлениеАвтомобиляToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактированиеАвтомобилчToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.выдачаАвтомобиляВПрокатToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.продлениеСрокаПрокатаАвтомобиляToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.помощьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.StlStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.TsbBrandModels = new System.Windows.Forms.ToolStripButton();
            this.TsbColors = new System.Windows.Forms.ToolStripButton();
            this.TsbClients = new System.Windows.Forms.ToolStripButton();
            this.TsbCars = new System.Windows.Forms.ToolStripButton();
            this.TsbHires = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbQuery01 = new System.Windows.Forms.ToolStripButton();
            this.TsbQuery02 = new System.Windows.Forms.ToolStripButton();
            this.TsbQuery03 = new System.Windows.Forms.ToolStripButton();
            this.TsbQuery04 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbQuery05 = new System.Windows.Forms.ToolStripButton();
            this.TsbQuery06 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton15 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.TsbQuit = new System.Windows.Forms.ToolStripButton();
            this.TbcResults = new System.Windows.Forms.TabControl();
            this.TbpTables = new System.Windows.Forms.TabPage();
            this.DgvTables = new System.Windows.Forms.DataGridView();
            this.TbpQueries = new System.Windows.Forms.TabPage();
            this.DgvQueries = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.TbcResults.SuspendLayout();
            this.TbpTables.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTables)).BeginInit();
            this.TbpQueries.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQueries)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.таблицыToolStripMenuItem,
            this.запросыToolStripMenuItem,
            this.операцииToolStripMenuItem,
            this.помощьToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(994, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileQuit});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // MniFileQuit
            // 
            this.MniFileQuit.Image = global::CarHiresWinFormsApp.Properties.Resources.door_out;
            this.MniFileQuit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileQuit.Name = "MniFileQuit";
            this.MniFileQuit.Size = new System.Drawing.Size(125, 38);
            this.MniFileQuit.Text = "Выход";
            this.MniFileQuit.Click += new System.EventHandler(this.Quit_Command);
            // 
            // таблицыToolStripMenuItem
            // 
            this.таблицыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTablesBrandModels,
            this.цветаToolStripMenuItem,
            this.клиентыToolStripMenuItem,
            this.автомобилиToolStripMenuItem,
            this.фактыПрокатаToolStripMenuItem});
            this.таблицыToolStripMenuItem.Name = "таблицыToolStripMenuItem";
            this.таблицыToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.таблицыToolStripMenuItem.Text = "Таблицы";
            // 
            // MniTablesBrandModels
            // 
            this.MniTablesBrandModels.Image = global::CarHiresWinFormsApp.Properties.Resources.car;
            this.MniTablesBrandModels.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTablesBrandModels.Name = "MniTablesBrandModels";
            this.MniTablesBrandModels.Size = new System.Drawing.Size(231, 38);
            this.MniTablesBrandModels.Text = "Производители и модели";
            this.MniTablesBrandModels.Click += new System.EventHandler(this.QueryToBrandModels);
            // 
            // цветаToolStripMenuItem
            // 
            this.цветаToolStripMenuItem.Image = global::CarHiresWinFormsApp.Properties.Resources.color_swatch;
            this.цветаToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.цветаToolStripMenuItem.Name = "цветаToolStripMenuItem";
            this.цветаToolStripMenuItem.Size = new System.Drawing.Size(231, 38);
            this.цветаToolStripMenuItem.Text = "Цвета";
            this.цветаToolStripMenuItem.Click += new System.EventHandler(this.QueryToColors);
            // 
            // клиентыToolStripMenuItem
            // 
            this.клиентыToolStripMenuItem.Image = global::CarHiresWinFormsApp.Properties.Resources.users_5;
            this.клиентыToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.клиентыToolStripMenuItem.Name = "клиентыToolStripMenuItem";
            this.клиентыToolStripMenuItem.Size = new System.Drawing.Size(231, 38);
            this.клиентыToolStripMenuItem.Text = "Клиенты";
            this.клиентыToolStripMenuItem.Click += new System.EventHandler(this.QueryToClients);
            // 
            // автомобилиToolStripMenuItem
            // 
            this.автомобилиToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.автомобилиToolStripMenuItem.Name = "автомобилиToolStripMenuItem";
            this.автомобилиToolStripMenuItem.Size = new System.Drawing.Size(231, 38);
            this.автомобилиToolStripMenuItem.Text = "Автомобили";
            this.автомобилиToolStripMenuItem.Click += new System.EventHandler(this.QueryToCars);
            // 
            // фактыПрокатаToolStripMenuItem
            // 
            this.фактыПрокатаToolStripMenuItem.Image = global::CarHiresWinFormsApp.Properties.Resources.calendar;
            this.фактыПрокатаToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.фактыПрокатаToolStripMenuItem.Name = "фактыПрокатаToolStripMenuItem";
            this.фактыПрокатаToolStripMenuItem.Size = new System.Drawing.Size(231, 38);
            this.фактыПрокатаToolStripMenuItem.Text = "Факты проката";
            this.фактыПрокатаToolStripMenuItem.Click += new System.EventHandler(this.QueryToHires);
            // 
            // запросыToolStripMenuItem
            // 
            this.запросыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.запрос1ToolStripMenuItem,
            this.запрос2ToolStripMenuItem,
            this.запрос3ToolStripMenuItem,
            this.запрос4ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.запрос5ToolStripMenuItem,
            this.запрос6ToolStripMenuItem});
            this.запросыToolStripMenuItem.Name = "запросыToolStripMenuItem";
            this.запросыToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.запросыToolStripMenuItem.Text = "Запросы";
            // 
            // запрос1ToolStripMenuItem
            // 
            this.запрос1ToolStripMenuItem.Image = global::CarHiresWinFormsApp.Properties.Resources.key_a;
            this.запрос1ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос1ToolStripMenuItem.Name = "запрос1ToolStripMenuItem";
            this.запрос1ToolStripMenuItem.Size = new System.Drawing.Size(196, 38);
            this.запрос1ToolStripMenuItem.Text = "Запрос 1";
            this.запрос1ToolStripMenuItem.Click += new System.EventHandler(this.Query01_Exec);
            // 
            // запрос2ToolStripMenuItem
            // 
            this.запрос2ToolStripMenuItem.Image = global::CarHiresWinFormsApp.Properties.Resources.key_b;
            this.запрос2ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос2ToolStripMenuItem.Name = "запрос2ToolStripMenuItem";
            this.запрос2ToolStripMenuItem.Size = new System.Drawing.Size(196, 38);
            this.запрос2ToolStripMenuItem.Text = "Запрос 2";
            this.запрос2ToolStripMenuItem.Click += new System.EventHandler(this.Query02_Exec);
            // 
            // запрос3ToolStripMenuItem
            // 
            this.запрос3ToolStripMenuItem.Image = global::CarHiresWinFormsApp.Properties.Resources.key_c;
            this.запрос3ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос3ToolStripMenuItem.Name = "запрос3ToolStripMenuItem";
            this.запрос3ToolStripMenuItem.Size = new System.Drawing.Size(196, 38);
            this.запрос3ToolStripMenuItem.Text = "Запрос 3";
            this.запрос3ToolStripMenuItem.Click += new System.EventHandler(this.Query03_Exec);
            // 
            // запрос4ToolStripMenuItem
            // 
            this.запрос4ToolStripMenuItem.Image = global::CarHiresWinFormsApp.Properties.Resources.key_d;
            this.запрос4ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос4ToolStripMenuItem.Name = "запрос4ToolStripMenuItem";
            this.запрос4ToolStripMenuItem.Size = new System.Drawing.Size(196, 38);
            this.запрос4ToolStripMenuItem.Text = "Запрос 4";
            this.запрос4ToolStripMenuItem.Click += new System.EventHandler(this.Query04_Exec);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(193, 6);
            // 
            // запрос5ToolStripMenuItem
            // 
            this.запрос5ToolStripMenuItem.Image = global::CarHiresWinFormsApp.Properties.Resources.key_e;
            this.запрос5ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос5ToolStripMenuItem.Name = "запрос5ToolStripMenuItem";
            this.запрос5ToolStripMenuItem.Size = new System.Drawing.Size(196, 38);
            this.запрос5ToolStripMenuItem.Text = "Запрос 5";
            this.запрос5ToolStripMenuItem.Click += new System.EventHandler(this.Query05_Exec);
            // 
            // запрос6ToolStripMenuItem
            // 
            this.запрос6ToolStripMenuItem.Image = global::CarHiresWinFormsApp.Properties.Resources.key_f;
            this.запрос6ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос6ToolStripMenuItem.Name = "запрос6ToolStripMenuItem";
            this.запрос6ToolStripMenuItem.Size = new System.Drawing.Size(196, 38);
            this.запрос6ToolStripMenuItem.Text = "Запрос 6";
            this.запрос6ToolStripMenuItem.Click += new System.EventHandler(this.Query06_Exec);
            // 
            // операцииToolStripMenuItem
            // 
            this.операцииToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавлениеАвтомобиляToolStripMenuItem,
            this.редактированиеАвтомобилчToolStripMenuItem,
            this.toolStripMenuItem2,
            this.выдачаАвтомобиляВПрокатToolStripMenuItem,
            this.продлениеСрокаПрокатаАвтомобиляToolStripMenuItem});
            this.операцииToolStripMenuItem.Name = "операцииToolStripMenuItem";
            this.операцииToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.операцииToolStripMenuItem.Text = "Операции";
            // 
            // добавлениеАвтомобиляToolStripMenuItem
            // 
            this.добавлениеАвтомобиляToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.добавлениеАвтомобиляToolStripMenuItem.Name = "добавлениеАвтомобиляToolStripMenuItem";
            this.добавлениеАвтомобиляToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            this.добавлениеАвтомобиляToolStripMenuItem.Text = "Добавление автомобиля";
            // 
            // редактированиеАвтомобилчToolStripMenuItem
            // 
            this.редактированиеАвтомобилчToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.редактированиеАвтомобилчToolStripMenuItem.Name = "редактированиеАвтомобилчToolStripMenuItem";
            this.редактированиеАвтомобилчToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            this.редактированиеАвтомобилчToolStripMenuItem.Text = "Редактирование автомобиля";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(285, 6);
            // 
            // выдачаАвтомобиляВПрокатToolStripMenuItem
            // 
            this.выдачаАвтомобиляВПрокатToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.выдачаАвтомобиляВПрокатToolStripMenuItem.Name = "выдачаАвтомобиляВПрокатToolStripMenuItem";
            this.выдачаАвтомобиляВПрокатToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            this.выдачаАвтомобиляВПрокатToolStripMenuItem.Text = "Выдача автомобиля в прокат";
            // 
            // продлениеСрокаПрокатаАвтомобиляToolStripMenuItem
            // 
            this.продлениеСрокаПрокатаАвтомобиляToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.продлениеСрокаПрокатаАвтомобиляToolStripMenuItem.Name = "продлениеСрокаПрокатаАвтомобиляToolStripMenuItem";
            this.продлениеСрокаПрокатаАвтомобиляToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            this.продлениеСрокаПрокатаАвтомобиляToolStripMenuItem.Text = "Продление срока проката автомобиля";
            // 
            // помощьToolStripMenuItem
            // 
            this.помощьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.помощьToolStripMenuItem.Name = "помощьToolStripMenuItem";
            this.помощьToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.помощьToolStripMenuItem.Text = "Помощь";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Image = global::CarHiresWinFormsApp.Properties.Resources.help;
            this.MniHelpAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(165, 38);
            this.MniHelpAbout.Text = "О программе";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 589);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(994, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // StlStatus
            // 
            this.StlStatus.Name = "StlStatus";
            this.StlStatus.Size = new System.Drawing.Size(979, 17);
            this.StlStatus.Spring = true;
            this.StlStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbBrandModels,
            this.TsbColors,
            this.TsbClients,
            this.TsbCars,
            this.TsbHires,
            this.toolStripSeparator1,
            this.TsbQuery01,
            this.TsbQuery02,
            this.TsbQuery03,
            this.TsbQuery04,
            this.toolStripSeparator2,
            this.TsbQuery05,
            this.TsbQuery06,
            this.toolStripSeparator3,
            this.toolStripButton12,
            this.toolStripButton13,
            this.toolStripSeparator4,
            this.toolStripButton14,
            this.toolStripButton15,
            this.toolStripSeparator5,
            this.toolStripButton16,
            this.TsbQuit});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(994, 39);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // TsbBrandModels
            // 
            this.TsbBrandModels.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbBrandModels.Image = global::CarHiresWinFormsApp.Properties.Resources.car;
            this.TsbBrandModels.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbBrandModels.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbBrandModels.Name = "TsbBrandModels";
            this.TsbBrandModels.Size = new System.Drawing.Size(36, 36);
            this.TsbBrandModels.ToolTipText = "Таблица производителей \r\nи моделей автомобилей";
            this.TsbBrandModels.Click += new System.EventHandler(this.QueryToBrandModels);
            // 
            // TsbColors
            // 
            this.TsbColors.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbColors.Image = global::CarHiresWinFormsApp.Properties.Resources.color_swatch;
            this.TsbColors.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbColors.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbColors.Name = "TsbColors";
            this.TsbColors.Size = new System.Drawing.Size(36, 36);
            this.TsbColors.Text = "toolStripButton2";
            this.TsbColors.ToolTipText = "Таблица цветов автомобилей";
            this.TsbColors.Click += new System.EventHandler(this.QueryToColors);
            // 
            // TsbClients
            // 
            this.TsbClients.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbClients.Image = global::CarHiresWinFormsApp.Properties.Resources.users_5;
            this.TsbClients.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbClients.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbClients.Name = "TsbClients";
            this.TsbClients.Size = new System.Drawing.Size(36, 36);
            this.TsbClients.Text = "toolStripButton3";
            this.TsbClients.ToolTipText = "Таблица клиентов\r\nпрокатной фирмы";
            this.TsbClients.Click += new System.EventHandler(this.QueryToClients);
            // 
            // TsbCars
            // 
            this.TsbCars.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbCars.Image = global::CarHiresWinFormsApp.Properties.Resources.car_taxi;
            this.TsbCars.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbCars.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbCars.Name = "TsbCars";
            this.TsbCars.Size = new System.Drawing.Size(36, 36);
            this.TsbCars.ToolTipText = "Таблица автомобилей\r\nв собственности прокатной\r\nфирмы";
            this.TsbCars.Click += new System.EventHandler(this.QueryToCars);
            // 
            // TsbHires
            // 
            this.TsbHires.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbHires.Image = global::CarHiresWinFormsApp.Properties.Resources.calendar;
            this.TsbHires.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbHires.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbHires.Name = "TsbHires";
            this.TsbHires.Size = new System.Drawing.Size(36, 36);
            this.TsbHires.Text = "toolStripButton2";
            this.TsbHires.ToolTipText = "Таблица фактов проката автомобилей";
            this.TsbHires.Click += new System.EventHandler(this.QueryToHires);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbQuery01
            // 
            this.TsbQuery01.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery01.Image = global::CarHiresWinFormsApp.Properties.Resources.key_a;
            this.TsbQuery01.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery01.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery01.Name = "TsbQuery01";
            this.TsbQuery01.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery01.Text = "toolStripButton6";
            this.TsbQuery01.ToolTipText = "Выполнение запроса 1 по заданию";
            this.TsbQuery01.Click += new System.EventHandler(this.Query01_Exec);
            // 
            // TsbQuery02
            // 
            this.TsbQuery02.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery02.Image = global::CarHiresWinFormsApp.Properties.Resources.key_b;
            this.TsbQuery02.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery02.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery02.Name = "TsbQuery02";
            this.TsbQuery02.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery02.Text = "toolStripButton7";
            this.TsbQuery02.ToolTipText = "Выполнение запроса 2 по заданию";
            this.TsbQuery02.Click += new System.EventHandler(this.Query02_Exec);
            // 
            // TsbQuery03
            // 
            this.TsbQuery03.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery03.Image = global::CarHiresWinFormsApp.Properties.Resources.key_c;
            this.TsbQuery03.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery03.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery03.Name = "TsbQuery03";
            this.TsbQuery03.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery03.Text = "toolStripButton8";
            this.TsbQuery03.ToolTipText = "Выполнение запроса 3 по заданию";
            this.TsbQuery03.Click += new System.EventHandler(this.Query03_Exec);
            // 
            // TsbQuery04
            // 
            this.TsbQuery04.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery04.Image = global::CarHiresWinFormsApp.Properties.Resources.key_d;
            this.TsbQuery04.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery04.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery04.Name = "TsbQuery04";
            this.TsbQuery04.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery04.Text = "toolStripButton9";
            this.TsbQuery04.ToolTipText = "Выполнение запроса 4 по заданию";
            this.TsbQuery04.Click += new System.EventHandler(this.Query04_Exec);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbQuery05
            // 
            this.TsbQuery05.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery05.Image = global::CarHiresWinFormsApp.Properties.Resources.key_e;
            this.TsbQuery05.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery05.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery05.Name = "TsbQuery05";
            this.TsbQuery05.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery05.Text = "toolStripButton10";
            this.TsbQuery05.ToolTipText = "Выполнение запроса 5 по заданию";
            this.TsbQuery05.Click += new System.EventHandler(this.Query05_Exec);
            // 
            // TsbQuery06
            // 
            this.TsbQuery06.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery06.Image = global::CarHiresWinFormsApp.Properties.Resources.key_f;
            this.TsbQuery06.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery06.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery06.Name = "TsbQuery06";
            this.TsbQuery06.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery06.Text = "toolStripButton11";
            this.TsbQuery06.ToolTipText = "Выполнение запроса 6 по заданию";
            this.TsbQuery06.Click += new System.EventHandler(this.Query06_Exec);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
            this.toolStripButton12.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton12.Text = "toolStripButton12";
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton13.Image")));
            this.toolStripButton13.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton13.Text = "toolStripButton13";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
            this.toolStripButton14.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton14.Text = "toolStripButton14";
            // 
            // toolStripButton15
            // 
            this.toolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton15.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton15.Image")));
            this.toolStripButton15.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton15.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton15.Name = "toolStripButton15";
            this.toolStripButton15.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton15.Text = "toolStripButton15";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButton16
            // 
            this.toolStripButton16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton16.Image = global::CarHiresWinFormsApp.Properties.Resources.help;
            this.toolStripButton16.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton16.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton16.Text = "toolStripButton16";
            // 
            // TsbQuit
            // 
            this.TsbQuit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuit.Image = global::CarHiresWinFormsApp.Properties.Resources.door_out;
            this.TsbQuit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuit.Name = "TsbQuit";
            this.TsbQuit.Size = new System.Drawing.Size(36, 36);
            this.TsbQuit.Text = "Выход";
            this.TsbQuit.ToolTipText = "Завершение приложения";
            this.TsbQuit.Click += new System.EventHandler(this.Quit_Command);
            // 
            // TbcResults
            // 
            this.TbcResults.Controls.Add(this.TbpTables);
            this.TbcResults.Controls.Add(this.TbpQueries);
            this.TbcResults.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcResults.Location = new System.Drawing.Point(0, 63);
            this.TbcResults.Name = "TbcResults";
            this.TbcResults.SelectedIndex = 0;
            this.TbcResults.Size = new System.Drawing.Size(994, 526);
            this.TbcResults.TabIndex = 3;
            // 
            // TbpTables
            // 
            this.TbpTables.Controls.Add(this.DgvTables);
            this.TbpTables.Location = new System.Drawing.Point(4, 22);
            this.TbpTables.Name = "TbpTables";
            this.TbpTables.Padding = new System.Windows.Forms.Padding(3);
            this.TbpTables.Size = new System.Drawing.Size(986, 500);
            this.TbpTables.TabIndex = 0;
            this.TbpTables.Text = "Таблицы";
            this.TbpTables.UseVisualStyleBackColor = true;
            // 
            // DgvTables
            // 
            this.DgvTables.AllowUserToAddRows = false;
            this.DgvTables.AllowUserToDeleteRows = false;
            this.DgvTables.AllowUserToResizeColumns = false;
            this.DgvTables.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Thistle;
            this.DgvTables.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DgvTables.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvTables.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DgvTables.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvTables.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvTables.Location = new System.Drawing.Point(3, 3);
            this.DgvTables.MultiSelect = false;
            this.DgvTables.Name = "DgvTables";
            this.DgvTables.ReadOnly = true;
            this.DgvTables.RowHeadersVisible = false;
            this.DgvTables.Size = new System.Drawing.Size(980, 494);
            this.DgvTables.TabIndex = 0;
            // 
            // TbpQueries
            // 
            this.TbpQueries.Controls.Add(this.DgvQueries);
            this.TbpQueries.Location = new System.Drawing.Point(4, 22);
            this.TbpQueries.Name = "TbpQueries";
            this.TbpQueries.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQueries.Size = new System.Drawing.Size(986, 500);
            this.TbpQueries.TabIndex = 1;
            this.TbpQueries.Text = "Запросы";
            this.TbpQueries.UseVisualStyleBackColor = true;
            // 
            // DgvQueries
            // 
            this.DgvQueries.AllowUserToAddRows = false;
            this.DgvQueries.AllowUserToDeleteRows = false;
            this.DgvQueries.AllowUserToResizeColumns = false;
            this.DgvQueries.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Thistle;
            this.DgvQueries.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.DgvQueries.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQueries.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DgvQueries.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQueries.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvQueries.Location = new System.Drawing.Point(3, 3);
            this.DgvQueries.MultiSelect = false;
            this.DgvQueries.Name = "DgvQueries";
            this.DgvQueries.ReadOnly = true;
            this.DgvQueries.RowHeadersVisible = false;
            this.DgvQueries.Size = new System.Drawing.Size(980, 494);
            this.DgvQueries.TabIndex = 1;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(994, 611);
            this.Controls.Add(this.TbcResults);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 02.02.2022 - запросы к базе данных фирмы по прокату автомобилей";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.TbcResults.ResumeLayout(false);
            this.TbpTables.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvTables)).EndInit();
            this.TbpQueries.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQueries)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniFileQuit;
        private System.Windows.Forms.ToolStripMenuItem таблицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniTablesBrandModels;
        private System.Windows.Forms.ToolStripMenuItem цветаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клиентыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem автомобилиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem фактыПрокатаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запросыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem запрос5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem помощьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem операцииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавлениеАвтомобиляToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактированиеАвтомобилчToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem выдачаАвтомобиляВПрокатToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem продлениеСрокаПрокатаАвтомобиляToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton TsbBrandModels;
        private System.Windows.Forms.ToolStripButton TsbHires;
        private System.Windows.Forms.ToolStripButton TsbClients;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton TsbQuery01;
        private System.Windows.Forms.ToolStripButton TsbQuery02;
        private System.Windows.Forms.ToolStripButton TsbQuery03;
        private System.Windows.Forms.ToolStripButton TsbQuery04;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton TsbQuery05;
        private System.Windows.Forms.ToolStripButton TsbQuery06;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.ToolStripButton toolStripButton15;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.ToolStripButton TsbQuit;
        private System.Windows.Forms.TabControl TbcResults;
        private System.Windows.Forms.TabPage TbpTables;
        private System.Windows.Forms.DataGridView DgvTables;
        private System.Windows.Forms.TabPage TbpQueries;
        private System.Windows.Forms.ToolStripStatusLabel StlStatus;
        private System.Windows.Forms.ToolStripButton TsbColors;
        private System.Windows.Forms.ToolStripButton TsbCars;
        private System.Windows.Forms.DataGridView DgvQueries;
    }
}

