﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarHires
{
    // Представление результатов запроса 5 - запроса с левым соединением
    // Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
    // суммарное количество дней проката
    public class ResultQuery05
    {
        // фамилия и инициалы клиента
        public string ClientFullname { get; set; }

        // количество фактов проката
        public int TotalHires { get; set; }

        // суммарное количество дней проката для клиента
        public int TotalDays { get; set; }
    } // class ResultQuery05
}
