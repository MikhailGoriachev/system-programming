﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarHires
{
    // Представление результатов запроса 6 - запроса с левым соединением:
    //     ☼ автомобиль прокатной фирмы
    //     ☼ количество фактов проката автомобиля
    //     ☼ сумма за прокаты автомобиля
    //     ☼ суммарная длительность прокатов автомобиля
    public class ResultQuery06
    {
        // автомобиль прокатной фирмы
        public string Plate { get; set; }
        public string BrandModel { get; set; }

        // количество фактов проката автомобиля
        public int TotalHires { get; set; }

        // сумма за прокаты автомобиля
        public int TotalCost { get; set; }

        // суммарная длительность прокатов автомобиля в днях
        public int TotalDays { get; set; }
    } // class ResultQuery06
}
