﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarHires
{
    // ------------------------------------------------------------------------
    // Запросы к базе данных CarHire
    //
    // запросы к таблицам, представлениям для выборки всех записей
    //
    // Запрос 1. Выборка данных.
    // Выбирает информацию обо всех фактах проката автомобиля с заданным
    // госномером
    //
    // Запрос 2. Выборка данных.
    // Выбирает информацию обо всех фактах проката автомобиля с заданной
    // моделью/брендом
    //
    // Запрос 3. Выборка данных.
    // Выбирает информацию о клиентах по серии и номеру паспорта
    //
    // Запрос 4. Выборка данных.
    // Вычисляет для каждого факта проката стоимость проката. Включает поля
    // Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
    // Сортировка по полю Дата проката
    //
    // Запрос 5. Запрос с левым соединением
    // Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
    // суммарное количество дней проката, упорядочивание по убыванию суммарного
    // количества дней проката
    //
    // Запрос 6. Запрос с левым соединением
    // Для всех автомобилей прокатной фирмы определите количество фактов
    // проката, сумма за прокаты, суммарная длительность прокатов
    // ------------------------------------------------------------------------
    public class CarHireQueries
    {
        private CarHireDataContext _db;

        public CarHireQueries():this(new CarHireDataContext()) {

        } // CarHireQueries

        public CarHireQueries(CarHireDataContext db) {
            _db = db;
        } // CarHireQueries


        // Вернуть все записи таблицы с названиями производителейи моделей автомобилей
        public List<BrandModels> GetBrandModelsAll() => _db.BrandModels.ToList();

        // Вернуть все записи таблицы с названиями цветов автомобилей
        public List<Colors> GetColorsAll() => _db.Colors.ToList();

        // Вернуть все записи таблицы с данными клиентов
        public List<Clients> GetClientsAll() => _db.Clients.ToList();

        // Вернуть все записи представления с данными автомобилей
        public List<ViewCars> GetCarsAll() => _db.ViewCars.ToList();

        // Вернуть все записи представления с данными о фактах проката
        public List<ViewHires> GetHiresAll() => _db.ViewHires.ToList();


        // Запрос 1. Выборка данных.
        // Выбирает информацию обо всех фактах проката автомобиля с заданным
        // госномером
        public List<ViewHires> Query01(string plate) => _db.ViewHires
            .Where(h => h.Plate == plate)
            .ToList();

        // Запрос 2. Выборка данных.
        // Выбирает информацию обо всех фактах проката автомобиля с заданной
        // моделью/брендом
        public List<ViewHires> Query02(string brandModel) => _db.ViewHires
            .Where(h => h.BrandModel == brandModel)
            .ToList();

        // Запрос 3. Выборка данных.
        // Выбирает информацию о клиентах по серии и номеру паспорта
        public List<Clients> Query03(string passport) => _db.Clients
            .Where(c => c.Passport == passport)
            .ToList();

        // Запрос 4. Выборка данных.
        // Вычисляет для каждого факта проката стоимость проката. Включает поля
        // Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
        // Сортировка по полю Дата проката
        public List<ResultQuery04> Query04() => _db.ViewHires
            .Select(h => new ResultQuery04 {
                Id = h.Id,
                Plate = h.Plate,
                BrandModel = h.BrandModel,
                DateStart = h.DateStart,
                Cost = h.Rental * h.Duration})
            .ToList();

        // Запрос 5. Запрос с левым соединением
        // Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
        // суммарное количество дней проката, упорядочивание по убыванию суммарного
        // количества дней проката
        public List<ResultQuery05> Query05() {
            // левое соединение
            var query1 = from client in _db.Clients
                join hire in _db.Hires
                    on client.Id equals hire.IdClient
                    into temp
                from item in temp.DefaultIfEmpty()
                select new {
                    // использоввание интерполяционной строки приводило к выбросу исключения
                    // ClientFullname = $"{client.Surname} {client.Name[0]}.{client.Patronymic[0]}.",
                    ClientFullname = client.Surname + " " +  client.Name[0] + "." + client.Patronymic[0] + ".",
                    Duration = item == null?0: item.Duration
                };

            // группировка по заданию
            var query2 = from datum in query1
                group datum by datum.ClientFullname
                into clients
                select new ResultQuery05 {
                    ClientFullname = clients.Key,
                    TotalHires = clients.Count(c => c.Duration != 0),
                    TotalDays = clients.Sum(c => c.Duration)
                };

            // сортировка данных запроса
            var query3 = from datum in query2
                orderby datum.TotalDays descending
                select datum;

            return query3.ToList();
        } // Query05

        // Запрос 6. Запрос с левым соединением
        // Для всех автомобилей прокатной фирмы определите количество фактов
        // проката, сумма за прокаты, суммарная длительность прокатов
        public List<ResultQuery06> Query06() {
            // левое соединение
            var query1 = from car in _db.Cars
                join hire in _db.Hires on car.Id equals hire.IdCar into temp
                from item in temp.DefaultIfEmpty()
                select new {
                    car.Plate,
                    car.BrandModels.BrandModel,
                    Rental = item == null? 0: car.Rental,
                    Duration = item == null ? 0 : item.Duration
                };

            // группировка записей, вычисление статистики
            var query2 = from datum in query1
                group datum by new {datum.Plate, datum.BrandModel, datum.Rental}
                into grCars
                select new ResultQuery06 {
                    Plate = grCars.Key.Plate,
                    BrandModel = grCars.Key.BrandModel,
                    TotalHires = grCars.Count(c => c.Duration != 0),
                    TotalDays = grCars.Sum(c => c.Duration),
                    TotalCost = grCars.Sum(c => c.Duration * c.Rental)
                };

            // упорядочить по убыванию фактов проката
            var query3 = from datum in query2
                orderby datum.TotalHires descending
                select datum;

            // возврат результатов запроса в виде коллекции
            return query3.ToList();
        } // Query06
    } // class CarHireQueries
}
