﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarHires
{
    // класс для представления результата запроса 4
    // Поля класса:
    // Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
    public class ResultQuery04
    {
        // Идентификатор записи
        public int Id { get; set; }

        // Дата проката
        public DateTime DateStart { get; set; }

        // Госномер автомобиля
        public string Plate { get; set; }

        // Модель автомобиля
        public string BrandModel { get; set; }

        // Стоимость проката - вычисляемое поле
        public int Cost { get; set; }
    } // class ResultQuery04
}
