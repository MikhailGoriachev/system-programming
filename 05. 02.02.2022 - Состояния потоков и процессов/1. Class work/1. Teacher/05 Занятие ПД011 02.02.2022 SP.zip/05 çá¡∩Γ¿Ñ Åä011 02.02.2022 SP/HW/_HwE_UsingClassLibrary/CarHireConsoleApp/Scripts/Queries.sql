﻿/* База данных «Прокат автомобилей» */

-- Вывод записей таблицы автомобилей с расшифровкой всех полей
select
    *
from
    ViewCars;
go

-- Вывод записей таблицы фактов проката с расшифровкой всех полей
select
    *
from
    ViewHires
-- order by
--    Plate
;
go

--  1. Запрос к представлению	
--     Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
declare @plate nvarchar(12) = N'О169РК';

select
    Id
    , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
          Substring(ClientPatronymic, 1, 1) + N'.' as Client
    , BrandModel
    , Plate
    , DateStart
    , Duration
from
    ViewHires
where
    Plate = @plate 
order by
    DateStart;
go


--  2. Запрос к представлению	
--     Выбирает информацию обо всех фактах проката автомобиля с заданной 
--     моделью/брендом
declare @brandModel nvarchar(30) = N'Volkswagen Polo';

select
    Id
    , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
          Substring(ClientPatronymic, 1, 1) + N'.' as Client
    , BrandModel
    , Plate
    , DateStart
    , Duration
from
    ViewHires
where
    BrandModel = @brandModel 
order by
    DateStart;
go

--  3. Запрос к представлению
--     Выбирает информацию об автомобиле с заданным госномером
-- declare @plate nvarchar(12) = N'О169РК';
declare @plate nvarchar(12) = N'С';

select
    Id 
    , BrandModel
    , Color
    , Plate
    , YearManuf
    , InsurValue
    , Rental
from
    ViewCars
where
    -- Plate = @plate;
    Plate like @plate + N'%';
go

--  4. Запрос с параметром	
--     Выбирает информацию о клиентах по серии и номеру паспорта
declare @passport nvarchar(15) = N'11 21 098181';

select
    Id 
    , Surname
    , [Name]
    , Patronymic
    , Passport
from
    Clients
where
    Passport = @passport;
go


--  5. Запрос к представлению	
--     Выбирает информацию обо всех зафиксированных фактах проката автомобилей
--     в некоторый заданный интервал времени.
declare @from date = '10-01-2021', @to date = '10-31-2021';

select
    Id
    , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
          Substring(ClientPatronymic, 1, 1) + N'.' as Client
    , BrandModel
    , Plate
    , DateStart
    , Duration
from
    ViewHires
where
    DateStart between @from and @to 
order by
    DateStart;
go

--  6. Запрос к представленмю
--     Вычисляет для каждого факта проката стоимость проката. Включает поля 
--     Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
--     Сортировка по полю Дата проката
select
    Id
    , DateStart
    , Plate
    , BrandModel
    , Rental                  as RentalPerDay
    , Duration
    , Rental * Duration as Price 
from
    ViewHires
order by
    DateStart;
go


--  7. Запрос с левым соединением	
--     Для всех клиентов прокатной фирмы вычисляет количество фактов проката, 
--     суммарное количество дней проката, упорядочивание по убыванию 
--     суммарного количества дней проката
select
    Clients.Id
    , Clients.Surname + N' ' + Substring(Clients.[Name], 1, 1) + N'.' + 
          Substring(Clients.Patronymic, 1, 1) + N'.' as ClientFullName
    , Count(Hires.IdCar) as Amount
    , IsNull(Sum(Duration), 0) as TotalDuration
from
    Clients left join Hires on Clients.Id = Hires.IdClient
group by
    Clients.Id, Clients.Surname, Clients.[Name], Clients.Patronymic
order by
    TotalDuration desc;
go


--  8. Итоговый запрос	
--     Выбирает информацию о фактах проката автомобилей по госномеру: 
--     количество фактов проката, сумма за прокаты, суммарная длительность 
--     прокатов
select
    Plate
    , Count(Plate)           as Total
    , Sum(Rental * Duration) as TotalRental
    , Sum(Duration)          as TotalDuration
from  
    ViewHires
group by
    Plate;
go


--  9. Запрос на добавление	
--     Добавляет данные о новом клиенте. Данные передавайте параметрами
declare @surname    nvarchar(60) = N'Дорамова',     -- Фамилия клиента
	    @name       nvarchar(50) = N'Серафима',     -- Имя клиента
	    @patronymic nvarchar(60) = N'Ричардовна',   -- Отчество клиента
 	    @passport   nvarchar(15) = N'13 29 112021'; -- Номер и серия паспорта

insert Clients
    (Surname, [Name], Patronymic, Passport)
values 
    (@surname, @name, @patronymic, @passport);

-- !! закомментировать вставку перед удалением !!
-- удаление введенных данных, для возможности повторного выполнения команды 
-- вставки при демонстрации работающих запросов
delete from
    Clients
where
    Passport = @passport;
go

-- 10. Запрос на обновление	
--     Изменяет данные клиента (все поля, кроме идентификатора). 
--     Данные передавайте параметрами.
declare @newSurname    nvarchar(60) = N'Дорамова',     -- Фамилия клиента
	    @newName       nvarchar(50) = N'Серафима',     -- Имя клиента
	    @newPatronymic nvarchar(60) = N'Ричардовна',   -- Отчество клиента
 	    @newPassport   nvarchar(15) = N'13 29 112021', -- Номер и серия паспорта
 	    @oldPassport   nvarchar(15) = N'13 18 000603';  -- старый номер и серия паспорта

update  -- поиск клиента по номеру и серии паспорта 
    Clients
set 
    Surname    = @newSurname,
    [Name]     = @newName,
    Patronymic = @newPatronymic,
    Passport   = @newPassport
where
    Passport = @oldPassport;
go

-- хардкодим проверяющий запрос, новый номер и серия паспортп
select * from Clients where Passport = N'13 29 112021';
go

-- !! хардкодим восстанавливающий запрос
update 
    Clients
set 
    Surname    = N'Ильюшин',
    [Name]     = N'Сергей',
    Patronymic = N'Юрьевич',
    Passport   = N'13 18 000603'
where
    Passport = N'13 29 112021';
select * from Clients where Passport = N'13 18 000603';
go
     

-- 11. Запрос на обновление	
--     Изменяет данные автомобиля (все поля, кроме идентификатора). 
--     Данные передавайте параметрами
declare @newBrandModel nvarchar(30) = N'Mercedes 210', -- бренд-модель автомобиля
        @newColor      nvarchar(30) = N'серебристый',  -- цвет автомобиля
        @newPlate      nvarchar(12) = N'М345РК',       -- гос. регистрационный номер автомобиля
        @newYearManuf  int          = 2020,            -- год производства автомобиля
        @newInsurValue int          = 4500000,         -- страховая стоимость
        @newRental     int          = 5100,            -- стоимость одного дня проката
        @oldPlate      nvarchar(12) = N'В019РК';       -- старый гос. регистрационный номер автомобиля

update 
    Cars
set 
    IdBrand      = (select Id from BrandModels where BrandModel = @newBrandModel)
    , idColor    = (select Id from Colors where Color = @newColor)
    , Plate      = @newPlate
    , YearManuf  = @newYearManuf
    , InsurValue = @newInsurValue
    , Rental     = @newRental
where
    Plate = @oldPlate;
go

-- хардкодим проверяющий запрос, новый гос. регистрационный номер
select * from ViewCars where Plate = N'М345РК';
go

-- !! хардкодим восстанавливающий запрос
update 
    Cars
set 
    IdBrand      = (select Id from BrandModels where BrandModel = N'Toyota Camry')
    , idColor    = (select Id from Colors where Color = N'бело-желтый')
    , Plate      = N'В019РК'
    , YearManuf  = 2018
    , InsurValue = 4000000
    , Rental     = 6000
where
    Plate = N'М345РК';
select * from ViewCars where Plate = N'В019РК';
go


-- 12. Изучение T-SQL	
--     Задача If13. Даны три числа. Найти среднее из них (то есть число, 
--     расположенное между наименьшим и наибольшим). Числа формируйте 
--     генератором случайных чисел
declare 
   @a int = -10 + 20*rand(),
   @b int = -10 + 20*rand(),
   @c int = -10 + 20*rand();
declare @mid int;    -- среднее из трех

print char(10) +
      N'    Задача If13.' + char(10) +
      N'    Вывести среднее из трех чисел (значение между наименьшим и наибольшим)' + char(10) +
      N'    ------------------------------------------------------------------' + char(10) +
      N'    Исходные данные      a         b         c' + char(10) +
      N'    ------------------------------------------------------------------' + char(10) +
      char(9) + char(9) + str(@a, 18) + str(@b, 10) + str(@c, 10);

if @a between @b and @c or @a between @c and @b 
    set @mid = @a;
else if @b between @a and @c or @b between @c and @a  
    set @mid = @b;
else 
    set @mid = @c;

-- выводим результат
print N'    ------------------------------------------------------------------' + char(10) +
      N'    Среднее из трех    ' + str(@mid, 13) + char(10) +
      N'    ------------------------------------------------------------------';
go

-- 13. Изучение T-SQL	
--     Задача If14. Даны три числа. Вывести вначале наименьшее, а затем 
--     наибольшее из данных чисел. Числа формируйте генератором случайных
--     чисел
declare 
   @a int = -10 + 20*rand(),
   @b int = -10 + 20*rand(),
   @c int = -10 + 20*rand();
declare @min int, @max int;

print char(10) +
      N'    Задача If14.' + char(10) +
      N'    Вывести наименьшее, затем наибольшее из трех чисел' + char(10) +
      N'    ------------------------------------------------------------------' + char(10) +
      N'    Исходные данные      a         b         c' + char(10) +
      N'    ------------------------------------------------------------------' + char(10) +
      char(9) + char(9) + str(@a, 18) + str(@b, 10) + str(@c, 10);

if @a < @b and @a < @c begin
    set @min = @a;
    set @max = iif(@b > @c, @b, @c);
end else if @b < @c begin
    set @min = @b;
    set @max = iif(@a > @c, @a, @c);
end else begin
    set @min = @c;
    set @max = iif(@a > @b, @a, @b);
end;

-- выводим результат
print N'    ------------------------------------------------------------------' + char(10) +
      N'    Наименьшее из трех ' + str(@min, 13) + char(10) +
      N'    Наибольшее из трех ' + str(@max, 13) + char(10) +
      N'    ------------------------------------------------------------------';
go

-- 14. Изучение T-SQL	
--     Задача If15. Даны три числа. Найти сумму двух наибольших из них. 
--     Числа формируйте генератором случайных чисел
declare 
   @a int = -10 + 20*rand(),
   @b int = -10 + 20*rand(),
   @c int = -10 + 20*rand();
declare @sum int, @max1 int, @max2 int;

print char(10) +
      N'    Задача If15.' + char(10) +
      N'    Сумма двух наибольших из трех чисел' + char(10) +
      N'    ------------------------------------------------------------------' + char(10) +
      N'    Исходные данные      a         b         c' + char(10) +
      N'    ------------------------------------------------------------------' + char(10) +
      char(9) + char(9) + str(@a, 18) + str(@b, 10) + str(@c, 10);

if @a < @b and @a < @c begin  -- если a - минимальное, то b, c два наибольших
    set @max1 = @b;
    set @max2 = @c;
end else if @b < @c begin     -- если b - минимальное, то a, c два наибольших
    set @max1 = @a;
    set @max2 = @c;
end else begin                -- если c - минимальное, то a, b два наибольших
    set @max1 = @a;
    set @max2 = @b;
end;

-- сумма двух наибольших
set @sum = @max1 + @max2;

-- выводим результат
print N'    ------------------------------------------------------------------' + char(10) +
      N'    Два наибольших       ' + str(@max1, 11) + str(@max2, 10) + char(10) +
      N'    Сумма двух наибольших' + str(@sum, 11) + char(10) +
      N'    ------------------------------------------------------------------';
go

-- 15. Изучение T-SQL	
--     Задача If17. Даны три числа. Если их значения упорядочены по возрастанию
--     или убыванию, то удвоить их; в противном случае заменить значение каждой
--     переменной на противоположное. Числа формируйте генератором случайных 
--     чисел или присваиванием
declare 
   @a int = -10 + 20*rand(),
   @b int = -10 + 20*rand(),
   @c int = -10 + 20*rand();

print char(10) +
      N'    Задача If17.' + char(10) +
      N'    Если три числа упорядочены по убыванию или по возрастанию, то удвоить' + char(10) +
      N'    их, иначе заменить значения на противоположоные' + char(10) +
      N'    ------------------------------------------------------------------' + char(10) +
      N'                                a         b         c' + char(10) +
      N'    ------------------------------------------------------------------' + char(10) +
      N'    Исходные данные    ' + str(@a, 10) + str(@b, 10) + str(@c, 10);

if @a < @b and @b < @c or @a > @b and @b > @c  begin  
    set @a *= 2;
    set @b *= 2;
    set @c *= 2;
end else begin     
    set @a = -@a;
    set @b = -@b;
    set @c = -@c;
end;

-- выводим результат
print N'    Обработанные данные' + str(@a, 10) + str(@b, 10) + str(@c, 10) + char(10) +
      N'    ------------------------------------------------------------------';
go
