﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using CarHires;
using CarHiresConsoleApp.Application;

namespace CarHiresConsoleApp
{
    
    public class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 02.02.2022, выполнение запросов по таймеру";

            // создать объект для выполнения запросов
            App app = new App();

            // вывод таблиц и представлений базы данных
            app.ShowBrandModels();
            app.ShowColors();
            app.ShowClients();
            app.ShowViewCars();
            app.ShowViewHires();

            // Реализация таймера в стиле "быстро, но грязно"
            Timer timer = new Timer(o => {
                // номерные запросы по заданию
                app.ShowQuery01();
                app.ShowQuery05();
                app.ShowQuery06();
            });

            // запуск с задержкой 0 мс, затем период запуска 2000 мс
            timer.Change(0, 2_000);

            Console.ReadKey(true);
        } // Main
    } // class Program
}
