﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarHires;

namespace CarHiresConsoleApp.Application
{
    public partial class App
    {
        // Добавить ссылку на библиотеку классов
        // Добавить строку соединения в app.config из app.config библиотеки классов
        CarHireQueries _carHireQueries;

        public App():this(new CarHireQueries()) { } // App
        public App(CarHireQueries carHireQueries) {
            _carHireQueries = carHireQueries;
        } // App
    } // class App
}
