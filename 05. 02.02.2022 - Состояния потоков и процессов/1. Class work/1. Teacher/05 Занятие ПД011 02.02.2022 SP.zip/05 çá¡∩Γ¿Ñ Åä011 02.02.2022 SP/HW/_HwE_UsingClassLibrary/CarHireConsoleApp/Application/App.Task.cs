﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarHires;
using CarHiresConsoleApp.Infrastructure;

namespace CarHiresConsoleApp.Application
{
    // выполнение запросов по заданию
    public partial class App
    {
        // Таблица производителей и типов автомобилей
        public void ShowBrandModels() {
            // Вывод таблиц базы данных
            Console.WriteLine("\n\n\tТаблица BrandModels. Производители и модели автомомбилей");
            List<BrandModels> brandModels = _carHireQueries.GetBrandModelsAll();
            brandModels.ForEach(b => Console.WriteLine($"\t│ {b.Id,3} │ {b.BrandModel,-20} │"));
        } // ShowBrandModels


        // Вывод таблицы цветов автомобилей
        public void ShowColors() {
            Console.WriteLine("\n\n\tТаблица Colors. Цвета автомомбилей");
            List<Colors> colors = _carHireQueries.GetColorsAll();
            colors.ForEach(c => Console.WriteLine($"\t│ {c.Id,3} │ {c.Color,-14} │"));
        } // ShowColors

        // Вывод таблицы клиентов
        public void ShowClients() {
            Console.WriteLine("\n\n\tТаблица Clients. Клиенты фирмы проката автомомбилей");
            List<Clients> clients = _carHireQueries.GetClientsAll();
            clients.ForEach(c => Console.WriteLine($"\t" +
                $"│ {c.Id,3} │ {c.Surname,-14} │ {c.Name,-12} " +
                $"│ {c.Patronymic,-16} │  {c.Passport,-12} │"));
        } // ShowClients

        // Вывод представления с данными об автомобилях
        public void ShowViewCars() {
            Console.WriteLine("\n\n\tПредставление ViewCars. Автомобили фирмы проката");
            List<ViewCars> cars = _carHireQueries.GetCarsAll();
            cars.ForEach(c => Console.WriteLine(
                $"\t│ {c.Id,3} │ {c.Plate, -6} │ {c.BrandModel,-16} │ {c.Color,-14} " +
                $"│ {c.YearManuf, 6} │  {c.InsurValue, 15:n2} │ {c.Rental, 8:n2} │"));
        } // ShowViewCars

        // Вывод представления с данными о фактах проката автомобилей
        public void ShowViewHires() {
            Console.WriteLine("\n\n\tПредставление ViewHires. Факты проката автомобилей фирмы проката");
            List<ViewHires> hires = _carHireQueries.GetHiresAll();
            hires.ForEach(c => Console.WriteLine(
                $"\t│ {c.Id,3} │ {c.Plate, -6} │ {c.BrandModel,-16} │ {c.Color,-14} " +
                $"│ {c.ClientSurname, -14} │  {c.ClientName, -12} │ {c.ClientPatronymic, -16} " +
                $"│ {c.DateStart:d} │ {c.Duration, 3} │ {c.Rental, 8:n2} │"));
        } // ShowViewHires

        // Запрос 1. Выборка данных.
        // Выбирает информацию обо всех фактах проката автомобиля с заданным
        // госномером
        public void ShowQuery01() {
            List<ViewCars> cars = _carHireQueries.GetCarsAll();
            string plate = cars[Utils.GetRandom(0, cars.Count - 1)].Plate;

            Console.WriteLine($"\n\n\tЗапрос 1. Факты проката автомобиля {plate}");
            List<ViewHires> hires = _carHireQueries.Query01(plate);
            hires.ForEach(c => Console.WriteLine(
                $"\t│ {c.Id,3} │ {c.Plate,-6} │ {c.BrandModel,-16} │ {c.Color,-14} " +
                $"│ {c.ClientSurname,-14} │  {c.ClientName,-12} │ {c.ClientPatronymic,-16} " +
                $"│ {c.DateStart:d} │ {c.Duration,3} │ {c.Rental,8:n2} │"));
        } // ShowQuery01

        // Запрос 2. Выборка данных.
        // Выбирает информацию обо всех фактах проката автомобиля с заданной
        // моделью/брендом

        // Запрос 3. Выборка данных.
        // Выбирает информацию о клиентах по серии и номеру паспорта

        // Запрос 4. Выборка данных.
        // Вычисляет для каждого факта проката стоимость проката. Включает поля
        // Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
        // Сортировка по полю Дата проката

        // Запрос 5. Запрос с левым соединением
        // Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
        // суммарное количество дней проката, упорядочивание по убыванию суммарного
        // количества дней проката
        public void ShowQuery05() {
            Console.WriteLine("\n\n\tЗапрос 5. Левое соединение");
            List<ResultQuery05> clients = _carHireQueries.Query05();
            clients.ForEach(c => Console.WriteLine(
                $"\t│ {c.ClientFullname,-18} │ {c.TotalHires, 6} │ {c.TotalDays, 6} │"));
        } // ShowQuery05

        // Запрос 6. Запрос с левым соединением
        // Для всех автомобилей прокатной фирмы определите количество фактов
        // проката, сумма за прокаты, суммарная длительность прокатов
        public void ShowQuery06() {
            Console.WriteLine("\n\n\tЗапрос 6. Левое соединение");
            List<ResultQuery06> cars = _carHireQueries.Query06();
            cars.ForEach(c => Console.WriteLine(
                $"\t│ {c.Plate,-6} │ {c.BrandModel, -18} │ {c.TotalHires,6} │ {c.TotalDays,6} │ {c.TotalCost, 11:n2} │"));
        } // ShowQuery05
    } // class App
}
