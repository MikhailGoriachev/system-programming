﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarHireLibrary.Models
{
    public class Car {
        // идентификатор
        public int Id{ get; set; }

        // бренд-модель автомобиля
        public string Brand{ get; set; }

        // цвет автомобиля
        public string Color{ get; set; }

        // гос.регистрационный номер автомобиля
        public string Plate{ get; set; }

        // год производства автомобиля
        public int YearManuf{ get; set; }

        // страховая стоимость
        public int InsurValue{ get; set; }

        // стоимость одного дня проката
        public int Rental{ get; set; }

    } // Car
}
