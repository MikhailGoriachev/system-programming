﻿using CarHireLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarHireLibrary.Controllers
{
    public class CarHireController {

        // контекст данных - подключение к базе данных
        private CarHireDataContext _db;
        public CarHireController() {
            _db = new CarHireDataContext();
        } // CarHireController


        #region Выборки всех записей таблиц
        public List<Clients> GetClients() => _db.Clients.ToList();
        public List<Colors> GetColors() => _db.Colors.ToList();
        public List<BrandModels> GetBrandModels() => _db.BrandModels.ToList();
        public List<Cars> GetCars() => _db.Cars.ToList();
        public List<Car> GetCarsViewModel() =>
            _db.Cars
                .Select(c => new Car {
                    Id = c.Id,
                    Brand = c.BrandModels.BrandModel,
                    Color = c.Colors.Color,
                    InsurValue = c.InsurValue,
                    Plate = c.Plate,
                    Rental = c.Rental,
                    YearManuf = c.YearManuf
                }).ToList();

        public List<Hire> GetHires() =>
            _db.Hires 
                .Select(h => new Hire {
                    Id = h.Id,
                    Brand = h.Cars.BrandModels.BrandModel,
                    Plate = h.Cars.Plate,
                    DateStart = h.DateStart,
                    Duration = h.Duration,
                    Rental = h.Cars.Rental,
                    Client = $"{h.Clients.Surname} {h.Clients.Name[0]}.{h.Clients.Patronymic[0]}."
                }).ToList();
        #endregion

        // Выдача автомобиля в прокат
        public void AddHire(Hires hire)  {
            _db.Hires.InsertOnSubmit(hire);

            try {
                _db.SubmitChanges();
            }
            catch (Exception e) {
                Console.WriteLine(e);
            } // try-catch
        } // Hire

        // Добавление автомобиля
        public void AddCar(Cars car) {
            _db.Cars.InsertOnSubmit(car);

            try {
                _db.SubmitChanges();
            }
            catch (Exception e) {
                Console.WriteLine(e);
            } // try-catch
        } // AddCar

        // редактировать автомобиль
        public void EditCar(int index, Cars car) {
            _db.Cars.ToArray()[index] = car;

            try {
                _db.SubmitChanges();
            }
            catch (Exception e) {
                Console.WriteLine(e);
            } // try-catch
        } // EditCar

        // продление срока проката автомобиля на заданное количество дней
        public void AddDuration(int index, int days) {
            Hires hire = _db.Hires.ToArray()[index];

            hire.Duration += days;
            try {
                _db.SubmitChanges();
            }
            catch (Exception e) {
                Console.WriteLine(e);
            } // try-catch
        } // EditCar


        #region Запросы
        // 1. Выборка данных
        // Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
        public List<Hire> Query01(string plate) =>
            _db.Hires
                .Where(h => h.Cars.Plate == plate)
                .Select(h => new Hire {
                    Id = h.Id,
                    Brand = h.Cars.BrandModels.BrandModel,
                    Plate = h.Cars.Plate,
                    DateStart = h.DateStart,
                    Duration = h.Duration,
                    Rental = h.Cars.Rental,
                    Client = $"{h.Clients.Surname} {h.Clients.Name[0]}.{h.Clients.Patronymic[0]}."
                }).ToList();


        // 2. Выборка данных
        // Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
        public List<Hire> Query02(string brand) =>
            _db.Hires
                .Where(h => h.Cars.BrandModels.BrandModel == brand)
                .Select(h => new Hire {
                    Id = h.Id,
                    Brand = h.Cars.BrandModels.BrandModel,
                    Plate = h.Cars.Plate,
                    DateStart = h.DateStart,
                    Duration = h.Duration,
                    Rental = h.Cars.Rental,
                    Client = $"{h.Clients.Surname} {h.Clients.Name[0]}.{h.Clients.Patronymic[0]}."
                }).ToList();


        // 3. Выборка данных
        // Выбирает информацию о клиентах по серии и номеру паспорта
        public List<Clients> Query03(string passport) =>
            _db.Clients.Where(c => c.Passport == passport).ToList();


        // 4. Выборка данных
        // Вычисляет для каждого факта проката стоимость проката.
        // Включает поля Дата проката, Госномер автомобиля, Модель автомобиля,
        // Стоимость проката.Сортировка по полю Дата проката
        public List<Query04ViewModel> Query04() =>
            _db.Hires
                .Select(h => new Query04ViewModel { 
                    Brand = h.Cars.BrandModels.BrandModel,
                    DateStart= h.DateStart,
                    Plate= h.Cars.Plate,
                    Price = h.Duration * h.Cars.Rental
                })
                .OrderBy(h => h.DateStart)
                .ToList();


        // 5. Запрос с левым соединением
        // Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
        // суммарное количество дней проката, упорядочивание по убыванию суммарного количества дней проката
        public List<Query05ViewModel> Query05() =>
            _db.Clients
                .GroupJoin(_db.Hires,
                    client => client.Id,
                    hire => hire.IdClient,
                    (client, group_join) => new {
                        client,
                        group_join
                    })
                .SelectMany(t => t.group_join.DefaultIfEmpty(),
                    (t, subHire) => new {
                        t.client.Passport,
                        Client = $"{t.client.Surname} {t.client.Name[0]}.{t.client.Patronymic[0]}.",
                        Duration = (int?)subHire.Duration,
                    }).ToList()
                .GroupBy(c => new { c.Client, c.Passport }, (key, group) => new Query05ViewModel {
                    Passport = key.Passport,
                    Client = key.Client,
                    Amount = group.Count(h => h.Duration != null),
                    SumDuration = (int)group.Sum(x => x.Duration)
                })
                .OrderBy(x => x.SumDuration)
                .ToList();


        // 6. Запрос с левым соединением
        // Для всех автомобилей прокатной фирмы определите количество фактов проката, сумма за прокаты,
        // суммарная длительность прокатов
        public List<Query06ViewModel> Query06() =>
            _db.Cars
                .GroupJoin(_db.Hires,
                    car => car.Id,
                    hire => hire.IdCar,
                    (car, group_join) => new {
                        car,
                        group_join
                    })
                .SelectMany(t => t.group_join.DefaultIfEmpty(),
                    (t, subHire) => new {
                        t.car.Id,
                        t.car.Plate,
                        Duration = (int?)subHire.Duration,
                        t.car.Rental
                    }).ToList()
                .GroupBy(c => c.Plate, (key, group) => new Query06ViewModel {
                    Plate = key,
                    Amount = group.Count(h => h.Duration != null),
                    SumDuration = (int) group.Sum(x => x.Duration),
                    SumRental = (int) group.Sum(x => x.Duration * x.Rental)
                }).ToList();
        #endregion
    } // CarHireController
}
