﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarHireLibrary.Models
{
    public class Query04ViewModel {
        // бренд-модель автомобиля
        public string Brand { get; set; }

        // гос.регистрационный номер автомобиля
        public string Plate { get; set; }

        // стоимость проката
        public int Price { get; set; }

        // дата начала проката
        public DateTime DateStart { get; set; }
    } // Query04ViewModel
}
