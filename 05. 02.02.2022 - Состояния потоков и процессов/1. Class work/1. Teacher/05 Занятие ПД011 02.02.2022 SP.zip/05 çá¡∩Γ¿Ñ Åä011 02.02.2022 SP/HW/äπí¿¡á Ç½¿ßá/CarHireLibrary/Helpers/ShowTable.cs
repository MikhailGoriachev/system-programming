﻿using CarHireLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarHireLibrary.Helpers
{
    public static class ShowTable {
        public static void Show(List<Hire> hires) {
            Console.WriteLine("\n   ┌─────┬──────────────────┬─────────┬───────────────────────┬────────────────────────┬───────────────────┬──────────────┐\n" +
                                "   │ Ид  │ Бренд автомобиля │ Номер   │ Cтоимость дня проката │ Клиент                 │ Дата нач. проката │ Длительность │\n" +
                                "   ├─────┼──────────────────┼─────────┼───────────────────────┼────────────────────────┼───────────────────┼──────────────┤");
            hires.ForEach(h => {
                Console.WriteLine($"   │ {h.Id,3} │ {h.Brand, -16} │ {h.Plate, -7} │ {h.Rental, 21:n2} │ {h.Client, -22} │ {h.DateStart, 17:d} │ {h.Duration, 12} │");
            });

            Console.WriteLine("   └─────┴──────────────────┴─────────┴───────────────────────┴────────────────────────┴───────────────────┴──────────────┘");
        } // Show

        public static void Show(List<Clients> clirnts) {
            Console.WriteLine("\n   ┌─────┬──────────────────┬──────────────────┬──────────────────┬──────────────────┐\n" +
                                "   │ Ид  │ Фамилия          │ Имя              │ Отчество         │ Номер паспорта   │\n" +
                                "   ├─────┼──────────────────┼──────────────────┼──────────────────┼──────────────────┤");
            clirnts.ForEach(h => {
                Console.WriteLine($"   │ {h.Id,3} │ {h.Surname, -16} │ {h.Name, -16} │ {h.Patronymic, -16} │ {h.Passport, -16} │");
            });

            Console.WriteLine("   └─────┴──────────────────┴──────────────────┴──────────────────┴──────────────────┘");
        } // Show

         public static void Show(List<Query04ViewModel> item) {
            Console.WriteLine("\n   ┌───────────────────┬─────────┬──────────────────┬───────────────────┐\n" +
                                "   │ Дата нач. проката │ Номер   │ Бренд автомобиля │ Cтоимость проката │\n" +
                                "   ├───────────────────┼─────────┼──────────────────┼───────────────────┤");
            item.ForEach(h => {
                Console.WriteLine($"   │ {h.DateStart, 17:d} │ {h.Plate, -7} │ {h.Brand, -16} │ {h.Price, -17} │");
            });

            Console.WriteLine("   └───────────────────┴─────────┴──────────────────┴───────────────────┘");
        } // Show

        public static void Show(List<Query05ViewModel> item) {
            Console.WriteLine("\n   ┌───────────────────┬────────────────┬──────────────────┬─────────────────────┐\n" +
                                "   │ Фамилия И.О.      │ Номер паспорта │ Кол-во прокатов  │ Кол-во дней проката │\n" +
                                "   ├───────────────────┼────────────────┼──────────────────┼─────────────────────┤");
            item.ForEach(h => {
                Console.WriteLine($"   │ {h.Client,-17} │ {h.Passport,-14} │ {h.Amount,-16} │ {h.SumDuration,-19} │");
            });

            Console.WriteLine("   └───────────────────┴────────────────┴──────────────────┴─────────────────────┘");
        } // Show

        public static void Show(List<Query06ViewModel> item) {
            Console.WriteLine("\n   ┌─────────┬──────────────────┬──────────────────┬─────────────────────┐\n" +
                                "   │ Номер   │ Кол-во прокатов  │ Cумма за прокат  │ Кол-во дней проката │\n" +
                                "   ├─────────┼──────────────────┼──────────────────┼─────────────────────┤");
            item.ForEach(h => {
                Console.WriteLine($"   │ {h.Plate,7} │ {h.Amount,-16} │ {h.SumRental,-16} │ {h.SumDuration,-19} │");
            });

            Console.WriteLine("   └─────────┴──────────────────┴──────────────────┴─────────────────────┘");
        } // Show
    } // ShowTable
}
