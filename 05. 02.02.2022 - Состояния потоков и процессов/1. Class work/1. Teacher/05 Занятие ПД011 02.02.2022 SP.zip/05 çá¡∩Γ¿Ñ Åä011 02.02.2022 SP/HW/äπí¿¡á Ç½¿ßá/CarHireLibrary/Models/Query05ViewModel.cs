﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarHireLibrary.Models
{
    public class Query05ViewModel {
        // Фамилия И.О. клиента
        public string Client { get; set; }

        // cерия и номер паспорта
        public string Passport { get; set; }

        // количество фактов проката,
        public int Amount { get; set; }

        // суммарное количество дней проката
        public int SumDuration { get; set; }
    } // Query05ViewModel
}
