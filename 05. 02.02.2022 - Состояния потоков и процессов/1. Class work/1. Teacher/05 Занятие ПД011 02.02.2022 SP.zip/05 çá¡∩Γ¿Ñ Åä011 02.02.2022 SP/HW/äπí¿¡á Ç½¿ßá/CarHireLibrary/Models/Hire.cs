﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarHireLibrary.Models
{
    public class Hire {
        // идентификатор
        public int Id { get; set; }

        // бренд-модель автомобиля
        public string Brand { get; set; }

        // гос.регистрационный номер автомобиля
        public string Plate { get; set; }

        // стоимость одного дня проката
        public int Rental { get; set; }

        // Фамилия И.О. клиента
        public string Client{ get; set; }

        // дата начала проката
        public DateTime DateStart { get; set; }

        // длительность проката
        public int Duration { get; set; }
    } // Hire
}
