﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarHireLibrary.Models
{
    public class Query06ViewModel {
        // гос.регистрационный номер автомобиля
        public string Plate { get; set; }

        // количество фактов проката
        public int Amount { get; set; }

        // сумма за прокаты
        public int SumRental { get; set; }

        // суммарная длительность прокатов
        public int SumDuration { get; set; }
    } // Query05ViewModel
}
