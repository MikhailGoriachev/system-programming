﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ConsoleApp.Application;

namespace ConsoleApp
{
    internal class Program {
        static void Main(string[] args) {
            App app = new App();
            Console.SetWindowSize(150, 40);

            
            int counter = 1;
            Timer timer = new Timer(o => {
                Console.Clear();
                switch (counter) {
                    case 1:
                        app.ExecQuery01();
                        break;
                    case 2:
                        app.ExecQuery02();
                        break;
                    case 3:
                        app.ExecQuery03();
                        break;
                    case 4:
                        app.ExecQuery04();
                        break;
                    case 5:
                        app.ExecQuery05();
                        break;
                    default:
                        app.ExecQuery06();
                        break;
                } // switch

                ++counter;
                if(counter == 7) counter = 1;
                //Console.Clear();

            });

            timer.Change(0, 2000);
            Console.ReadKey();
        }
    }
}
