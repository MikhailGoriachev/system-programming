﻿using System;
using CarHireLibrary.Controllers;
using CarHireLibrary.Helpers;

namespace ConsoleApp.Application
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
     public partial class App {
        CarHireController _carHireController;  // объект для решения 

        // конструктор по умолчанию
        public App() : this(new CarHireController()) { }

        // конструктор с внедрением зависимостей
        public App(CarHireController carHireController) {
            _carHireController = carHireController;
        } // App

        // Запрос 1
        public void ExecQuery01() {
            string plate = _carHireController.GetHires()[Utils.Random.Next(0, _carHireController.GetHires().Count)].Plate;
            Utils.ShowNavBarTask($"Информация о фактах проката автомобиля с госномером: {plate}");
            ShowTable.Show(_carHireController.Query01(plate));
        } // ExecQuery01

        // Запрос 2
        public void ExecQuery02() {
            string brand = _carHireController.GetCarsViewModel()[Utils.Random.Next(0, _carHireController.GetCarsViewModel().Count)].Brand;
            Utils.ShowNavBarTask($"Информация о фактах проката автомобилей бренда: {brand}");
            ShowTable.Show(_carHireController.Query02(brand));
        } // ExecQuery02

        // Запрос 3
        public void ExecQuery03() {
            string passport = _carHireController.GetClients()[Utils.Random.Next(0, _carHireController.GetClients().Count)].Passport;
            Utils.ShowNavBarTask($"Информация о клиентах c серией и номером паспорта: {passport}");
            ShowTable.Show(_carHireController.Query03(passport));
        } // ExecQuery03

        // Запрос 4
        public void ExecQuery04() {
            Utils.ShowNavBarTask($"Вычислить для каждого факта проката стоимость проката");
            ShowTable.Show(_carHireController.Query04());
        } // ExecQuery04 

        // Запрос 5
        public void ExecQuery05() {
            Utils.ShowNavBarTask($"Для всех клиентов вычисляет кол-во фактов проката, суммарное кол-во дней проката");
            ShowTable.Show(_carHireController.Query05());
        } // ExecQuery05     

        // Запрос 6
        public void ExecQuery06() {
            Utils.ShowNavBarTask($"Для всех автомобилей определить кол-во фактов проката, сумму за прокаты, суммарную длительность прокатов");
            ShowTable.Show(_carHireController.Query06());
        } // ExecQuery06

    } // class App
}