﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework.Views
{
    public partial class AddDurationForm : Form
    {
        private int _days;
        public int Days { get => _days; }
        public AddDurationForm() {
            InitializeComponent();
        }

        private void BtnOk_Click(object sender, EventArgs e)  {
            _days =(int) NudDuration.Value;
            DialogResult = DialogResult.OK;
            Close();
        } // BtnOk_Click
    }
}
