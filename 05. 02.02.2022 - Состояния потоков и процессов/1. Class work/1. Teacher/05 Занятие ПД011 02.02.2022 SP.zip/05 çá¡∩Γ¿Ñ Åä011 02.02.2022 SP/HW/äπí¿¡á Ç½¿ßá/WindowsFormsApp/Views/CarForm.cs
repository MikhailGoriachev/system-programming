﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarHireLibrary.Models;

namespace Homework.Views
{
    public partial class CarForm : Form
    {
        private Cars _car;
        public Cars Car { 
            get => _car;
            set {
                CmbBrand.Text       = value.BrandModels.BrandModel;
                CmbColor.Text       = value.Colors.Color;
                TbxPlate.Text       = value.Plate;
                NudInsurValue.Value = value.InsurValue;
                NudRental.Value     = value.Rental;
                NudYear.Value       = value.YearManuf;

                _car = value;
            }
        } // Cars

        private List<Colors> _colors;
        private List<BrandModels> _brands;

        public CarForm() : this("Добавление автомобиля", "Добавить", new List<BrandModels>(), new List<Colors>()) { }
        public CarForm(string title, string btnText, List<BrandModels> brands, List<Colors> colors) {
            InitializeComponent();
            _car = new Cars();
            CmbBrand.DataSource = brands.Select(b => b.BrandModel).ToList();
            CmbBrand.SelectedIndex = 0;
            CmbColor.DataSource = colors.Select(c => c.Color).ToList();
            CmbColor.SelectedIndex = 0;
            _colors = colors;
            _brands = brands;

            Text = title;
            BtnOk.Text = btnText;
        } // ApplianceForm

        private void BtnOk_Click(object sender, EventArgs e) {
            _car.Plate = TbxPlate.Text;
            _car.Colors = _colors[CmbColor.SelectedIndex];
            _car.BrandModels = _brands[CmbBrand.SelectedIndex];
            _car.InsurValue = (int)NudInsurValue.Value;
            _car.Rental = (int)NudRental.Value;
            _car.YearManuf = (int)NudYear.Value;
            DialogResult = DialogResult.OK;
            Close();
        } // BtnOk_Click

        private void BtnCancel_Click(object sender, EventArgs e) => Close();

        private void Txb_Validated(object sender, EventArgs e) {
            TextBox tb = sender as TextBox;
            if (String.IsNullOrEmpty(tb.Text))
            {
                ErpPlate.SetError(tb, "Некорректный ввод!");
                BtnOk.Enabled = false;
            } // if
        } // Txb_Validated

        private void Tbx_TextChanged(object sender, EventArgs e) {
            TextBox tb = sender as TextBox;
            ErpPlate.SetError(tb, "");

            if (!String.IsNullOrEmpty(TbxPlate.Text))
                BtnOk.Enabled = true;
        } // Tbx_TextChanged

    }
}
