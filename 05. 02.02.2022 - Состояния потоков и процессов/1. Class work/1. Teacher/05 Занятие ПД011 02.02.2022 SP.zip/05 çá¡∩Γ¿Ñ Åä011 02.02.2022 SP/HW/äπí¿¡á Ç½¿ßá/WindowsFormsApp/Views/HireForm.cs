﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarHireLibrary.Models;
using System.Windows.Forms;

namespace Homework.Views
{
    public partial class HireForm : Form
    {

        private Hires _hire;
        public Hires Hire {
            get => _hire;
            set {
                CmbClient.Text = $"{value.Clients.Surname} {value.Clients.Name[0]}.{value.Clients.Patronymic[0]}.";
                CmbCar.Text = value.Cars.Plate;
                NudDuration.Value = value.Duration;
                DtpDateStart.Value = value.DateStart;

                _hire = value;
            }
        } // Cars
        private List<Cars> _cars;
        private List<Clients> _clients;

        public HireForm() : this("Добавление проката", "Добавить", new List<Cars>(), new List<Clients>()) { }
        public HireForm(string title, string btnText, List<Cars> cars, List<Clients> clients) {
            InitializeComponent();
            _hire = new Hires();
            CmbCar.DataSource = cars.Select(b => b.Plate).ToList();
            CmbCar.SelectedIndex = 0;
            CmbClient.DataSource = clients.Select(c => $"{c.Surname} {c.Name[0]}.{c.Patronymic[0]}.").ToList();
            CmbClient.SelectedIndex = 0;
            _cars = cars;
            _clients = clients;

            Text = title;
            BtnOk.Text = btnText;
        } // HireForm

        private void BtnOk_Click(object sender, EventArgs e) {
            _hire.Cars = _cars[CmbCar.SelectedIndex];
            _hire.Clients = _clients[CmbClient.SelectedIndex];
            _hire.DateStart = DtpDateStart.Value;
            _hire.Duration = (int) NudDuration.Value;
            DialogResult = DialogResult.OK;
            Close();
        } // BtnOk_Click
    }
}
