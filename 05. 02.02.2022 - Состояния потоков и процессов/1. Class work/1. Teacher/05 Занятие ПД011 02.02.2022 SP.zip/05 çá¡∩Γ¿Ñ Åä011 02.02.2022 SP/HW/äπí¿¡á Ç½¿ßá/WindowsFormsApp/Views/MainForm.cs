﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarHireLibrary.Controllers;
using CarHireLibrary.Helpers;

namespace Homework.Views
{
    public partial class MainForm : Form
    {
        CarHireController _carHireController;
        public MainForm() {
            InitializeComponent();
             _carHireController = new CarHireController();

            DgvBrands.DataSource = _carHireController.GetBrandModels();
            DgvColors.DataSource = _carHireController.GetColors();
            DgvHires.DataSource = _carHireController.GetHires();
            DgvClients.DataSource = _carHireController.GetClients();
            DgvCars.DataSource = _carHireController.GetCarsViewModel();
        } // MainForm

        // Таблица прокатов
        private void ShowHires_Command(object sender, EventArgs e) => TbcMain.SelectedTab = TbpHires;

        // Таблица автомобилей
        private void ShowCars_Command(object sender, EventArgs e) => TbcMain.SelectedTab = TbpCars;

        // Таблица моделей
        private void ShowBrands_Command(object sender, EventArgs e) => TbcMain.SelectedTab = TbpBrands;

        // Таблица цветов
        private void ShowColors_Command(object sender, EventArgs e) => TbcMain.SelectedTab = TbpColors;

        // Таблица клиентов
        private void ShowClients_Command(object sender, EventArgs e) => TbcMain.SelectedTab = TbpClients;

        private void Query01_Command(object sender, EventArgs e) {
            string plate = _carHireController.GetCarsViewModel()[Utils.Random.Next(0, _carHireController.GetCarsViewModel().Count)].Plate;
            LblQuery01.Text = $"Информация о фактах проката автомобиля с госномером: {plate}";
            DgvQuery01.DataSource = _carHireController.Query01(plate);
            TbcMain.SelectedTab = TbpQuery01;
        } // Query01_Command

        private void Query02_Command(object sender, EventArgs e) {
            string brand = _carHireController.GetCarsViewModel()[Utils.Random.Next(0, _carHireController.GetCarsViewModel().Count)].Brand;
            LblQuery02.Text = $"Информация о фактах проката автомобилей бренда: {brand}";
            DgvQuery02.DataSource = _carHireController.Query02(brand);
            TbcMain.SelectedTab = TbpQuery02;
        } // Query02_Command

        private void Query03_Command(object sender, EventArgs e) {
            string passport = _carHireController.GetClients()[Utils.Random.Next(0, _carHireController.GetClients().Count)].Passport;
            LblQuery03.Text = $"Информация о клиентах c серией и номером паспорта: {passport}";
            DgvQuery03.DataSource = _carHireController.Query03(passport);
            TbcMain.SelectedTab = TbpQuery03;
        } // Query03_Command

        private void Query04_Command(object sender, EventArgs e) {
            DgvQuery04.DataSource = _carHireController.Query04();
            TbcMain.SelectedTab = TbpQuery04;
        } // Query04_Command

        private void Query05_Command(object sender, EventArgs e) {
            DgvQuery05.DataSource = _carHireController.Query05();
            TbcMain.SelectedTab = TbpQuery05;
        } // Query05_Command

        private void Query06_Command(object sender, EventArgs e) {
            DgvQuery06.DataSource = _carHireController.Query06();
            TbcMain.SelectedTab = TbpQuery06;
        } // Query06_Command
        

        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e)  {
            FormAbout formAbout = new FormAbout();
            formAbout.ShowDialog();
        } // About_Command

        private void TbcMain_SelectedIndexChanged(object sender, EventArgs e) {
            BtnAdd.Enabled = BtnEdit.Enabled = TbcMain.SelectedTab == TbpCars;
            BtnAddHire.Enabled = BtnEditHire.Enabled =  TbcMain.SelectedTab == TbpHires;
        } // TbcMain_SelectedIndexChanged

        // добавление автомобиля
        private void AddCar_Command(object sender, EventArgs e) {
            CarForm carForm = new CarForm("Добавление автомобиля", "Добавить",
                _carHireController.GetBrandModels(),
                _carHireController.GetColors());

            if(carForm.ShowDialog() != DialogResult.OK) return;
            _carHireController.AddCar(carForm.Car);
            DgvCars.DataSource = _carHireController.GetCarsViewModel();
            DgvCars.Rows[DgvCars.RowCount - 1].Selected = true;

        } // AddCar_Command

        // выдача автомобиля в прокат
        private void BtnAddHire_Click(object sender, EventArgs e) {
            HireForm carForm = new HireForm("Добавление проката", "Добавить",
                _carHireController.GetCars(),
                _carHireController.GetClients());

            if (carForm.ShowDialog() != DialogResult.OK) return;
            _carHireController.AddHire(carForm.Hire);
            DgvHires.DataSource = _carHireController.GetHires();
            DgvHires.Rows[DgvHires.RowCount - 1].Selected = true;
        } // BtnAddHire_Click

        // редактирование автомобиля
        private void EditCar_Command(object sender, EventArgs e) {
            if (DgvCars.SelectedRows.Count == 0) return;

            CarForm carForm = new CarForm("Редактирование автомобиля", "Сохранить",
                _carHireController.GetBrandModels(),
                _carHireController.GetColors());

            int index = DgvCars.SelectedRows[0].Index;
            carForm.Car = _carHireController.GetCars()[index];
            if(carForm.ShowDialog() != DialogResult.OK) return;
            _carHireController.EditCar(index, carForm.Car);
            DgvCars.DataSource = _carHireController.GetCarsViewModel();
            DgvCars.Rows[index].Selected = true;
        } // EditCar_Command

        // продление срока проката автомобиля на заданное количество дней
        private void AddDuration_Command(object sender, EventArgs e) {
            if (DgvHires.SelectedRows.Count == 0) return;

            AddDurationForm addDurationForm = new AddDurationForm();

            int index = DgvHires.SelectedRows[0].Index;
            if (addDurationForm.ShowDialog() != DialogResult.OK) return;

            _carHireController.AddDuration(index, addDurationForm.Days);
            DgvHires.DataSource = _carHireController.GetHires();
            DgvHires.Rows[index].Selected = true;
        } // BtnEditHire_Click
    }
}
