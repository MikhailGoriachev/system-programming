﻿namespace Homework.Views
{
    partial class CarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.CmbBrand = new System.Windows.Forms.ComboBox();
            this.CmbColor = new System.Windows.Forms.ComboBox();
            this.TbxPlate = new System.Windows.Forms.TextBox();
            this.NudYear = new System.Windows.Forms.NumericUpDown();
            this.NudInsurValue = new System.Windows.Forms.NumericUpDown();
            this.NudRental = new System.Windows.Forms.NumericUpDown();
            this.BtnOk = new System.Windows.Forms.Button();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.ErpPlate = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.NudYear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudInsurValue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudRental)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpPlate)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Бренд-модель:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Цвет:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Гос. номер:\r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(28, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Год производства:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(181, 21);
            this.label5.TabIndex = 4;
            this.label5.Text = "Страховая стоимость:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 267);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(198, 21);
            this.label6.TabIndex = 5;
            this.label6.Text = "Стоимость дня проката:";
            // 
            // CmbBrand
            // 
            this.CmbBrand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbBrand.FormattingEnabled = true;
            this.CmbBrand.Location = new System.Drawing.Point(266, 33);
            this.CmbBrand.Name = "CmbBrand";
            this.CmbBrand.Size = new System.Drawing.Size(176, 29);
            this.CmbBrand.TabIndex = 6;
            // 
            // CmbColor
            // 
            this.CmbColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbColor.FormattingEnabled = true;
            this.CmbColor.Location = new System.Drawing.Point(266, 79);
            this.CmbColor.Name = "CmbColor";
            this.CmbColor.Size = new System.Drawing.Size(176, 29);
            this.CmbColor.TabIndex = 7;
            // 
            // TbxPlate
            // 
            this.TbxPlate.Location = new System.Drawing.Point(266, 125);
            this.TbxPlate.Name = "TbxPlate";
            this.TbxPlate.Size = new System.Drawing.Size(176, 28);
            this.TbxPlate.TabIndex = 8;
            this.TbxPlate.Text = "Н153РК";
            this.TbxPlate.TextChanged += new System.EventHandler(this.Tbx_TextChanged);
            this.TbxPlate.Validated += new System.EventHandler(this.Txb_Validated);
            // 
            // NudYear
            // 
            this.NudYear.Location = new System.Drawing.Point(266, 170);
            this.NudYear.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.NudYear.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NudYear.Name = "NudYear";
            this.NudYear.Size = new System.Drawing.Size(176, 28);
            this.NudYear.TabIndex = 9;
            this.NudYear.Value = new decimal(new int[] {
            2018,
            0,
            0,
            0});
            // 
            // NudInsurValue
            // 
            this.NudInsurValue.Location = new System.Drawing.Point(266, 215);
            this.NudInsurValue.Maximum = new decimal(new int[] {
            -727379968,
            232,
            0,
            0});
            this.NudInsurValue.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NudInsurValue.Name = "NudInsurValue";
            this.NudInsurValue.Size = new System.Drawing.Size(176, 28);
            this.NudInsurValue.TabIndex = 10;
            this.NudInsurValue.Value = new decimal(new int[] {
            3300000,
            0,
            0,
            0});
            // 
            // NudRental
            // 
            this.NudRental.Location = new System.Drawing.Point(266, 260);
            this.NudRental.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.NudRental.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NudRental.Name = "NudRental";
            this.NudRental.Size = new System.Drawing.Size(176, 28);
            this.NudRental.TabIndex = 11;
            this.NudRental.Value = new decimal(new int[] {
            5500,
            0,
            0,
            0});
            // 
            // BtnOk
            // 
            this.BtnOk.BackColor = System.Drawing.Color.SteelBlue;
            this.BtnOk.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnOk.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnOk.Location = new System.Drawing.Point(188, 326);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(119, 36);
            this.BtnOk.TabIndex = 12;
            this.BtnOk.Text = "Добавить";
            this.BtnOk.UseVisualStyleBackColor = false;
            this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // BtnCancel
            // 
            this.BtnCancel.BackColor = System.Drawing.Color.Maroon;
            this.BtnCancel.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnCancel.Location = new System.Drawing.Point(323, 326);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(119, 36);
            this.BtnCancel.TabIndex = 13;
            this.BtnCancel.Text = "Отмена";
            this.BtnCancel.UseVisualStyleBackColor = false;
            // 
            // ErpPlate
            // 
            this.ErpPlate.ContainerControl = this;
            // 
            // CarForm
            // 
            this.AcceptButton = this.BtnOk;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.BtnCancel;
            this.ClientSize = new System.Drawing.Size(479, 388);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.BtnOk);
            this.Controls.Add(this.NudRental);
            this.Controls.Add(this.NudInsurValue);
            this.Controls.Add(this.NudYear);
            this.Controls.Add(this.TbxPlate);
            this.Controls.Add(this.CmbColor);
            this.Controls.Add(this.CmbBrand);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "CarForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CarForm";
            ((System.ComponentModel.ISupportInitialize)(this.NudYear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudInsurValue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudRental)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpPlate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox CmbBrand;
        private System.Windows.Forms.ComboBox CmbColor;
        private System.Windows.Forms.TextBox TbxPlate;
        private System.Windows.Forms.NumericUpDown NudYear;
        private System.Windows.Forms.NumericUpDown NudInsurValue;
        private System.Windows.Forms.NumericUpDown NudRental;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.ErrorProvider ErpPlate;
    }
}