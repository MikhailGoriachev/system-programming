﻿namespace Homework.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаЕдиницИзмеренияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаПерсонToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаПродавцовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаТоваровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаЗакупокToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запросыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запросToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnAdd = new System.Windows.Forms.ToolStripButton();
            this.BtnEdit = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnAddHire = new System.Windows.Forms.ToolStripButton();
            this.BtnEditHire = new System.Windows.Forms.ToolStripButton();
            this.TbpQuery06 = new System.Windows.Forms.TabPage();
            this.DgvQuery06 = new System.Windows.Forms.DataGridView();
            this.LblQuery06 = new System.Windows.Forms.Label();
            this.TbpQuery05 = new System.Windows.Forms.TabPage();
            this.DgvQuery05 = new System.Windows.Forms.DataGridView();
            this.LblQuery05 = new System.Windows.Forms.Label();
            this.TbpQuery04 = new System.Windows.Forms.TabPage();
            this.DgvQuery04 = new System.Windows.Forms.DataGridView();
            this.LblQuery04 = new System.Windows.Forms.Label();
            this.TbpQuery03 = new System.Windows.Forms.TabPage();
            this.DgvQuery03 = new System.Windows.Forms.DataGridView();
            this.LblQuery03 = new System.Windows.Forms.Label();
            this.TbpQuery02 = new System.Windows.Forms.TabPage();
            this.DgvQuery02 = new System.Windows.Forms.DataGridView();
            this.LblQuery02 = new System.Windows.Forms.Label();
            this.TbpQuery01 = new System.Windows.Forms.TabPage();
            this.DgvQuery01 = new System.Windows.Forms.DataGridView();
            this.LblQuery01 = new System.Windows.Forms.Label();
            this.TbpHires = new System.Windows.Forms.TabPage();
            this.DgvHires = new System.Windows.Forms.DataGridView();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpCars = new System.Windows.Forms.TabPage();
            this.DgvCars = new System.Windows.Forms.DataGridView();
            this.TbpBrands = new System.Windows.Forms.TabPage();
            this.DgvBrands = new System.Windows.Forms.DataGridView();
            this.TbpColors = new System.Windows.Forms.TabPage();
            this.DgvColors = new System.Windows.Forms.DataGridView();
            this.TbpClients = new System.Windows.Forms.TabPage();
            this.DgvClients = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plateDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rentalDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateStartDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.durationDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hireBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plateDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearManufDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.insurValueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rentalDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandModelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandModelsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colorDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colorsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rentalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateStartDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.durationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hireBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patronymicDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passportDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateStartDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.query04ViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passportDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sumDurationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.query05ViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.plateDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sumRentalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sumDurationDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.query06ViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.TbpQuery06.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).BeginInit();
            this.TbpQuery05.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery05)).BeginInit();
            this.TbpQuery04.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery04)).BeginInit();
            this.TbpQuery03.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery03)).BeginInit();
            this.TbpQuery02.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).BeginInit();
            this.TbpQuery01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).BeginInit();
            this.TbpHires.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvHires)).BeginInit();
            this.TbcMain.SuspendLayout();
            this.TbpCars.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvCars)).BeginInit();
            this.TbpBrands.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvBrands)).BeginInit();
            this.TbpColors.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvColors)).BeginInit();
            this.TbpClients.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvClients)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hireBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brandModelsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hireBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.query04ViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.query05ViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.query06ViewModelBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.таблицыToolStripMenuItem,
            this.запросыToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(862, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(59, 26);
            this.файлToolStripMenuItem.Text = "&Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.выходToolStripMenuItem.Text = "&Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // таблицыToolStripMenuItem
            // 
            this.таблицыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.таблицаЕдиницИзмеренияToolStripMenuItem,
            this.таблицаПерсонToolStripMenuItem,
            this.таблицаПродавцовToolStripMenuItem,
            this.таблицаТоваровToolStripMenuItem,
            this.таблицаЗакупокToolStripMenuItem});
            this.таблицыToolStripMenuItem.Name = "таблицыToolStripMenuItem";
            this.таблицыToolStripMenuItem.Size = new System.Drawing.Size(85, 26);
            this.таблицыToolStripMenuItem.Text = "Таблицы";
            // 
            // таблицаЕдиницИзмеренияToolStripMenuItem
            // 
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Name = "таблицаЕдиницИзмеренияToolStripMenuItem";
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Text = "Прокаты";
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Click += new System.EventHandler(this.ShowHires_Command);
            // 
            // таблицаПерсонToolStripMenuItem
            // 
            this.таблицаПерсонToolStripMenuItem.Name = "таблицаПерсонToolStripMenuItem";
            this.таблицаПерсонToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.таблицаПерсонToolStripMenuItem.Text = "Автомобили";
            this.таблицаПерсонToolStripMenuItem.Click += new System.EventHandler(this.ShowCars_Command);
            // 
            // таблицаПродавцовToolStripMenuItem
            // 
            this.таблицаПродавцовToolStripMenuItem.Name = "таблицаПродавцовToolStripMenuItem";
            this.таблицаПродавцовToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.таблицаПродавцовToolStripMenuItem.Text = "Модели";
            this.таблицаПродавцовToolStripMenuItem.Click += new System.EventHandler(this.ShowBrands_Command);
            // 
            // таблицаТоваровToolStripMenuItem
            // 
            this.таблицаТоваровToolStripMenuItem.Name = "таблицаТоваровToolStripMenuItem";
            this.таблицаТоваровToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.таблицаТоваровToolStripMenuItem.Text = "Цвета";
            this.таблицаТоваровToolStripMenuItem.Click += new System.EventHandler(this.ShowColors_Command);
            // 
            // таблицаЗакупокToolStripMenuItem
            // 
            this.таблицаЗакупокToolStripMenuItem.Name = "таблицаЗакупокToolStripMenuItem";
            this.таблицаЗакупокToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.таблицаЗакупокToolStripMenuItem.Text = "Клиенты";
            this.таблицаЗакупокToolStripMenuItem.Click += new System.EventHandler(this.ShowClients_Command);
            // 
            // запросыToolStripMenuItem
            // 
            this.запросыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.запрос1ToolStripMenuItem,
            this.запросToolStripMenuItem,
            this.запрос3ToolStripMenuItem,
            this.запрос4ToolStripMenuItem,
            this.запрос5ToolStripMenuItem,
            this.запрос6ToolStripMenuItem});
            this.запросыToolStripMenuItem.Name = "запросыToolStripMenuItem";
            this.запросыToolStripMenuItem.Size = new System.Drawing.Size(84, 26);
            this.запросыToolStripMenuItem.Text = "Запросы";
            // 
            // запрос1ToolStripMenuItem
            // 
            this.запрос1ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос1ToolStripMenuItem.Name = "запрос1ToolStripMenuItem";
            this.запрос1ToolStripMenuItem.Size = new System.Drawing.Size(171, 26);
            this.запрос1ToolStripMenuItem.Text = "Запрос №1";
            this.запрос1ToolStripMenuItem.Click += new System.EventHandler(this.Query01_Command);
            // 
            // запросToolStripMenuItem
            // 
            this.запросToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запросToolStripMenuItem.Name = "запросToolStripMenuItem";
            this.запросToolStripMenuItem.Size = new System.Drawing.Size(171, 26);
            this.запросToolStripMenuItem.Text = "Запрос №2";
            this.запросToolStripMenuItem.Click += new System.EventHandler(this.Query02_Command);
            // 
            // запрос3ToolStripMenuItem
            // 
            this.запрос3ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос3ToolStripMenuItem.Name = "запрос3ToolStripMenuItem";
            this.запрос3ToolStripMenuItem.Size = new System.Drawing.Size(171, 26);
            this.запрос3ToolStripMenuItem.Text = "Запрос №3";
            this.запрос3ToolStripMenuItem.Click += new System.EventHandler(this.Query03_Command);
            // 
            // запрос4ToolStripMenuItem
            // 
            this.запрос4ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос4ToolStripMenuItem.Name = "запрос4ToolStripMenuItem";
            this.запрос4ToolStripMenuItem.Size = new System.Drawing.Size(171, 26);
            this.запрос4ToolStripMenuItem.Text = "Запрос №4";
            this.запрос4ToolStripMenuItem.Click += new System.EventHandler(this.Query04_Command);
            // 
            // запрос5ToolStripMenuItem
            // 
            this.запрос5ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос5ToolStripMenuItem.Name = "запрос5ToolStripMenuItem";
            this.запрос5ToolStripMenuItem.Size = new System.Drawing.Size(171, 26);
            this.запрос5ToolStripMenuItem.Text = "Запрос №5";
            this.запрос5ToolStripMenuItem.Click += new System.EventHandler(this.Query05_Command);
            // 
            // запрос6ToolStripMenuItem
            // 
            this.запрос6ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос6ToolStripMenuItem.Name = "запрос6ToolStripMenuItem";
            this.запрос6ToolStripMenuItem.Size = new System.Drawing.Size(171, 26);
            this.запрос6ToolStripMenuItem.Text = "Запрос №6";
            this.запрос6ToolStripMenuItem.Click += new System.EventHandler(this.Query06_Command);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(81, 26);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(196, 26);
            this.оПрограммеToolStripMenuItem.Text = "О программе...";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripButton9,
            this.toolStripButton10,
            this.toolStripSeparator1,
            this.BtnAdd,
            this.BtnEdit,
            this.toolStripSeparator2,
            this.BtnAddHire,
            this.BtnEditHire});
            this.toolStrip1.Location = new System.Drawing.Point(0, 30);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(862, 39);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::WindowsFormsApp.Properties.Resources._1;
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.ToolTipText = "Запрос №1.\r\nИнформация о товарах, единица измерения которых «шт» \r\nи цена закупки" +
    " меньше 200 руб";
            this.toolStripButton1.Click += new System.EventHandler(this.Query01_Command);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::WindowsFormsApp.Properties.Resources._2;
            this.toolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.ToolTipText = "Запрос №2.\r\nИнформация о товарах, цена закупки которых больше 500 руб";
            this.toolStripButton2.Click += new System.EventHandler(this.Query02_Command);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::WindowsFormsApp.Properties.Resources._3;
            this.toolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.ToolTipText = "Запрос №3.\r\nИнформация о товарах, с заданным наименованием, \r\nдля которых цена за" +
    "купки меньше 1800 руб";
            this.toolStripButton3.Click += new System.EventHandler(this.Query03_Command);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::WindowsFormsApp.Properties.Resources._4;
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton4.Text = "toolStripButton1";
            this.toolStripButton4.ToolTipText = "Запрос №4.\r\nИнформация о продавцах с заданным значением процента комиссионных.";
            this.toolStripButton4.Click += new System.EventHandler(this.Query04_Command);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = global::WindowsFormsApp.Properties.Resources._5;
            this.toolStripButton5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton5.Text = "toolStripButton2";
            this.toolStripButton5.ToolTipText = "Запрос №5.\r\nИнформация о фактах продажи, для которых \r\nцена продажи в заданном ди" +
    "апазоне";
            this.toolStripButton5.Click += new System.EventHandler(this.Query05_Command);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = global::WindowsFormsApp.Properties.Resources._6;
            this.toolStripButton6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton6.Text = "toolStripButton3";
            this.toolStripButton6.ToolTipText = "Запрос №6\r\nВычислить прибыль от продажи за каждый проданный товар";
            this.toolStripButton6.Click += new System.EventHandler(this.Query06_Command);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(29, 36);
            this.toolStripButton9.Text = "toolStripButton9";
            this.toolStripButton9.ToolTipText = "Выход";
            this.toolStripButton9.Click += new System.EventHandler(this.Exit_Command);
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Size = new System.Drawing.Size(29, 36);
            this.toolStripButton10.Text = "toolStripButton10";
            this.toolStripButton10.ToolTipText = "О программе...";
            this.toolStripButton10.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // BtnAdd
            // 
            this.BtnAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnAdd.Enabled = false;
            this.BtnAdd.Image = global::WindowsFormsApp.Properties.Resources.add;
            this.BtnAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(36, 36);
            this.BtnAdd.Text = "toolStripButton7";
            this.BtnAdd.ToolTipText = "Добавить автомобиль";
            this.BtnAdd.Click += new System.EventHandler(this.AddCar_Command);
            // 
            // BtnEdit
            // 
            this.BtnEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnEdit.Enabled = false;
            this.BtnEdit.Image = global::WindowsFormsApp.Properties.Resources.edit_mx_entry;
            this.BtnEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnEdit.Name = "BtnEdit";
            this.BtnEdit.Size = new System.Drawing.Size(36, 36);
            this.BtnEdit.Text = "toolStripButton8";
            this.BtnEdit.ToolTipText = "Редактировать автомобиль";
            this.BtnEdit.Click += new System.EventHandler(this.EditCar_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // BtnAddHire
            // 
            this.BtnAddHire.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnAddHire.Image = global::WindowsFormsApp.Properties.Resources.add;
            this.BtnAddHire.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnAddHire.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnAddHire.Name = "BtnAddHire";
            this.BtnAddHire.Size = new System.Drawing.Size(36, 36);
            this.BtnAddHire.Text = "toolStripButton11";
            this.BtnAddHire.ToolTipText = "Выдать автомобиль в прокат";
            this.BtnAddHire.Click += new System.EventHandler(this.BtnAddHire_Click);
            // 
            // BtnEditHire
            // 
            this.BtnEditHire.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnEditHire.Image = global::WindowsFormsApp.Properties.Resources.edit_mx_entry;
            this.BtnEditHire.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnEditHire.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnEditHire.Name = "BtnEditHire";
            this.BtnEditHire.Size = new System.Drawing.Size(36, 36);
            this.BtnEditHire.Text = "toolStripButton7";
            this.BtnEditHire.ToolTipText = "Продлить срок проката автомобиля";
            this.BtnEditHire.Click += new System.EventHandler(this.AddDuration_Command);
            // 
            // TbpQuery06
            // 
            this.TbpQuery06.Controls.Add(this.DgvQuery06);
            this.TbpQuery06.Controls.Add(this.LblQuery06);
            this.TbpQuery06.Location = new System.Drawing.Point(4, 31);
            this.TbpQuery06.Name = "TbpQuery06";
            this.TbpQuery06.Size = new System.Drawing.Size(854, 474);
            this.TbpQuery06.TabIndex = 6;
            this.TbpQuery06.Text = "Запрос №6";
            this.TbpQuery06.UseVisualStyleBackColor = true;
            // 
            // DgvQuery06
            // 
            this.DgvQuery06.AllowUserToAddRows = false;
            this.DgvQuery06.AllowUserToDeleteRows = false;
            this.DgvQuery06.AutoGenerateColumns = false;
            this.DgvQuery06.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery06.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.plateDataGridViewTextBoxColumn2,
            this.amountDataGridViewTextBoxColumn1,
            this.sumRentalDataGridViewTextBoxColumn,
            this.sumDurationDataGridViewTextBoxColumn1});
            this.DgvQuery06.DataSource = this.query06ViewModelBindingSource;
            this.DgvQuery06.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery06.Location = new System.Drawing.Point(0, 44);
            this.DgvQuery06.MultiSelect = false;
            this.DgvQuery06.Name = "DgvQuery06";
            this.DgvQuery06.ReadOnly = true;
            this.DgvQuery06.RowHeadersVisible = false;
            this.DgvQuery06.RowHeadersWidth = 51;
            this.DgvQuery06.RowTemplate.Height = 24;
            this.DgvQuery06.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery06.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery06.Size = new System.Drawing.Size(854, 430);
            this.DgvQuery06.TabIndex = 6;
            // 
            // LblQuery06
            // 
            this.LblQuery06.Location = new System.Drawing.Point(3, 0);
            this.LblQuery06.Name = "LblQuery06";
            this.LblQuery06.Size = new System.Drawing.Size(851, 41);
            this.LblQuery06.TabIndex = 4;
            this.LblQuery06.Text = "Для всех автомобилей определить кол-во фактов проката, сумму за прокаты,\r\nсуммарн" +
    "ую длительность прокатов";
            // 
            // TbpQuery05
            // 
            this.TbpQuery05.Controls.Add(this.DgvQuery05);
            this.TbpQuery05.Controls.Add(this.LblQuery05);
            this.TbpQuery05.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery05.Name = "TbpQuery05";
            this.TbpQuery05.Size = new System.Drawing.Size(854, 480);
            this.TbpQuery05.TabIndex = 5;
            this.TbpQuery05.Text = "Запрос №5";
            this.TbpQuery05.UseVisualStyleBackColor = true;
            // 
            // DgvQuery05
            // 
            this.DgvQuery05.AllowUserToAddRows = false;
            this.DgvQuery05.AllowUserToDeleteRows = false;
            this.DgvQuery05.AutoGenerateColumns = false;
            this.DgvQuery05.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery05.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clientDataGridViewTextBoxColumn1,
            this.passportDataGridViewTextBoxColumn1,
            this.amountDataGridViewTextBoxColumn,
            this.sumDurationDataGridViewTextBoxColumn});
            this.DgvQuery05.DataSource = this.query05ViewModelBindingSource;
            this.DgvQuery05.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery05.Location = new System.Drawing.Point(0, 40);
            this.DgvQuery05.MultiSelect = false;
            this.DgvQuery05.Name = "DgvQuery05";
            this.DgvQuery05.ReadOnly = true;
            this.DgvQuery05.RowHeadersVisible = false;
            this.DgvQuery05.RowHeadersWidth = 51;
            this.DgvQuery05.RowTemplate.Height = 24;
            this.DgvQuery05.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery05.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery05.Size = new System.Drawing.Size(854, 440);
            this.DgvQuery05.TabIndex = 5;
            // 
            // LblQuery05
            // 
            this.LblQuery05.Location = new System.Drawing.Point(3, 0);
            this.LblQuery05.Name = "LblQuery05";
            this.LblQuery05.Size = new System.Drawing.Size(851, 41);
            this.LblQuery05.TabIndex = 4;
            this.LblQuery05.Text = "Для всех клиентов вычисляет кол-во фактов проката, суммарное кол-во дней проката\r" +
    "\n";
            // 
            // TbpQuery04
            // 
            this.TbpQuery04.Controls.Add(this.DgvQuery04);
            this.TbpQuery04.Controls.Add(this.LblQuery04);
            this.TbpQuery04.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery04.Name = "TbpQuery04";
            this.TbpQuery04.Size = new System.Drawing.Size(854, 480);
            this.TbpQuery04.TabIndex = 4;
            this.TbpQuery04.Text = "Запрос №4";
            this.TbpQuery04.UseVisualStyleBackColor = true;
            // 
            // DgvQuery04
            // 
            this.DgvQuery04.AllowUserToAddRows = false;
            this.DgvQuery04.AllowUserToDeleteRows = false;
            this.DgvQuery04.AutoGenerateColumns = false;
            this.DgvQuery04.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery04.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dateStartDataGridViewTextBoxColumn1,
            this.plateDataGridViewTextBoxColumn1,
            this.brandDataGridViewTextBoxColumn1,
            this.priceDataGridViewTextBoxColumn});
            this.DgvQuery04.DataSource = this.query04ViewModelBindingSource;
            this.DgvQuery04.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery04.Location = new System.Drawing.Point(0, 32);
            this.DgvQuery04.MultiSelect = false;
            this.DgvQuery04.Name = "DgvQuery04";
            this.DgvQuery04.ReadOnly = true;
            this.DgvQuery04.RowHeadersVisible = false;
            this.DgvQuery04.RowHeadersWidth = 51;
            this.DgvQuery04.RowTemplate.Height = 24;
            this.DgvQuery04.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery04.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery04.Size = new System.Drawing.Size(854, 448);
            this.DgvQuery04.TabIndex = 4;
            // 
            // LblQuery04
            // 
            this.LblQuery04.Location = new System.Drawing.Point(3, 0);
            this.LblQuery04.Name = "LblQuery04";
            this.LblQuery04.Size = new System.Drawing.Size(851, 41);
            this.LblQuery04.TabIndex = 3;
            this.LblQuery04.Text = "Вычислить для каждого факта проката стоимость проката";
            // 
            // TbpQuery03
            // 
            this.TbpQuery03.Controls.Add(this.DgvQuery03);
            this.TbpQuery03.Controls.Add(this.LblQuery03);
            this.TbpQuery03.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery03.Name = "TbpQuery03";
            this.TbpQuery03.Size = new System.Drawing.Size(854, 480);
            this.TbpQuery03.TabIndex = 3;
            this.TbpQuery03.Text = "Запрос №3";
            this.TbpQuery03.UseVisualStyleBackColor = true;
            // 
            // DgvQuery03
            // 
            this.DgvQuery03.AllowUserToAddRows = false;
            this.DgvQuery03.AllowUserToDeleteRows = false;
            this.DgvQuery03.AutoGenerateColumns = false;
            this.DgvQuery03.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery03.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.patronymicDataGridViewTextBoxColumn,
            this.passportDataGridViewTextBoxColumn});
            this.DgvQuery03.DataSource = this.clientsBindingSource;
            this.DgvQuery03.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery03.Location = new System.Drawing.Point(0, 40);
            this.DgvQuery03.MultiSelect = false;
            this.DgvQuery03.Name = "DgvQuery03";
            this.DgvQuery03.ReadOnly = true;
            this.DgvQuery03.RowHeadersVisible = false;
            this.DgvQuery03.RowHeadersWidth = 51;
            this.DgvQuery03.RowTemplate.Height = 24;
            this.DgvQuery03.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery03.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery03.Size = new System.Drawing.Size(854, 440);
            this.DgvQuery03.TabIndex = 3;
            // 
            // LblQuery03
            // 
            this.LblQuery03.Location = new System.Drawing.Point(3, 2);
            this.LblQuery03.Name = "LblQuery03";
            this.LblQuery03.Size = new System.Drawing.Size(848, 41);
            this.LblQuery03.TabIndex = 2;
            // 
            // TbpQuery02
            // 
            this.TbpQuery02.Controls.Add(this.DgvQuery02);
            this.TbpQuery02.Controls.Add(this.LblQuery02);
            this.TbpQuery02.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery02.Name = "TbpQuery02";
            this.TbpQuery02.Size = new System.Drawing.Size(854, 480);
            this.TbpQuery02.TabIndex = 2;
            this.TbpQuery02.Text = "Запрос №2";
            this.TbpQuery02.UseVisualStyleBackColor = true;
            // 
            // DgvQuery02
            // 
            this.DgvQuery02.AllowUserToAddRows = false;
            this.DgvQuery02.AllowUserToDeleteRows = false;
            this.DgvQuery02.AutoGenerateColumns = false;
            this.DgvQuery02.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery02.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.DgvQuery02.DataSource = this.hireBindingSource;
            this.DgvQuery02.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery02.Location = new System.Drawing.Point(0, 40);
            this.DgvQuery02.MultiSelect = false;
            this.DgvQuery02.Name = "DgvQuery02";
            this.DgvQuery02.ReadOnly = true;
            this.DgvQuery02.RowHeadersVisible = false;
            this.DgvQuery02.RowHeadersWidth = 51;
            this.DgvQuery02.RowTemplate.Height = 24;
            this.DgvQuery02.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery02.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery02.Size = new System.Drawing.Size(854, 440);
            this.DgvQuery02.TabIndex = 4;
            // 
            // LblQuery02
            // 
            this.LblQuery02.Location = new System.Drawing.Point(3, 2);
            this.LblQuery02.Name = "LblQuery02";
            this.LblQuery02.Size = new System.Drawing.Size(786, 41);
            this.LblQuery02.TabIndex = 2;
            // 
            // TbpQuery01
            // 
            this.TbpQuery01.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.TbpQuery01.Controls.Add(this.DgvQuery01);
            this.TbpQuery01.Controls.Add(this.LblQuery01);
            this.TbpQuery01.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery01.Name = "TbpQuery01";
            this.TbpQuery01.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery01.Size = new System.Drawing.Size(854, 480);
            this.TbpQuery01.TabIndex = 1;
            this.TbpQuery01.Text = "Запрос №1";
            this.TbpQuery01.UseVisualStyleBackColor = true;
            // 
            // DgvQuery01
            // 
            this.DgvQuery01.AllowUserToAddRows = false;
            this.DgvQuery01.AllowUserToDeleteRows = false;
            this.DgvQuery01.AutoGenerateColumns = false;
            this.DgvQuery01.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery01.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn32,
            this.brandDataGridViewTextBoxColumn,
            this.plateDataGridViewTextBoxColumn,
            this.rentalDataGridViewTextBoxColumn,
            this.clientDataGridViewTextBoxColumn,
            this.dateStartDataGridViewTextBoxColumn,
            this.durationDataGridViewTextBoxColumn});
            this.DgvQuery01.DataSource = this.hireBindingSource;
            this.DgvQuery01.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery01.Location = new System.Drawing.Point(3, 37);
            this.DgvQuery01.MultiSelect = false;
            this.DgvQuery01.Name = "DgvQuery01";
            this.DgvQuery01.ReadOnly = true;
            this.DgvQuery01.RowHeadersVisible = false;
            this.DgvQuery01.RowHeadersWidth = 51;
            this.DgvQuery01.RowTemplate.Height = 24;
            this.DgvQuery01.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery01.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery01.Size = new System.Drawing.Size(848, 440);
            this.DgvQuery01.TabIndex = 1;
            // 
            // LblQuery01
            // 
            this.LblQuery01.Location = new System.Drawing.Point(3, 3);
            this.LblQuery01.Name = "LblQuery01";
            this.LblQuery01.Size = new System.Drawing.Size(851, 41);
            this.LblQuery01.TabIndex = 0;
            // 
            // TbpHires
            // 
            this.TbpHires.Controls.Add(this.DgvHires);
            this.TbpHires.Location = new System.Drawing.Point(4, 31);
            this.TbpHires.Name = "TbpHires";
            this.TbpHires.Padding = new System.Windows.Forms.Padding(3);
            this.TbpHires.Size = new System.Drawing.Size(854, 474);
            this.TbpHires.TabIndex = 0;
            this.TbpHires.Text = "Прокаты";
            this.TbpHires.UseVisualStyleBackColor = true;
            // 
            // DgvHires
            // 
            this.DgvHires.AllowUserToAddRows = false;
            this.DgvHires.AllowUserToDeleteRows = false;
            this.DgvHires.AutoGenerateColumns = false;
            this.DgvHires.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvHires.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.brandDataGridViewTextBoxColumn2,
            this.plateDataGridViewTextBoxColumn3,
            this.rentalDataGridViewTextBoxColumn1,
            this.clientDataGridViewTextBoxColumn2,
            this.dateStartDataGridViewTextBoxColumn2,
            this.durationDataGridViewTextBoxColumn1});
            this.DgvHires.DataSource = this.hireBindingSource1;
            this.DgvHires.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvHires.Location = new System.Drawing.Point(3, 3);
            this.DgvHires.MultiSelect = false;
            this.DgvHires.Name = "DgvHires";
            this.DgvHires.ReadOnly = true;
            this.DgvHires.RowHeadersVisible = false;
            this.DgvHires.RowHeadersWidth = 51;
            this.DgvHires.RowTemplate.Height = 24;
            this.DgvHires.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvHires.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvHires.Size = new System.Drawing.Size(848, 468);
            this.DgvHires.TabIndex = 3;
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpHires);
            this.TbcMain.Controls.Add(this.TbpCars);
            this.TbcMain.Controls.Add(this.TbpBrands);
            this.TbcMain.Controls.Add(this.TbpColors);
            this.TbcMain.Controls.Add(this.TbpClients);
            this.TbcMain.Controls.Add(this.TbpQuery01);
            this.TbcMain.Controls.Add(this.TbpQuery02);
            this.TbcMain.Controls.Add(this.TbpQuery03);
            this.TbcMain.Controls.Add(this.TbpQuery04);
            this.TbcMain.Controls.Add(this.TbpQuery05);
            this.TbcMain.Controls.Add(this.TbpQuery06);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Location = new System.Drawing.Point(0, 69);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(862, 509);
            this.TbcMain.TabIndex = 2;
            this.TbcMain.SelectedIndexChanged += new System.EventHandler(this.TbcMain_SelectedIndexChanged);
            // 
            // TbpCars
            // 
            this.TbpCars.Controls.Add(this.DgvCars);
            this.TbpCars.Location = new System.Drawing.Point(4, 25);
            this.TbpCars.Name = "TbpCars";
            this.TbpCars.Size = new System.Drawing.Size(854, 480);
            this.TbpCars.TabIndex = 7;
            this.TbpCars.Text = "Автомобили";
            this.TbpCars.UseVisualStyleBackColor = true;
            // 
            // DgvCars
            // 
            this.DgvCars.AllowUserToAddRows = false;
            this.DgvCars.AllowUserToDeleteRows = false;
            this.DgvCars.AutoGenerateColumns = false;
            this.DgvCars.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvCars.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.brandDataGridViewTextBoxColumn3,
            this.colorDataGridViewTextBoxColumn,
            this.plateDataGridViewTextBoxColumn4,
            this.yearManufDataGridViewTextBoxColumn,
            this.insurValueDataGridViewTextBoxColumn,
            this.rentalDataGridViewTextBoxColumn2});
            this.DgvCars.DataSource = this.carBindingSource;
            this.DgvCars.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvCars.Location = new System.Drawing.Point(0, 0);
            this.DgvCars.MultiSelect = false;
            this.DgvCars.Name = "DgvCars";
            this.DgvCars.ReadOnly = true;
            this.DgvCars.RowHeadersVisible = false;
            this.DgvCars.RowHeadersWidth = 51;
            this.DgvCars.RowTemplate.Height = 24;
            this.DgvCars.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvCars.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvCars.Size = new System.Drawing.Size(854, 480);
            this.DgvCars.TabIndex = 4;
            // 
            // TbpBrands
            // 
            this.TbpBrands.Controls.Add(this.DgvBrands);
            this.TbpBrands.Location = new System.Drawing.Point(4, 25);
            this.TbpBrands.Name = "TbpBrands";
            this.TbpBrands.Size = new System.Drawing.Size(854, 480);
            this.TbpBrands.TabIndex = 8;
            this.TbpBrands.Text = "Модели";
            this.TbpBrands.UseVisualStyleBackColor = true;
            // 
            // DgvBrands
            // 
            this.DgvBrands.AllowUserToAddRows = false;
            this.DgvBrands.AllowUserToDeleteRows = false;
            this.DgvBrands.AutoGenerateColumns = false;
            this.DgvBrands.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvBrands.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn3,
            this.brandModelDataGridViewTextBoxColumn});
            this.DgvBrands.DataSource = this.brandModelsBindingSource;
            this.DgvBrands.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvBrands.Location = new System.Drawing.Point(0, 0);
            this.DgvBrands.MultiSelect = false;
            this.DgvBrands.Name = "DgvBrands";
            this.DgvBrands.ReadOnly = true;
            this.DgvBrands.RowHeadersVisible = false;
            this.DgvBrands.RowHeadersWidth = 51;
            this.DgvBrands.RowTemplate.Height = 24;
            this.DgvBrands.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvBrands.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvBrands.Size = new System.Drawing.Size(854, 480);
            this.DgvBrands.TabIndex = 5;
            // 
            // TbpColors
            // 
            this.TbpColors.Controls.Add(this.DgvColors);
            this.TbpColors.Location = new System.Drawing.Point(4, 25);
            this.TbpColors.Name = "TbpColors";
            this.TbpColors.Size = new System.Drawing.Size(854, 480);
            this.TbpColors.TabIndex = 9;
            this.TbpColors.Text = "Цвета";
            this.TbpColors.UseVisualStyleBackColor = true;
            // 
            // DgvColors
            // 
            this.DgvColors.AllowUserToAddRows = false;
            this.DgvColors.AllowUserToDeleteRows = false;
            this.DgvColors.AutoGenerateColumns = false;
            this.DgvColors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvColors.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn4,
            this.colorDataGridViewTextBoxColumn1});
            this.DgvColors.DataSource = this.colorsBindingSource;
            this.DgvColors.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvColors.Location = new System.Drawing.Point(0, 0);
            this.DgvColors.MultiSelect = false;
            this.DgvColors.Name = "DgvColors";
            this.DgvColors.ReadOnly = true;
            this.DgvColors.RowHeadersVisible = false;
            this.DgvColors.RowHeadersWidth = 51;
            this.DgvColors.RowTemplate.Height = 24;
            this.DgvColors.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvColors.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvColors.Size = new System.Drawing.Size(854, 480);
            this.DgvColors.TabIndex = 6;
            // 
            // TbpClients
            // 
            this.TbpClients.Controls.Add(this.DgvClients);
            this.TbpClients.Location = new System.Drawing.Point(4, 25);
            this.TbpClients.Name = "TbpClients";
            this.TbpClients.Size = new System.Drawing.Size(854, 480);
            this.TbpClients.TabIndex = 10;
            this.TbpClients.Text = "Клиенты";
            this.TbpClients.UseVisualStyleBackColor = true;
            // 
            // DgvClients
            // 
            this.DgvClients.AllowUserToAddRows = false;
            this.DgvClients.AllowUserToDeleteRows = false;
            this.DgvClients.AutoGenerateColumns = false;
            this.DgvClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvClients.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.DgvClients.DataSource = this.clientsBindingSource;
            this.DgvClients.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvClients.Location = new System.Drawing.Point(0, 0);
            this.DgvClients.MultiSelect = false;
            this.DgvClients.Name = "DgvClients";
            this.DgvClients.ReadOnly = true;
            this.DgvClients.RowHeadersVisible = false;
            this.DgvClients.RowHeadersWidth = 51;
            this.DgvClients.RowTemplate.Height = 24;
            this.DgvClients.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvClients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvClients.Size = new System.Drawing.Size(854, 480);
            this.DgvClients.TabIndex = 4;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            this.idDataGridViewTextBoxColumn1.Width = 125;
            // 
            // brandDataGridViewTextBoxColumn2
            // 
            this.brandDataGridViewTextBoxColumn2.DataPropertyName = "Brand";
            this.brandDataGridViewTextBoxColumn2.HeaderText = "Brand";
            this.brandDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.brandDataGridViewTextBoxColumn2.Name = "brandDataGridViewTextBoxColumn2";
            this.brandDataGridViewTextBoxColumn2.ReadOnly = true;
            this.brandDataGridViewTextBoxColumn2.Width = 125;
            // 
            // plateDataGridViewTextBoxColumn3
            // 
            this.plateDataGridViewTextBoxColumn3.DataPropertyName = "Plate";
            this.plateDataGridViewTextBoxColumn3.HeaderText = "Plate";
            this.plateDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.plateDataGridViewTextBoxColumn3.Name = "plateDataGridViewTextBoxColumn3";
            this.plateDataGridViewTextBoxColumn3.ReadOnly = true;
            this.plateDataGridViewTextBoxColumn3.Width = 125;
            // 
            // rentalDataGridViewTextBoxColumn1
            // 
            this.rentalDataGridViewTextBoxColumn1.DataPropertyName = "Rental";
            this.rentalDataGridViewTextBoxColumn1.HeaderText = "Rental";
            this.rentalDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.rentalDataGridViewTextBoxColumn1.Name = "rentalDataGridViewTextBoxColumn1";
            this.rentalDataGridViewTextBoxColumn1.ReadOnly = true;
            this.rentalDataGridViewTextBoxColumn1.Width = 125;
            // 
            // clientDataGridViewTextBoxColumn2
            // 
            this.clientDataGridViewTextBoxColumn2.DataPropertyName = "Client";
            this.clientDataGridViewTextBoxColumn2.HeaderText = "Client";
            this.clientDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.clientDataGridViewTextBoxColumn2.Name = "clientDataGridViewTextBoxColumn2";
            this.clientDataGridViewTextBoxColumn2.ReadOnly = true;
            this.clientDataGridViewTextBoxColumn2.Width = 125;
            // 
            // dateStartDataGridViewTextBoxColumn2
            // 
            this.dateStartDataGridViewTextBoxColumn2.DataPropertyName = "DateStart";
            this.dateStartDataGridViewTextBoxColumn2.HeaderText = "DateStart";
            this.dateStartDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dateStartDataGridViewTextBoxColumn2.Name = "dateStartDataGridViewTextBoxColumn2";
            this.dateStartDataGridViewTextBoxColumn2.ReadOnly = true;
            this.dateStartDataGridViewTextBoxColumn2.Width = 125;
            // 
            // durationDataGridViewTextBoxColumn1
            // 
            this.durationDataGridViewTextBoxColumn1.DataPropertyName = "Duration";
            this.durationDataGridViewTextBoxColumn1.HeaderText = "Duration";
            this.durationDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.durationDataGridViewTextBoxColumn1.Name = "durationDataGridViewTextBoxColumn1";
            this.durationDataGridViewTextBoxColumn1.ReadOnly = true;
            this.durationDataGridViewTextBoxColumn1.Width = 125;
            // 
            // hireBindingSource1
            // 
            this.hireBindingSource1.DataSource = typeof(CarHireLibrary.Models.Hire);
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn2.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            this.idDataGridViewTextBoxColumn2.ReadOnly = true;
            this.idDataGridViewTextBoxColumn2.Width = 125;
            // 
            // brandDataGridViewTextBoxColumn3
            // 
            this.brandDataGridViewTextBoxColumn3.DataPropertyName = "Brand";
            this.brandDataGridViewTextBoxColumn3.HeaderText = "Brand";
            this.brandDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.brandDataGridViewTextBoxColumn3.Name = "brandDataGridViewTextBoxColumn3";
            this.brandDataGridViewTextBoxColumn3.ReadOnly = true;
            this.brandDataGridViewTextBoxColumn3.Width = 125;
            // 
            // colorDataGridViewTextBoxColumn
            // 
            this.colorDataGridViewTextBoxColumn.DataPropertyName = "Color";
            this.colorDataGridViewTextBoxColumn.HeaderText = "Color";
            this.colorDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.colorDataGridViewTextBoxColumn.Name = "colorDataGridViewTextBoxColumn";
            this.colorDataGridViewTextBoxColumn.ReadOnly = true;
            this.colorDataGridViewTextBoxColumn.Width = 125;
            // 
            // plateDataGridViewTextBoxColumn4
            // 
            this.plateDataGridViewTextBoxColumn4.DataPropertyName = "Plate";
            this.plateDataGridViewTextBoxColumn4.HeaderText = "Plate";
            this.plateDataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.plateDataGridViewTextBoxColumn4.Name = "plateDataGridViewTextBoxColumn4";
            this.plateDataGridViewTextBoxColumn4.ReadOnly = true;
            this.plateDataGridViewTextBoxColumn4.Width = 125;
            // 
            // yearManufDataGridViewTextBoxColumn
            // 
            this.yearManufDataGridViewTextBoxColumn.DataPropertyName = "YearManuf";
            this.yearManufDataGridViewTextBoxColumn.HeaderText = "YearManuf";
            this.yearManufDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.yearManufDataGridViewTextBoxColumn.Name = "yearManufDataGridViewTextBoxColumn";
            this.yearManufDataGridViewTextBoxColumn.ReadOnly = true;
            this.yearManufDataGridViewTextBoxColumn.Width = 125;
            // 
            // insurValueDataGridViewTextBoxColumn
            // 
            this.insurValueDataGridViewTextBoxColumn.DataPropertyName = "InsurValue";
            this.insurValueDataGridViewTextBoxColumn.HeaderText = "InsurValue";
            this.insurValueDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.insurValueDataGridViewTextBoxColumn.Name = "insurValueDataGridViewTextBoxColumn";
            this.insurValueDataGridViewTextBoxColumn.ReadOnly = true;
            this.insurValueDataGridViewTextBoxColumn.Width = 125;
            // 
            // rentalDataGridViewTextBoxColumn2
            // 
            this.rentalDataGridViewTextBoxColumn2.DataPropertyName = "Rental";
            this.rentalDataGridViewTextBoxColumn2.HeaderText = "Rental";
            this.rentalDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.rentalDataGridViewTextBoxColumn2.Name = "rentalDataGridViewTextBoxColumn2";
            this.rentalDataGridViewTextBoxColumn2.ReadOnly = true;
            this.rentalDataGridViewTextBoxColumn2.Width = 125;
            // 
            // carBindingSource
            // 
            this.carBindingSource.DataSource = typeof(CarHireLibrary.Models.Car);
            // 
            // idDataGridViewTextBoxColumn3
            // 
            this.idDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.idDataGridViewTextBoxColumn3.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn3.FillWeight = 10F;
            this.idDataGridViewTextBoxColumn3.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn3.Name = "idDataGridViewTextBoxColumn3";
            this.idDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // brandModelDataGridViewTextBoxColumn
            // 
            this.brandModelDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.brandModelDataGridViewTextBoxColumn.DataPropertyName = "BrandModel";
            this.brandModelDataGridViewTextBoxColumn.FillWeight = 90F;
            this.brandModelDataGridViewTextBoxColumn.HeaderText = "Модель ";
            this.brandModelDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.brandModelDataGridViewTextBoxColumn.Name = "brandModelDataGridViewTextBoxColumn";
            this.brandModelDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // brandModelsBindingSource
            // 
            this.brandModelsBindingSource.DataSource = typeof(CarHireLibrary.Models.BrandModels);
            // 
            // idDataGridViewTextBoxColumn4
            // 
            this.idDataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.idDataGridViewTextBoxColumn4.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn4.FillWeight = 10F;
            this.idDataGridViewTextBoxColumn4.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn4.Name = "idDataGridViewTextBoxColumn4";
            this.idDataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // colorDataGridViewTextBoxColumn1
            // 
            this.colorDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colorDataGridViewTextBoxColumn1.DataPropertyName = "Color";
            this.colorDataGridViewTextBoxColumn1.FillWeight = 90F;
            this.colorDataGridViewTextBoxColumn1.HeaderText = "Цвет";
            this.colorDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.colorDataGridViewTextBoxColumn1.Name = "colorDataGridViewTextBoxColumn1";
            this.colorDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // colorsBindingSource
            // 
            this.colorsBindingSource.DataSource = typeof(CarHireLibrary.Models.Colors);
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn8.HeaderText = "Ид";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 125;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Surname";
            this.dataGridViewTextBoxColumn9.HeaderText = "Фамилия";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 190;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn10.HeaderText = "Имя";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 170;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Patronymic";
            this.dataGridViewTextBoxColumn11.HeaderText = "Отчество";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 200;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Passport";
            this.dataGridViewTextBoxColumn12.HeaderText = "Серия и номер паспорта";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 200;
            // 
            // clientsBindingSource
            // 
            this.clientsBindingSource.DataSource = typeof(CarHireLibrary.Models.Clients);
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn32.HeaderText = "Ид";
            this.dataGridViewTextBoxColumn32.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            this.dataGridViewTextBoxColumn32.Width = 60;
            // 
            // brandDataGridViewTextBoxColumn
            // 
            this.brandDataGridViewTextBoxColumn.DataPropertyName = "Brand";
            this.brandDataGridViewTextBoxColumn.HeaderText = "Бренд автомобиля";
            this.brandDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.brandDataGridViewTextBoxColumn.Name = "brandDataGridViewTextBoxColumn";
            this.brandDataGridViewTextBoxColumn.ReadOnly = true;
            this.brandDataGridViewTextBoxColumn.Width = 125;
            // 
            // plateDataGridViewTextBoxColumn
            // 
            this.plateDataGridViewTextBoxColumn.DataPropertyName = "Plate";
            this.plateDataGridViewTextBoxColumn.HeaderText = "Гос. номер автомобиля";
            this.plateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.plateDataGridViewTextBoxColumn.Name = "plateDataGridViewTextBoxColumn";
            this.plateDataGridViewTextBoxColumn.ReadOnly = true;
            this.plateDataGridViewTextBoxColumn.Width = 125;
            // 
            // rentalDataGridViewTextBoxColumn
            // 
            this.rentalDataGridViewTextBoxColumn.DataPropertyName = "Rental";
            this.rentalDataGridViewTextBoxColumn.HeaderText = "Cтоимость одного дня проката";
            this.rentalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.rentalDataGridViewTextBoxColumn.Name = "rentalDataGridViewTextBoxColumn";
            this.rentalDataGridViewTextBoxColumn.ReadOnly = true;
            this.rentalDataGridViewTextBoxColumn.Width = 175;
            // 
            // clientDataGridViewTextBoxColumn
            // 
            this.clientDataGridViewTextBoxColumn.DataPropertyName = "Client";
            this.clientDataGridViewTextBoxColumn.HeaderText = "Фамилия И.О. клиента";
            this.clientDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.clientDataGridViewTextBoxColumn.Name = "clientDataGridViewTextBoxColumn";
            this.clientDataGridViewTextBoxColumn.ReadOnly = true;
            this.clientDataGridViewTextBoxColumn.Width = 125;
            // 
            // dateStartDataGridViewTextBoxColumn
            // 
            this.dateStartDataGridViewTextBoxColumn.DataPropertyName = "DateStart";
            this.dateStartDataGridViewTextBoxColumn.HeaderText = "Дата начала проката";
            this.dateStartDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dateStartDataGridViewTextBoxColumn.Name = "dateStartDataGridViewTextBoxColumn";
            this.dateStartDataGridViewTextBoxColumn.ReadOnly = true;
            this.dateStartDataGridViewTextBoxColumn.Width = 125;
            // 
            // durationDataGridViewTextBoxColumn
            // 
            this.durationDataGridViewTextBoxColumn.DataPropertyName = "Duration";
            this.durationDataGridViewTextBoxColumn.HeaderText = "Длительность проката";
            this.durationDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.durationDataGridViewTextBoxColumn.Name = "durationDataGridViewTextBoxColumn";
            this.durationDataGridViewTextBoxColumn.ReadOnly = true;
            this.durationDataGridViewTextBoxColumn.Width = 125;
            // 
            // hireBindingSource
            // 
            this.hireBindingSource.DataSource = typeof(CarHireLibrary.Models.Hire);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Ид";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 60;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Brand";
            this.dataGridViewTextBoxColumn2.HeaderText = "Бренд автомобиля";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Plate";
            this.dataGridViewTextBoxColumn3.HeaderText = "Гос. номер автомобиля";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Rental";
            this.dataGridViewTextBoxColumn4.HeaderText = "Cтоимость одного дня проката";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 175;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Client";
            this.dataGridViewTextBoxColumn5.HeaderText = "Фамилия И.О. клиента";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "DateStart";
            this.dataGridViewTextBoxColumn6.HeaderText = "Дата начала проката";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Duration";
            this.dataGridViewTextBoxColumn7.HeaderText = "Длительность проката";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 125;
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Фамилия";
            this.surnameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            this.surnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.surnameDataGridViewTextBoxColumn.Width = 190;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Имя";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 170;
            // 
            // patronymicDataGridViewTextBoxColumn
            // 
            this.patronymicDataGridViewTextBoxColumn.DataPropertyName = "Patronymic";
            this.patronymicDataGridViewTextBoxColumn.HeaderText = "Отчество";
            this.patronymicDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.patronymicDataGridViewTextBoxColumn.Name = "patronymicDataGridViewTextBoxColumn";
            this.patronymicDataGridViewTextBoxColumn.ReadOnly = true;
            this.patronymicDataGridViewTextBoxColumn.Width = 200;
            // 
            // passportDataGridViewTextBoxColumn
            // 
            this.passportDataGridViewTextBoxColumn.DataPropertyName = "Passport";
            this.passportDataGridViewTextBoxColumn.HeaderText = "Серия и номер паспорта";
            this.passportDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.passportDataGridViewTextBoxColumn.Name = "passportDataGridViewTextBoxColumn";
            this.passportDataGridViewTextBoxColumn.ReadOnly = true;
            this.passportDataGridViewTextBoxColumn.Width = 200;
            // 
            // dateStartDataGridViewTextBoxColumn1
            // 
            this.dateStartDataGridViewTextBoxColumn1.DataPropertyName = "DateStart";
            this.dateStartDataGridViewTextBoxColumn1.HeaderText = "Дата начала проката";
            this.dateStartDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dateStartDataGridViewTextBoxColumn1.Name = "dateStartDataGridViewTextBoxColumn1";
            this.dateStartDataGridViewTextBoxColumn1.ReadOnly = true;
            this.dateStartDataGridViewTextBoxColumn1.Width = 209;
            // 
            // plateDataGridViewTextBoxColumn1
            // 
            this.plateDataGridViewTextBoxColumn1.DataPropertyName = "Plate";
            this.plateDataGridViewTextBoxColumn1.HeaderText = "Гос. номер автомобиля";
            this.plateDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.plateDataGridViewTextBoxColumn1.Name = "plateDataGridViewTextBoxColumn1";
            this.plateDataGridViewTextBoxColumn1.ReadOnly = true;
            this.plateDataGridViewTextBoxColumn1.Width = 240;
            // 
            // brandDataGridViewTextBoxColumn1
            // 
            this.brandDataGridViewTextBoxColumn1.DataPropertyName = "Brand";
            this.brandDataGridViewTextBoxColumn1.HeaderText = "Модель автомобиля";
            this.brandDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.brandDataGridViewTextBoxColumn1.Name = "brandDataGridViewTextBoxColumn1";
            this.brandDataGridViewTextBoxColumn1.ReadOnly = true;
            this.brandDataGridViewTextBoxColumn1.Width = 230;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Стоимость проката";
            this.priceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            this.priceDataGridViewTextBoxColumn.Width = 195;
            // 
            // query04ViewModelBindingSource
            // 
            this.query04ViewModelBindingSource.DataSource = typeof(CarHireLibrary.Models.Query04ViewModel);
            // 
            // clientDataGridViewTextBoxColumn1
            // 
            this.clientDataGridViewTextBoxColumn1.DataPropertyName = "Client";
            this.clientDataGridViewTextBoxColumn1.HeaderText = "Фамилия И.О.";
            this.clientDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.clientDataGridViewTextBoxColumn1.Name = "clientDataGridViewTextBoxColumn1";
            this.clientDataGridViewTextBoxColumn1.ReadOnly = true;
            this.clientDataGridViewTextBoxColumn1.Width = 180;
            // 
            // passportDataGridViewTextBoxColumn1
            // 
            this.passportDataGridViewTextBoxColumn1.DataPropertyName = "Passport";
            this.passportDataGridViewTextBoxColumn1.HeaderText = "Серия и номер паспорта";
            this.passportDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.passportDataGridViewTextBoxColumn1.Name = "passportDataGridViewTextBoxColumn1";
            this.passportDataGridViewTextBoxColumn1.ReadOnly = true;
            this.passportDataGridViewTextBoxColumn1.Width = 250;
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn.HeaderText = "Кол-во фактов проката";
            this.amountDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            this.amountDataGridViewTextBoxColumn.ReadOnly = true;
            this.amountDataGridViewTextBoxColumn.Width = 220;
            // 
            // sumDurationDataGridViewTextBoxColumn
            // 
            this.sumDurationDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.sumDurationDataGridViewTextBoxColumn.DataPropertyName = "SumDuration";
            this.sumDurationDataGridViewTextBoxColumn.HeaderText = "Суммарное кол-во дней проката";
            this.sumDurationDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sumDurationDataGridViewTextBoxColumn.Name = "sumDurationDataGridViewTextBoxColumn";
            this.sumDurationDataGridViewTextBoxColumn.ReadOnly = true;
            this.sumDurationDataGridViewTextBoxColumn.Width = 221;
            // 
            // query05ViewModelBindingSource
            // 
            this.query05ViewModelBindingSource.DataSource = typeof(CarHireLibrary.Models.Query05ViewModel);
            // 
            // plateDataGridViewTextBoxColumn2
            // 
            this.plateDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.plateDataGridViewTextBoxColumn2.DataPropertyName = "Plate";
            this.plateDataGridViewTextBoxColumn2.FillWeight = 80F;
            this.plateDataGridViewTextBoxColumn2.HeaderText = "Гос. номер";
            this.plateDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.plateDataGridViewTextBoxColumn2.Name = "plateDataGridViewTextBoxColumn2";
            this.plateDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // amountDataGridViewTextBoxColumn1
            // 
            this.amountDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.amountDataGridViewTextBoxColumn1.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn1.FillWeight = 150F;
            this.amountDataGridViewTextBoxColumn1.HeaderText = "Кол-во фактов проката";
            this.amountDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.amountDataGridViewTextBoxColumn1.Name = "amountDataGridViewTextBoxColumn1";
            this.amountDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // sumRentalDataGridViewTextBoxColumn
            // 
            this.sumRentalDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.sumRentalDataGridViewTextBoxColumn.DataPropertyName = "SumRental";
            this.sumRentalDataGridViewTextBoxColumn.HeaderText = "Сумма за прокаты";
            this.sumRentalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sumRentalDataGridViewTextBoxColumn.Name = "sumRentalDataGridViewTextBoxColumn";
            this.sumRentalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sumDurationDataGridViewTextBoxColumn1
            // 
            this.sumDurationDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.sumDurationDataGridViewTextBoxColumn1.DataPropertyName = "SumDuration";
            this.sumDurationDataGridViewTextBoxColumn1.FillWeight = 170F;
            this.sumDurationDataGridViewTextBoxColumn1.HeaderText = "Суммарная длительность прокатов";
            this.sumDurationDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.sumDurationDataGridViewTextBoxColumn1.Name = "sumDurationDataGridViewTextBoxColumn1";
            this.sumDurationDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // query06ViewModelBindingSource
            // 
            this.query06ViewModelBindingSource.DataSource = typeof(CarHireLibrary.Models.Query06ViewModel);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(862, 578);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 24.01.2022";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.TbpQuery06.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).EndInit();
            this.TbpQuery05.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery05)).EndInit();
            this.TbpQuery04.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery04)).EndInit();
            this.TbpQuery03.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery03)).EndInit();
            this.TbpQuery02.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).EndInit();
            this.TbpQuery01.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).EndInit();
            this.TbpHires.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvHires)).EndInit();
            this.TbcMain.ResumeLayout(false);
            this.TbpCars.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvCars)).EndInit();
            this.TbpBrands.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvBrands)).EndInit();
            this.TbpColors.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvColors)).EndInit();
            this.TbpClients.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvClients)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hireBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brandModelsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hireBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.query04ViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.query05ViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.query06ViewModelBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запросыToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripMenuItem запрос1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запросToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаЕдиницИзмеренияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаПерсонToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаПродавцовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаТоваровToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаЗакупокToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.TabPage TbpQuery06;
        private System.Windows.Forms.DataGridView DgvQuery06;
        private System.Windows.Forms.Label LblQuery06;
        private System.Windows.Forms.TabPage TbpQuery05;
        private System.Windows.Forms.DataGridView DgvQuery05;
        private System.Windows.Forms.Label LblQuery05;
        private System.Windows.Forms.TabPage TbpQuery04;
        private System.Windows.Forms.DataGridView DgvQuery04;
        private System.Windows.Forms.Label LblQuery04;
        private System.Windows.Forms.TabPage TbpQuery03;
        private System.Windows.Forms.DataGridView DgvQuery03;
        private System.Windows.Forms.Label LblQuery03;
        private System.Windows.Forms.TabPage TbpQuery02;
        private System.Windows.Forms.Label LblQuery02;
        private System.Windows.Forms.TabPage TbpQuery01;
        private System.Windows.Forms.DataGridView DgvQuery01;
        private System.Windows.Forms.Label LblQuery01;
        private System.Windows.Forms.TabPage TbpHires;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.BindingSource hireBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn brandDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn plateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateStartDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn durationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView DgvQuery02;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.BindingSource clientsBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronymicDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passportDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource query04ViewModelBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateStartDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn plateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn brandDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn passportDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sumDurationDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource query05ViewModelBindingSource;
        private System.Windows.Forms.BindingSource query06ViewModelBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn plateDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sumRentalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sumDurationDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridView DgvHires;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn brandDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn plateDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentalDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateStartDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn durationDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource hireBindingSource1;
        private System.Windows.Forms.TabPage TbpCars;
        private System.Windows.Forms.TabPage TbpBrands;
        private System.Windows.Forms.TabPage TbpColors;
        private System.Windows.Forms.TabPage TbpClients;
        private System.Windows.Forms.DataGridView DgvCars;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn brandDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn colorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn plateDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearManufDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn insurValueDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentalDataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource carBindingSource;
        private System.Windows.Forms.DataGridView DgvBrands;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn brandModelDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource brandModelsBindingSource;
        private System.Windows.Forms.DataGridView DgvColors;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn colorDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource colorsBindingSource;
        private System.Windows.Forms.DataGridView DgvClients;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton BtnAdd;
        private System.Windows.Forms.ToolStripButton BtnEdit;
        private System.Windows.Forms.ToolStripButton BtnAddHire;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton BtnEditHire;
    }
}

