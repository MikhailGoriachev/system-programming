﻿
namespace BankBranch
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сортировкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.платежиПлательщикаПоПолучателюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.платежиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.платежиСДиапазономСуммыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.TsbCreate = new System.Windows.Forms.ToolStripButton();
            this.TsbOrderByReceiver = new System.Windows.Forms.ToolStripButton();
            this.TsbOrderBySender = new System.Windows.Forms.ToolStripButton();
            this.TsbOrderByDiapozone = new System.Windows.Forms.ToolStripButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.DgvCollection = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvCollection)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.сортировкиToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1199, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(69, 29);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // сортировкиToolStripMenuItem
            // 
            this.сортировкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.платежиПлательщикаПоПолучателюToolStripMenuItem,
            this.платежиToolStripMenuItem,
            this.платежиСДиапазономСуммыToolStripMenuItem});
            this.сортировкиToolStripMenuItem.Name = "сортировкиToolStripMenuItem";
            this.сортировкиToolStripMenuItem.Size = new System.Drawing.Size(129, 29);
            this.сортировкиToolStripMenuItem.Text = "Сортировки";
            // 
            // платежиПлательщикаПоПолучателюToolStripMenuItem
            // 
            this.платежиПлательщикаПоПолучателюToolStripMenuItem.Name = "платежиПлательщикаПоПолучателюToolStripMenuItem";
            this.платежиПлательщикаПоПолучателюToolStripMenuItem.Size = new System.Drawing.Size(464, 34);
            this.платежиПлательщикаПоПолучателюToolStripMenuItem.Text = "Платежи плательщика по получателю";
            this.платежиПлательщикаПоПолучателюToolStripMenuItem.Click += new System.EventHandler(this.SortByReveiver_Click);
            // 
            // платежиToolStripMenuItem
            // 
            this.платежиToolStripMenuItem.Name = "платежиToolStripMenuItem";
            this.платежиToolStripMenuItem.Size = new System.Drawing.Size(464, 34);
            this.платежиToolStripMenuItem.Text = "Платежи получателя по убыванию суммы ";
            this.платежиToolStripMenuItem.Click += new System.EventHandler(this.SortBySumDesc_Click);
            // 
            // платежиСДиапазономСуммыToolStripMenuItem
            // 
            this.платежиСДиапазономСуммыToolStripMenuItem.Name = "платежиСДиапазономСуммыToolStripMenuItem";
            this.платежиСДиапазономСуммыToolStripMenuItem.Size = new System.Drawing.Size(464, 34);
            this.платежиСДиапазономСуммыToolStripMenuItem.Text = "Платежи с диапазоном до 1000";
            this.платежиСДиапазономСуммыToolStripMenuItem.Click += new System.EventHandler(this.SumDiapazone_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbCreate,
            this.TsbOrderByReceiver,
            this.TsbOrderBySender,
            this.TsbOrderByDiapozone});
            this.toolStrip1.Location = new System.Drawing.Point(0, 33);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1199, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // TsbCreate
            // 
            this.TsbCreate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbCreate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbCreate.Name = "TsbCreate";
            this.TsbCreate.Size = new System.Drawing.Size(34, 20);
            this.TsbCreate.Text = "toolStripButton1";
            // 
            // TsbOrderByReceiver
            // 
            this.TsbOrderByReceiver.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOrderByReceiver.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOrderByReceiver.Name = "TsbOrderByReceiver";
            this.TsbOrderByReceiver.Size = new System.Drawing.Size(34, 20);
            this.TsbOrderByReceiver.Text = "toolStripButton2";
            // 
            // TsbOrderBySender
            // 
            this.TsbOrderBySender.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOrderBySender.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOrderBySender.Name = "TsbOrderBySender";
            this.TsbOrderBySender.Size = new System.Drawing.Size(34, 20);
            this.TsbOrderBySender.Text = "toolStripButton3";
            // 
            // TsbOrderByDiapozone
            // 
            this.TsbOrderByDiapozone.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOrderByDiapozone.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOrderByDiapozone.Name = "TsbOrderByDiapozone";
            this.TsbOrderByDiapozone.Size = new System.Drawing.Size(34, 20);
            this.TsbOrderByDiapozone.Text = "toolStripButton4";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(21, 99);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(1166, 466);
            this.textBox1.TabIndex = 2;
            // 
            // DgvCollection
            // 
            this.DgvCollection.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvCollection.Location = new System.Drawing.Point(21, 99);
            this.DgvCollection.Name = "DgvCollection";
            this.DgvCollection.RowHeadersWidth = 62;
            this.DgvCollection.RowTemplate.Height = 33;
            this.DgvCollection.Size = new System.Drawing.Size(1156, 466);
            this.DgvCollection.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 604);
            this.Controls.Add(this.DgvCollection);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "BankStatement";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvCollection)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сортировкиToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton TsbCreate;
        private System.Windows.Forms.ToolStripButton TsbOrderByReceiver;
        private System.Windows.Forms.ToolStripButton TsbOrderBySender;
        private System.Windows.Forms.ToolStripButton TsbOrderByDiapozone;
        private System.Windows.Forms.ToolStripMenuItem платежиПлательщикаПоПолучателюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem платежиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem платежиСДиапазономСуммыToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView DgvCollection;
    }
}

