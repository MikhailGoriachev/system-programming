﻿using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;
using OrderBankDepartment;
using BankBranch.Controllers;

namespace BankBranch
{
    public partial class Form1 : Form
    {
        public Controller controller = new Controller();
        public Form1()
        {
            InitializeComponent();
            DgvCollection.DataSource = controller.orders;
        }

        private void SortByReveiver_Click(object sender, System.EventArgs e)
        {

            DgvCollection.DataSource = null;
            DgvCollection.DataSource = controller.OrderByReceiver().ToArray();

        }

        private void SortBySumDesc_Click(object sender, System.EventArgs e)
        {
            DgvCollection.DataSource = null;
            DgvCollection.DataSource = controller.OrderBySumDesc().ToArray();
        }

        private void SumDiapazone_Click(object sender, System.EventArgs e)
        {
            DgvCollection.DataSource = null;
            DgvCollection.DataSource = controller.SumDiapazone().ToArray();
        }
    }
}
