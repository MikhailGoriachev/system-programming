﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using OrderBankDepartment;

namespace BankBranch.Controllers
{
    public class Controller
    {
        public BankDepartment Department { get; set; }

        // коллекция счетов
        public List<Order> orders = new List<Order>
        {
            new Order {PayeersAccount = 0390394267, ReceiversAccount = 1387978342, PayeersCurrentBalance = 12000, ReceiversCurrentBalance = 1000, TotalSum = 13000},
            new Order {PayeersAccount = 0545632497, ReceiversAccount = 0764589965, PayeersCurrentBalance = 500, ReceiversCurrentBalance = 500, TotalSum = 1000}, 
            new Order {PayeersAccount = 0475837583,  ReceiversAccount = 0292345634, PayeersCurrentBalance = 700, ReceiversCurrentBalance = 700, TotalSum = 1400},
            new Order {PayeersAccount = 0390394267, ReceiversAccount = 0764589965, PayeersCurrentBalance = 13000, ReceiversCurrentBalance = 400, TotalSum = 13400}
        };

        //добавление объекта 
        public void AddCustomer(Order person) => Department.AddOrder(person);

        //удаление объекта 
        public void RemoveCustomer(Order person) => Department.DeleteOrder(person);

        //сериализация
        public void Serialization(StreamWriter stream) => Department.Serialize(stream);

        //десериализация
        public void Deserialization(StreamReader reader) => Department.Deserialize(reader);

        //упорядочивание по получателю
        public IEnumerable<Order> OrderByReceiver() => orders.OrderBy(a=>a.ReceiversAccount);

        //упорядочивание по убыванию суммы
        public IEnumerable<Order> OrderBySumDesc() => orders.OrderByDescending(a => a.TotalSum);

        // диапазон платежей до 1000 рублей
        public IEnumerable<Order> SumDiapazone() => orders.Where(a => a.TotalSum <= 1000);
    }
}
