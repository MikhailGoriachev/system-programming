﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace OrderBankDepartment
{
    public class BankDepartment
    {
        //название отделения
        public string BranchName { get; set; }

        //коллекция счетов 
        private List<Order> Orders { get; set; }

        //индексатор
        public Order this[int index]
        {
            get => Orders[index]; 
            set => Orders[index] = value;
            
        }

        

        //добавление объекта Order
        public void AddOrder(Order item) => Orders.Add(item);

        //удаление объект Order
        public void DeleteOrder(Order item) => Orders.Remove(item);

        //сериализация в формате XML
        public void Serialize(StreamWriter stream)
        {
            XmlSerializer xml = new XmlSerializer(typeof(BankDepartment));

            xml.Serialize(stream, this);
        }

        //десериализация в формате XML
        public void Deserialize(StreamReader stream)
        {
            XmlSerializer xml = new XmlSerializer(typeof(BankDepartment));
            var item = (BankDepartment)xml.Deserialize(stream);

            BranchName = item.BranchName;

            Orders = item.Orders;


        }

    }
}
