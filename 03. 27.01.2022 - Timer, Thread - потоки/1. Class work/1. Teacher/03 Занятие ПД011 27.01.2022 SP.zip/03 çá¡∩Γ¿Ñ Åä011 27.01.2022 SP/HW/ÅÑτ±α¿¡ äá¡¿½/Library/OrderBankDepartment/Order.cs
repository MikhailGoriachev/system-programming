﻿using System;

namespace OrderBankDepartment
{
    public class Order
    {
        //расчетный счет плательщика
        public int PayeersAccount { get; set; }

        // расчетный счет получателя
        public int ReceiversAccount { get; set; }

        // текущая сумма на счету плательщика
        public int PayeersCurrentBalance { get; set; }

        //текущая сумма на счету получателя
        public int ReceiversCurrentBalance { get; set; }

        //сумма платежа
        public int TotalSum { get; set; }
    }
}
