﻿namespace Library
{
	public sealed class Order
	{
		public Client Sender { get; set; }
		public Client Receiver { get; set; }
		public decimal Sum { get; set; }
	}
}