﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Xml.Serialization;


namespace Library
{
	public sealed class BankDepartment
	{
		private List<Order> _orders = new();

		public string Title { get; set; }
		public IReadOnlyCollection<Order> Orders => _orders;
		public Order this[int index] { get => _orders[index]; set => _orders[index] = value; }


		public BankDepartment(string title) =>
			Title = title;


		public void Add(Order order) =>
			_orders.Add(order);


		public bool Remove(Order order) =>
			_orders.Remove(order);


		public void Serialize(StreamWriter writer)
		{
			var serialzier = new XmlSerializer(typeof(BankDepartment));

			serialzier.Serialize(writer, this);
		}


		public void Deserialize(StreamReader reader)
		{
			var serialzier = new XmlSerializer(typeof(BankDepartment));

			var deserialized = (BankDepartment)serialzier.Deserialize(reader)!;

			Title  = deserialized.Title;
			_orders = deserialized.Orders.ToList();
		}
	}
}