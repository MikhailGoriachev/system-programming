﻿namespace Library
{
	public sealed class Client
	{
		public string Account { get; set; }
		public decimal Amount { get; set; }
	}
}