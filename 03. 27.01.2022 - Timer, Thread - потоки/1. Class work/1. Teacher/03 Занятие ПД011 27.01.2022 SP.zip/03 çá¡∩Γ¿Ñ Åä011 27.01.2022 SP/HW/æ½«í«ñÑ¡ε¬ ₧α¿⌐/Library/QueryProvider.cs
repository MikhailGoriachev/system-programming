﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Library
{
	public sealed class QueryProvider
	{
		private readonly BankDepartment _bank = new("Title1");


		public IReadOnlyCollection<Order> Orders => _bank.Orders;


		public QueryProvider()
		{
			var size = new Random().Next(10, 20);
			for (int i = 0; i < size; i++)
			{
				var orderToAdd = new Order()
				{
					Receiver = new()
					{
						Account = $"Account{i}",
						Amount  = i
					},
					Sender = new()
					{
						Account = $"Account{i}",
						Amount  = i
					},
					Sum = i
				};

				_bank.Add(orderToAdd);
			}
		}


		public IEnumerable<Order> WhereSender(string payerAccount) =>
			_bank.Orders.Where(order => order.Sender.Account.Equals(payerAccount, StringComparison.Ordinal));

		public IEnumerable<Order> WhereReceiver(string receiverAccount) =>
			_bank.Orders.Where(order => order.Receiver.Account.Equals(receiverAccount, StringComparison.Ordinal));

		public IEnumerable<Order> WhereOrderSumInRangeInclusive(Range<decimal> range) =>
			_bank.Orders.Where(order => range.IsInRangeInclusive(order.Sum));
	}
}