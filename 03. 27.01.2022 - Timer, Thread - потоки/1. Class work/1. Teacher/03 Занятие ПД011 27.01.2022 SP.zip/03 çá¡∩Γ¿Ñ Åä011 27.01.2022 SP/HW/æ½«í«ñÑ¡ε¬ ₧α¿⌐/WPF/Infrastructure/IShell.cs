﻿using Stylet;


namespace WPF.Infrastructure
{
	public interface IShell
	{
		void ActivateItem(Screen screen);
	}
}