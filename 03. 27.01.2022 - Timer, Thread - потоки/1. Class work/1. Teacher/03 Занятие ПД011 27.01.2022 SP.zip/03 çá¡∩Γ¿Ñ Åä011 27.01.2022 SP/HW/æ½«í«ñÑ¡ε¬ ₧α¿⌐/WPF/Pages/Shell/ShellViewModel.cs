﻿using Stylet;
using WPF.Infrastructure;
using WPF.Pages.Query;


namespace WPF.Pages.Shell
{
	public sealed class ShellViewModel : Conductor<Screen>.Collection.OneActive, IShell
	{
		public ShellViewModel() => AddQueries();


		private void AddQueries()
		{
			var provider = new QueriesProvider();

			foreach (var (title, result) in provider.Queries())
			{
				var queryViewModel = new QueryViewModel(title, result);

				Items.Add(queryViewModel);
			}
		}
	}
}