﻿using Stylet;
using WPF.Pages.Shell;


namespace WPF
{
	public sealed class Bootstrapper : Bootstrapper<ShellViewModel> { }
}