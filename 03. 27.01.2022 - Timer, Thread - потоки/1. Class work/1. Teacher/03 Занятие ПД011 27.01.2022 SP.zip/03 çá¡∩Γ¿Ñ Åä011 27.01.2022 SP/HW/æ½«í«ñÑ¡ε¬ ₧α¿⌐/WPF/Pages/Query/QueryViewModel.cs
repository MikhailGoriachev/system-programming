﻿using System.Collections;
using WPF.Infrastructure;


namespace WPF.Pages.Query
{
	public sealed class QueryViewModel : TabScreen
	{
		public ICollection Items { get; }


		public QueryViewModel(string displayName, ICollection items) : base(displayName) =>
			Items = items;
	}
}