﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using Library;


namespace WPF.Infrastructure
{
	public static class Extensions
	{
		public static IEnumerable<object> RaiseNestedObjectsOfOrder(this IEnumerable<Order> orders) =>
			orders.Select(order => new
			{
				ReceiverAccount = order.Receiver.Account,
				ReceiverAmount  = order.Receiver.Amount,
				SenderAccount   = order.Sender.Account,
				SenderAmount    = order.Sender.Amount,
				OrderSum        = order.Sum
			});
	}


	public sealed class QueriesProvider
	{
		private readonly QueryProvider _libraryQueries = new();


		public IEnumerable<(string Title, ICollection Result)> Queries()
		{
			var queryMethods = GetType()
							   .GetMethods(BindingFlags.Instance | BindingFlags.NonPublic)
							   .Where(method => method.Name.Contains("Query"));

			foreach (var queryMethod in queryMethods)
			{
				var result = (ICollection)queryMethod.Invoke(this, null)!;
				var title = queryMethod.GetCustomAttribute<DisplayNameAttribute>()?.DisplayName
							?? queryMethod.Name;

				yield return (title, result);
			}
		}


		[DisplayName("Первый запрос")]
		private ICollection Query1() => _libraryQueries.WhereSender(TakeRandom().Sender.Account)
													   .RaiseNestedObjectsOfOrder()
													   .ToArray();


		[DisplayName("Второй запрос")]
		private ICollection Query2() => _libraryQueries.WhereReceiver(TakeRandom().Receiver.Account)
													   .RaiseNestedObjectsOfOrder()
													   .ToArray();


		[DisplayName("Третий запрос")]
		private ICollection Query3()
		{
			var random = new Random();

			static decimal SumSelector(Order order) => order.Sum;

			var max = _libraryQueries.Orders.Max(SumSelector);
			var min = _libraryQueries.Orders.Min(SumSelector);

			var range = Range<decimal>.CreateWithRandom(() => random.Next((int)min, (int)max));

			return _libraryQueries.WhereOrderSumInRangeInclusive(range)
								  .RaiseNestedObjectsOfOrder()
								  .ToArray();
		}


		private Order TakeRandom()
		{
			var randomPosition = new Random().Next(_libraryQueries.Orders.Count);

			return _libraryQueries.Orders.ElementAt(randomPosition);
		}
	}
}