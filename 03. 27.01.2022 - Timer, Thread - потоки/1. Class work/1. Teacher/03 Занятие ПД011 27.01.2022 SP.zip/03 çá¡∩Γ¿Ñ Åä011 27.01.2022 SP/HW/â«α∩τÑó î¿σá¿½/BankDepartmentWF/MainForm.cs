﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using BankDepartmentClassLibrary.Models;        // модели
using BankDepartmentWF.Controllers;     // контроллеры
using BankDepartmentWF.Utilities;

namespace BankDepartmentWF
{
    public partial class MainForm : Form
    {
        // контроллер обработки по заданию
        private TaskController _controller;

        public TaskController Controller
        {
            get => _controller;
            set => _controller = value;
        }


        #region Конструкторы

        // конструктор по умолчанию
        public MainForm() : this(new TaskController()) { }


        // конструктор инициализирующий
        public MainForm(TaskController taskController)
        {
            InitializeComponent();

            _controller = taskController;
        }

        #endregion


        #region Методы

        // загрузка формы
        private void MainForm_Load(object sender, EventArgs e)
        {
            // заполнение DataGridView
            UpdateBinding(_controller.BankDepartment.Orders, DgvMain);
        }


        // обновление привязки 
        public void UpdateBinding(List<Order> source, DataGridView grid)
        {
            grid.DataSource = null;
            grid.DataSource = source;

        }


        // переход на вкладку
        private void TbcMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (TbcMain.SelectedIndex)
            {
                // главная 
                case 0:
                    UpdateBinding(_controller.BankDepartment.Orders, DgvMain);
                    break;

                // запрос 1
                case 1:

                    // номер счёта 
                    string num1 = _controller.BankDepartment.Orders.ToArray()[Utils.GetRand(0, _controller.BankDepartment.Orders.Count())].SenderAccount;

                    // текст информации о запросе
                    string text1 = TbxQuery1.Text;

                    // вывод условий запроса
                    TbxQuery1.Text = text1.Remove(text1.LastIndexOf(':') + 2) + num1;


                    UpdateBinding(_controller.Query1(num1), DgvQuery1);
                    break;

                // запрос 2
                case 2:

                    // номер счёта 
                    string num2 = _controller.BankDepartment.Orders.ToArray()[Utils.GetRand(0, _controller.BankDepartment.Orders.Count())].ReceiverAccount;

                    // текст информации о запросе
                    string text2 = TbxQuery2.Text;

                    // вывод условий запроса
                    TbxQuery2.Text = text2.Remove(text2.LastIndexOf(':') + 2) + num2;


                    UpdateBinding(_controller.Query2(num2), DgvQuery2);
                    break;

                // запрос 3
                case 3:

                    // номер счёта 
                    int lo = Utils.GetRand(10, 20) * 1_000, hi = lo + 40_000;

                    // текст информации о запросе
                    string text3 = TbxQuery3.Text;

                    // вывод условий запроса
                    TbxQuery3.Text = text3.Remove(text3.LastIndexOf(':') + 2) + $"{lo} - {hi}";


                    UpdateBinding(_controller.Query3(lo, hi), DgvQuery3);
                    break;

                default:
                    break;
            }
        }

        #endregion
    }
}
