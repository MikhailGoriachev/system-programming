﻿namespace BankDepartmentWF
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.управлениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запросыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpMain = new System.Windows.Forms.TabPage();
            this.DgvMain = new System.Windows.Forms.DataGridView();
            this.GbxOrders = new System.Windows.Forms.GroupBox();
            this.GbxInfo = new System.Windows.Forms.GroupBox();
            this.LblName = new System.Windows.Forms.Label();
            this.TbxName = new System.Windows.Forms.TextBox();
            this.senderAccountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.receiverAccountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.senderAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.receiverAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountPaymentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TbpQuery1 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.DgvQuery1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GbxQuery1 = new System.Windows.Forms.GroupBox();
            this.TbxQuery1 = new System.Windows.Forms.TextBox();
            this.TbpQuery2 = new System.Windows.Forms.TabPage();
            this.GbxQuery2 = new System.Windows.Forms.GroupBox();
            this.TbxQuery2 = new System.Windows.Forms.TextBox();
            this.Gbx = new System.Windows.Forms.GroupBox();
            this.DgvQuery2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TbpQuery3 = new System.Windows.Forms.TabPage();
            this.GbxQuery3 = new System.Windows.Forms.GroupBox();
            this.TbxQuery3 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.DgvQuery3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MnsMain.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvMain)).BeginInit();
            this.GbxOrders.SuspendLayout();
            this.GbxInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).BeginInit();
            this.TbpQuery1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery1)).BeginInit();
            this.GbxQuery1.SuspendLayout();
            this.TbpQuery2.SuspendLayout();
            this.GbxQuery2.SuspendLayout();
            this.Gbx.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery2)).BeginInit();
            this.TbpQuery3.SuspendLayout();
            this.GbxQuery3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery3)).BeginInit();
            this.SuspendLayout();
            // 
            // MnsMain
            // 
            this.MnsMain.BackColor = System.Drawing.Color.Silver;
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.управлениеToolStripMenuItem,
            this.запросыToolStripMenuItem});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.MnsMain.Size = new System.Drawing.Size(1033, 28);
            this.MnsMain.TabIndex = 0;
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(57, 24);
            this.файлToolStripMenuItem.Text = "&Файл";
            // 
            // управлениеToolStripMenuItem
            // 
            this.управлениеToolStripMenuItem.Name = "управлениеToolStripMenuItem";
            this.управлениеToolStripMenuItem.Size = new System.Drawing.Size(106, 24);
            this.управлениеToolStripMenuItem.Text = "&Управление";
            // 
            // запросыToolStripMenuItem
            // 
            this.запросыToolStripMenuItem.Name = "запросыToolStripMenuItem";
            this.запросыToolStripMenuItem.Size = new System.Drawing.Size(82, 24);
            this.запросыToolStripMenuItem.Text = "&Запросы";
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpMain);
            this.TbcMain.Controls.Add(this.TbpQuery1);
            this.TbcMain.Controls.Add(this.TbpQuery2);
            this.TbcMain.Controls.Add(this.TbpQuery3);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.Location = new System.Drawing.Point(0, 28);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(1033, 477);
            this.TbcMain.TabIndex = 1;
            this.TbcMain.SelectedIndexChanged += new System.EventHandler(this.TbcMain_SelectedIndexChanged);
            // 
            // TbpMain
            // 
            this.TbpMain.BackColor = System.Drawing.Color.Gray;
            this.TbpMain.Controls.Add(this.GbxInfo);
            this.TbpMain.Controls.Add(this.GbxOrders);
            this.TbpMain.Location = new System.Drawing.Point(4, 25);
            this.TbpMain.Name = "TbpMain";
            this.TbpMain.Padding = new System.Windows.Forms.Padding(3);
            this.TbpMain.Size = new System.Drawing.Size(1025, 448);
            this.TbpMain.TabIndex = 0;
            this.TbpMain.Text = "Главная";
            // 
            // DgvMain
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gainsboro;
            this.DgvMain.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DgvMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvMain.AutoGenerateColumns = false;
            this.DgvMain.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvMain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.senderAccountDataGridViewTextBoxColumn,
            this.receiverAccountDataGridViewTextBoxColumn,
            this.senderAmountDataGridViewTextBoxColumn,
            this.receiverAmountDataGridViewTextBoxColumn,
            this.amountPaymentDataGridViewTextBoxColumn});
            this.DgvMain.DataSource = this.orderBindingSource;
            this.DgvMain.Location = new System.Drawing.Point(8, 24);
            this.DgvMain.MultiSelect = false;
            this.DgvMain.Name = "DgvMain";
            this.DgvMain.ReadOnly = true;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.DgvMain.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.DgvMain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvMain.Size = new System.Drawing.Size(760, 392);
            this.DgvMain.TabIndex = 0;
            // 
            // GbxOrders
            // 
            this.GbxOrders.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxOrders.Controls.Add(this.DgvMain);
            this.GbxOrders.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxOrders.ForeColor = System.Drawing.Color.White;
            this.GbxOrders.Location = new System.Drawing.Point(8, 16);
            this.GbxOrders.Name = "GbxOrders";
            this.GbxOrders.Size = new System.Drawing.Size(776, 424);
            this.GbxOrders.TabIndex = 1;
            this.GbxOrders.TabStop = false;
            this.GbxOrders.Text = " Платежи ";
            // 
            // GbxInfo
            // 
            this.GbxInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxInfo.Controls.Add(this.TbxName);
            this.GbxInfo.Controls.Add(this.LblName);
            this.GbxInfo.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxInfo.ForeColor = System.Drawing.Color.White;
            this.GbxInfo.Location = new System.Drawing.Point(792, 16);
            this.GbxInfo.Name = "GbxInfo";
            this.GbxInfo.Size = new System.Drawing.Size(224, 112);
            this.GbxInfo.TabIndex = 2;
            this.GbxInfo.TabStop = false;
            this.GbxInfo.Text = " Отделение банка ";
            // 
            // LblName
            // 
            this.LblName.BackColor = System.Drawing.Color.Silver;
            this.LblName.ForeColor = System.Drawing.Color.Black;
            this.LblName.Location = new System.Drawing.Point(8, 24);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(208, 32);
            this.LblName.TabIndex = 0;
            this.LblName.Text = "Название отделения";
            this.LblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TbxName
            // 
            this.TbxName.BackColor = System.Drawing.Color.Gainsboro;
            this.TbxName.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxName.Location = new System.Drawing.Point(8, 56);
            this.TbxName.Name = "TbxName";
            this.TbxName.ReadOnly = true;
            this.TbxName.Size = new System.Drawing.Size(208, 26);
            this.TbxName.TabIndex = 1;
            this.TbxName.TabStop = false;
            this.TbxName.Text = "Название";
            this.TbxName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // senderAccountDataGridViewTextBoxColumn
            // 
            this.senderAccountDataGridViewTextBoxColumn.DataPropertyName = "SenderAccount";
            this.senderAccountDataGridViewTextBoxColumn.HeaderText = "Счет плательщика";
            this.senderAccountDataGridViewTextBoxColumn.Name = "senderAccountDataGridViewTextBoxColumn";
            this.senderAccountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // receiverAccountDataGridViewTextBoxColumn
            // 
            this.receiverAccountDataGridViewTextBoxColumn.DataPropertyName = "ReceiverAccount";
            this.receiverAccountDataGridViewTextBoxColumn.HeaderText = "Счет получателя";
            this.receiverAccountDataGridViewTextBoxColumn.Name = "receiverAccountDataGridViewTextBoxColumn";
            this.receiverAccountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // senderAmountDataGridViewTextBoxColumn
            // 
            this.senderAmountDataGridViewTextBoxColumn.DataPropertyName = "SenderAmount";
            this.senderAmountDataGridViewTextBoxColumn.HeaderText = "Сумма на счету плательщика (руб.)";
            this.senderAmountDataGridViewTextBoxColumn.Name = "senderAmountDataGridViewTextBoxColumn";
            this.senderAmountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // receiverAmountDataGridViewTextBoxColumn
            // 
            this.receiverAmountDataGridViewTextBoxColumn.DataPropertyName = "ReceiverAmount";
            this.receiverAmountDataGridViewTextBoxColumn.HeaderText = "Сумма на счету получателя (руб.)";
            this.receiverAmountDataGridViewTextBoxColumn.Name = "receiverAmountDataGridViewTextBoxColumn";
            this.receiverAmountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // amountPaymentDataGridViewTextBoxColumn
            // 
            this.amountPaymentDataGridViewTextBoxColumn.DataPropertyName = "AmountPayment";
            this.amountPaymentDataGridViewTextBoxColumn.HeaderText = "Сумма платежа (руб.)";
            this.amountPaymentDataGridViewTextBoxColumn.Name = "amountPaymentDataGridViewTextBoxColumn";
            this.amountPaymentDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // orderBindingSource
            // 
            this.orderBindingSource.DataSource = typeof(BankDepartmentClassLibrary.Models.Order);
            // 
            // TbpQuery1
            // 
            this.TbpQuery1.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery1.Controls.Add(this.GbxQuery1);
            this.TbpQuery1.Controls.Add(this.groupBox2);
            this.TbpQuery1.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery1.Name = "TbpQuery1";
            this.TbpQuery1.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery1.Size = new System.Drawing.Size(1025, 448);
            this.TbpQuery1.TabIndex = 1;
            this.TbpQuery1.Text = "Запрос №1";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.DgvQuery1);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(8, 192);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1008, 248);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = " Платежи ";
            // 
            // DgvQuery1
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Gainsboro;
            this.DgvQuery1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.DgvQuery1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery1.AutoGenerateColumns = false;
            this.DgvQuery1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.DgvQuery1.DataSource = this.orderBindingSource;
            this.DgvQuery1.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery1.MultiSelect = false;
            this.DgvQuery1.Name = "DgvQuery1";
            this.DgvQuery1.ReadOnly = true;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.DgvQuery1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery1.Size = new System.Drawing.Size(992, 216);
            this.DgvQuery1.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "SenderAccount";
            this.dataGridViewTextBoxColumn1.HeaderText = "Счет плательщика";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ReceiverAccount";
            this.dataGridViewTextBoxColumn2.HeaderText = "Счет получателя";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "SenderAmount";
            this.dataGridViewTextBoxColumn3.HeaderText = "Сумма на счету плательщика (руб.)";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "ReceiverAmount";
            this.dataGridViewTextBoxColumn4.HeaderText = "Сумма на счету получателя (руб.)";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "AmountPayment";
            this.dataGridViewTextBoxColumn5.HeaderText = "Сумма платежа (руб.)";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // GbxQuery1
            // 
            this.GbxQuery1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxQuery1.Controls.Add(this.TbxQuery1);
            this.GbxQuery1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxQuery1.ForeColor = System.Drawing.Color.White;
            this.GbxQuery1.Location = new System.Drawing.Point(16, 16);
            this.GbxQuery1.Name = "GbxQuery1";
            this.GbxQuery1.Size = new System.Drawing.Size(1000, 160);
            this.GbxQuery1.TabIndex = 3;
            this.GbxQuery1.TabStop = false;
            this.GbxQuery1.Text = " Отделение банка ";
            // 
            // TbxQuery1
            // 
            this.TbxQuery1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery1.BackColor = System.Drawing.Color.Gainsboro;
            this.TbxQuery1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxQuery1.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery1.Multiline = true;
            this.TbxQuery1.Name = "TbxQuery1";
            this.TbxQuery1.ReadOnly = true;
            this.TbxQuery1.Size = new System.Drawing.Size(984, 128);
            this.TbxQuery1.TabIndex = 1;
            this.TbxQuery1.TabStop = false;
            this.TbxQuery1.Text = "1. Платежи заданного плательщика, упорядочивание по получателю\r\n\r\nНомер заданного" +
    " плательщика: значение\r\n";
            // 
            // TbpQuery2
            // 
            this.TbpQuery2.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery2.Controls.Add(this.GbxQuery2);
            this.TbpQuery2.Controls.Add(this.Gbx);
            this.TbpQuery2.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery2.Name = "TbpQuery2";
            this.TbpQuery2.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery2.Size = new System.Drawing.Size(1025, 448);
            this.TbpQuery2.TabIndex = 2;
            this.TbpQuery2.Text = "Запрос №2";
            // 
            // GbxQuery2
            // 
            this.GbxQuery2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxQuery2.Controls.Add(this.TbxQuery2);
            this.GbxQuery2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxQuery2.ForeColor = System.Drawing.Color.White;
            this.GbxQuery2.Location = new System.Drawing.Point(16, 16);
            this.GbxQuery2.Name = "GbxQuery2";
            this.GbxQuery2.Size = new System.Drawing.Size(1000, 160);
            this.GbxQuery2.TabIndex = 3;
            this.GbxQuery2.TabStop = false;
            this.GbxQuery2.Text = " Отделение банка ";
            // 
            // TbxQuery2
            // 
            this.TbxQuery2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery2.BackColor = System.Drawing.Color.Gainsboro;
            this.TbxQuery2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxQuery2.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery2.Multiline = true;
            this.TbxQuery2.Name = "TbxQuery2";
            this.TbxQuery2.ReadOnly = true;
            this.TbxQuery2.Size = new System.Drawing.Size(984, 128);
            this.TbxQuery2.TabIndex = 1;
            this.TbxQuery2.TabStop = false;
            this.TbxQuery2.Text = "2. Платежи заданному получателю, упорядочивание по убыванию суммы\r\n\r\nНомер заданн" +
    "ого плательщика: значение";
            // 
            // Gbx
            // 
            this.Gbx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Gbx.Controls.Add(this.DgvQuery2);
            this.Gbx.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Gbx.ForeColor = System.Drawing.Color.White;
            this.Gbx.Location = new System.Drawing.Point(8, 192);
            this.Gbx.Name = "Gbx";
            this.Gbx.Size = new System.Drawing.Size(1008, 248);
            this.Gbx.TabIndex = 1;
            this.Gbx.TabStop = false;
            this.Gbx.Text = " Платежи ";
            // 
            // DgvQuery2
            // 
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Gainsboro;
            this.DgvQuery2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.DgvQuery2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery2.AutoGenerateColumns = false;
            this.DgvQuery2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.DgvQuery2.DataSource = this.orderBindingSource;
            this.DgvQuery2.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery2.MultiSelect = false;
            this.DgvQuery2.Name = "DgvQuery2";
            this.DgvQuery2.ReadOnly = true;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery2.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.DgvQuery2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery2.Size = new System.Drawing.Size(992, 216);
            this.DgvQuery2.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "SenderAccount";
            this.dataGridViewTextBoxColumn6.HeaderText = "Счет плательщика";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ReceiverAccount";
            this.dataGridViewTextBoxColumn7.HeaderText = "Счет получателя";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "SenderAmount";
            this.dataGridViewTextBoxColumn8.HeaderText = "Сумма на счету плательщика (руб.)";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "ReceiverAmount";
            this.dataGridViewTextBoxColumn9.HeaderText = "Сумма на счету получателя (руб.)";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "AmountPayment";
            this.dataGridViewTextBoxColumn10.HeaderText = "Сумма платежа (руб.)";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // TbpQuery3
            // 
            this.TbpQuery3.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery3.Controls.Add(this.GbxQuery3);
            this.TbpQuery3.Controls.Add(this.groupBox6);
            this.TbpQuery3.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery3.Name = "TbpQuery3";
            this.TbpQuery3.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery3.Size = new System.Drawing.Size(1025, 448);
            this.TbpQuery3.TabIndex = 3;
            this.TbpQuery3.Text = "Запрос №3";
            // 
            // GbxQuery3
            // 
            this.GbxQuery3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxQuery3.Controls.Add(this.TbxQuery3);
            this.GbxQuery3.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxQuery3.ForeColor = System.Drawing.Color.White;
            this.GbxQuery3.Location = new System.Drawing.Point(16, 16);
            this.GbxQuery3.Name = "GbxQuery3";
            this.GbxQuery3.Size = new System.Drawing.Size(1000, 160);
            this.GbxQuery3.TabIndex = 3;
            this.GbxQuery3.TabStop = false;
            this.GbxQuery3.Text = " Отделение банка ";
            // 
            // TbxQuery3
            // 
            this.TbxQuery3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery3.BackColor = System.Drawing.Color.Gainsboro;
            this.TbxQuery3.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxQuery3.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery3.Multiline = true;
            this.TbxQuery3.Name = "TbxQuery3";
            this.TbxQuery3.ReadOnly = true;
            this.TbxQuery3.Size = new System.Drawing.Size(984, 128);
            this.TbxQuery3.TabIndex = 1;
            this.TbxQuery3.TabStop = false;
            this.TbxQuery3.Text = "3. Платежи с заданным диапазоном перечисляемой суммы\r\n\r\nЗаданный диапазон суммы: " +
    "значение";
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.DgvQuery3);
            this.groupBox6.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox6.ForeColor = System.Drawing.Color.White;
            this.groupBox6.Location = new System.Drawing.Point(8, 192);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1008, 248);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = " Платежи ";
            // 
            // DgvQuery3
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.Gainsboro;
            this.DgvQuery3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.DgvQuery3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery3.AutoGenerateColumns = false;
            this.DgvQuery3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15});
            this.DgvQuery3.DataSource = this.orderBindingSource;
            this.DgvQuery3.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery3.MultiSelect = false;
            this.DgvQuery3.Name = "DgvQuery3";
            this.DgvQuery3.ReadOnly = true;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery3.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.DgvQuery3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery3.Size = new System.Drawing.Size(992, 216);
            this.DgvQuery3.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "SenderAccount";
            this.dataGridViewTextBoxColumn11.HeaderText = "Счет плательщика";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "ReceiverAccount";
            this.dataGridViewTextBoxColumn12.HeaderText = "Счет получателя";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "SenderAmount";
            this.dataGridViewTextBoxColumn13.HeaderText = "Сумма на счету плательщика (руб.)";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "ReceiverAmount";
            this.dataGridViewTextBoxColumn14.HeaderText = "Сумма на счету получателя (руб.)";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "AmountPayment";
            this.dataGridViewTextBoxColumn15.HeaderText = "Сумма платежа (руб.)";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1033, 505);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.MnsMain);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.MnsMain;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание на 27.01.2022";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.TbpMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvMain)).EndInit();
            this.GbxOrders.ResumeLayout(false);
            this.GbxInfo.ResumeLayout(false);
            this.GbxInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).EndInit();
            this.TbpQuery1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery1)).EndInit();
            this.GbxQuery1.ResumeLayout(false);
            this.GbxQuery1.PerformLayout();
            this.TbpQuery2.ResumeLayout(false);
            this.GbxQuery2.ResumeLayout(false);
            this.GbxQuery2.PerformLayout();
            this.Gbx.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery2)).EndInit();
            this.TbpQuery3.ResumeLayout(false);
            this.GbxQuery3.ResumeLayout(false);
            this.GbxQuery3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem управлениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запросыToolStripMenuItem;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpMain;
        private System.Windows.Forms.GroupBox GbxInfo;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.GroupBox GbxOrders;
        private System.Windows.Forms.DataGridView DgvMain;
        private System.Windows.Forms.TextBox TbxName;
        private System.Windows.Forms.DataGridViewTextBoxColumn senderAccountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn receiverAccountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn senderAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn receiverAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountPaymentDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource orderBindingSource;
        private System.Windows.Forms.TabPage TbpQuery1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView DgvQuery1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.GroupBox GbxQuery1;
        private System.Windows.Forms.TextBox TbxQuery1;
        private System.Windows.Forms.TabPage TbpQuery2;
        private System.Windows.Forms.GroupBox GbxQuery2;
        private System.Windows.Forms.TextBox TbxQuery2;
        private System.Windows.Forms.GroupBox Gbx;
        private System.Windows.Forms.DataGridView DgvQuery2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.TabPage TbpQuery3;
        private System.Windows.Forms.GroupBox GbxQuery3;
        private System.Windows.Forms.TextBox TbxQuery3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridView DgvQuery3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
    }
}

