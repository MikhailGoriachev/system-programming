﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;     

using BankDepartmentClassLibrary.Utilities;     // утилиты библиотеки
using BankDepartmentWF.Utilities;               // утилиты 
using BankDepartmentClassLibrary.Models;        // модели


namespace BankDepartmentWF.Controllers
{
    // Класс Контроллер обработки по заданию
    public class TaskController
    {
        // отделение банка 
        private BankDepartmentModel _bankDepartment;

        public BankDepartmentModel BankDepartment
        {
            get => _bankDepartment;
            set => _bankDepartment = value;
        }


        // название файла для сохранения
        public string SaveFile { get; set; } = "./App_data/Orders.xml";


        #region Конструкторы

        // конструктор по умолчанию
        public TaskController()
        {
            _bankDepartment = new BankDepartmentModel($"Отделение №{Utils.GetRand(1, 50)}", new List<Order>().GetOrders());
        }

        // конструктор инициализирующий
        public TaskController(BankDepartmentModel bankDepartment)
        {
            _bankDepartment = bankDepartment;
        }

        #endregion

        #region Методы


        // добавление платежа
        public void Add(Order order) => _bankDepartment.Add(order);


        // удаление платежа
        public void Remove(Order order) => _bankDepartment.Remove(order);


        // удаление платежа по индексу
        public void RemoveAt(int index) => _bankDepartment.RemoveAt(index);


        // сериализация в формате XML
        public void SerializableXml()
        {
            using (FileStream fs = File.Create(SaveFile))
            {
                _bankDepartment.SerializableXml(fs);
            }
        }


        // десериализация в формате XML
        public void DeserializableXml()
        {
            using (FileStream fs = File.OpenRead(SaveFile))
            {
                _bankDepartment = BankDepartmentModel.DeserializableXml(fs);
            }
        }


        #region Запросы 

        // 1.	Платежи заданного плательщика, упорядочивание по получателю
        public List<Order> Query1(string sender) => _bankDepartment.Orders.Where(o => o.SenderAccount == sender).ToList();


        // 2.	Платежи заданному получателю, упорядочивание по убыванию суммы
        public List<Order> Query2(string receiver) => _bankDepartment.Orders.Where(o => o.ReceiverAccount == receiver).ToList();


        // 3.	Платежи с заданным диапазоном перечисляемой суммы
        public List<Order> Query3(int lo, int hi) => _bankDepartment.Orders.Where(o => o.AmountPayment >= lo && o.AmountPayment <= hi).ToList();


        #endregion

        #endregion
    }
}
